// Key Review Routes - Samsung FMS Portal
const express = require('express');
const KeyReview = require('../models/KeyReview');
const Project = require('../models/Project');
const { authenticateToken } = require('./auth');
const router = express.Router();

// Apply authentication middleware to all routes
router.use(authenticateToken);

// GET /api/keyreviews/project/:projectId - Get all key reviews for a project
router.get('/project/:projectId', async (req, res) => {
    try {
        const projectId = req.params.projectId;

        // Check if user has access to this project
        const hasAccess = await Project.hasAccess(projectId, req.user.username);
        if (!hasAccess) {
            return res.status(403).json({
                success: false,
                message: 'Access denied to this project'
            });
        }

        const reviews = await KeyReview.getHierarchicalData(projectId);

        res.json({
            success: true,
            reviews
        });
    } catch (error) {
        console.error('Get project key reviews error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to fetch key reviews'
        });
    }
});

// GET /api/keyreviews/group/:groupId - Get key reviews for a specific group
router.get('/group/:groupId', async (req, res) => {
    try {
        const groupId = req.params.groupId;

        // TODO: Add group access validation
        const reviews = await KeyReview.getByGroup(groupId);

        res.json({
            success: true,
            reviews
        });
    } catch (error) {
        console.error('Get group key reviews error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to fetch group key reviews'
        });
    }
});

// POST /api/keyreviews - Create or update a key review
router.post('/', async (req, res) => {
    try {
        const {
            fms_key_id,
            gm_id,
            group_id,
            target_val,
            ref1_val,
            ref2_val,
            ref3_val,
            comment,
            status,
            kona_ids,
            cl_numbers
        } = req.body;

        // Validate required fields
        if (!fms_key_id || !gm_id || !group_id) {
            return res.status(400).json({
                success: false,
                message: 'FMS Key ID, gm_id and group_id are required'
            });
        }

        // Only reviewers and admins can create/update reviews
        if (req.user.role === 'viewer') {
            return res.status(403).json({
                success: false,
                message: 'Viewers cannot modify key reviews'
            });
        }

        const reviewData = {
            fms_key_id,
            gm_id,
            group_id,
            target_val,
            ref1_val,
            ref2_val,
            ref3_val,
            comment,
            status: status || 'unreviewed',
            kona_ids,
            cl_numbers,
            reviewed_by_username: req.user.username
        };

        const review = await KeyReview.upsert(reviewData);

        res.json({
            success: true,
            message: 'Key review saved successfully',
            review
        });
    } catch (error) {
        console.error('Create/update key review error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to save key review'
        });
    }
});

// PUT /api/keyreviews/:reviewId/status - Update review status
router.put('/:reviewId/status', async (req, res) => {
    try {
        const reviewId = req.params.reviewId;
        const { status } = req.body;

        if (!status) {
            return res.status(400).json({
                success: false,
                message: 'Status is required'
            });
        }

        // Only reviewers and admins can update status
        if (req.user.role === 'viewer') {
            return res.status(403).json({
                success: false,
                message: 'Viewers cannot modify review status'
            });
        }

        await KeyReview.updateStatus(reviewId, status, req.user.username);

        res.json({
            success: true,
            message: 'Review status updated successfully'
        });
    } catch (error) {
        console.error('Update review status error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to update review status'
        });
    }
});

// PUT /api/keyreviews/:reviewId/values - Update review values
router.put('/:reviewId/values', async (req, res) => {
    try {
        const reviewId = req.params.reviewId;
        const { target_val, ref1_val, ref2_val, ref3_val } = req.body;

        // Only reviewers and admins can update values
        if (req.user.role === 'viewer') {
            return res.status(403).json({
                success: false,
                message: 'Viewers cannot modify review values'
            });
        }

        const values = { target_val, ref1_val, ref2_val, ref3_val };
        await KeyReview.updateValues(reviewId, values);

        res.json({
            success: true,
            message: 'Review values updated successfully'
        });
    } catch (error) {
        console.error('Update review values error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to update review values'
        });
    }
});

// PUT /api/keyreviews/:reviewId/comment - Update review comment
router.put('/:reviewId/comment', async (req, res) => {
    try {
        const reviewId = req.params.reviewId;
        const { comment } = req.body;

        // Only reviewers and admins can update comments
        if (req.user.role === 'viewer') {
            return res.status(403).json({
                success: false,
                message: 'Viewers cannot modify review comments'
            });
        }

        await KeyReview.updateComment(reviewId, comment, req.user.username);

        res.json({
            success: true,
            message: 'Review comment updated successfully'
        });
    } catch (error) {
        console.error('Update review comment error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to update review comment'
        });
    }
});

// PUT /api/keyreviews/:reviewId/kona - Update KONA IDs
router.put('/:reviewId/kona', async (req, res) => {
    try {
        const reviewId = req.params.reviewId;
        const { kona_ids } = req.body;

        // Only reviewers and admins can update KONA IDs
        if (req.user.role === 'viewer') {
            return res.status(403).json({
                success: false,
                message: 'Viewers cannot modify KONA IDs'
            });
        }

        await KeyReview.updateKonaIds(reviewId, kona_ids, req.user.username);

        res.json({
            success: true,
            message: 'KONA IDs updated successfully'
        });
    } catch (error) {
        console.error('Update KONA IDs error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to update KONA IDs'
        });
    }
});

// PUT /api/keyreviews/:reviewId/cl - Update CL numbers
router.put('/:reviewId/cl', async (req, res) => {
    try {
        const reviewId = req.params.reviewId;
        const { cl_numbers } = req.body;

        // Only reviewers and admins can update CL numbers
        if (req.user.role === 'viewer') {
            return res.status(403).json({
                success: false,
                message: 'Viewers cannot modify CL numbers'
            });
        }

        await KeyReview.updateClNumbers(reviewId, cl_numbers, req.user.username);

        res.json({
            success: true,
            message: 'CL numbers updated successfully'
        });
    } catch (error) {
        console.error('Update CL numbers error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to update CL numbers'
        });
    }
});

// DELETE /api/keyreviews/:reviewId - Delete a key review
router.delete('/:reviewId', async (req, res) => {
    try {
        const reviewId = req.params.reviewId;

        // Only admins can delete reviews
        if (req.user.role !== 'admin') {
            return res.status(403).json({
                success: false,
                message: 'Only admins can delete key reviews'
            });
        }

        await KeyReview.delete(reviewId);

        res.json({
            success: true,
            message: 'Key review deleted successfully'
        });
    } catch (error) {
        console.error('Delete key review error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to delete key review'
        });
    }
});

// GET /api/keyreviews/project/:projectId/stats - Get review statistics for project
router.get('/project/:projectId/stats', async (req, res) => {
    try {
        const projectId = req.params.projectId;

        // Check if user has access to this project
        const hasAccess = await Project.hasAccess(projectId, req.user.username);
        if (!hasAccess) {
            return res.status(403).json({
                success: false,
                message: 'Access denied to this project'
            });
        }

        const stats = await KeyReview.getProjectStats(projectId);

        res.json({
            success: true,
            stats
        });
    } catch (error) {
        console.error('Get project review stats error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to fetch review statistics'
        });
    }
});

// GET /api/keyreviews/project/:projectId/activity - Get recent review activity
router.get('/project/:projectId/activity', async (req, res) => {
    try {
        const projectId = req.params.projectId;
        const limit = parseInt(req.query.limit) || 10;

        // Check if user has access to this project
        const hasAccess = await Project.hasAccess(projectId, req.user.username);
        if (!hasAccess) {
            return res.status(403).json({
                success: false,
                message: 'Access denied to this project'
            });
        }

        const activity = await KeyReview.getRecentActivity(projectId, limit);

        res.json({
            success: true,
            activity
        });
    } catch (error) {
        console.error('Get project review activity error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to fetch review activity'
        });
    }
});

module.exports = router;
