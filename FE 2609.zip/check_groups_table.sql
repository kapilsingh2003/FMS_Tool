-- Check grps table structure and data

USE samsung_fms_portal;

-- Check table structure
DESCRIBE `grps`;

-- Check data in grps table
SELECT 'Groups table data:' as Info;
SELECT group_id, project_id, name, comparison_type FROM `grps`;

-- Check if data exists
SELECT 'Total groups:' as Info, COUNT(*) as count FROM `grps`;
