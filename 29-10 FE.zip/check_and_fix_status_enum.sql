-- Check current ENUM values for status column in Key_Reviews table
SHOW COLUMNS FROM `Key_Reviews` LIKE 'status';

-- If the output doesn't include 'value_changed', run this ALTER statement:
ALTER TABLE `Key_Reviews`
MODIFY COLUMN `status` ENUM('unreviewed', 'changes_made', 'pending_response', 'no_change_req', 'internal_discussion', 'changes_in_progress', 'value_changed') DEFAULT 'unreviewed';

-- Verify the change
SHOW COLUMNS FROM `Key_Reviews` LIKE 'status';


