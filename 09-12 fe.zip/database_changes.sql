-- Live database ALTERs for samsung_fms_portal
-- Run with: mysql -u root -proot < database_changes.sql

USE samsung_fms_portal;

-- 1) Branches: replace description with branch_path
SET @has_desc := (SELECT COUNT(*) FROM information_schema.COLUMNS 
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'Branches' AND COLUMN_NAME = 'description');
SET @has_branch_path := (SELECT COUNT(*) FROM information_schema.COLUMNS 
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'Branches' AND COLUMN_NAME = 'branch_path');

-- Drop description if exists
SET @sql := IF(@has_desc = 1, 'ALTER TABLE `Branches` DROP COLUMN `description`', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- Add branch_path if missing
SET @sql := IF(@has_branch_path = 0, 'ALTER TABLE `Branches` ADD COLUMN `branch_path` VARCHAR(500) AFTER `branch_type`', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- 2) Models: replace specifications with chipset
SET @has_specs := (SELECT COUNT(*) FROM information_schema.COLUMNS 
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'Models' AND COLUMN_NAME = 'specifications');
SET @has_chipset := (SELECT COUNT(*) FROM information_schema.COLUMNS 
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'Models' AND COLUMN_NAME = 'chipset');

-- Drop specifications if exists
SET @sql := IF(@has_specs = 1, 'ALTER TABLE `Models` DROP COLUMN `specifications`', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- Add chipset if missing
SET @sql := IF(@has_chipset = 0, 'ALTER TABLE `Models` ADD COLUMN `chipset` VARCHAR(100) AFTER `product_category`', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- Done
SELECT '✅ Database ALTERs applied (idempotent)' as Status;
-- Database Schema Changes for Work Machine
-- Run these queries to update your existing database with the latest changes

USE samsung_fms_portal;

-- =====================================================
-- CHANGE 1: Models Table - Replace specifications with chipset
-- =====================================================

-- Step 1: Add the new chipset column
ALTER TABLE `Models` 
ADD COLUMN chipset VARCHAR(100) AFTER product_category;

-- Step 2: Add index for chipset column
ALTER TABLE `Models` 
ADD INDEX idx_chipset (chipset);

-- Step 3: Drop the old specifications column
ALTER TABLE `Models` 
DROP COLUMN specifications;

-- Step 4: Update existing models with chipset data
UPDATE `Models` SET chipset = 'Tizen OS 7.0' WHERE model_name = 'M50D';
UPDATE `Models` SET chipset = 'Tizen OS 7.0' WHERE model_name = 'M70D';
UPDATE `Models` SET chipset = 'Tizen OS 8.0' WHERE model_name = 'M80D';
UPDATE `Models` SET chipset = 'Tizen OS 8.0' WHERE model_name = 'G95SD';
UPDATE `Models` SET chipset = 'Tizen OS 8.0' WHERE model_name = 'G97NC';
UPDATE `Models` SET chipset = 'Tizen OS 7.5' WHERE model_name = 'S90PC';
UPDATE `Models` SET chipset = 'CTV Platform 2024' WHERE model_name = 'CTV_2024_A';
UPDATE `Models` SET chipset = 'CTV Platform 2024' WHERE model_name = 'CTV_2024_B';
UPDATE `Models` SET chipset = 'ENT Platform 2025' WHERE model_name = 'ENT_55_2025';
UPDATE `Models` SET chipset = 'ENT Platform 2025' WHERE model_name = 'ENT_65_2025';

-- =====================================================
-- CHANGE 2: Branches Table - Replace description with branch_path
-- =====================================================

-- Step 1: Add the new branch_path column
ALTER TABLE `Branches` 
ADD COLUMN branch_path VARCHAR(500) AFTER branch_type;

-- Step 2: Add index for branch_path column
ALTER TABLE `Branches` 
ADD INDEX idx_branch_path (branch_path);

-- Step 3: Drop the old description column
ALTER TABLE `Branches` 
DROP COLUMN description;

-- Step 4: Update existing branches with branch_path data
UPDATE `Branches` SET branch_path = '/samsung/fms/trunk/2025/monitor_rc' WHERE branch_name = 'Trunk_25_MonitorRC_MP_Prj';
UPDATE `Branches` SET branch_path = '/samsung/fms/smartmonitor/2025/main_project' WHERE branch_name = 'SmartMonitor_2025_MP_Prj';
UPDATE `Branches` SET branch_path = '/samsung/fms/osu/2025/sm_tv_ready' WHERE branch_name = 'OSU_2025_SM_TV_Ready_MP_Prj';
UPDATE `Branches` SET branch_path = '/samsung/fms/features/gamebar/2025' WHERE branch_name = 'Feature_GameBar_2025';
UPDATE `Branches` SET branch_path = '/samsung/fms/ctv/2024/platform' WHERE branch_name = 'CTV_2024_Platform';
UPDATE `Branches` SET branch_path = '/samsung/fms/ent_tv/2025/base' WHERE branch_name = 'ENT_TV_2025_Base';

-- =====================================================
-- VERIFICATION QUERIES
-- =====================================================

-- Verify Models table changes
SELECT 'Models Table Structure:' as Info;
DESCRIBE `Models`;

-- Verify sample model data
SELECT 'Sample Models Data:' as Info;
SELECT model_name, product_category, chipset FROM `Models` LIMIT 5;

-- Verify Branches table changes
SELECT 'Branches Table Structure:' as Info;
DESCRIBE `Branches`;

-- Verify sample branch data
SELECT 'Sample Branches Data:' as Info;
SELECT branch_name, branch_type, branch_path FROM `Branches` LIMIT 5;

-- Display success message
SELECT 'Database schema changes applied successfully!' as Status;
SELECT 'Changes made:' as Summary;
SELECT '1. Models table: specifications → chipset' as Change1;
SELECT '2. Branches table: description → branch_path' as Change2;
