// Reference Data Routes - Samsung FMS Portal (Branches, Models, FMS Keys)
const express = require('express');
const Reference = require('../models/Reference');
const Group = require('../models/Group');
const { authenticateToken } = require('./auth');
const router = express.Router();

// GET /api/reference/branches - Get all branches (PUBLIC - no auth required)
router.get('/branches', async (req, res) => {
  try {
    const branches = await Reference.getAllBranches();

    res.json({
      success: true,
      branches
    });
  } catch (error) {
    console.error('Get branches error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch branches'
    });
  }
});

// GET /api/reference/branches/search - Search branches (PUBLIC - no auth required)
router.get('/branches/search', async (req, res) => {
  try {
    const { q } = req.query;

    if (!q || q.length < 2) {
      return res.json({
        success: true,
        branches: []
      });
    }

    const branches = await Reference.searchBranches(q);

    res.json({
      success: true,
      branches
    });
  } catch (error) {
    console.error('Search branches error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to search branches'
    });
  }
});

// GET /api/reference/models - Get all models (PUBLIC - no auth required)
router.get('/models', async (req, res) => {
  try {
    const { category } = req.query;

    let models;
    if (category) {
      models = await Reference.getModelsByCategory(category);
    } else {
      models = await Reference.getAllModels();
    }

    res.json({
      success: true,
      models
    });
  } catch (error) {
    console.error('Get models error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch models'
    });
  }
});

// GET /api/reference/models/search - Search models (PUBLIC - no auth required)
router.get('/models/search', async (req, res) => {
  try {
    const { q } = req.query;

    if (!q || q.length < 1) {
      return res.json({
        success: true,
        models: []
      });
    }

    const models = await Reference.searchModels(q);

    res.json({
      success: true,
      models
    });
  } catch (error) {
    console.error('Search models error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to search models'
    });
  }
});

// Apply authentication middleware to protected routes
router.use(authenticateToken);

// GET /api/reference/models/branch/:branchId - Get models available in specific branch
router.get('/models/branch/:branchId', async (req, res) => {
  try {
    const branchId = req.params.branchId;

    const models = await Reference.getModelsInBranch(branchId);

    res.json({
      success: true,
      models
    });
  } catch (error) {
    console.error('Get models in branch error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch models for branch'
    });
  }
});

// GET /api/reference/models/branch/:branchName/by-name - Get models by branch name
router.get('/models/branch/:branchName/by-name', async (req, res) => {
  try {
    const branchName = req.params.branchName;

    // Get branch by name first
    const branch = await Reference.getBranchByName(branchName);
    if (!branch) {
      return res.status(404).json({
        success: false,
        message: 'Branch not found'
      });
    }

    const models = await Reference.getModelsInBranch(branch.branch_id);

    res.json({
      success: true,
      models
    });
  } catch (error) {
    console.error('Get models by branch name error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch models for branch'
    });
  }
});

// GET /api/reference/fms-keys - Get all FMS keys
router.get('/fms-keys', async (req, res) => {
  try {
    const { with_differences, work_assignment } = req.query;

    let fmsKeys;
    if (with_differences === 'true') {
      fmsKeys = await Reference.getFMSKeysWithDifferences();
    } else if (work_assignment) {
      fmsKeys = await Reference.getFMSKeysByWorkAssignment(work_assignment);
    } else {
      fmsKeys = await Reference.getAllFMSKeys();
    }

    res.json({
      success: true,
      fmsKeys
    });
  } catch (error) {
    console.error('Get FMS keys error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch FMS keys'
    });
  }
});

// GET /api/reference/work-assignments - Get unique work assignments
router.get('/work-assignments', async (req, res) => {
  try {
    const workAssignments = await Reference.getWorkAssignments();

    res.json({
      success: true,
      workAssignments
    });
  } catch (error) {
    console.error('Get work assignments error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch work assignments'
    });
  }
});

// GET /api/reference/key-owners - Get unique key owners
router.get('/key-owners', async (req, res) => {
  try {
    const keyOwners = await Reference.getKeyOwners();

    res.json({
      success: true,
      keyOwners
    });
  } catch (error) {
    console.error('Get key owners error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch key owners'
    });
  }
});

// GET /api/reference/branch-model-matrix - Get branch-model compatibility matrix
router.get('/branch-model-matrix', async (req, res) => {
  try {
    const matrix = await Reference.getBranchModelMatrix();

    res.json({
      success: true,
      matrix
    });
  } catch (error) {
    console.error('Get branch-model matrix error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch branch-model matrix'
    });
  }
});

// POST /api/reference/validate-branch-model - Validate branch-model compatibility
router.post('/validate-branch-model', async (req, res) => {
  try {
    const { branchId, modelId } = req.body;

    if (!branchId || !modelId) {
      return res.status(400).json({
        success: false,
        message: 'Branch ID and Model ID are required'
      });
    }

    const isCompatible = await Reference.validateBranchModelCompatibility(branchId, modelId);

    res.json({
      success: true,
      isCompatible
    });
  } catch (error) {
    console.error('Validate branch-model compatibility error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to validate branch-model compatibility'
    });
  }
});

// GET /api/reference/stats - Get reference data statistics
router.get('/stats', async (req, res) => {
  try {
    const stats = await Reference.getStats();

    res.json({
      success: true,
      stats
    });
  } catch (error) {
    console.error('Get reference stats error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch reference statistics'
    });
  }
});

// GET /api/reference/group/:groupId/available-models - Get available models for group based on its branch configuration
router.get('/group/:groupId/available-models', async (req, res) => {
  try {
    const groupId = req.params.groupId;

    // Get group branches
    const branches = await Group.getBranches(groupId);
    if (branches.length === 0) {
      return res.json({
        success: true,
        models: []
      });
    }

    // Get models available in all configured branches (intersection)
    let availableModels = null;

    for (const branch of branches) {
      const branchModels = await Reference.getModelsInBranch(branch.branch_id);

      if (availableModels === null) {
        availableModels = branchModels;
      } else {
        // Find intersection of models (models available in all branches)
        const branchModelIds = new Set(branchModels.map(m => m.model_id));
        availableModels = availableModels.filter(m => branchModelIds.has(m.model_id));
      }
    }

    res.json({
      success: true,
      models: availableModels || []
    });
  } catch (error) {
    console.error('Get available models for group error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch available models for group'
    });
  }
});

module.exports = router;