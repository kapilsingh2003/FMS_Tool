// Project Routes - Samsung FMS Portal
const express = require('express');
const Project = require('../models/Project');
const Group = require('../models/Group');
const KeyReview = require('../models/KeyReview');
const { executeQuery } = require('../config/database');
const { authenticateToken } = require('./auth');
const router = express.Router();

// Apply authentication middleware to all routes
router.use(authenticateToken);

// GET /api/projects - Get projects for current user
router.get('/', async (req, res) => {
  try {
    console.log('Getting projects for user:', req.user.username);
    const projects = await Project.getByUser(req.user.username);
    console.log('Found projects:', projects.length);

    // Get statistics for each project
    const projectsWithStats = await Promise.all(
      projects.map(async (project) => {
        try {
          const stats = await Project.getStats(project.project_id);
          return {
            ...project,
            ...stats
          };
        } catch (statsError) {
          console.error('Error getting stats for project', project.project_id, ':', statsError);
          return {
            ...project,
            keyDifferences: 0,
            reviewedKeys: 0
          };
        }
      })
    );

    res.json({
      success: true,
      projects: projectsWithStats
    });
  } catch (error) {
    console.error('Get projects error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch projects',
      error: error.message
    });
  }
});

// GET /api/projects/:id - Get project details
router.get('/:id', async (req, res) => {
  try {
    const projectId = req.params.id;

    // Check if user has access to this project
    const hasAccess = await Project.hasAccess(projectId, req.user.username);
    if (!hasAccess) {
      return res.status(403).json({
        success: false,
        message: 'Access denied to this project'
      });
    }

    const project = await Project.getFullDetails(projectId);
    if (!project) {
      return res.status(404).json({
        success: false,
        message: 'Project not found'
      });
    }

    res.json({
      success: true,
      project
    });
  } catch (error) {
    console.error('Get project details error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch project details'
    });
  }
});

// POST /api/projects - Create new project
router.post('/', async (req, res) => {
  try {
    const { title, description, refreshSchedule, groups } = req.body;

    // Only admins can create projects
    if (req.user.role !== 'admin') {
      return res.status(403).json({
        success: false,
        message: 'Only admins can create projects'
      });
    }

    // Validate input
    if (!title) {
      return res.status(400).json({
        success: false,
        message: 'Project title is required'
      });
    }

    const projectData = {
      title: title.substring(0, 100), // Enforce character limit
      description: description ? description.substring(0, 500) : '',
      admin_username: req.user.username,
      refresh_schedule: refreshSchedule || 'Weekly'
    };

    const project = await Project.create(projectData);

    // Add creator as admin participant
    await Project.addParticipant(project.project_id, req.user.username, req.user.username, 'admin');

    // Create groups and their configurations if provided
    if (groups && Array.isArray(groups) && groups.length > 0) {
      for (const groupData of groups) {
        const { name, comparisonType, branches, models } = groupData;

        // Create the group
        const group = await Group.create({
          project_id: project.project_id,
          name,
          comparison_type: comparisonType
        });

        // Set branch configuration if provided
        if (branches && typeof branches === 'object') {
          await Group.setBranchConfig(group.group_id, branches);
        }

        // Add models to the group if provided
        if (models && Array.isArray(models) && models.length > 0) {
          for (const modelName of models) {
            await Group.addModel(group.group_id, modelName);
          }
        }
      }
    }

    // Get the complete project with all details
    const completeProject = await Project.getFullDetails(project.project_id);

    res.status(201).json({
      success: true,
      message: 'Project created successfully',
      data: completeProject
    });
  } catch (error) {
    console.error('Create project error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to create project'
    });
  }
});

// PUT /api/projects/:id - Update project
router.put('/:id', async (req, res) => {
  try {
    const projectId = req.params.id;
    const { title, description, refreshSchedule, groups } = req.body;

    // Check if user is admin of this project
    const project = await Project.findById(projectId);
    if (!project || project.admin_username !== req.user.username) {
      return res.status(403).json({
        success: false,
        message: 'Only project admin can update project'
      });
    }

    // Update basic project information
    const updateData = {
      title: title ? title.substring(0, 100) : project.title,
      description: description !== undefined ? description.substring(0, 500) : project.description,
      refresh_schedule: refreshSchedule || project.refresh_schedule
    };

    const updatedProject = await Project.update(projectId, updateData);

    // Update groups and their configurations if provided
    if (groups && Array.isArray(groups)) {
      // Delete existing groups and their mappings
      await executeQuery('DELETE FROM `Group_Branch_Model_Map` WHERE gb_id IN (SELECT gb_id FROM `Group_Branch_Mapping` WHERE group_id IN (SELECT group_id FROM `grps` WHERE project_id = ?))', [projectId]);
      await executeQuery('DELETE FROM `Group_Branch_Mapping` WHERE group_id IN (SELECT group_id FROM `grps` WHERE project_id = ?)', [projectId]);
      await executeQuery('DELETE FROM `grps` WHERE project_id = ?', [projectId]);

      // Create new groups
      for (const groupData of groups) {
        const { name, comparisonType, branches, models } = groupData;

        // Create the group
        const group = await Group.create({
          project_id: projectId,
          name,
          comparison_type: comparisonType
        });

        // Set branch configuration if provided
        if (branches && typeof branches === 'object') {
          await Group.setBranchConfig(group.group_id, branches);
        }

        // Add models to the group if provided
        if (models && Array.isArray(models) && models.length > 0) {
          for (const modelName of models) {
            await Group.addModel(group.group_id, modelName);
          }
        }
      }
    }

    // Get the complete updated project with all details
    const completeProject = await Project.getFullDetails(projectId);

    res.json({
      success: true,
      message: 'Project updated successfully',
      data: completeProject
    });
  } catch (error) {
    console.error('Update project error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to update project'
    });
  }
});

// DELETE /api/projects/:id - Delete project
router.delete('/:id', async (req, res) => {
  try {
    const projectId = req.params.id;

    // Check if user is admin of this project
    const project = await Project.findById(projectId);
    if (!project || project.admin_username !== req.user.username) {
      return res.status(403).json({
        success: false,
        message: 'Only project admin can delete project'
      });
    }

    await Project.delete(projectId);

    res.json({
      success: true,
      message: 'Project deleted successfully'
    });
  } catch (error) {
    console.error('Delete project error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to delete project'
    });
  }
});

// POST /api/projects/:id/participants - Add participant to project
router.post('/:id/participants', async (req, res) => {
  try {
    const projectId = req.params.id;
    const { username, role } = req.body;

    // Check if user is admin of this project
    const project = await Project.findById(projectId);
    if (!project || project.admin_username !== req.user.username) {
      return res.status(403).json({
        success: false,
        message: 'Only project admin can add participants'
      });
    }

    await Project.addParticipant(projectId, username, req.user.username, role || 'reviewer');

    res.json({
      success: true,
      message: 'Participant added successfully'
    });
  } catch (error) {
    console.error('Add participant error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to add participant'
    });
  }
});

// DELETE /api/projects/:id/participants/:username - Remove participant
router.delete('/:id/participants/:username', async (req, res) => {
  try {
    const projectId = req.params.id;
    const username = req.params.username;

    // Check if user is admin of this project
    const project = await Project.findById(projectId);
    if (!project || project.admin_username !== req.user.username) {
      return res.status(403).json({
        success: false,
        message: 'Only project admin can remove participants'
      });
    }

    await Project.removeParticipant(projectId, username);

    res.json({
      success: true,
      message: 'Participant removed successfully'
    });
  } catch (error) {
    console.error('Remove participant error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to remove participant'
    });
  }
});

// GET /api/projects/:id/groups - Get project groups
router.get('/:id/groups', async (req, res) => {
  try {
    const projectId = req.params.id;

    // Check access
    const hasAccess = await Project.hasAccess(projectId, req.user.username);
    if (!hasAccess) {
      return res.status(403).json({
        success: false,
        message: 'Access denied to this project'
      });
    }

    const groups = await Group.getByProject(projectId);

    res.json({
      success: true,
      groups
    });
  } catch (error) {
    console.error('Get project groups error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch project groups'
    });
  }
});

// POST /api/projects/:id/groups - Create group in project
router.post('/:id/groups', async (req, res) => {
  try {
    const projectId = req.params.id;
    const { name, comparison_type, branchConfig } = req.body;

    // Check if user is admin of this project
    const project = await Project.findById(projectId);
    if (!project || project.admin_username !== req.user.username) {
      return res.status(403).json({
        success: false,
        message: 'Only project admin can create groups'
      });
    }

    // Validate input
    if (!name || !comparison_type) {
      return res.status(400).json({
        success: false,
        message: 'Group name and comparison type are required'
      });
    }

    const groupData = {
      project_id: projectId,
      name,
      comparison_type
    };

    const group = await Group.create(groupData);

    // Set branch configuration if provided
    if (branchConfig) {
      await Group.setBranchConfig(group.group_id, branchConfig);
    }

    res.status(201).json({
      success: true,
      message: 'Group created successfully',
      group
    });
  } catch (error) {
    console.error('Create group error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to create group'
    });
  }
});

// GET /api/projects/:id/reviews - Get key reviews for project
router.get('/:id/reviews', async (req, res) => {
  try {
    const projectId = req.params.id;

    // Check access
    const hasAccess = await Project.hasAccess(projectId, req.user.username);
    if (!hasAccess) {
      return res.status(403).json({
        success: false,
        message: 'Access denied to this project'
      });
    }

    const reviews = await KeyReview.getHierarchicalData(projectId);

    res.json({
      success: true,
      reviews
    });
  } catch (error) {
    console.error('Get project reviews error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch project reviews'
    });
  }
});

// GET /api/projects/:id/stats - Get project statistics
router.get('/:id/stats', async (req, res) => {
  try {
    const projectId = req.params.id;

    // Check access
    const hasAccess = await Project.hasAccess(projectId, req.user.username);
    if (!hasAccess) {
      return res.status(403).json({
        success: false,
        message: 'Access denied to this project'
      });
    }

    const stats = await KeyReview.getProjectStats(projectId);

    res.json({
      success: true,
      stats
    });
  } catch (error) {
    console.error('Get project stats error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch project statistics'
    });
  }
});

module.exports = router;