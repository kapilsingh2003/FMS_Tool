// Key Review Model - Samsung FMS Portal
const { executeQuery } = require('../config/database');

class KeyReview {
  // Get all key reviews for a project
  static async getByProject(projectId) {
    const query = `
      SELECT 
        kr.*,
        fk.key_name,
        fk.work_assignment,
        fk.work_assignment_owner,
        fk.description,
        g.group_id,
        g.name as group_name,
        g.comparison_type,
        -- Target branch info
        target_gb.branch_role as target_branch_role,
        target_b.branch_name as target_branch_name,
        target_m.model_name as target_model_name,
        target_m.product_category as target_product_category,
        -- Reference 1 branch info
        ref1_gb.branch_role as ref1_branch_role,
        ref1_b.branch_name as ref1_branch_name,
        ref1_m.model_name as ref1_model_name,
        ref1_m.product_category as ref1_product_category,
        -- Reference 2 branch info
        ref2_gb.branch_role as ref2_branch_role,
        ref2_b.branch_name as ref2_branch_name,
        ref2_m.model_name as ref2_model_name,
        ref2_m.product_category as ref2_product_category,
        -- Reference 3 branch info
        ref3_gb.branch_role as ref3_branch_role,
        ref3_b.branch_name as ref3_branch_name,
        ref3_m.model_name as ref3_model_name,
        ref3_m.product_category as ref3_product_category
      FROM \`Key_Reviews\` kr
      JOIN \`FMS_Keys\` fk ON kr.fms_key_id = fk.fms_key_id
      JOIN \`grps\` g ON fk.fms_key_id IN (
        SELECT DISTINCT kr2.fms_key_id 
        FROM \`Key_Reviews\` kr2 
        JOIN \`Group_Branch_Model_Map\` gbm2 ON kr2.target_gbm_id = gbm2.gbm_id
        JOIN \`Group_Branch_Mapping\` gb2 ON gbm2.gb_id = gb2.gb_id
        WHERE gb2.group_id = g.group_id
      )
      -- Target branch joins
      JOIN \`Group_Branch_Model_Map\` target_gbm ON kr.target_gbm_id = target_gbm.gbm_id
      JOIN \`Models\` target_m ON target_gbm.model_id = target_m.model_id
      JOIN \`Group_Branch_Mapping\` target_gb ON target_gbm.gb_id = target_gb.gb_id
      JOIN \`Branches\` target_b ON target_gb.branch_id = target_b.branch_id
      -- Reference 1 branch joins
      JOIN \`Group_Branch_Model_Map\` ref1_gbm ON kr.ref1_gbm_id = ref1_gbm.gbm_id
      JOIN \`Models\` ref1_m ON ref1_gbm.model_id = ref1_m.model_id
      JOIN \`Group_Branch_Mapping\` ref1_gb ON ref1_gbm.gb_id = ref1_gb.gb_id
      JOIN \`Branches\` ref1_b ON ref1_gb.branch_id = ref1_b.branch_id
      -- Reference 2 branch joins
      JOIN \`Group_Branch_Model_Map\` ref2_gbm ON kr.ref2_gbm_id = ref2_gbm.gbm_id
      JOIN \`Models\` ref2_m ON ref2_gbm.model_id = ref2_m.model_id
      JOIN \`Group_Branch_Mapping\` ref2_gb ON ref2_gbm.gb_id = ref2_gb.gb_id
      JOIN \`Branches\` ref2_b ON ref2_gb.branch_id = ref2_b.branch_id
      -- Reference 3 branch joins
      JOIN \`Group_Branch_Model_Map\` ref3_gbm ON kr.ref3_gbm_id = ref3_gbm.gbm_id
      JOIN \`Models\` ref3_m ON ref3_gbm.model_id = ref3_m.model_id
      JOIN \`Group_Branch_Mapping\` ref3_gb ON ref3_gbm.gb_id = ref3_gb.gb_id
      JOIN \`Branches\` ref3_b ON ref3_gb.branch_id = ref3_b.branch_id
      WHERE g.project_id = ?
      ORDER BY fk.work_assignment, fk.key_name, g.group_id, g.name
    `;

    return await executeQuery(query, [projectId]);
  }

  // Get key reviews by group
  static async getByGroup(groupId) {
    const query = `
      SELECT 
        kr.*,
        fk.key_name,
        fk.work_assignment,
        fk.work_assignment_owner,
        fk.description,
        -- Target branch info
        target_m.model_name as target_model_name,
        target_m.product_category as target_product_category,
        -- Reference 1 branch info
        ref1_m.model_name as ref1_model_name,
        ref1_m.product_category as ref1_product_category,
        -- Reference 2 branch info
        ref2_m.model_name as ref2_model_name,
        ref2_m.product_category as ref2_product_category,
        -- Reference 3 branch info
        ref3_m.model_name as ref3_model_name,
        ref3_m.product_category as ref3_product_category
      FROM \`Key_Reviews\` kr
      JOIN \`FMS_Keys\` fk ON kr.fms_key_id = fk.fms_key_id
      -- Target branch joins
      JOIN \`Group_Branch_Model_Map\` target_gbmm ON kr.target_gbm_id = target_gbmm.gbm_id
      JOIN \`Models\` target_m ON target_gbmm.model_id = target_m.model_id
      JOIN \`Group_Branch_Mapping\` target_gbm ON target_gbmm.gb_id = target_gbm.gb_id
      -- Reference 1 branch joins
      JOIN \`Group_Branch_Model_Map\` ref1_gbmm ON kr.ref1_gbm_id = ref1_gbmm.gbm_id
      JOIN \`Models\` ref1_m ON ref1_gbmm.model_id = ref1_m.model_id
      JOIN \`Group_Branch_Mapping\` ref1_gbm ON ref1_gbmm.gb_id = ref1_gbm.gb_id
      -- Reference 2 branch joins
      JOIN \`Group_Branch_Model_Map\` ref2_gbmm ON kr.ref2_gbm_id = ref2_gbmm.gbm_id
      JOIN \`Models\` ref2_m ON ref2_gbmm.model_id = ref2_m.model_id
      JOIN \`Group_Branch_Mapping\` ref2_gbm ON ref2_gbmm.gb_id = ref2_gbm.gb_id
      -- Reference 3 branch joins
      JOIN \`Group_Branch_Model_Map\` ref3_gbmm ON kr.ref3_gbm_id = ref3_gbmm.gbm_id
      JOIN \`Models\` ref3_m ON ref3_gbmm.model_id = ref3_m.model_id
      JOIN \`Group_Branch_Mapping\` ref3_gbm ON ref3_gbmm.gb_id = ref3_gbm.gb_id
      WHERE target_gbm.group_id = ?
      ORDER BY fk.work_assignment, fk.key_name, target_m.model_name
    `;

    return await executeQuery(query, [groupId]);
  }

  // Get hierarchical key review data for project (organized by keys -> groups -> models)
  static async getHierarchicalData(projectId) {
    const reviews = await this.getByProject(projectId);

    // Organize data hierarchically: keys -> groups -> models with branch values
    const keyMap = new Map();

    reviews.forEach(review => {
      const keyId = review.fms_key_id;
      const groupId = review.group_id;

      // Initialize key if not exists
      if (!keyMap.has(keyId)) {
        keyMap.set(keyId, {
          fms_key_id: keyId,
          key_name: review.key_name,
          work_assignment: review.work_assignment,
          work_assignment_owner: review.work_assignment_owner,
          description: review.description,
          groups: new Map()
        });
      }

      const key = keyMap.get(keyId);

      // Initialize group if not exists
      if (!key.groups.has(groupId)) {
        key.groups.set(groupId, {
          group_id: groupId,
          group_name: review.group_name,
          comparison_type: review.comparison_type,
          models: new Map()
        });
      }

      const group = key.groups.get(groupId);

      // Create model display based on comparison type
      let modelDisplay = '';

      if (review.comparison_type === '2-way') {
        // For 2-way, only show target and ref1, ignore ref2 and ref3
        modelDisplay = `${review.target_model_name} | ${review.ref1_model_name}`;
      } else if (review.comparison_type === '3-way') {
        // For 3-way, show target, ref1, and ref2, ignore ref3
        modelDisplay = `${review.target_model_name} | ${review.ref1_model_name} | ${review.ref2_model_name}`;
      } else if (review.comparison_type === '4-way') {
        // For 4-way, show all models
        modelDisplay = `${review.target_model_name} | ${review.ref1_model_name} | ${review.ref2_model_name} | ${review.ref3_model_name}`;
      }

      // Use key_review_id as the unique key to ensure each review record is separate
      const uniqueKey = `${review.key_review_id}`;

      if (!group.models.has(uniqueKey)) {
        // Create values object based on comparison type
        let values = {
          target: review.target_val,
          ref1: review.ref1_val
        };

        if (review.comparison_type === '3-way' || review.comparison_type === '4-way') {
          values.ref2 = review.ref2_val;
        }

        if (review.comparison_type === '4-way') {
          values.ref3 = review.ref3_val;
        }

        group.models.set(uniqueKey, {
          model: modelDisplay,
          model_name: modelDisplay,
          ...values,
          comment: review.comment,
          status: review.status,
          kona_ids: review.kona_ids,
          cl_numbers: review.cl_numbers,
          reviewed_by_username: review.reviewed_by_username,
          last_modified: review.reviewed_at,
          key_review_id: review.key_review_id,
          // Store individual gbm_ids for updates
          target_gbm_id: review.target_gbm_id,
          ref1_gbm_id: review.ref1_gbm_id,
          ref2_gbm_id: review.ref2_gbm_id,
          ref3_gbm_id: review.ref3_gbm_id
        });
      }
    });

    // Convert Maps to Arrays for JSON serialization
    const result = Array.from(keyMap.values()).map(key => ({
      ...key,
      groups: Array.from(key.groups.values()).map(group => ({
        ...group,
        models: Array.from(group.models.values())
      }))
    }));

    return result;
  }

  // Create or update a key review
  static async upsert(reviewData) {
    const {
      fms_key_id,
      target_gbm_id,
      ref1_gbm_id,
      ref2_gbm_id,
      ref3_gbm_id,
      target_val,
      ref1_val,
      ref2_val,
      ref3_val,
      comment,
      status,
      kona_ids,
      cl_numbers,
      reviewed_by_username
    } = reviewData;

    const query = `
      INSERT INTO \`Key_Reviews\` (
        fms_key_id, target_gbm_id, ref1_gbm_id, ref2_gbm_id, ref3_gbm_id,
        target_val, ref1_val, ref2_val, ref3_val,
        comment, status, kona_ids, cl_numbers, reviewed_by_username
      )
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      ON DUPLICATE KEY UPDATE
        target_val = VALUES(target_val),
        ref1_val = VALUES(ref1_val),
        ref2_val = VALUES(ref2_val),
        ref3_val = VALUES(ref3_val),
        comment = VALUES(comment),
        status = VALUES(status),
        kona_ids = VALUES(kona_ids),
        cl_numbers = VALUES(cl_numbers),
        reviewed_by_username = VALUES(reviewed_by_username),
        reviewed_at = CURRENT_TIMESTAMP
    `;

    await executeQuery(query, [
      fms_key_id, target_gbm_id, ref1_gbm_id, ref2_gbm_id, ref3_gbm_id,
      target_val, ref1_val, ref2_val, ref3_val,
      comment, status, kona_ids, cl_numbers, reviewed_by_username
    ]);

    return this.findByKeyAndGBMs(fms_key_id, target_gbm_id, ref1_gbm_id, ref2_gbm_id, ref3_gbm_id);
  }

  // Find specific key review by multiple gbm_ids
  static async findByKeyAndGBMs(fmsKeyId, targetGbmId, ref1GbmId, ref2GbmId, ref3GbmId) {
    const query = `
      SELECT kr.*, fk.key_name
      FROM \`Key_Reviews\` kr
      JOIN \`FMS_Keys\` fk ON kr.fms_key_id = fk.fms_key_id
      WHERE kr.fms_key_id = ? AND kr.target_gbm_id = ? AND kr.ref1_gbm_id = ? AND kr.ref2_gbm_id = ? AND kr.ref3_gbm_id = ?
    `;

    const reviews = await executeQuery(query, [fmsKeyId, targetGbmId, ref1GbmId, ref2GbmId, ref3GbmId]);
    return reviews[0] || null;
  }

  // Find specific key review (legacy method for backward compatibility)
  static async findByKeyAndGBM(fmsKeyId, gbmId) {
    const query = `
      SELECT kr.*, fk.key_name
      FROM \`Key_Reviews\` kr
      JOIN \`FMS_Keys\` fk ON kr.fms_key_id = fk.fms_key_id
      WHERE kr.fms_key_id = ? AND (kr.target_gbm_id = ? OR kr.ref1_gbm_id = ? OR kr.ref2_gbm_id = ? OR kr.ref3_gbm_id = ?)
    `;

    const reviews = await executeQuery(query, [fmsKeyId, gbmId, gbmId, gbmId, gbmId]);
    return reviews[0] || null;
  }

  // Update review status
  static async updateStatus(keyReviewId, status, reviewedBy) {
    const query = `
      UPDATE \`Key_Reviews\`
      SET status = ?, reviewed_by_username = ?, reviewed_at = CURRENT_TIMESTAMP
      WHERE key_review_id = ?
    `;

    await executeQuery(query, [status, reviewedBy, keyReviewId]);
  }

  // Update review values
  static async updateValues(keyReviewId, values) {
    const { target_val, ref1_val, ref2_val, ref3_val } = values;

    const query = `
      UPDATE \`Key_Reviews\`
      SET target_val = ?, ref1_val = ?, ref2_val = ?, ref3_val = ?, reviewed_at = CURRENT_TIMESTAMP
      WHERE key_review_id = ?
    `;

    await executeQuery(query, [target_val, ref1_val, ref2_val, ref3_val, keyReviewId]);
  }

  // Add or update comment
  static async updateComment(keyReviewId, comment, reviewedBy) {
    const query = `
      UPDATE \`Key_Reviews\`
      SET comment = ?, reviewed_by_username = ?, reviewed_at = CURRENT_TIMESTAMP
      WHERE key_review_id = ?
    `;

    await executeQuery(query, [comment, reviewedBy, keyReviewId]);
  }

  // Update KONA IDs
  static async updateKonaIds(keyReviewId, konaIds, reviewedBy) {
    const query = `
      UPDATE \`Key_Reviews\`
      SET kona_ids = ?, reviewed_by_username = ?, reviewed_at = CURRENT_TIMESTAMP
      WHERE key_review_id = ?
    `;

    await executeQuery(query, [konaIds, reviewedBy, keyReviewId]);
  }

  // Update CL numbers
  static async updateClNumbers(keyReviewId, clNumbers, reviewedBy) {
    const query = `
      UPDATE \`Key_Reviews\`
      SET cl_numbers = ?, reviewed_by_username = ?, reviewed_at = CURRENT_TIMESTAMP
      WHERE key_review_id = ?
    `;

    await executeQuery(query, [clNumbers, reviewedBy, keyReviewId]);
  }

  // Get review statistics for a project
  static async getProjectStats(projectId) {
    const query = `
      SELECT 
        COUNT(DISTINCT kr.fms_key_id) as total_keys,
        COUNT(DISTINCT CASE WHEN kr.status = 'changes_made' THEN kr.fms_key_id END) as reviewed_keys,
        COUNT(DISTINCT CASE WHEN kr.status = 'pending_response' THEN kr.fms_key_id END) as pending_keys,
        COUNT(DISTINCT CASE WHEN kr.status = 'internal_discussion' THEN kr.fms_key_id END) as discussion_keys,
        COUNT(DISTINCT CASE WHEN kr.status = 'no_change_req' THEN kr.fms_key_id END) as no_change_keys
      FROM \`Key_Reviews\` kr
      JOIN \`Group_Branch_Model_Map\` target_gbmm ON kr.target_gbm_id = target_gbmm.gbm_id
      JOIN \`Group_Branch_Mapping\` target_gbm ON target_gbmm.gb_id = target_gbm.gb_id
      JOIN \`grps\` g ON target_gbm.group_id = g.group_id
      WHERE g.project_id = ?
    `;

    const stats = await executeQuery(query, [projectId]);
    return stats[0];
  }

  // Delete key review
  static async delete(keyReviewId) {
    const query = `DELETE FROM \`Key_Reviews\` WHERE key_review_id = ?`;
    await executeQuery(query, [keyReviewId]);
  }

  // Get recent review activity
  static async getRecentActivity(projectId, limit = 10) {
    const query = `
      SELECT 
        kr.reviewed_at as last_modified,
        kr.status,
        kr.comment,
        fk.key_name,
        target_m.model_name,
        g.name as group_name,
        u.name as reviewer_name
      FROM \`Key_Reviews\` kr
      JOIN \`FMS_Keys\` fk ON kr.fms_key_id = fk.fms_key_id
      JOIN \`Group_Branch_Model_Map\` target_gbmm ON kr.target_gbm_id = target_gbmm.gbm_id
      JOIN \`Models\` target_m ON target_gbmm.model_id = target_m.model_id
      JOIN \`Group_Branch_Mapping\` target_gbm ON target_gbmm.gb_id = target_gbm.gb_id
      JOIN \`grps\` g ON target_gbm.group_id = g.group_id
      LEFT JOIN \`Users\` u ON kr.reviewed_by_username = u.username
      WHERE g.project_id = ?
      ORDER BY kr.reviewed_at DESC
      LIMIT ?
    `;

    return await executeQuery(query, [projectId, limit]);
  }
}

module.exports = KeyReview;
