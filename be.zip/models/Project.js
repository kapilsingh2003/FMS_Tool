// Project Model - Samsung FMS Portal
const { executeQuery } = require('../config/database');

class Project {
    // Create a new project
    static async create(projectData) {
        const { title, description, admin_username, refresh_schedule } = projectData;

        const query = `
      INSERT INTO \`projects\` (title, description, admin_username, refresh_schedule)
      VALUES (?, ?, ?, ?)
    `;

        const result = await executeQuery(query, [title, description, admin_username, refresh_schedule]);
        return this.findById(result.insertId);
    }

    // Find project by ID
    static async findById(projectId) {
        const query = `
      SELECT p.*, u.name as admin_name
      FROM \`projects\` p
      JOIN \`users\` u ON p.admin_username = u.username
      WHERE p.project_id = ?
    `;

        const projects = await executeQuery(query, [projectId]);
        return projects[0] || null;
    }

    // Get all projects for a user
    static async getByUser(username) {
        const query = `
      SELECT DISTINCT p.*, u.name as admin_name
      FROM \`projects\` p
      JOIN \`users\` u ON p.admin_username = u.username
      LEFT JOIN \`project_participants\` pp ON p.project_id = pp.project_id
      WHERE p.admin_username = ? OR pp.user_username = ?
      ORDER BY p.created_date DESC
    `;

        return await executeQuery(query, [username, username]);
    }

    // Get project with full details (groups, models, etc.)
    static async getFullDetails(projectId) {
        const project = await this.findById(projectId);
        if (!project) return null;

        // Get participants
        const participants = await this.getParticipants(projectId);

        // Get groups with branches
        const groups = await this.getGroups(projectId);

        return {
            ...project,
            participants,
            groups
        };
    }

    // Get project participants
    static async getParticipants(projectId) {
        const query = `
      SELECT pp.*, u.name, u.email, u.team
      FROM \`project_participants\` pp
      JOIN \`users\` u ON pp.user_username = u.username
      WHERE pp.project_id = ?
      ORDER BY pp.participant_role, u.name
    `;

        return await executeQuery(query, [projectId]);
    }

    // Get project groups with branches and models
    static async getGroups(projectId) {
        const query = `
      SELECT g.*, 
        GROUP_CONCAT(
          CONCAT(gbm.branch_role, ':', b.branch_name)
          ORDER BY gbm.sort_order
        ) as branches
      FROM \`groups\` g
      LEFT JOIN \`group_branch_mapping\` gbm ON g.group_id = gbm.group_id
      LEFT JOIN \`branches\` b ON gbm.branch_id = b.branch_id
      WHERE g.project_id = ?
      GROUP BY g.group_id
      ORDER BY g.created_at
    `;

        const groups = await executeQuery(query, [projectId]);

        // Get models for each group
        for (let group of groups) {
            group.models = await this.getGroupModels(group.group_id);

            // Parse branches string into object
            if (group.branches) {
                const branchPairs = group.branches.split(',');
                group.branchConfig = {};
                branchPairs.forEach(pair => {
                    const [role, name] = pair.split(':');
                    group.branchConfig[role] = name;
                });
            }
            delete group.branches;
        }

        return groups;
    }

    // Get models for a specific group
    static async getGroupModels(groupId) {
        const query = `
      SELECT DISTINCT m.*
      FROM \`models\` m
      JOIN \`group_branch_model_map\` gbmm ON m.model_id = gbmm.model_id
      JOIN \`group_branch_mapping\` gbm ON gbmm.gb_id = gbm.gb_id
      WHERE gbm.group_id = ?
      ORDER BY m.model_name
    `;

        return await executeQuery(query, [groupId]);
    }

    // Add participant to project
    static async addParticipant(projectId, username, addedBy, role = 'reviewer') {
        const query = `
      INSERT INTO \`project_participants\` (project_id, user_username, added_by, participant_role)
      VALUES (?, ?, ?, ?)
      ON DUPLICATE KEY UPDATE participant_role = VALUES(participant_role)
    `;

        await executeQuery(query, [projectId, username, addedBy, role]);
    }

    // Remove participant from project
    static async removeParticipant(projectId, username) {
        const query = `
      DELETE FROM \`project_participants\`
      WHERE project_id = ? AND user_username = ?
    `;

        await executeQuery(query, [projectId, username]);
    }

    // Update project
    static async update(projectId, updateData) {
        const { title, description, refresh_schedule, status } = updateData;

        const query = `
      UPDATE \`projects\`
      SET title = ?, description = ?, refresh_schedule = ?, status = ?, updated_at = CURRENT_TIMESTAMP
      WHERE project_id = ?
    `;

        await executeQuery(query, [title, description, refresh_schedule, status, projectId]);
        return this.findById(projectId);
    }

    // Delete project
    static async delete(projectId) {
        const query = `DELETE FROM \`projects\` WHERE project_id = ?`;
        await executeQuery(query, [projectId]);
    }

    // Check if user has access to project
    static async hasAccess(projectId, username) {
        const query = `
      SELECT 1 FROM \`projects\` p
      LEFT JOIN \`project_participants\` pp ON p.project_id = pp.project_id
      WHERE p.project_id = ? AND (p.admin_username = ? OR pp.user_username = ?)
    `;

        const result = await executeQuery(query, [projectId, username, username]);
        return result.length > 0;
    }

    // Get project statistics
    static async getStats(projectId) {
        // Get total keys with differences
        const keyDifferencesQuery = `
      SELECT COUNT(DISTINCT fk.fms_key_id) as total_keys_with_differences
      FROM \`fms_keys\` fk
      WHERE fk.has_differences = true
    `;

        // Get reviewed keys count
        const reviewedKeysQuery = `
      SELECT COUNT(DISTINCT kr.fms_key_id) as reviewed_keys
      FROM \`key_reviews\` kr
      JOIN \`group_branch_model_map\` gbmm ON kr.gbm_id = gbmm.gbm_id
      JOIN \`group_branch_mapping\` gbm ON gbmm.gb_id = gbm.gb_id
      JOIN \`groups\` g ON gbm.group_id = g.group_id
      WHERE g.project_id = ? AND kr.status IN ('reviewed', 'dev_response')
    `;

        const [keyDiffs, reviewedKeys] = await Promise.all([
            executeQuery(keyDifferencesQuery),
            executeQuery(reviewedKeysQuery, [projectId])
        ]);

        return {
            keyDifferences: keyDiffs[0]?.total_keys_with_differences || 0,
            reviewedKeys: reviewedKeys[0]?.reviewed_keys || 0
        };
    }
}

module.exports = Project;
