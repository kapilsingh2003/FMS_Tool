// Test script to test project creation
const axios = require('axios');

async function testProjectCreation() {
    try {
        console.log('Testing Project Creation...');
        
        // First, login to get a token
        console.log('\n1. Logging in...');
        const loginResponse = await axios.post('http://localhost:5000/api/auth/login', {
            username: 'admin.john',
            password: 'password123'
        });
        
        if (!loginResponse.data.success) {
            console.error('Login failed:', loginResponse.data.message);
            return;
        }
        
        const token = loginResponse.data.token;
        console.log('✅ Login successful');
        
        // Test project creation
        console.log('\n2. Testing project creation...');
        const projectData = {
            title: 'Test Project',
            description: 'Test Description',
            refreshSchedule: 'daily',
            groups: [
                {
                    name: 'Test Group',
                    comparisonType: '2-way',
                    branches: {
                        target: '[TIZENPROD_Prj]',
                        reference1: '[Trunk_2025_MP_Prj]'
                    },
                    models: [
                        {
                            target: 'M80D',
                            reference1: 'M70D'
                        }
                    ]
                }
            ]
        };
        
        const createResponse = await axios.post('http://localhost:5000/api/projects', projectData, {
            headers: {
                'Authorization': `Bearer ${token}`,
                'Content-Type': 'application/json'
            }
        });
        
        console.log('Create Project Response:', createResponse.data);
        
        if (createResponse.data.success) {
            console.log('✅ Project created successfully');
            
            // Test getting the project
            console.log('\n3. Testing project retrieval...');
            const projectId = createResponse.data.project.project_id;
            const getResponse = await axios.get(`http://localhost:5000/api/projects/${projectId}`, {
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            });
            
            console.log('Get Project Response:', getResponse.data);
            console.log('✅ Project retrieved successfully');
        } else {
            console.error('❌ Project creation failed:', createResponse.data.message);
        }
        
    } catch (error) {
        console.error('❌ Error:', error.message);
        if (error.response) {
            console.error('Response Status:', error.response.status);
            console.error('Response Data:', error.response.data);
        }
    }
}

testProjectCreation();
