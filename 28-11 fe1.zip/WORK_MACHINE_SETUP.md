# Samsung FMS Portal - Work Machine Setup Guide

## Prerequisites

### 1. Install Required Software
- **Node.js** (v16 or higher): [Download from nodejs.org](https://nodejs.org/)
- **MySQL** (v8.0 or higher): [Download MySQL Community Server](https://dev.mysql.com/downloads/mysql/)
- **Git**: [Download from git-scm.com](https://git-scm.com/downloads)
- **Visual Studio Code** (recommended): [Download from code.visualstudio.com](https://code.visualstudio.com/)

### 2. Verify Installations
```bash
node --version    # Should be v16 or higher
npm --version     # Should be v8 or higher
mysql --version   # Should be v8.0 or higher
git --version     # Any recent version
```

## Database Setup

### 1. Start MySQL Service
```bash
# Windows (Command Prompt as Administrator)
net start mysql

# Or start MySQL through Services (services.msc)
```

### 2. Create Database
```bash
# Option A: Using MySQL Command Line
mysql -u root -p

# Option B: Using MySQL Workbench (GUI)
# Open MySQL Workbench and connect to your local instance
```

### 3. Run Database Schema
```sql
-- Copy and run the contents of revised_schema.sql
-- This will create the database and all tables with sample data
```

**Or from command line:**
```bash
mysql -u root -p < revised_schema.sql
```

### 4. Verify Database Creation
```sql
USE samsung_fms_portal;
SHOW TABLES;
SELECT COUNT(*) FROM Users;  -- Should return 4
SELECT COUNT(*) FROM Projects;  -- Should return 2
```

## Project Setup

### 1. Clone/Copy Project Files
```bash
# Create project directory
mkdir samsung-fms-portal
cd samsung-fms-portal

# Copy all project files to this directory
# Or clone from repository if available
```

### 2. Install Dependencies

#### Frontend Dependencies
```bash
# In project root directory
npm install
```

#### Backend Dependencies
```bash
# Navigate to backend directory
cd backend
npm install
cd ..
```

### 3. Configure Environment Variables

#### Create Backend Environment File
```bash
cd backend
copy env.example .env
# Edit .env file with your MySQL credentials
```

#### Update `.env` file:
```env
DB_HOST=localhost
DB_USER=root
DB_PASSWORD=your_mysql_password
DB_NAME=samsung_fms_portal
DB_PORT=3306
PORT=5000
NODE_ENV=development
JWT_SECRET=samsung_fms_portal_secret_key_2024_secure
JWT_EXPIRES_IN=24h
FRONTEND_URL=http://localhost:3000
DEBUG_MODE=true
```

## Running the Application

### Method 1: Start Both Servers Separately

#### Terminal 1 - Backend Server
```bash
cd backend
npm start
# Should see: "🚀 Server running on http://localhost:5000"
```

#### Terminal 2 - Frontend Server
```bash
# In project root
npm start
# Should open browser at http://localhost:3000
```

### Method 2: Quick Setup (if setup script works)
```bash
# In project root
npm run setup  # Installs all dependencies
npm start      # Starts frontend (backend needs separate terminal)
```

## Testing the Setup

### 1. Access the Application
- Open browser: `http://localhost:3000`
- Should see Samsung FMS Portal login page

### 2. Test Login
Use these test credentials:
```
Username: admin.john
Password: password123
```

### 3. Verify Functionality
- ✅ Login successful → Dashboard loads
- ✅ Can see sample projects
- ✅ Can click on projects → Key Review page loads
- ✅ Can edit values (simulated for now)

## Troubleshooting

### Common Issues

#### 1. MySQL Connection Error
```
Error: Access denied for user 'root'@'localhost'
```
**Solution:** Check MySQL credentials in `.env` file

#### 2. Port Already in Use
```
Error: listen EADDRINUSE :::5000
```
**Solution:** 
```bash
# Kill existing processes
taskkill /F /IM node.exe
# Or change PORT in .env file
```

#### 3. Frontend Won't Connect to Backend
```
Error: Network Error
```
**Solution:** Verify backend is running on port 5000

#### 4. Database Schema Errors
```
Error: Table doesn't exist
```
**Solution:** Re-run `revised_schema.sql`

### Reset Everything
```bash
# 1. Kill all node processes
taskkill /F /IM node.exe

# 2. Reset database
mysql -u root -p
DROP DATABASE samsung_fms_portal;
# Then re-run revised_schema.sql

# 3. Clear node modules and reinstall
rmdir /s node_modules
rmdir /s backend\node_modules
npm install
cd backend && npm install
```

## Development Workflow

### Daily Startup
1. Start MySQL service (if not auto-started)
2. Open two terminals:
   ```bash
   # Terminal 1
   cd backend
   npm start
   
   # Terminal 2 (project root)
   npm start
   ```
3. Open browser: `http://localhost:3000`

### Making Changes
- **Frontend**: Files auto-reload in browser
- **Backend**: Restart `npm start` in backend terminal
- **Database**: Changes persist automatically

## File Structure
```
samsung-fms-portal/
├── public/                 # React public files
├── src/                    # React source code
│   ├── components/         # React components
│   ├── contexts/          # React contexts
│   └── services/          # API services
├── backend/               # Node.js backend
│   ├── config/           # Database config
│   ├── models/           # Database models
│   ├── routes/           # API routes
│   ├── .env              # Environment variables
│   └── server.js         # Main server file
├── revised_schema.sql     # Database schema
├── package.json          # Frontend dependencies
└── WORK_MACHINE_SETUP.md # This file
```

## Support

### Default Credentials
```
Admin: admin.john / password123
Reviewer: reviewer.jane / password123
Reviewer: reviewer.mike / password123
Viewer: viewer.sarah / password123
```

### Key URLs
- Frontend: http://localhost:3000
- Backend API: http://localhost:5000
- MySQL: localhost:3306

### Important Notes
- Backend must be running before frontend
- MySQL service must be started
- Keep both terminals open during development
- Changes to `.env` require backend restart
