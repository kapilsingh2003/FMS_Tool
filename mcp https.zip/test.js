#!/usr/bin/env node
/**
 * Test script for FMS Portal MCP Server
 * 
 * This script tests the MCP server by:
 * 1. Connecting to the database directly to verify connectivity
 * 2. Running sample queries that the MCP tools would execute
 * 
 * Run with: node test.js
 */

import { createConnection } from './db.js';
import { config } from './config.js';

async function runTests() {
    console.log('🧪 FMS Portal MCP Server - Test Suite\n');
    console.log('=' .repeat(50));
    
    let db;
    let allPassed = true;
    let sampleKeys = [];
    
    try {
        // Test 1: Database Connection
        console.log('\n📋 Test 1: Database Connection');
        console.log('-'.repeat(30));
        
        try {
            db = await createConnection();
            console.log('✅ Successfully connected to database');
            console.log(`   Host: ${config.db.host}:${config.db.port}`);
            console.log(`   Database: ${config.db.database}`);
        } catch (error) {
            console.log('❌ Failed to connect to database');
            console.log(`   Error: ${error.message}`);
            allPassed = false;
            return;
        }
        
        // Test 2: Project Exists
        console.log('\n📋 Test 2: Project Configuration');
        console.log('-'.repeat(30));
        
        const [projects] = await db.execute(
            'SELECT project_id, title, description FROM Projects WHERE project_id = ?',
            [config.projectId]
        );
        
        if (projects.length > 0) {
            console.log('✅ Configured project exists');
            console.log(`   Project ID: ${projects[0].project_id}`);
            console.log(`   Title: ${projects[0].title}`);
            console.log(`   Description: ${projects[0].description || 'N/A'}`);
        } else {
            console.log('❌ Configured project not found');
            console.log(`   Project ID ${config.projectId} does not exist in the database`);
            console.log('   Please update MCP_PROJECT_ID in config.js or .env');
            allPassed = false;
        }
        
        // Test 3: Groups in Project
        console.log('\n📋 Test 3: Groups in Project');
        console.log('-'.repeat(30));
        
        const [groups] = await db.execute(`
            SELECT g.group_id, g.name, g.comparison_type,
                target_b.branch_name as target_branch,
                ref1_b.branch_name as ref1_branch
            FROM grps g
            LEFT JOIN Branches target_b ON g.target_branch_id = target_b.branch_id
            LEFT JOIN Branches ref1_b ON g.ref1_branch_id = ref1_b.branch_id
            WHERE g.project_id = ?
            LIMIT 5
        `, [config.projectId]);
        
        if (groups.length > 0) {
            console.log(`✅ Found ${groups.length} group(s) in project`);
            for (const group of groups) {
                console.log(`   - ${group.name} (${group.comparison_type})`);
                console.log(`     Branches: ${group.target_branch} vs ${group.ref1_branch}`);
            }
        } else {
            console.log('⚠️ No groups found in project');
            console.log('   The project may not have any configured groups yet');
        }
        
        // Test 4: Key Reviews in Project
        console.log('\n📋 Test 4: Key Reviews in Project');
        console.log('-'.repeat(30));
        
        const [keyCount] = await db.execute(`
            SELECT COUNT(DISTINCT kr.fms_key_id) as count
            FROM Key_Reviews kr
            JOIN grps g ON kr.group_id = g.group_id
            WHERE g.project_id = ?
        `, [config.projectId]);
        
        if (keyCount[0].count > 0) {
            console.log(`✅ Found ${keyCount[0].count} unique FMS key(s) with reviews`);
        } else {
            console.log('⚠️ No key reviews found in project');
            console.log('   The project may not have any key review data yet');
        }
        
        // Test 5: Sample Key Query (simulating get_fms_key_values)
        console.log('\n📋 Test 5: Sample Key Query');
        console.log('-'.repeat(30));
        
        [sampleKeys] = await db.execute(`
            SELECT 
                fk.key_name,
                kr.target_val,
                kr.ref1_val,
                kr.status,
                target_m.model_name as target_model,
                ref1_m.model_name as ref1_model
            FROM Key_Reviews kr
            JOIN FMS_Keys fk ON kr.fms_key_id = fk.fms_key_id
            JOIN grps g ON kr.group_id = g.group_id
            JOIN Group_Model_Mapping gmm ON kr.gm_id = gmm.gm_id
            LEFT JOIN Models target_m ON gmm.target_model_id = target_m.model_id
            LEFT JOIN Models ref1_m ON gmm.ref1_model_id = ref1_m.model_id
            WHERE g.project_id = ?
            LIMIT 3
        `, [config.projectId]);
        
        if (sampleKeys.length > 0) {
            console.log(`✅ Sample query returned ${sampleKeys.length} result(s)`);
            console.log('\n   Sample data your chatbot can query:');
            for (const key of sampleKeys) {
                console.log(`   📌 Key: ${key.key_name}`);
                console.log(`      ${key.target_model}: ${key.target_val || 'N/A'}`);
                console.log(`      ${key.ref1_model}: ${key.ref1_val || 'N/A'}`);
                console.log(`      Status: ${key.status}`);
                console.log('');
            }
        } else {
            console.log('⚠️ No sample data available');
        }
        
        // Test 6: Comments Check
        console.log('\n📋 Test 6: Comments in Project');
        console.log('-'.repeat(30));
        
        const [commentCount] = await db.execute(`
            SELECT COUNT(*) as count
            FROM Comments c
            JOIN Key_Reviews kr ON c.key_review_id = kr.key_review_id
            JOIN grps g ON kr.group_id = g.group_id
            WHERE g.project_id = ?
        `, [config.projectId]);
        
        if (commentCount[0].count > 0) {
            console.log(`✅ Found ${commentCount[0].count} comment(s) in project`);
        } else {
            console.log('ℹ️ No comments found in project');
        }
        
    } catch (error) {
        console.log('\n❌ Test Error:', error.message);
        allPassed = false;
    } finally {
        if (db) {
            await db.end();
        }
    }
    
    // Summary
    console.log('\n' + '='.repeat(50));
    console.log('📊 Test Summary');
    console.log('='.repeat(50));
    
    if (allPassed) {
        console.log('\n✅ All tests passed! The MCP server should work correctly.');
        console.log('\n🚀 Next steps:');
        console.log('   1. Start the MCP server: npm start');
        console.log('   2. Configure your MCP client (Claude Desktop, etc.)');
        console.log('   3. Try asking: "What FMS keys are in the project?"');
        
        if (sampleKeys && sampleKeys.length > 0) {
            console.log(`\n💡 Example query you can try:`);
            console.log(`   "What are the values of ${sampleKeys[0].key_name}?"`);
        }
    } else {
        console.log('\n⚠️ Some tests failed. Please check the errors above.');
        console.log('\n🔧 Common fixes:');
        console.log('   - Ensure MySQL is running');
        console.log('   - Check database credentials in config.js');
        console.log('   - Verify the project ID exists');
    }
    
    console.log('\n');
}

// Run tests
runTests().catch(console.error);
