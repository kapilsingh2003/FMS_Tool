/**
 * Database Connection Module for FMS Portal MCP Server
 * 
 * Uses the same database configuration as the main backend.
 */

import mysql from 'mysql2/promise';
import { config } from './config.js';

/**
 * Create a new database connection
 * Each tool call gets its own connection to avoid conflicts
 */
export async function createConnection() {
    const connection = await mysql.createConnection({
        host: config.db.host,
        port: config.db.port,
        user: config.db.user,
        password: config.db.password,
        database: config.db.database,
    });
    
    return connection;
}

/**
 * Execute a query with error handling
 */
export async function executeQuery(connection, query, params = []) {
    try {
        const [rows] = await connection.execute(query, params);
        return rows;
    } catch (error) {
        console.error('Database query error:', error.message);
        throw error;
    }
}
