-- Update comparison_type ENUM to include the correct format
ALTER TABLE `grps` 
MODIFY COLUMN `comparison_type` ENUM('2-way', '3-way', '4-way', '2-way-vs-2-way') NOT NULL;
