// Project Model - Samsung FMS Portal
const { executeQuery } = require('../config/database');

class Project {
  // Create a new project
  static async create(projectData) {
    const { title, description, admin_username, refresh_schedule } = projectData;

    const query = `
      INSERT INTO \`Projects\` (title, description, admin_username, refresh_schedule)
      VALUES (?, ?, ?, ?)
    `;

    const result = await executeQuery(query, [title, description, admin_username, refresh_schedule]);
    return this.findById(result.insertId);
  }

  // Find project by ID
  static async findById(projectId) {
    const query = `
      SELECT p.*, u.name as admin_name
      FROM \`Projects\` p
      JOIN \`Users\` u ON p.admin_username = u.username
      WHERE p.project_id = ?
    `;

    const projects = await executeQuery(query, [projectId]);
    return projects[0] || null;
  }

  // Get all projects for a user
  static async getByUser(username) {
    const query = `
      SELECT DISTINCT p.*, u.name as admin_name
      FROM \`Projects\` p
      JOIN \`Users\` u ON p.admin_username = u.username
      LEFT JOIN \`Project_Participants\` pp ON p.project_id = pp.project_id
      WHERE p.admin_username = ? OR pp.user_username = ?
      ORDER BY p.created_date DESC
    `;

    return await executeQuery(query, [username, username]);
  }

  // Get project with full details (groups, models, etc.)
  static async getFullDetails(projectId) {
    const project = await this.findById(projectId);
    if (!project) return null;

    // Get participants
    const participants = await this.getParticipants(projectId);

    // Get groups with branches
    const groups = await this.getGroups(projectId);

    return {
      ...project,
      participants,
      groups
    };
  }

  // Get project participants
  static async getParticipants(projectId) {
    const query = `
      SELECT pp.*, u.name, u.email, u.team
      FROM \`Project_Participants\` pp
      JOIN \`Users\` u ON pp.user_username = u.username
      WHERE pp.project_id = ?
      ORDER BY pp.participant_role, u.name
    `;

    return await executeQuery(query, [projectId]);
  }

  // Get project groups with branches and models
  static async getGroups(projectId) {
    const query = `
      SELECT g.*,
        target_b.branch_name as target_branch_name,
        ref1_b.branch_name as ref1_branch_name,
        ref2_b.branch_name as ref2_branch_name,
        ref3_b.branch_name as ref3_branch_name
      FROM \`grps\` g
      LEFT JOIN \`Branches\` target_b ON g.target_branch_id = target_b.branch_id
      LEFT JOIN \`Branches\` ref1_b ON g.ref1_branch_id = ref1_b.branch_id
      LEFT JOIN \`Branches\` ref2_b ON g.ref2_branch_id = ref2_b.branch_id
      LEFT JOIN \`Branches\` ref3_b ON g.ref3_branch_id = ref3_b.branch_id
      WHERE g.project_id = ?
      ORDER BY g.created_at
    `;

    const groups = await executeQuery(query, [projectId]);

    // Get model combinations for each group
    for (let group of groups) {
      group.models = await this.getGroupModelCombinations(group.group_id);

      // Create branch configuration object
      group.branchConfig = {};
      group.branches = {}; // Create branches object for frontend compatibility

      if (group.target_branch_name) {
        group.branchConfig.target = group.target_branch_name;
        group.branches.target = group.target_branch_name;
      }
      if (group.ref1_branch_name) {
        group.branchConfig.reference1 = group.ref1_branch_name;
        group.branches.reference1 = group.ref1_branch_name;
      }
      if (group.ref2_branch_name) {
        group.branchConfig.reference2 = group.ref2_branch_name;
        group.branches.reference2 = group.ref2_branch_name;
      }
      if (group.ref3_branch_name) {
        group.branchConfig.reference3 = group.ref3_branch_name;
        group.branches.reference3 = group.ref3_branch_name;
      }
    }

    return groups;
  }

  // Get models for a specific group
  static async getGroupModels(groupId) {
    const query = `
      SELECT DISTINCT m.*
      FROM \`Models\` m
      JOIN \`Group_Model_Mapping\` gmm 
        ON m.model_id IN (gmm.target_model_id, gmm.ref1_model_id, gmm.ref2_model_id, gmm.ref3_model_id)
      WHERE gmm.group_id = ?
      ORDER BY m.model_name
    `;

    return await executeQuery(query, [groupId]);
  }

  // Get model combinations for a specific group (each row is a combination)
  static async getGroupModelCombinations(groupId) {
    const query = `
      SELECT 
        gmm.gm_id,
        target_m.model_name AS target,
        ref1_m.model_name AS reference,
        ref1_m.model_name AS reference1,
        ref2_m.model_name AS reference2,
        ref3_m.model_name AS reference3,
        target_m.model_name AS target1,
        ref2_m.model_name AS target2
      FROM \`Group_Model_Mapping\` gmm
      LEFT JOIN \`Models\` target_m ON gmm.target_model_id = target_m.model_id
      LEFT JOIN \`Models\` ref1_m ON gmm.ref1_model_id = ref1_m.model_id
      LEFT JOIN \`Models\` ref2_m ON gmm.ref2_model_id = ref2_m.model_id
      LEFT JOIN \`Models\` ref3_m ON gmm.ref3_model_id = ref3_m.model_id
      WHERE gmm.group_id = ?
      ORDER BY gmm.gm_id
    `;

    return await executeQuery(query, [groupId]);
  }

  // Add participant to project
  static async addParticipant(projectId, username, addedBy, role = 'reviewer') {
    const query = `
      INSERT INTO \`Project_Participants\` (project_id, user_username, added_by, participant_role)
      VALUES (?, ?, ?, ?)
      ON DUPLICATE KEY UPDATE participant_role = VALUES(participant_role)
    `;

    await executeQuery(query, [projectId, username, addedBy, role]);
  }

  // Remove participant from project
  static async removeParticipant(projectId, username) {
    const query = `
        DELETE FROM \`Project_Participants\`
      WHERE project_id = ? AND user_username = ?
    `;

    await executeQuery(query, [projectId, username]);
  }

  // Update project
  static async update(projectId, updateData) {
    const { title, description, refresh_schedule, status } = updateData;

    const query = `
      UPDATE \`Projects\`
      SET title = ?, description = ?, refresh_schedule = ?, status = ?, updated_at = CURRENT_TIMESTAMP
      WHERE project_id = ?
    `;

    // Convert undefined values to null to avoid SQL binding errors
    const safeTitle = title ?? null;
    const safeDescription = description ?? null;
    const safeRefreshSchedule = refresh_schedule ?? null;
    const safeStatus = status ?? null;

    await executeQuery(query, [safeTitle, safeDescription, safeRefreshSchedule, safeStatus, projectId]);
    return this.findById(projectId);
  }

  // Delete project
  static async delete(projectId) {
    const query = `DELETE FROM \`Projects\` WHERE project_id = ?`;
    await executeQuery(query, [projectId]);
  }

  // Check if user has access to project
  static async hasAccess(projectId, username) {
    const query = `
      SELECT 1 FROM \`Projects\` p
      LEFT JOIN \`Project_Participants\` pp ON p.project_id = pp.project_id
      WHERE p.project_id = ? AND (p.admin_username = ? OR pp.user_username = ?)
    `;

    const result = await executeQuery(query, [projectId, username, username]);
    return result.length > 0;
  }

  // Get project statistics
  static async getStats(projectId) {
    try {
      // Get total keys with differences
      const keyDifferencesQuery = `
        SELECT COUNT(DISTINCT fk.fms_key_id) as total_keys_with_differences
        FROM \`FMS_Keys\` fk
        WHERE fk.has_differences = true
      `;

      // Get reviewed keys count (simplified for now)
      const reviewedKeysQuery = `
        SELECT COUNT(DISTINCT kr.fms_key_id) as reviewed_keys
        FROM \`Key_Reviews\` kr
        WHERE kr.status IN ('changes_made', 'no_change_req', 'internal_discussion')
      `;

      const [keyDiffs, reviewedKeys] = await Promise.all([
        executeQuery(keyDifferencesQuery),
        executeQuery(reviewedKeysQuery)
      ]);

      return {
        keyDifferences: keyDiffs[0]?.total_keys_with_differences || 0,
        reviewedKeys: reviewedKeys[0]?.reviewed_keys || 0
      };
    } catch (error) {
      console.error('Error getting project stats:', error);
      // Return default stats if there's an error
      return {
        keyDifferences: 0,
        reviewedKeys: 0
      };
    }
  }

  // Create a group with the new structure (grps table with branch data)
  static async createGroup(groupData) {
    const { project_id, name, comparison_type, target_branch_id, ref1_branch_id, ref2_branch_id, ref3_branch_id } = groupData;

    const query = `
      INSERT INTO \`grps\` (project_id, name, comparison_type, target_branch_id, ref1_branch_id, ref2_branch_id, ref3_branch_id)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `;

    const result = await executeQuery(query, [
      project_id, name, comparison_type, target_branch_id, ref1_branch_id, ref2_branch_id, ref3_branch_id
    ]);

    return this.getGroupById(result.insertId);
  }

  // Get group by ID
  static async getGroupById(groupId) {
    const query = `
      SELECT g.*,
        target_b.branch_name as target_branch_name,
        ref1_b.branch_name as ref1_branch_name,
        ref2_b.branch_name as ref2_branch_name,
        ref3_b.branch_name as ref3_branch_name
      FROM \`grps\` g
      LEFT JOIN \`Branches\` target_b ON g.target_branch_id = target_b.branch_id
      LEFT JOIN \`Branches\` ref1_b ON g.ref1_branch_id = ref1_b.branch_id
      LEFT JOIN \`Branches\` ref2_b ON g.ref2_branch_id = ref2_b.branch_id
      LEFT JOIN \`Branches\` ref3_b ON g.ref3_branch_id = ref3_b.branch_id
      WHERE g.group_id = ?
    `;

    const groups = await executeQuery(query, [groupId]);
    return groups[0] || null;
  }

  // Add model to group
  static async addModelToGroup(groupId, modelData) {
    // Handle both string model names and model objects
    let targetModelName, ref1ModelName, ref2ModelName, ref3ModelName;

    if (typeof modelData === 'string') {
      // Legacy support for string model names
      targetModelName = modelData;
      ref1ModelName = null;
      ref2ModelName = null;
      ref3ModelName = null;
    } else if (typeof modelData === 'object' && modelData !== null) {
      // Handle model object with different roles
      targetModelName = modelData.target || modelData.model_name;
      // Support 2-way key 'reference' and 3+/4-way 'reference1'
      ref1ModelName = modelData.reference || modelData.reference1 || modelData.ref1 || null;
      ref2ModelName = modelData.reference2 || modelData.ref2 || null;
      ref3ModelName = modelData.reference3 || modelData.ref3 || null;
    } else {
      throw new Error('Invalid model data format');
    }

    // Get model IDs for each role
    const getModelId = async (modelName) => {
      if (!modelName) return null;
      const modelQuery = 'SELECT model_id FROM Models WHERE model_name = ?';
      const modelResult = await executeQuery(modelQuery, [modelName]);
      return modelResult.length > 0 ? modelResult[0].model_id : null;
    };

    const targetModelId = await getModelId(targetModelName);
    const ref1ModelId = await getModelId(ref1ModelName);
    const ref2ModelId = await getModelId(ref2ModelName);
    const ref3ModelId = await getModelId(ref3ModelName);

    // Validate that at least the target model exists
    if (!targetModelId) {
      throw new Error(`Target model ${targetModelName} not found`);
    }

    // Insert the model mapping (ignore duplicates by unique key)
    const insertQuery = `
      INSERT INTO \`Group_Model_Mapping\` (group_id, target_model_id, ref1_model_id, ref2_model_id, ref3_model_id)
      VALUES (?, ?, ?, ?, ?)
      ON DUPLICATE KEY UPDATE group_id = group_id
    `;

    await executeQuery(insertQuery, [groupId, targetModelId, ref1ModelId, ref2ModelId, ref3ModelId]);
  }
}

module.exports = Project;
