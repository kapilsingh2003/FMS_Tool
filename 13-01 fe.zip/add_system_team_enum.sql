-- Add 'System' to the team ENUM in Users table
-- This allows the 'system' user to have a valid team value

USE samsung_fms_portal;

-- Alter the Users table to add 'System' to the team ENUM
   

-- Verify the change
SHOW COLUMNS FROM `Users` LIKE 'team';

SELECT 'System team ENUM added successfully!' as Status;


