-- Fix Key_Reviews status ENUM step by step to avoid truncation errors

USE samsung_fms_portal;

-- Step 1: First, expand the ENUM to include all old and new values
ALTER TABLE `Key_Reviews` 
MODIFY COLUMN status ENUM('reviewed', 'pending', 'needs_discussion', 'unreviewed', 'changes_made', 'pending_response', 'no_change_req', 'internal_discussion') DEFAULT 'unreviewed';

-- Step 2: Update existing status values to new ones
UPDATE `Key_Reviews` SET status = 'changes_made' WHERE status = 'reviewed';
UPDATE `Key_Reviews` SET status = 'pending_response' WHERE status = 'pending';
UPDATE `Key_Reviews` SET status = 'internal_discussion' WHERE status = 'needs_discussion';

-- Step 3: Now remove the old values from ENUM
ALTER TABLE `Key_Reviews` 
MODIFY COLUMN status ENUM('unreviewed', 'changes_made', 'pending_response', 'no_change_req', 'internal_discussion') DEFAULT 'unreviewed';

-- Step 4: Check final status values
SELECT 'Final status values:' as Info;
SELECT status, COUNT(*) as count FROM `Key_Reviews` GROUP BY status;

SELECT '✅ Successfully updated Key_Reviews status ENUM!' as Status;
