import mysql.connector
import pandas as pd
import json

# Database connection details
db_config = {
    'host':'localhost',
    'database':'samsung_fms_portal',
    'user':'root',
    'password':'root'
}

df = pd.read_csv(r'C:\Users\kapil\Downloads\sample key review data\sample key review data\FMS_Model.csv')
df["categories"] = df["categories"].str.replace("\n", " ",regex=True)
model_name = list(df['name'])
chipset = list(df['chipset'])
product_category = list(df['categories'])
# json_data = df['chipset'].apply(lambda x: json.dumps({'chipset': x}))
# specifications = json_data.tolist()

# Default values for other attributes
models_default_values = {
    'model_id': None,
    'is_active': True 
}

# Connect to the database
conn = mysql.connector.connect(**db_config)
cursor = conn.cursor()

# Insert data into the Models table
for name, chip, pcat in zip(model_name, chipset, product_category):
    query = """
    INSERT INTO Models (model_name, product_category, chipset, is_active)
    VALUES (%s, %s, %s, %s)
    """
    values = (name, pcat, chip, models_default_values['is_active'])
    cursor.execute(query, values)

# Commit the transaction and close the connection
conn.commit()
cursor.close()
conn.close()