branch_models_dict = {
  "branch": [
    [
      "[Ballie_2025_MP_Prj]"
    ],
    [
      "[Enterprise_Trunk_2024_MP_Prj]"
    ]
  ],
  "model": [
    [
      [
        "BED_H"
      ]
    ],
    [
      [
        "BEC_H"
      ],
      [
        "Q60D_K"
      ]
    ]
  ]
}
