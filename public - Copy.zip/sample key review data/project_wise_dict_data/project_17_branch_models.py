branch_models_dict = {
  "branch": [
    [
      "[Enterprise_Trunk_2024_MP_Prj]"
    ],
    [
      "[Enterprise_Trunk_2024_MP_Prj]",
      "[Enterprise_Trunk_2023_MP_Prj]",
      "[Enterprise_Trunk_2025_MP_Prj]"
    ]
  ],
  "model": [
    [
      [
        "LFF3C"
      ]
    ],
    [
      [
        "BEC_H",
        "LFF3C",
        "DU700D"
      ],
      [
        "BEC_H",
        "LFF3C",
        "DU700D"
      ]
    ]
  ]
}
