import mysql.connector
import pandas as pd

# Database connection details
db_config = {
    'host':'localhost',
    'database':'samsung_fms_portal',
    'user':'root',
    'password':'root'
}

# Default values for other attributes
branches_default_values = {
    'branch_id': None,
    'branch_type': None, 
    'is_active': True
}

df = pd.read_csv(r'C:\Users\kapil\Downloads\sample key review data\sample key review data\FMS_Branch.csv')

branch_name = list(df['name'])
branch_path = list(df['path'])
branch_type = list(df['branchType'])


# Connect to the database
conn = mysql.connector.connect(**db_config)
cursor = conn.cursor()

# Insert data into the Branches table
for name, bpath, btype in zip(branch_name, branch_path, branch_type):
    query = """
    INSERT INTO Branches (branch_name, branch_type, branch_path, is_active)
    VALUES (%s, %s, %s, %s)
    """
    values = (name, btype, bpath, branches_default_values['is_active'])
    cursor.execute(query, values)

# Commit the transaction and close the connection
conn.commit()
cursor.close()
conn.close()
