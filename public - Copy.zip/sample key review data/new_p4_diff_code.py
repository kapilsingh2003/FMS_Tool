import json
import pandas as pd
import requests
import time
import os

# Base URL of the API
BASE_URL = "http://107.108.161.134:8000/"

# Change the file path accordingly (will fetch from DB)
model_data = pd.read_csv(r"E:\MERN Projects\LearningProj\sample key review data\FMS_Branch.csv")
branch_data = pd.read_csv(r"E:\MERN Projects\LearningProj\sample key review data\FMS_Model.csv")

def filter_and_transform_dataframe(df):
    df_filtered = df.copy()
    
    for col in df_filtered.columns[1:]:
        # Step 1: Remove rows with 'NA' values in any model column
        # df_filtered = df_filtered[df_filtered[col] != 'NA']
        
        # Step 2: Remove rows with empty string values in any model column
        df_filtered = df_filtered[df_filtered[col] != '']
         
        # Step 3: Remove rows with values longer than 500 characters in any model column
        # df_filtered = df_filtered[df_filtered[col].apply(lambda x: len(str(x)) <= 500)]
        
        # Step 4: Replace values longer than 100 characters with 'Various by localsets'
        df_filtered[col] = df_filtered[col].apply(lambda x: 'Various by localsets' if len(str(x)) > 100 else x)
    
    return df_filtered

# Function to get difference sheet data of a group with multiple models via P4 (currently code works for only "TV" models)
def get_dif_from_p4(branch_models_dict, model_data, branch_data):
    branch_list_2d = branch_models_dict['branch']
    model_list_3d = branch_models_dict['model']

    if(len(model_list_3d)!= len(branch_list_2d)):
        print("Branch list and Model list length not matching!")
        return
    
    i = 0
    file_paths = []
    fms_tables = []
    for i in range(0,len(branch_list_2d)):
        branch_list = branch_list_2d[i]
        model_list_2d = model_list_3d[i]
        for model_list in model_list_2d:
            master_data = {
                "arr": [],
                "has_reference": "false"
            }
            for ind in range(0, len(branch_list)):
                branch_name = branch_list[ind]
                branch_path = branch_data.loc[branch_data['name'] == branch_name, 'path'].values[0]

                model_name = model_list[ind]
                chipset = model_data.loc[model_data['name'] == model_name, 'chipset'].values[0]

                new_entry = {
                    "delta_path": f"{branch_path}FEATURECONFIG/Feature-config/feature-config-data/csv/delta/TV/{chipset}",  # (currently code works for only "TV" models)
                    "model": model_name,
                    "changelist": 0
                }
                master_data["arr"].append(new_entry)

            print(master_data)
            api_result = requests.post(f"{BASE_URL}multi_model/process", json=master_data)
            file_path = api_result.json()['data']['file_path']
            fms_table = api_result.json()['data']['fms_table']
            file_paths.append(file_path)
            fms_tables.append(fms_table)

    # Converting data to df
    data_frame_list = []
    for fms_table in fms_tables:
        df = pd.DataFrame(fms_table)
        df = filter_and_transform_dataframe(df)
        data_frame_list.append(df)

    return data_frame_list
