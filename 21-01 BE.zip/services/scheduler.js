const cron = require('node-cron');
const Project = require('../models/Project');
const projectRoutes = require('../routes/projects');
const refreshWithCases = projectRoutes && projectRoutes.refreshProjectData;
const { spawn } = require('child_process');
const path = require('path');

// Simple in-memory queue (no Redis required)
class SimpleQueue {
    constructor() {
        this.queue = [];
        this.processing = false;
        this.activeJobs = new Set();
        this.maxConcurrent = 3; // Process max 3 projects at once
    }

    async add(jobName, data) {
        const job = {
            id: Date.now() + Math.random(),
            name: jobName,
            data: data,
            addedAt: new Date()
        };
        this.queue.push(job);
        console.log(`✅ [QUEUE] Added job ${job.id} for project ${data.projectId}`);
        
        // Start processing if not already processing
        if (!this.processing) {
            this.processQueue();
        }
        
        return job;
    }

    async processQueue() {
        if (this.processing) return;
        this.processing = true;

        while (this.queue.length > 0 || this.activeJobs.size > 0) {
            // Process jobs up to max concurrent limit
            while (this.queue.length > 0 && this.activeJobs.size < this.maxConcurrent) {
                const job = this.queue.shift();
                this.activeJobs.add(job.id);
                
                console.log(`⚙️ [QUEUE] Processing job ${job.id} for project ${job.data.projectId} (${this.activeJobs.size} active, ${this.queue.length} waiting)`);
                
                // Process job asynchronously
                this.processJob(job).then(() => {
                    this.activeJobs.delete(job.id);
                    console.log(`✅ [QUEUE] Completed job ${job.id} for project ${job.data.projectId}`);
                }).catch((error) => {
                    this.activeJobs.delete(job.id);
                    console.error(`❌ [QUEUE] Failed job ${job.id} for project ${job.data.projectId}:`, error.message);
                });
            }

            // Wait a bit before checking again
            await new Promise(resolve => setTimeout(resolve, 1000));
        }

        this.processing = false;
    }

    async processJob(job) {
    const { projectId } = job.data;

    try {
            await runRefreshUsingExistingLogic(projectId);
            console.log(`✅ [QUEUE] Successfully refreshed project ${projectId}`);
        return { success: true, projectId };
    } catch (error) {
            console.error(`❌ [QUEUE] Failed to refresh project ${projectId}:`, error.message);
            console.error(`❌ [QUEUE] Error stack:`, error.stack);
        throw error;
    }
    }

    getJobCounts() {
        return {
            waiting: this.queue.length,
            active: this.activeJobs.size,
            completed: 0,
            failed: 0
        };
    }

    close() {
        this.queue = [];
        this.activeJobs.clear();
        this.processing = false;
    }
}

// Create simple queue instance
const refreshQueue = new SimpleQueue();

console.log(`✅ [QUEUE] Simple in-memory queue initialized (no Redis required)`);

// Function to refresh a single project using existing Case 0/1/2 logic
async function runRefreshUsingExistingLogic(projectId) {
    console.log(`Starting refresh for project ${projectId}`);

    try {
        if (typeof refreshWithCases !== 'function') {
            throw new Error('Existing refresh function not available');
        }

        // Get project groups and their model combinations
        const groups = await Project.getGroups(projectId);
        if (!groups || groups.length === 0) {
            console.error(`No groups found for project ${projectId}`);
            await Project.update(projectId, { status: 'sync error' });
            return;
        }

        // Build branch_models_dict
        const branchList2D = [];
        const modelList3D = [];

        for (const group of groups) {
            const comparisonType = group.comparison_type || group.comparisonType;
            const branches = [];

            // Always add target branch
            if (group.target_branch_name || group.branches?.target) {
                branches.push(group.target_branch_name || group.branches?.target);
            }

            // Add reference branches based on comparison type
            if (comparisonType === '2-way' || comparisonType === '3-way' || comparisonType === '4-way' || comparisonType === '2-way-vs-2-way') {
                const ref1Branch = group.ref1_branch_name || group.branches?.reference1 || group.branches?.reference;
                if (ref1Branch) {
                    branches.push(ref1Branch);
                }
            }

            if (comparisonType === '3-way' || comparisonType === '4-way') {
                if (group.ref2_branch_name || group.branches?.reference2) {
                    branches.push(group.ref2_branch_name || group.branches?.reference2);
                }
            }

            if (comparisonType === '4-way') {
                if (group.ref3_branch_name || group.branches?.reference3) {
                    branches.push(group.ref3_branch_name || group.branches?.reference3);
                }
            }

            branchList2D.push(branches);

            // Fetch model combinations for the group
            const modelCombinations = await Project.getGroupModelCombinations(group.group_id);
            const modelRows = modelCombinations.map((row) => {
                const models = [];
                if (row.target) models.push(row.target);
                if (branches.length >= 2) models.push(row.reference || row.reference1 || row.target);
                if (branches.length >= 3) models.push(row.reference2 || row.target);
                if (branches.length >= 4) models.push(row.reference3 || row.target);
                return models;
            });
            modelList3D.push(modelRows);
        }

        const branchModelsDict = { branch: branchList2D, model: modelList3D };

        console.log(`Branch models dict for project ${projectId}:`, JSON.stringify(branchModelsDict, null, 2));

        // Execute Python script to get fresh diff data
        const pythonPath = 'python';
        const scriptPath = path.join(__dirname, '..', '..', 'sample key review data', 'new_p4_diff_code.py');
        const jsonArg = JSON.stringify(branchModelsDict);

        // Determine which Python function to call based on comparison types
        const has2WayVs2Way = groups.some(group =>
            (group.comparison_type || group.comparisonType) === '2-way-vs-2-way'
        );
        const pythonFunction = has2WayVs2Way ? 'get_dif_from_p4_2wayvs2way' : 'get_dif_from_p4';

        // Python shim code with better error handling for empty/invalid data
        const shimCode = `import sys,json;\nfrom pathlib import Path;\nfp = ${JSON.stringify(scriptPath) !== undefined ? `r'''${scriptPath.replace(/\\/g, '\\\\')}'''` : `''`};\nimport importlib.util;\nspec = importlib.util.spec_from_file_location('p4mod', fp);\nmod = importlib.util.module_from_spec(spec);\nspec.loader.exec_module(mod);\narg=json.loads(sys.argv[1]);\nprint('P4 shim start');\ntry:\n    res = mod.${pythonFunction}(arg, mod.model_data, mod.branch_data);\nexcept Exception as e:\n    print('P4 function error:', str(e));\n    res = [];\nprint('P4 shim done', len(res) if res else 0);\nprint('DF_COUNT:', len(res) if res else 0);\nimport pandas as pd;\nprint('DF_DATA_START');\nfor i, df in enumerate(res or []):\n    # Skip if df is None or not a DataFrame\n    if df is None:\n        print('Skipping DF index', i, 'df is None');\n        continue;\n    if not isinstance(df, pd.DataFrame):\n        print('Skipping DF index', i, 'not a DataFrame, type:', type(df));\n        continue;\n    if df.empty:\n        print('Skipping DF index', i, 'DataFrame is empty');\n        continue;\n    # Transform column names to match expected format safely (4-way -> 3-way -> 2-way)\n    df_processed = df.copy()\n    ncols = len(df_processed.columns)\n    try:\n        if ncols >= 5:\n            df_processed = df_processed.iloc[:, :5]\n            df_processed.columns = ['key name', 'target_model data', 'ref1 model data', 'ref2 model data', 'ref3 model data']\n        elif ncols == 4:\n            df_processed = df_processed.iloc[:, :4]\n            df_processed.columns = ['key name', 'target_model data', 'ref1 model data', 'ref2 model data']\n        elif ncols == 3:\n            df_processed = df_processed.iloc[:, :3]\n            df_processed.columns = ['key name', 'target_model data', 'ref1 model data']\n        else:\n            print('Skipping DF index', i, 'unsupported column count', ncols)\n            continue\n    except Exception as e:\n        print('Column rename error for DF', i, 'with ncols', ncols, ':', e)\n        continue\n    print('DF_START', i);\n    print(df_processed.to_json(orient='records'));\n    print('DF_END', i);\nprint('DF_DATA_END');`;

        const child = spawn(pythonPath, ['-c', shimCode, jsonArg], {
            stdio: ['ignore', 'pipe', 'pipe'],
            detached: false
        });

        let pythonOutput = '';
        let pythonError = '';

        child.stdout.on('data', (data) => {
            pythonOutput += data.toString();
        });

        child.stderr.on('data', (data) => {
            pythonError += data.toString();
        });

        // Set 60 minute timeout (1 hour) - some large projects take a long time
        const timeout = setTimeout(async () => {
            child.kill('SIGTERM');
            await Project.update(projectId, { status: 'sync error' });
            console.log(`Project ${projectId} sync timed out after 60 minutes. Status set to 'sync error'.`);
        }, 2 * 60 * 60 * 1000); // 2 hours

        return new Promise((resolve, reject) => {
            child.on('close', async (code) => {
                clearTimeout(timeout);
                console.log(`Python process closed with code: ${code} for project ${projectId}`);

                if (code !== 0) {
                    console.error(`Python script failed with code: ${code} for project ${projectId}`);
                    console.error('Python stderr:', pythonError);
                    await Project.update(projectId, { status: 'sync error' });
                    reject(new Error(`Python script failed with code: ${code}`));
                    return;
                }

                try {
                    // Parse DataFrame data
                    const dfCountMatch = pythonOutput.match(/DF_COUNT:\s*(\d+)/);
                    const dfCount = dfCountMatch ? parseInt(dfCountMatch[1]) : 0;

                    console.log(`Found ${dfCount} DataFrames for project ${projectId}`);

                    if (dfCount === 0) {
                        console.log(`No data found for project ${projectId}`);
                        await Project.update(projectId, { status: 'active' });
                        resolve();
                        return;
                    }

                    // Parse each DataFrame
                    const dfDataStartIndex = pythonOutput.indexOf('DF_DATA_START');
                    const dfDataEndIndex = pythonOutput.indexOf('DF_DATA_END');

                    if (dfDataStartIndex === -1 || dfDataEndIndex === -1) {
                        console.error(`Could not find DataFrame data markers for project ${projectId}`);
                        await Project.update(projectId, { status: 'sync error' });
                        reject(new Error('Could not find DataFrame data markers'));
                        return;
                    }

                    const dfDataSection = pythonOutput.substring(dfDataStartIndex, dfDataEndIndex);
                    const dfMatches = dfDataSection.match(/DF_START\s+(\d+)\s+([\s\S]*?)\s+DF_END\s+\1/g);

                    if (!dfMatches || dfMatches.length === 0) {
                        console.error(`No DataFrame data found for project ${projectId}`);
                        await Project.update(projectId, { status: 'sync error' });
                        reject(new Error('No DataFrame data found'));
                        return;
                    }

                    // Collect DataFrames the way routes refresh expects
                    const newDataFrames = [];
                    for (let i = 0; i < dfMatches.length; i++) {
                        const match = dfMatches[i];
                        const dfIndexMatch = match.match(/DF_START\s+(\d+)/);
                        const dfIndex = dfIndexMatch ? parseInt(dfIndexMatch[1]) : i;
                        const jsonDataMatch = match.match(/DF_START\s+\d+\s+([\s\S]*?)\s+DF_END\s+\d+/);
                        if (!jsonDataMatch) continue;
                            try {
                            const records = JSON.parse(jsonDataMatch[1].trim());
                            newDataFrames[dfIndex] = records;
                            } catch (parseError) {
                                console.error(`Error parsing JSON data for DataFrame ${dfIndex} of project ${projectId}:`, parseError.message);
                            }
                        }

                    // Use the existing Case 0/1/2 refresh function
                    await refreshWithCases(projectId, newDataFrames, branchModelsDict);

                    // Update project status to active and set last_refreshed_at
                    const { executeQuery } = require('../config/database');
                    await executeQuery(
                        'UPDATE `Projects` SET status = ?, last_refreshed_at = NOW() WHERE project_id = ?',
                        ['active', projectId]
                    );
                    console.log(`✅ Successfully refreshed project ${projectId} at ${new Date().toISOString()}`);
                    resolve();

                } catch (error) {
                    console.error(`Error processing Python output for project ${projectId}:`, error.message);
                    await Project.update(projectId, { status: 'sync error' });
                    reject(error);
                }
            });
        });

    } catch (error) {
        console.error(`Error refreshing project ${projectId}:`, error.message);
        await Project.update(projectId, { status: 'sync error' });
        throw error;
    }
}

// Function to get all active projects and queue them for refresh
async function queueAllProjectsForRefresh() {
    try {
        console.log('🕐 [SCHEDULER] Starting midnight refresh for all projects...');

        // Get all active projects
        const projects = await Project.getAll();
        const activeProjects = projects.filter(project => project.status === 'active');

        console.log(`📊 [SCHEDULER] Found ${activeProjects.length} active projects to refresh`);
        console.log(`📋 [SCHEDULER] Project IDs: ${activeProjects.map(p => p.project_id).join(', ')}`);

        if (activeProjects.length === 0) {
            console.log('⚠️ [SCHEDULER] No active projects found for refresh');
            return;
        }

        // Check queue health before adding jobs
        const queueHealth = await refreshQueue.getJobCounts();
        console.log(`🔍 [SCHEDULER] Queue status before adding jobs:`, queueHealth);

        // Queue each project for refresh
        let queuedCount = 0;
        let failedCount = 0;
        
        for (const project of activeProjects) {
            try {
                const job = await refreshQueue.add('refresh-project', { projectId: project.project_id });
                console.log(`✅ [SCHEDULER] Queued project ${project.project_id} (title: "${project.title}") with job ID: ${job.id}`);
                queuedCount++;
            } catch (error) {
                console.error(`❌ [SCHEDULER] Failed to queue project ${project.project_id}:`, error.message);
                console.error(`❌ [SCHEDULER] Error stack:`, error.stack);
                failedCount++;
            }
        }

        console.log(`✅ [SCHEDULER] Successfully queued ${queuedCount} projects, ${failedCount} failed`);
        
        // Check queue status after adding
        const queueHealthAfter = await refreshQueue.getJobCounts();
        console.log(`🔍 [SCHEDULER] Queue status after adding jobs:`, queueHealthAfter);
        
    } catch (error) {
        console.error('❌ [SCHEDULER] Error queuing projects for refresh:', error.message);
        console.error('❌ [SCHEDULER] Error stack:', error.stack);
    }
}

// Schedule the midnight refresh
function startScheduler() {
    console.log('Starting scheduler service...');

    // Schedule refresh at midnight every day (00:00)
    cron.schedule('0 0 * * *', async () => {
        console.log('Midnight refresh triggered at:', new Date().toISOString());
        await queueAllProjectsForRefresh();
    }, {
        scheduled: true,
        timezone: "IST" // You can change this to your preferred timezone
    });

    console.log('Scheduler started - automatic refresh scheduled for midnight UTC');
}

// Graceful shutdown
function stopScheduler() {
    console.log('Stopping scheduler service...');
    refreshQueue.close();
    console.log('Scheduler stopped');
}

module.exports = {
    startScheduler,
    stopScheduler,
    refreshQueue,
    queueAllProjectsForRefresh
};
