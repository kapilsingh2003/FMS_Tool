const express = require('express');
const router = express.Router();
const User = require('../models/User');
const { authenticateToken } = require('./auth');

// GET /api/users - Get all users (admin only)
router.get('/', authenticateToken, async (req, res) => {
    try {
        // Check if user is admin
        if (req.user.user_type !== 'admin') {
            return res.status(403).json({ message: 'Access denied. Admin rights required.' });
        }

        const users = await User.getAll();
        res.json(users);
    } catch (error) {
        console.error('Error loading users:', error);
        res.status(500).json({ message: 'Error loading users' });
    }
});

// GET /api/users/:username - Get specific user (admin only)
router.get('/:username', authenticateToken, async (req, res) => {
    try {
        // Check if user is admin
        if (req.user.user_type !== 'admin') {
            return res.status(403).json({ message: 'Access denied. Admin rights required.' });
        }

        const user = await User.findByUsername(req.params.username);

        if (!user) {
            return res.status(404).json({ message: 'User not found' });
        }

        res.json(user);
    } catch (error) {
        console.error('Error loading user:', error);
        res.status(500).json({ message: 'Error loading user' });
    }
});

// PUT /api/users/:username - Update user (admin only)
router.put('/:username', authenticateToken, async (req, res) => {
    try {
        // Check if user is admin
        if (req.user.user_type !== 'admin') {
            return res.status(403).json({ message: 'Access denied. Admin rights required.' });
        }

        const { user_type } = req.body;

        if (user_type && !['admin', 'user'].includes(user_type)) {
            return res.status(400).json({ message: 'Invalid user type. Must be admin or user.' });
        }

        if (user_type) {
            const updatedUser = await User.updateUserType(req.params.username, user_type);
            if (!updatedUser) {
                return res.status(404).json({ message: 'User not found' });
            }
            res.json({ success: true, user: updatedUser });
        } else {
            res.status(400).json({ message: 'No valid fields to update' });
        }
    } catch (error) {
        console.error('Error updating user:', error);
        res.status(500).json({ message: 'Error updating user' });
    }
});

// POST /api/users/:username/projects/:projectId - Add user to project with role
router.post('/:username/projects/:projectId', authenticateToken, async (req, res) => {
    try {
        // Check if user is admin
        if (req.user.user_type !== 'admin') {
            return res.status(403).json({ message: 'Access denied. Admin rights required.' });
        }

        const { role = 'reviewer' } = req.body;
        const { username, projectId } = req.params;

        // Validate role - admin, reviewer, and viewer are allowed
        if (!['admin', 'viewer', 'reviewer'].includes(role)) {
            return res.status(400).json({ message: 'Invalid role. Must be admin, viewer, or reviewer.' });
        }

        // Check if user exists
        const user = await User.findByUsername(username);
        if (!user) {
            return res.status(404).json({ message: 'User not found' });
        }

        // Add user to project with specified role
        const participant = await User.addToProject(username, projectId, role, req.user.username);

        res.json({
            success: true,
            message: `User added to project as ${role} successfully`,
            participant: participant
        });
    } catch (error) {
        console.error('Error adding user to project:', error);
        res.status(500).json({ message: 'Error adding user to project' });
    }
});

// PUT /api/users/:username/projects/:projectId/role - Update user's role in project
router.put('/:username/projects/:projectId/role', authenticateToken, async (req, res) => {
    try {
        // Check if user is admin
        if (req.user.user_type !== 'admin') {
            return res.status(403).json({ message: 'Access denied. Admin rights required.' });
        }

        const { role } = req.body;
        const { username, projectId } = req.params;

        // Validate role - admin, reviewer, and viewer are allowed
        if (!['admin', 'viewer', 'reviewer'].includes(role)) {
            return res.status(400).json({ message: 'Invalid role. Must be admin, viewer, or reviewer.' });
        }

        // Update user's role in project
        const participant = await User.updateProjectRole(username, projectId, role);

        if (!participant) {
            return res.status(404).json({ message: 'User not found in this project' });
        }

        res.json({
            success: true,
            message: `User role updated to ${role} successfully`,
            participant: participant
        });
    } catch (error) {
        console.error('Error updating user role in project:', error);
        res.status(500).json({ message: 'Error updating user role in project' });
    }
});

// DELETE /api/users/:username/projects/:projectId - Remove user from project
router.delete('/:username/projects/:projectId', authenticateToken, async (req, res) => {
    try {
        // Check if user is admin
        if (req.user.user_type !== 'admin') {
            return res.status(403).json({ message: 'Access denied. Admin rights required.' });
        }

        const { username, projectId } = req.params;

        // Check if user exists
        const user = await User.findByUsername(username);
        if (!user) {
            return res.status(404).json({ message: 'User not found' });
        }

        // Remove user from project
        await User.removeFromProject(username, projectId);

        res.json({
            success: true,
            message: 'User removed from project successfully'
        });
    } catch (error) {
        console.error('Error removing user from project:', error);
        res.status(500).json({ message: 'Error removing user from project' });
    }
});

// GET /api/users/:username/projects - Get projects for a specific user
router.get('/:username/projects', authenticateToken, async (req, res) => {
    try {
        const { username } = req.params;

        // Users can only see their own projects unless they're admin
        if (req.user.username !== username && req.user.user_type !== 'admin') {
            return res.status(403).json({ message: 'Access denied.' });
        }

        // Check if user exists
        const user = await User.findByUsername(username);
        if (!user) {
            return res.status(404).json({ message: 'User not found' });
        }

        // Get user's projects
        const userProjects = await User.getUserProjects(username);

        res.json(userProjects);
    } catch (error) {
        console.error('Error loading user projects:', error);
        res.status(500).json({ message: 'Error loading user projects' });
    }
});

module.exports = router; 