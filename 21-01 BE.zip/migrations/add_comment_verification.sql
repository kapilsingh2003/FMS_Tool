-- Migration: Add verification_status column to Comments table
-- Run this script on your database to add comment verification feature

USE samsung_fms_portal;

-- Add verification_status column to Comments table
-- Values: 'pending', 'verified'
-- Comments by admins are auto-verified, comments by reviewers need admin verification

-- Step 1: Add the new columns (run these one by one if needed)
ALTER TABLE `Comments` 
ADD COLUMN `verification_status` ENUM('pending', 'verified') NOT NULL DEFAULT 'pending' AFTER `comment_text`,
ADD COLUMN `verified_by_username` VARCHAR(50) NULL AFTER `verification_status`,
ADD COLUMN `verified_at` TIMESTAMP NULL AFTER `verified_by_username`;

-- Step 2: Add foreign key for verified_by_username (optional - skip if it fails)
-- ALTER TABLE `Comments`
-- ADD CONSTRAINT `fk_comments_verified_by` 
-- FOREIGN KEY (`verified_by_username`) REFERENCES `Users`(`username`) ON DELETE SET NULL;

-- Step 3: Create index for faster filtering by verification status
CREATE INDEX `idx_comments_verification_status` ON `Comments`(`verification_status`);

-- Update existing comments: Auto-verify comments made by admins
-- First, verify comments made by users who are global admins
UPDATE `Comments` c
JOIN `Users` u ON c.commented_by_username = u.username
SET c.verification_status = 'verified',
    c.verified_by_username = c.commented_by_username,
    c.verified_at = c.created_at
WHERE u.user_type = 'admin';

-- Also verify comments made by users who are project admins for the project the comment belongs to
UPDATE `Comments` c
JOIN `Key_Reviews` kr ON c.key_review_id = kr.key_review_id
JOIN `grps` g ON kr.group_id = g.group_id
JOIN `Projects` p ON g.project_id = p.project_id
JOIN `Project_Participants` pp ON p.project_id = pp.project_id AND c.commented_by_username = pp.user_username
SET c.verification_status = 'verified',
    c.verified_by_username = c.commented_by_username,
    c.verified_at = c.created_at
WHERE pp.participant_role = 'admin';

-- Verify comments by the project creator (admin_username)
UPDATE `Comments` c
JOIN `Key_Reviews` kr ON c.key_review_id = kr.key_review_id
JOIN `grps` g ON kr.group_id = g.group_id
JOIN `Projects` p ON g.project_id = p.project_id
SET c.verification_status = 'verified',
    c.verified_by_username = c.commented_by_username,
    c.verified_at = c.created_at
WHERE c.commented_by_username = p.admin_username;

SELECT 'Migration completed: Comment verification columns added' AS status;

