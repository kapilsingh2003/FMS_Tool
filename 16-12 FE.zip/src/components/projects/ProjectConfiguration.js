import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import {
    Container,
    Paper,
    Box,
    Typography,
    TextField,
    FormControl,
    InputLabel,
    Select,
    MenuItem,
    Button,
    Card,
    CardContent,
    Grid,
    Divider,
    IconButton,
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TableRow,
    Chip,
    Dialog,
    DialogTitle,
    DialogContent,
    DialogActions,
    Alert,
    Stepper,
    Step,
    StepLabel,
    Autocomplete,
    Collapse,
    CardHeader,
    CardActions,
    CircularProgress,
    Tooltip,
    Checkbox,
    FormControlLabel
} from '@mui/material';
import {
    ArrowBack,
    Add,
    Edit,
    Delete,
    Save,
    CheckCircle,
    Error,
    Settings,
    CompareArrows,
    DeviceHub,
    ExpandMore,
    ExpandLess,
    Group,
    FolderOpen,
    InfoOutlined,
    ContentCopy,
    SwapHoriz
} from '@mui/icons-material';
import { toast } from 'react-toastify';
import { useAuth } from '../../contexts/AuthContext';
import { projectsAPI, referenceAPI } from '../../services/api';

const TITLE_LIMIT = 30;
const DESCRIPTION_LIMIT = 500;

const comparisonTypes = [
    { value: '2-way', label: '2-Way Comparison' },
    { value: '3-way', label: '3-Way Comparison' },
    { value: '4-way', label: '4-Way Comparison' },
    { value: '2-way-vs-2-way', label: '2-Way vs 2-Way Comparison' }
];

const refreshSchedules = [
    { value: 'Daily', label: 'Daily' },
    { value: 'Weekly', label: 'Weekly' },
    { value: 'Monthly', label: 'Monthly' }
];

const steps = ['Basic Settings', 'Group & Model Configuration'];

const ProjectConfiguration = () => {
    const { user } = useAuth();
    const navigate = useNavigate();
    const { projectId } = useParams(); // Get projectId from route params
    const isEditMode = Boolean(projectId); // Determine if we're editing or creating
    const [activeStep, setActiveStep] = useState(0);
    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);

    // Reference data from backend
    const [branches, setBranches] = useState([]);
    const [modelOptions, setModelOptions] = useState([]);
    const [filteredModels, setFilteredModels] = useState([]);
    const [branchModelMap, setBranchModelMap] = useState(new Map()); // Cache for branch-model relationships

    // Project configuration state (removed comparisonType)
    const [projectConfig, setProjectConfig] = useState({
        title: '',
        description: '',
        refreshSchedule: 'Daily', // Set Daily as default
        groups: []
    });

    // Group management state (added comparisonType to group structure)
    const [groups, setGroups] = useState([]);
    const [groupDialogOpen, setGroupDialogOpen] = useState(false);
    const [newGroup, setNewGroup] = useState({ name: '', comparisonType: '', branches: {} });
    const [editingGroupIndex, setEditingGroupIndex] = useState(null);
    const [expandedGroups, setExpandedGroups] = useState({});

    // Model management state
    const [modelDialogOpen, setModelDialogOpen] = useState(false);
    const [newModel, setNewModel] = useState({});
    const [editingModel, setEditingModel] = useState({ groupIndex: null, modelIndex: null });
    const [currentGroupIndex, setCurrentGroupIndex] = useState(null);

    // Inline model addition state - tracks which groups have an "add model" row visible
    // Changed to support multiple rows: { [groupIndex]: [{ target: '', reference: '', ... }, ...] }
    const [inlineAddingModel, setInlineAddingModel] = useState({});

    // State for multi-select target mode
    const [targetDropdownOpen, setTargetDropdownOpen] = useState({});
    const [selectedTargets, setSelectedTargets] = useState({}); // { [groupIndex]: Set of selected target models }

    // Load reference data and project data (if editing) on component mount
    useEffect(() => {
        loadInitialData();
    }, [projectId]);

    // Load temporary data from localStorage on component mount
    useEffect(() => {
        if (!isEditMode) {
            loadTemporaryData();
        }
    }, [isEditMode]);

    // Auto-save temporary data when projectConfig or groups change (only for create mode)
    useEffect(() => {
        if (!isEditMode && !loading) {
            const timeoutId = setTimeout(() => {
                saveTemporaryData();
            }, 1000); // Debounce auto-save by 1 second

            return () => clearTimeout(timeoutId);
        }
    }, [projectConfig, groups, isEditMode, loading]);

    // Filter models when a group is selected for model addition
    useEffect(() => {
        if (currentGroupIndex !== null && groups[currentGroupIndex]) {
            const group = groups[currentGroupIndex];
            // Extract branch names from the group's branch configuration
            const branchNames = Object.values(group.branches || {}).filter(Boolean);
            if (branchNames.length > 0) {
                filterModelsForGroup(group.branches);
            } else {
                setFilteredModels([]);
            }
        }
    }, [currentGroupIndex, groups]);

    const loadTemporaryData = () => {
        try {
            const tempData = localStorage.getItem('tempProjectConfig');
            if (tempData) {
                const parsed = JSON.parse(tempData);
                setProjectConfig(parsed.projectConfig || {
                    title: '',
                    description: '',
                    refreshSchedule: '',
                    groups: []
                });
                setGroups(parsed.groups || []);
            }
        } catch (error) {
            console.error('Failed to load temporary data:', error);
        }
    };

    const saveTemporaryData = () => {
        try {
            const tempData = {
                projectConfig,
                groups
            };
            localStorage.setItem('tempProjectConfig', JSON.stringify(tempData));
        } catch (error) {
            console.error('Failed to save temporary data:', error);
        }
    };

    const clearTemporaryData = () => {
        localStorage.removeItem('tempProjectConfig');
    };

    const loadInitialData = async () => {
        try {
            setLoading(true);

            // Load branches and models in parallel
            const [branchesResult, modelsResult] = await Promise.all([
                referenceAPI.getBranches(),
                referenceAPI.getModels()
            ]);

            if (branchesResult.success) {
                setBranches(branchesResult.data.map(branch => branch.branch_name));
            } else {
                toast.error('Failed to load branches');
            }

            if (modelsResult.success) {
                setModelOptions(modelsResult.data.map(model => model.model_name));
            } else {
                toast.error('Failed to load models');
            }

            // If editing, load existing project data
            if (isEditMode && projectId) {
                await loadProjectData(projectId);
            }
        } catch (error) {
            toast.error('Failed to load initial data');
        } finally {
            setLoading(false);
        }
    };

    // Load existing project data for editing
    const loadProjectData = async (projectId) => {
        try {
            const result = await projectsAPI.getProject(projectId);
            if (result.success) {
                const project = result.data;

                // Set basic project info
                setProjectConfig({
                    title: project.title || '',
                    description: project.description || '',
                    refreshSchedule: project.refresh_schedule || 'Daily'
                });

                // Set groups with their branch and model configurations
                if (project.groups && project.groups.length > 0) {
                    const normalizeModelsForUI = (models, comparisonType) => {
                        if (!Array.isArray(models)) return [];
                        return models.map((m) => {
                            const target = m.target ?? m.target1 ?? m.model ?? m.model_name ?? null;
                            const reference = m.reference ?? m.reference1 ?? m.ref1 ?? null;
                            const ref2 = m.reference2 ?? m.ref2 ?? null;
                            const ref3 = m.reference3 ?? m.ref3 ?? null;

                            if (comparisonType === '2-way') {
                                return { target, reference: reference };
                            }
                            if (comparisonType === '3-way') {
                                return { target, reference1: reference, reference2: ref2 };
                            }
                            if (comparisonType === '4-way') {
                                return { target, reference1: reference, reference2: ref2, reference3: ref3 };
                            }
                            if (comparisonType === '2-way-vs-2-way' || comparisonType === '2-way vs 2-way') {
                                return { target1: target, reference1: reference, target2: ref2, reference2: ref3 };
                            }
                            return m;
                        });
                    };

                    const loadedGroups = project.groups.map(group => {
                        // Normalize branches based on comparison type
                        let branches;
                        if (group.comparison_type === '2-way-vs-2-way' || group.comparison_type === '2-way vs 2-way') {
                            // For 2-way-vs-2-way, map to UI keys: target1, reference1, target2, reference2
                            branches = {
                                target1: group.target_branch_name,
                                reference1: group.ref1_branch_name,
                                target2: group.ref2_branch_name,
                                reference2: group.ref3_branch_name
                            };
                        } else {
                            // For regular comparison types, use standard keys
                            branches = {
                                target: group.target_branch_name,
                                reference1: group.ref1_branch_name,
                                reference2: group.ref2_branch_name,
                                reference3: group.ref3_branch_name
                            };
                        }

                        return {
                            name: group.name,
                            comparisonType: group.comparison_type,
                            branches,
                            models: normalizeModelsForUI(group.models || [], group.comparison_type)
                        };
                    });
                    setGroups(loadedGroups);
                } else {
                    setGroups([]);
                }
            } else {
                toast.error(result.error || 'Failed to load project data');
            }
        } catch (error) {
            console.error('Error loading project data:', error);
            toast.error('Failed to load project data');
        }
    };

    // Load models for a specific branch
    const loadModelsForBranch = async (branchName) => {
        try {
            // Check if we already have models for this branch cached
            if (branchModelMap.has(branchName)) {
                return branchModelMap.get(branchName);
            }

            const result = await referenceAPI.getModelsByBranchName(branchName);
            if (result.success) {
                const models = result.data.map(model => model.model_name);
                // Cache the result
                setBranchModelMap(prev => new Map(prev.set(branchName, models)));
                return models;
            } else {
                console.error('Failed to load models for branch:', branchName, result.error);
                return [];
            }
        } catch (error) {
            console.error('Error loading models for branch:', branchName, error);
            return [];
        }
    };

    // Filter models based on selected branches in a group
    const filterModelsForGroup = async (groupBranches) => {
        try {
            const branchNames = Object.values(groupBranches).filter(Boolean);
            if (branchNames.length === 0) {
                setFilteredModels([]);
                return;
            }

            // Load models for all selected branches
            const modelPromises = branchNames.map(branchName => loadModelsForBranch(branchName));
            const modelArrays = await Promise.all(modelPromises);

            // Find intersection of models (models available in all selected branches)
            if (modelArrays.length === 1) {
                setFilteredModels(modelArrays[0]);
            } else {
                const firstArray = modelArrays[0];
                const commonModels = firstArray.filter(model =>
                    modelArrays.every(arr => arr.includes(model))
                );
                setFilteredModels(commonModels);
            }
        } catch (error) {
            console.error('Error filtering models for group:', error);
            setFilteredModels([]);
        }
    };


    const handleBack = () => {
        navigate('/dashboard');
    };

    const handleBasicSettingChange = (field, value) => {
        setProjectConfig(prev => ({
            ...prev,
            [field]: value
        }));
    };

    // Updated to work with group-specific comparison type
    const getBranchConfig = (comparisonType) => {
        switch (comparisonType) {
            case '2-way':
                return ['target', 'reference1'];
            case '3-way':
                return ['target', 'reference1', 'reference2'];
            case '4-way':
                return ['target', 'reference1', 'reference2', 'reference3'];
            case '2-way-vs-2-way':
                return ['target1', 'reference1', 'target2', 'reference2'];
            default:
                return [];
        }
    };

    // Updated to work with group-specific comparison type
    const getModelFields = (comparisonType) => {
        switch (comparisonType) {
            case '2-way':
                return [
                    { key: 'target', label: 'Target Model' },
                    { key: 'reference', label: 'Reference Model' }
                ];
            case '3-way':
                return [
                    { key: 'target', label: 'Target Model' },
                    { key: 'reference1', label: 'Reference 1 Model' },
                    { key: 'reference2', label: 'Reference 2 Model' }
                ];
            case '4-way':
                return [
                    { key: 'target', label: 'Target Model' },
                    { key: 'reference1', label: 'Reference 1 Model' },
                    { key: 'reference2', label: 'Reference 2 Model' },
                    { key: 'reference3', label: 'Reference 3 Model' }
                ];
            case '2-way-vs-2-way':
                return [
                    { key: 'target1', label: 'Target 1 Model' },
                    { key: 'reference1', label: 'Reference 1 Model' },
                    { key: 'target2', label: 'Target 2 Model' },
                    { key: 'reference2', label: 'Reference 2 Model' }
                ];
            default:
                return [];
        }
    };

    const validateGroupBranches = (groupBranches, comparisonType) => {
        const branchConfig = getBranchConfig(comparisonType);
        const selectedBranches = branchConfig.map(type => groupBranches[type]).filter(Boolean);
        // Only check that all branches are selected, allow duplicate branches
        return selectedBranches.length === branchConfig.length;
    };

    const validateNewModel = (model, comparisonType) => {
        // Check that all required fields are filled
        const modelFields = getModelFields(comparisonType);
        const missingFields = modelFields.filter(field => !model[field.key]);
        return missingFields.length === 0;
    };

    // Group management functions
    const handleAddGroup = () => {
        setNewGroup({ name: '', comparisonType: '', branches: {} });
        setEditingGroupIndex(null);
        setGroupDialogOpen(true);
    };

    const handleEditGroup = (index) => {
        setNewGroup({ ...groups[index] });
        setEditingGroupIndex(index);
        setGroupDialogOpen(true);
    };

    const handleDeleteGroup = (index) => {
        const updatedGroups = groups.filter((_, i) => i !== index);
        setGroups(updatedGroups);
        setProjectConfig(prev => ({
            ...prev,
            groups: updatedGroups
        }));
        toast.success('Group deleted successfully');
    };

    const handleSaveGroup = () => {
        // Validate group name
        if (!newGroup.name.trim()) {
            toast.error('Group name is required');
            return;
        }

        // Validate comparison type
        if (!newGroup.comparisonType) {
            toast.error('FMS Comparison Type is required');
            return;
        }

        // Validate branches
        if (!validateGroupBranches(newGroup.branches, newGroup.comparisonType)) {
            toast.error('All branches must be selected');
            return;
        }

        // Check for duplicate group names
        const existingGroups = editingGroupIndex !== null ?
            groups.filter((_, i) => i !== editingGroupIndex) : groups;

        if (existingGroups.some(group => group.name === newGroup.name.trim())) {
            toast.error('Group name already exists');
            return;
        }

        const groupToSave = {
            ...newGroup,
            name: newGroup.name.trim(),
            models: editingGroupIndex !== null ? groups[editingGroupIndex].models : []
        };

        if (editingGroupIndex !== null) {
            // Update existing group
            const updatedGroups = groups.map((group, index) =>
                index === editingGroupIndex ? groupToSave : group
            );
            setGroups(updatedGroups);
            setProjectConfig(prev => ({
                ...prev,
                groups: updatedGroups
            }));
            toast.success('Group updated successfully');
        } else {
            // Add new group
            const updatedGroups = [...groups, groupToSave];
            setGroups(updatedGroups);
            setProjectConfig(prev => ({
                ...prev,
                groups: updatedGroups
            }));
            // Auto-expand the newly created group
            setExpandedGroups(prev => ({
                ...prev,
                [updatedGroups.length - 1]: true
            }));
            toast.success('Group created successfully');
        }

        setGroupDialogOpen(false);
        setNewGroup({ name: '', comparisonType: '', branches: {} });
        setEditingGroupIndex(null);
    };

    const handleGroupFieldChange = (field, value) => {
        setNewGroup(prev => ({
            ...prev,
            [field]: value,
            // Reset branches when comparison type changes
            ...(field === 'comparisonType' ? { branches: {} } : {})
        }));
    };

    const handleGroupBranchChange = async (branchType, value) => {
        const updatedGroup = {
            ...newGroup,
            branches: {
                ...newGroup.branches,
                [branchType]: value
            }
        };
        setNewGroup(updatedGroup);

        // Filter models based on the updated branch selection
        await filterModelsForGroup(updatedGroup.branches);
    };

    const toggleGroupExpansion = (groupIndex) => {
        setExpandedGroups(prev => ({
            ...prev,
            [groupIndex]: !prev[groupIndex]
        }));
    };

    // Model management functions
    const handleAddModel = (groupIndex) => {
        setNewModel({});
        setEditingModel({ groupIndex: null, modelIndex: null });
        setCurrentGroupIndex(groupIndex);
        setModelDialogOpen(true);
    };

    // Inline model addition functions - supports multiple rows
    const handleStartInlineAdd = async (groupIndex) => {
        const group = groups[groupIndex];
        // Initialize with one empty model row
        const modelFields = getModelFields(group.comparisonType);
        const emptyModel = {};
        modelFields.forEach(field => {
            emptyModel[field.key] = '';
        });

        setInlineAddingModel(prev => ({
            ...prev,
            [groupIndex]: [emptyModel] // Array of model rows
        }));

        // Clear selected targets
        setSelectedTargets(prev => ({
            ...prev,
            [groupIndex]: new Set()
        }));

        // Make sure the group is expanded
        setExpandedGroups(prev => ({
            ...prev,
            [groupIndex]: true
        }));

        // Filter models for this group
        setCurrentGroupIndex(groupIndex);
        await filterModelsForGroup(group.branches);
    };

    const handleInlineModelChange = (groupIndex, rowIndex, fieldKey, value) => {
        setInlineAddingModel(prev => {
            const rows = [...(prev[groupIndex] || [])];
            rows[rowIndex] = {
                ...rows[rowIndex],
                [fieldKey]: value
            };
            return {
                ...prev,
                [groupIndex]: rows
            };
        });
    };

    const handleCancelInlineAdd = (groupIndex) => {
        setInlineAddingModel(prev => {
            const newState = { ...prev };
            delete newState[groupIndex];
            return newState;
        });
        setSelectedTargets(prev => {
            const newState = { ...prev };
            delete newState[groupIndex];
            return newState;
        });
        setTargetDropdownOpen(prev => ({
            ...prev,
            [groupIndex]: false
        }));
    };

    // Remove a specific row from inline add
    const handleRemoveInlineRow = (groupIndex, rowIndex) => {
        setInlineAddingModel(prev => {
            const rows = [...(prev[groupIndex] || [])];
            const removedModel = rows[rowIndex];
            rows.splice(rowIndex, 1);

            // If no rows left, add an empty one
            if (rows.length === 0) {
                const group = groups[groupIndex];
                const modelFields = getModelFields(group.comparisonType);
                const emptyModel = {};
                modelFields.forEach(field => {
                    emptyModel[field.key] = '';
                });
                rows.push(emptyModel);
            }

            return {
                ...prev,
                [groupIndex]: rows
            };
        });

        // Also remove from selected targets if it was selected
        setSelectedTargets(prev => {
            const rows = inlineAddingModel[groupIndex] || [];
            const removedModel = rows[rowIndex];
            if (removedModel) {
                const group = groups[groupIndex];
                const targetField = getModelFields(group.comparisonType).find(f => f.key === 'target' || f.key === 'target1');
                if (targetField && removedModel[targetField.key]) {
                    const newSet = new Set(prev[groupIndex]);
                    newSet.delete(removedModel[targetField.key]);
                    return {
                        ...prev,
                        [groupIndex]: newSet
                    };
                }
            }
            return prev;
        });
    };

    // Handle target checkbox selection
    // First row is kept as the "search row" - checkbox selections always create new rows
    const handleTargetCheckboxChange = (groupIndex, targetValue, isChecked) => {
        const group = groups[groupIndex];
        const modelFields = getModelFields(group.comparisonType);
        const targetField = modelFields.find(f => f.key === 'target' || f.key === 'target1');

        if (isChecked) {
            // Add to selected targets
            setSelectedTargets(prev => {
                const newSet = new Set(prev[groupIndex] || []);
                newSet.add(targetValue);
                return {
                    ...prev,
                    [groupIndex]: newSet
                };
            });

            // Always add a new row for checkbox selection (keep first row for searching)
            setInlineAddingModel(prev => {
                const rows = [...(prev[groupIndex] || [])];

                // Add a new row with the target pre-filled
                const newRow = {};
                modelFields.forEach(field => {
                    newRow[field.key] = field.key === targetField.key ? targetValue : '';
                });
                rows.push(newRow);

                return {
                    ...prev,
                    [groupIndex]: rows
                };
            });
        } else {
            // Remove from selected targets
            setSelectedTargets(prev => {
                const newSet = new Set(prev[groupIndex] || []);
                newSet.delete(targetValue);
                return {
                    ...prev,
                    [groupIndex]: newSet
                };
            });

            // Remove the row with this target
            setInlineAddingModel(prev => {
                let rows = [...(prev[groupIndex] || [])];
                rows = rows.filter(row => row[targetField.key] !== targetValue);

                // If no rows left, add an empty one
                if (rows.length === 0) {
                    const emptyModel = {};
                    modelFields.forEach(field => {
                        emptyModel[field.key] = '';
                    });
                    rows.push(emptyModel);
                }

                return {
                    ...prev,
                    [groupIndex]: rows
                };
            });
        }
    };

    // Handle select all targets
    const handleSelectAllTargets = (groupIndex, filteredOptions) => {
        const group = groups[groupIndex];
        const modelFields = getModelFields(group.comparisonType);
        const targetField = modelFields.find(f => f.key === 'target' || f.key === 'target1');
        const currentSelected = selectedTargets[groupIndex] || new Set();

        // Check if all filtered options are already selected
        const allSelected = filteredOptions.every(opt => currentSelected.has(opt));

        if (allSelected) {
            // Deselect all filtered options
            setSelectedTargets(prev => {
                const newSet = new Set(prev[groupIndex] || []);
                filteredOptions.forEach(opt => newSet.delete(opt));
                return {
                    ...prev,
                    [groupIndex]: newSet
                };
            });

            // Remove rows with these targets
            setInlineAddingModel(prev => {
                let rows = [...(prev[groupIndex] || [])];
                rows = rows.filter(row => !filteredOptions.includes(row[targetField.key]));

                if (rows.length === 0) {
                    const emptyModel = {};
                    modelFields.forEach(field => {
                        emptyModel[field.key] = '';
                    });
                    rows.push(emptyModel);
                }

                return {
                    ...prev,
                    [groupIndex]: rows
                };
            });
        } else {
            // Select all filtered options
            const newTargets = filteredOptions.filter(opt => !currentSelected.has(opt));

            setSelectedTargets(prev => {
                const newSet = new Set(prev[groupIndex] || []);
                filteredOptions.forEach(opt => newSet.add(opt));
                return {
                    ...prev,
                    [groupIndex]: newSet
                };
            });

            // Add new rows for each selection (keep first row for searching)
            setInlineAddingModel(prev => {
                const rows = [...(prev[groupIndex] || [])];

                // Add all new targets as new rows
                for (const target of newTargets) {
                    const newRow = {};
                    modelFields.forEach(field => {
                        newRow[field.key] = field.key === targetField.key ? target : '';
                    });
                    rows.push(newRow);
                }

                return {
                    ...prev,
                    [groupIndex]: rows
                };
            });
        }
    };

    // Handle single click on target item (not checkbox)
    const handleTargetItemClick = (groupIndex, rowIndex, targetValue) => {
        const group = groups[groupIndex];
        const modelFields = getModelFields(group.comparisonType);
        const targetField = modelFields.find(f => f.key === 'target' || f.key === 'target1');

        // Set the target value for the current row
        handleInlineModelChange(groupIndex, rowIndex, targetField.key, targetValue);

        // Close the dropdown
        setTargetDropdownOpen(prev => ({
            ...prev,
            [`${groupIndex}-${rowIndex}`]: false
        }));
    };

    // Apply target model value to all reference fields for a specific row
    const handleApplyTargetToAll = (groupIndex, rowIndex) => {
        const rows = inlineAddingModel[groupIndex] || [];
        const currentModel = rows[rowIndex];
        if (!currentModel) return;

        const group = groups[groupIndex];
        const modelFields = getModelFields(group.comparisonType);

        // Find the target field
        const targetField = modelFields.find(f => f.key === 'target' || f.key === 'target1');
        if (!targetField) return;

        const targetValue = currentModel[targetField.key];
        if (!targetValue) {
            toast.warning('Please select a target model first');
            return;
        }

        // Apply target value to all other fields in this row
        setInlineAddingModel(prev => {
            const newRows = [...(prev[groupIndex] || [])];
            const updatedModel = { ...newRows[rowIndex] };
            modelFields.forEach(field => {
                if (field.key !== targetField.key) {
                    updatedModel[field.key] = targetValue;
                }
            });
            newRows[rowIndex] = updatedModel;
            return {
                ...prev,
                [groupIndex]: newRows
            };
        });

        toast.success('Applied to all reference models');
    };

    // Apply target to all refs for ALL valid selection rows (skip search row)
    const handleApplyTargetToAllRows = (groupIndex) => {
        const rows = inlineAddingModel[groupIndex] || [];
        const group = groups[groupIndex];
        const modelFields = getModelFields(group.comparisonType);
        const targetField = modelFields.find(f => f.key === 'target' || f.key === 'target1');
        const currentSelectedTargets = selectedTargets[groupIndex] || new Set();

        if (!targetField) return;

        setInlineAddingModel(prev => {
            const newRows = [...(prev[groupIndex] || [])];
            newRows.forEach((row, idx) => {
                const targetValue = row[targetField.key];
                // Only apply to valid selection rows (in selectedTargets set)
                if (targetValue && currentSelectedTargets.has(targetValue)) {
                    modelFields.forEach(field => {
                        if (field.key !== targetField.key) {
                            newRows[idx] = { ...newRows[idx], [field.key]: targetValue };
                        }
                    });
                }
            });
            return {
                ...prev,
                [groupIndex]: newRows
            };
        });

        toast.success('Applied target to all reference fields for all rows');
    };

    const handleSaveInlineModel = (groupIndex) => {
        const currentGroup = groups[groupIndex];
        const comparisonType = currentGroup.comparisonType;
        const modelRows = inlineAddingModel[groupIndex] || [];
        const modelFields = getModelFields(comparisonType);
        const currentSelectedTargets = selectedTargets[groupIndex] || new Set();
        const targetField = modelFields.find(f => f.key === 'target' || f.key === 'target1');

        // Validate all rows
        const validRows = [];
        const existingModels = currentGroup.models || [];
        let duplicateCount = 0;
        let invalidCount = 0;
        let searchRowSkipped = 0;

        for (const modelData of modelRows) {
            const targetValue = modelData[targetField.key];

            // Skip empty rows
            if (!targetValue) continue;

            // Skip rows that are just search text (not checkbox-selected)
            // A row is valid only if its target is in the selectedTargets set
            // OR if there are no selected targets (single-select mode via clicking item text)
            if (currentSelectedTargets.size > 0 && !currentSelectedTargets.has(targetValue)) {
                searchRowSkipped++;
                continue;
            }

            // Validate model
            if (!validateNewModel(modelData, comparisonType)) {
                invalidCount++;
                continue;
            }

            // Check for duplicate model combination
            const isDuplicateExisting = existingModels.some(existingModel => {
                return modelFields.every(field =>
                    existingModel[field.key] === modelData[field.key]
                );
            });

            // Also check against already validated rows in this batch
            const isDuplicateInBatch = validRows.some(validRow => {
                return modelFields.every(field =>
                    validRow[field.key] === modelData[field.key]
                );
            });

            if (isDuplicateExisting || isDuplicateInBatch) {
                duplicateCount++;
                continue;
            }

            // Generate mock key differences
            const keyDifferences = Math.floor(Math.random() * 50) + 1;
            validRows.push({ ...modelData, keyDifferences });
        }

        if (validRows.length === 0) {
            if (invalidCount > 0) {
                toast.error('Please fill all model fields for each row');
            } else if (duplicateCount > 0) {
                toast.error('All selected combinations already exist');
            } else {
                toast.error('No models to add');
            }
            return;
        }

        // Add all valid rows
        const updatedGroups = groups.map((group, gIndex) => {
            if (gIndex === groupIndex) {
                return {
                    ...group,
                    models: [...(group.models || []), ...validRows]
                };
            }
            return group;
        });

        setGroups(updatedGroups);
        setProjectConfig(prev => ({
            ...prev,
            groups: updatedGroups
        }));

        // Clear and reset to single empty row
        const emptyModel = {};
        modelFields.forEach(field => {
            emptyModel[field.key] = '';
        });
        setInlineAddingModel(prev => ({
            ...prev,
            [groupIndex]: [emptyModel]
        }));
        setSelectedTargets(prev => ({
            ...prev,
            [groupIndex]: new Set()
        }));

        const message = validRows.length === 1
            ? 'Model added successfully'
            : `${validRows.length} models added successfully`;
        if (duplicateCount > 0) {
            toast.success(`${message} (${duplicateCount} duplicate${duplicateCount > 1 ? 's' : ''} skipped)`);
        } else if (invalidCount > 0) {
            toast.success(`${message} (${invalidCount} incomplete row${invalidCount > 1 ? 's' : ''} skipped)`);
        } else {
            toast.success(message);
        }
    };

    const handleEditModel = (groupIndex, modelIndex) => {
        setNewModel({ ...groups[groupIndex].models[modelIndex] });
        setEditingModel({ groupIndex, modelIndex });
        setCurrentGroupIndex(groupIndex);
        setModelDialogOpen(true);
    };

    const handleDeleteModel = (groupIndex, modelIndex) => {
        const updatedGroups = groups.map((group, gIndex) => {
            if (gIndex === groupIndex) {
                return {
                    ...group,
                    models: group.models.filter((_, mIndex) => mIndex !== modelIndex)
                };
            }
            return group;
        });

        setGroups(updatedGroups);
        setProjectConfig(prev => ({
            ...prev,
            groups: updatedGroups
        }));
        toast.success('Model removed successfully');
    };

    const handleSaveModel = () => {
        const currentGroup = groups[currentGroupIndex];
        const comparisonType = currentGroup.comparisonType;

        // Validate model
        if (!validateNewModel(newModel, comparisonType)) {
            toast.error('Please fill all model fields');
            return;
        }

        // Check for duplicate model combination (skip the model being edited)
        const modelFields = getModelFields(comparisonType);
        const existingModels = currentGroup.models || [];
        const isDuplicate = existingModels.some((existingModel, index) => {
            // Skip the model being edited
            if (editingModel.groupIndex !== null && editingModel.modelIndex === index) {
                return false;
            }
            // Check if all field values match
            return modelFields.every(field =>
                existingModel[field.key] === newModel[field.key]
            );
        });

        if (isDuplicate) {
            toast.error('This model combination already exists in this group');
            return;
        }

        // Generate mock key differences
        const keyDifferences = Math.floor(Math.random() * 50) + 1;
        const modelWithStats = { ...newModel, keyDifferences };

        const updatedGroups = groups.map((group, gIndex) => {
            if (gIndex === currentGroupIndex) {
                if (editingModel.groupIndex !== null && editingModel.modelIndex !== null) {
                    // Update existing model
                    return {
                        ...group,
                        models: group.models.map((model, mIndex) =>
                            mIndex === editingModel.modelIndex ? modelWithStats : model
                        )
                    };
                } else {
                    // Add new model
                    return {
                        ...group,
                        models: [...(group.models || []), modelWithStats]
                    };
                }
            }
            return group;
        });

        setGroups(updatedGroups);
        setProjectConfig(prev => ({
            ...prev,
            groups: updatedGroups
        }));

        // Auto-expand the group after adding/editing a model
        setExpandedGroups(prev => ({
            ...prev,
            [currentGroupIndex]: true
        }));

        const message = editingModel.groupIndex !== null && editingModel.modelIndex !== null ?
            'Model updated successfully' : 'Model added successfully';
        toast.success(message);

        setModelDialogOpen(false);
        setNewModel({});
        setEditingModel({ groupIndex: null, modelIndex: null });
        setCurrentGroupIndex(null);
    };

    const handleFinish = async () => {
        // Check for unsaved model selections
        const unsavedGroups = [];
        Object.keys(selectedTargets).forEach(groupIndex => {
            const selected = selectedTargets[groupIndex];
            if (selected && selected.size > 0) {
                const group = groups[parseInt(groupIndex)];
                if (group) {
                    unsavedGroups.push({ groupName: group.name, count: selected.size });
                }
            }
        });

        if (unsavedGroups.length > 0) {
            const groupNames = unsavedGroups.map(g => `"${g.groupName}" (${g.count} model${g.count > 1 ? 's' : ''})`).join(', ');
            toast.warning(`You have unsaved model selections in: ${groupNames}. Please click "Save" to add them or "Cancel" to discard.`);
            return;
        }

        // Final validation
        if (!projectConfig.title || !projectConfig.description) {
            toast.error('Please fill all basic settings');
            return;
        }

        if (groups.length === 0) {
            toast.error('Please create at least one group');
            return;
        }

        const hasModels = groups.some(group => group.models && group.models.length > 0);
        if (!hasModels) {
            toast.error('Please add at least one model to any group');
            return;
        }

        // Prepare project data for backend
        const projectData = {
            title: projectConfig.title,
            description: projectConfig.description,
            refreshSchedule: projectConfig.refreshSchedule,
            groups: groups // Include groups with their comparison types and models
        };

        try {
            setSaving(true);

            // Use create or update API based on mode
            const result = isEditMode
                ? await projectsAPI.updateProject(projectId, projectData)
                : await projectsAPI.createProject(projectData);

            if (result.success) {
                const message = isEditMode
                    ? 'Project updated successfully!'
                    : 'Project created successfully!';
                toast.success(message);

                // Clear temporary data if creating new project
                if (!isEditMode) {
                    clearTemporaryData();
                }

                // If creating a new project, navigate to dashboard and start polling
                if (!isEditMode && result.data && result.data.data && result.data.data.project_id) {
                    navigate('/dashboard');
                    // Start polling for the newly created project
                    setTimeout(() => {
                        window.dispatchEvent(new CustomEvent('startProjectPolling', {
                            detail: { projectId: result.data.data.project_id }
                        }));
                    }, 1000);
                } else {
                    navigate('/dashboard');
                }
            } else {
                const errorMsg = isEditMode
                    ? 'Failed to update project'
                    : 'Failed to create project';
                toast.error(result.error || errorMsg);
            }
        } catch (error) {
            const errorMsg = isEditMode
                ? 'Failed to update project'
                : 'Failed to create project';
            toast.error(errorMsg);
        } finally {
            setSaving(false);
        }
    };

    const canProceedToNext = () => {
        switch (activeStep) {
            case 0:
                return projectConfig.title && projectConfig.description && projectConfig.refreshSchedule;
            case 1:
                // Step 1 now includes both group config and models
                // Need at least one group with valid branches and at least one model in any group
                return groups.length > 0 &&
                    groups.every(group =>
                        group.comparisonType && validateGroupBranches(group.branches, group.comparisonType)
                    ) &&
                    groups.some(group => group.models && group.models.length > 0);
            default:
                return false;
        }
    };

    if (loading) {
        return (
            <Container maxWidth="xl">
                <Box sx={{ mt: 4, mb: 4, display: 'flex', justifyContent: 'center', alignItems: 'center', height: '50vh' }}>
                    <CircularProgress />
                </Box>
            </Container>
        );
    }

    return (
        <Container maxWidth="lg">
            <Box sx={{ mt: 4, mb: 4 }}>
                {/* Header */}
                <Paper sx={{ p: 3, mb: 3 }}>
                    <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                        <IconButton onClick={handleBack} sx={{ mr: 2 }}>
                            <ArrowBack />
                        </IconButton>
                        <Box sx={{ flexGrow: 1 }}>
                            <Typography variant="h4" sx={{ color: '#0d459c', fontWeight: 700 }}>
                                {isEditMode ? 'Edit Project Configuration' : 'Create New Project'}
                            </Typography>
                            <Typography variant="body2" color="text.secondary">
                                {isEditMode
                                    ? 'Update project settings and configuration'
                                    : 'Configure project settings with group-specific FMS comparison types'
                                }
                            </Typography>
                        </Box>
                        <Chip
                            icon={<Settings />}
                            label={`${user?.user_type === 'admin' ? 'Administrator' : 'User'} Mode`}
                            color="primary"
                            variant="outlined"
                        />
                    </Box>

                    {/* Stepper */}
                    <Box sx={{ display: 'flex', alignItems: 'center' }}>
                        <Stepper activeStep={activeStep} sx={{ mt: 3, flexGrow: 1 }}>
                            {steps.map((label) => (
                                <Step key={label}>
                                    <StepLabel>{label}</StepLabel>
                                </Step>
                            ))}
                        </Stepper>
                        <Tooltip
                            title={
                                <Box>
                                    <Typography variant="subtitle2" gutterBottom>Project Creation Process</Typography>
                                    <Typography variant="body2">
                                        <strong>Step 1:</strong> Set project title, description, and refresh schedule<br />
                                        <strong>Step 2:</strong> Create groups with branches and add models for comparison<br /><br />
                                        💡 <em>Each step must be completed before proceeding to the next</em>
                                    </Typography>
                                </Box>
                            }
                            arrow
                            placement="left"
                        >
                            <IconButton size="small" sx={{ ml: 2, mt: 3 }}>
                                <InfoOutlined fontSize="small" color="primary" />
                            </IconButton>
                        </Tooltip>
                    </Box>
                </Paper>

                {/* Step 0: Basic Settings (removed FMS Comparison Type) */}
                {activeStep === 0 && (
                    <Card sx={{ mb: 3 }}>
                        <CardContent>
                            <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                                <Typography variant="h6" sx={{ display: 'flex', alignItems: 'center' }}>
                                    <Settings sx={{ mr: 1 }} />
                                    Basic Project Settings
                                </Typography>
                                <Tooltip
                                    title={
                                        <Box>
                                            <Typography variant="subtitle2" gutterBottom>Basic Project Settings</Typography>
                                            <Typography variant="body2">
                                                • <strong>Project Title:</strong> A descriptive name for your FMS key review project<br />
                                                • <strong>Description:</strong> Explain the scope, objectives, and purpose of this review<br />
                                                • <strong>Refresh Schedule:</strong> How often the FMS data should be updated from the source
                                            </Typography>
                                        </Box>
                                    }
                                    arrow
                                    placement="right"
                                >
                                    <IconButton size="small" sx={{ ml: 1 }}>
                                        <InfoOutlined fontSize="small" color="action" />
                                    </IconButton>
                                </Tooltip>
                            </Box>

                            <Grid container spacing={3} sx={{ mt: 1 }}>
                                <Grid item xs={12} md={6}>
                                    <TextField
                                        fullWidth
                                        label="Project Title"
                                        value={projectConfig.title}
                                        onChange={(e) => handleBasicSettingChange('title', e.target.value.slice(0, TITLE_LIMIT))}
                                        helperText={`${projectConfig.title.length}/${TITLE_LIMIT} characters`}
                                        placeholder="e.g., SM_GameBar_Keys_Review"
                                    />
                                </Grid>

                                <Grid item xs={12} md={6}>
                                    <FormControl fullWidth>
                                        <InputLabel>Refresh Schedule</InputLabel>
                                        <Select
                                            value={projectConfig.refreshSchedule}
                                            label="Refresh Schedule"
                                            onChange={(e) => handleBasicSettingChange('refreshSchedule', e.target.value)}
                                        >
                                            {refreshSchedules.map((schedule) => (
                                                <MenuItem key={schedule.value} value={schedule.value}>
                                                    {schedule.label}
                                                </MenuItem>
                                            ))}
                                        </Select>
                                    </FormControl>
                                </Grid>

                                <Grid item xs={12}>
                                    <TextField
                                        fullWidth
                                        multiline
                                        rows={3}
                                        label="Project Description"
                                        value={projectConfig.description}
                                        onChange={(e) => handleBasicSettingChange('description', e.target.value.slice(0, DESCRIPTION_LIMIT))}
                                        helperText={`${projectConfig.description.length}/${DESCRIPTION_LIMIT} characters`}
                                        placeholder="Describe the scope and objectives of this FMS key review project..."
                                    />
                                </Grid>
                            </Grid>
                        </CardContent>
                    </Card>
                )}

                {/* Step 1: Combined Group & Model Configuration */}
                {activeStep === 1 && (
                    <Card sx={{ mb: 3 }}>
                        <CardContent>
                            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
                                <Box sx={{ display: 'flex', alignItems: 'center' }}>
                                    <Typography variant="h6" sx={{ display: 'flex', alignItems: 'center' }}>
                                        <Group sx={{ mr: 1 }} />
                                        Group & Model Configuration
                                    </Typography>
                                    <Tooltip
                                        title={
                                            <Box>
                                                <Typography variant="subtitle2" gutterBottom>Group & Model Configuration</Typography>
                                                <Typography variant="body2">
                                                    • <strong>Groups:</strong> Organize models with similar comparison requirements<br />
                                                    • <strong>FMS Comparison Type:</strong> Choose how many branches to compare<br />
                                                    • <strong>Models:</strong> Add model configurations directly in each group<br />
                                                    • Each group can have different comparison types
                                                </Typography>
                                            </Box>
                                        }
                                        arrow
                                        placement="left"
                                    >
                                        <IconButton size="small" sx={{ ml: 1 }}>
                                            <InfoOutlined fontSize="small" color="action" />
                                        </IconButton>
                                    </Tooltip>
                                </Box>
                                <Button
                                    variant="contained"
                                    startIcon={<Add />}
                                    onClick={handleAddGroup}
                                    sx={{
                                        background: 'linear-gradient(45deg, #1976d2 30%, #42a5f5 90%)',
                                        '&:hover': {
                                            background: 'linear-gradient(45deg, #1565c0 30%, #1976d2 90%)',
                                        },
                                    }}
                                >
                                    Add Group
                                </Button>
                            </Box>

                            <Alert severity="info" sx={{ mb: 2 }}>
                                Create groups with branch configurations, then add models directly to each group.
                            </Alert>

                            {groups.length === 0 ? (
                                <Box sx={{ textAlign: 'center', py: 4 }}>
                                    <Typography variant="body1" color="text.secondary" gutterBottom>
                                        No groups configured yet
                                    </Typography>
                                    <Typography variant="body2" color="text.secondary">
                                        Click "Add Group" to start creating groups and adding models
                                    </Typography>
                                </Box>
                            ) : (
                                <Box sx={{ mt: 2 }}>
                                    {groups.map((group, groupIndex) => (
                                        <Card key={groupIndex} sx={{ mb: 2, border: '1px solid #e0e0e0' }}>
                                            <CardHeader
                                                sx={{
                                                    cursor: 'pointer',
                                                    '&:hover': { bgcolor: 'action.hover' }
                                                }}
                                                onClick={(e) => {
                                                    if (!e.target.closest('button')) {
                                                        toggleGroupExpansion(groupIndex);
                                                    }
                                                }}
                                                title={
                                                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                                                        <FolderOpen color="primary" />
                                                        <Typography variant="h6">{group.name}</Typography>
                                                        <Chip
                                                            size="small"
                                                            label={comparisonTypes.find(t => t.value === group.comparisonType)?.label || group.comparisonType}
                                                            color="secondary"
                                                        />
                                                        <Chip size="small" label={`${(group.models || []).length} models`} />
                                                    </Box>
                                                }
                                                subheader={
                                                    <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1, mt: 1 }}>
                                                        {getBranchConfig(group.comparisonType).map((branchType) => (
                                                            <Chip
                                                                key={branchType}
                                                                label={`${branchType}: ${group.branches?.[branchType] || 'Not set'}`}
                                                                size="small"
                                                                variant="outlined"
                                                                color={group.branches?.[branchType] ? 'primary' : 'default'}
                                                            />
                                                        ))}
                                                    </Box>
                                                }
                                                action={
                                                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                                                        <IconButton
                                                            onClick={(e) => {
                                                                e.stopPropagation();
                                                                handleDeleteGroup(groupIndex);
                                                            }}
                                                            color="error"
                                                            size="small"
                                                        >
                                                            <Delete />
                                                        </IconButton>
                                                        <IconButton onClick={(e) => {
                                                            e.stopPropagation();
                                                            toggleGroupExpansion(groupIndex);
                                                        }}>
                                                            {expandedGroups[groupIndex] ? <ExpandLess /> : <ExpandMore />}
                                                        </IconButton>
                                                    </Box>
                                                }
                                            />

                                            <Collapse in={expandedGroups[groupIndex]} timeout="auto" unmountOnExit>
                                                <CardContent sx={{ pt: 0 }}>
                                                    {/* Models Table or Empty Message */}
                                                    {!group.models || group.models.length === 0 ? (
                                                        <Box sx={{ textAlign: 'center', py: 2 }}>
                                                            <Typography variant="body2" color="text.secondary">
                                                                No models in this group yet
                                                            </Typography>
                                                        </Box>
                                                    ) : (
                                                        <TableContainer>
                                                            <Table size="small">
                                                                <TableHead>
                                                                    <TableRow>
                                                                        {getModelFields(group.comparisonType).map((field) => (
                                                                            <TableCell key={field.key}>{field.label}</TableCell>
                                                                        ))}
                                                                        <TableCell align="center">Actions</TableCell>
                                                                    </TableRow>
                                                                </TableHead>
                                                                <TableBody>
                                                                    {group.models.map((model, modelIndex) => (
                                                                        <TableRow key={modelIndex}>
                                                                            {getModelFields(group.comparisonType).map((field) => (
                                                                                <TableCell key={field.key}>
                                                                                    <Chip label={model[field.key]} variant="outlined" size="small" />
                                                                                </TableCell>
                                                                            ))}
                                                                            <TableCell align="center">
                                                                                <Box sx={{ display: 'flex', gap: 1, justifyContent: 'center' }}>
                                                                                    {!isEditMode && (
                                                                                        <Button
                                                                                            size="small"
                                                                                            startIcon={<Edit />}
                                                                                            onClick={() => handleEditModel(groupIndex, modelIndex)}
                                                                                            variant="contained"
                                                                                            sx={{
                                                                                                fontSize: '0.75rem',
                                                                                                py: 0.5,
                                                                                                px: 1.5,
                                                                                                bgcolor: 'primary.main',
                                                                                                '&:hover': { bgcolor: 'primary.dark' }
                                                                                            }}
                                                                                        >
                                                                                            Edit
                                                                                        </Button>
                                                                                    )}
                                                                                    <Button
                                                                                        size="small"
                                                                                        startIcon={<Delete />}
                                                                                        onClick={() => handleDeleteModel(groupIndex, modelIndex)}
                                                                                        variant="contained"
                                                                                        sx={{
                                                                                            fontSize: '0.75rem',
                                                                                            py: 0.5,
                                                                                            px: 1.5,
                                                                                            bgcolor: 'error.main',
                                                                                            '&:hover': { bgcolor: 'error.dark' }
                                                                                        }}
                                                                                    >
                                                                                        Delete
                                                                                    </Button>
                                                                                </Box>
                                                                            </TableCell>
                                                                        </TableRow>
                                                                    ))}
                                                                </TableBody>
                                                            </Table>
                                                        </TableContainer>
                                                    )}

                                                    {/* Inline Add Model Section - Always at Bottom */}
                                                    {inlineAddingModel[groupIndex] && Array.isArray(inlineAddingModel[groupIndex]) ? (
                                                        <Box sx={{ mt: 2, p: 2, bgcolor: 'action.hover', borderRadius: 1 }}>
                                                            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 1.5 }}>
                                                                <Typography variant="subtitle2" sx={{ color: 'primary.main' }}>
                                                                    Add New Model{(selectedTargets[groupIndex]?.size || 0) > 1 ? 's' : ''}
                                                                    {(selectedTargets[groupIndex]?.size || 0) > 0 &&
                                                                        <Chip
                                                                            label={`${selectedTargets[groupIndex].size} selected`}
                                                                            size="small"
                                                                            sx={{ ml: 1, height: 20 }}
                                                                            color="primary"
                                                                        />
                                                                    }
                                                                </Typography>
                                                            </Box>

                                                            {/* Model Rows */}
                                                            {inlineAddingModel[groupIndex].map((modelRow, rowIndex) => {
                                                                const modelFields = getModelFields(group.comparisonType);
                                                                const targetField = modelFields.find(f => f.key === 'target' || f.key === 'target1');
                                                                const availableOptions = currentGroupIndex === groupIndex && filteredModels.length > 0 ? filteredModels : modelOptions;
                                                                const currentSelectedTargets = selectedTargets[groupIndex] || new Set();
                                                                const targetValue = modelRow[targetField?.key] || '';

                                                                // Check if this is a "search row" (row 0 with unselected target when there are checkbox selections)
                                                                const isSearchRow = rowIndex === 0 &&
                                                                    currentSelectedTargets.size > 0 &&
                                                                    !currentSelectedTargets.has(targetValue);

                                                                // Check if this is a valid selection row
                                                                const isValidSelectionRow = currentSelectedTargets.has(targetValue);

                                                                return (
                                                                    <Box
                                                                        key={rowIndex}
                                                                        sx={{
                                                                            mb: 2,
                                                                            pb: 2,
                                                                            borderBottom: rowIndex < inlineAddingModel[groupIndex].length - 1 ? '1px dashed' : 'none',
                                                                            borderColor: 'divider',
                                                                            ...(isSearchRow && {
                                                                                bgcolor: 'info.50',
                                                                                borderRadius: 1,
                                                                                p: 1,
                                                                                border: '1px dashed',
                                                                                borderColor: 'info.main'
                                                                            })
                                                                        }}
                                                                    >
                                                                        {/* Row Header */}
                                                                        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 1 }}>
                                                                            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                                                                                <Typography variant="caption" color={isSearchRow ? 'info.main' : 'text.secondary'}>
                                                                                    {isSearchRow ? '🔍 Search & Select (use checkboxes for multi-select)' :
                                                                                        (currentSelectedTargets.size > 0 ? `Model ${Array.from(currentSelectedTargets).indexOf(targetValue) + 1}` : '')}
                                                                                </Typography>
                                                                                {/* Same as Target (All) button - show next to search row label */}
                                                                                {isSearchRow && currentSelectedTargets.size > 0 && (
                                                                                    <Tooltip title="Copy target model to all reference fields for ALL selected models">
                                                                                        <Button
                                                                                            size="small"
                                                                                            variant="outlined"
                                                                                            startIcon={<SwapHoriz sx={{ fontSize: 14 }} />}
                                                                                            onClick={() => handleApplyTargetToAllRows(groupIndex)}
                                                                                            sx={{
                                                                                                fontSize: '0.65rem',
                                                                                                textTransform: 'none',
                                                                                                py: 0.25,
                                                                                                px: 1,
                                                                                                minHeight: 'auto'
                                                                                            }}
                                                                                        >
                                                                                            Same as Target (All)
                                                                                        </Button>
                                                                                    </Tooltip>
                                                                                )}
                                                                            </Box>
                                                                            <Box sx={{ display: 'flex', gap: 0.5, alignItems: 'center' }}>
                                                                                {isValidSelectionRow && (
                                                                                    <Tooltip title="Remove this selection">
                                                                                        <IconButton
                                                                                            size="small"
                                                                                            color="error"
                                                                                            onClick={() => handleTargetCheckboxChange(groupIndex, targetValue, false)}
                                                                                            sx={{ p: 0.5 }}
                                                                                        >
                                                                                            <Delete sx={{ fontSize: 14 }} />
                                                                                        </IconButton>
                                                                                    </Tooltip>
                                                                                )}
                                                                            </Box>
                                                                        </Box>

                                                                        <Grid container spacing={2} alignItems="center">
                                                                            {modelFields.map((field, fieldIndex) => {
                                                                                const isTargetField = field.key === targetField?.key;
                                                                                const dropdownKey = `${groupIndex}-${rowIndex}`;

                                                                                // For search row, only show target field
                                                                                if (isSearchRow && !isTargetField) {
                                                                                    return null;
                                                                                }

                                                                                if (isTargetField) {
                                                                                    // Custom Target Autocomplete with checkboxes
                                                                                    return (
                                                                                        <Grid item xs={12} sm={6} md={3} key={field.key}>
                                                                                            <Autocomplete
                                                                                                size="small"
                                                                                                options={availableOptions}
                                                                                                value={modelRow[field.key] || ''}
                                                                                                open={targetDropdownOpen[dropdownKey] || false}
                                                                                                onOpen={() => setTargetDropdownOpen(prev => ({ ...prev, [dropdownKey]: true }))}
                                                                                                onClose={() => setTargetDropdownOpen(prev => ({ ...prev, [dropdownKey]: false }))}
                                                                                                onChange={(_, value, reason) => {
                                                                                                    if (reason === 'selectOption') {
                                                                                                        handleTargetItemClick(groupIndex, rowIndex, value);
                                                                                                    } else if (reason === 'clear') {
                                                                                                        handleInlineModelChange(groupIndex, rowIndex, field.key, '');
                                                                                                    }
                                                                                                }}
                                                                                                onInputChange={(_, value, reason) => {
                                                                                                    if (reason === 'input') {
                                                                                                        handleInlineModelChange(groupIndex, rowIndex, field.key, value);
                                                                                                    }
                                                                                                }}
                                                                                                filterOptions={(options, { inputValue }) => {
                                                                                                    const filtered = options.filter(opt =>
                                                                                                        opt.toLowerCase().includes(inputValue.toLowerCase())
                                                                                                    );
                                                                                                    return filtered;
                                                                                                }}
                                                                                                ListboxComponent={React.forwardRef((listboxProps, ref) => {
                                                                                                    const { children, ...other } = listboxProps;
                                                                                                    const currentValue = modelRow[field.key] || '';
                                                                                                    const filteredOpts = availableOptions.filter(opt =>
                                                                                                        opt.toLowerCase().includes(currentValue.toLowerCase())
                                                                                                    );
                                                                                                    const currentSelected = selectedTargets[groupIndex] || new Set();
                                                                                                    const allFilteredSelected = filteredOpts.length > 0 && filteredOpts.every(opt => currentSelected.has(opt));

                                                                                                    return (
                                                                                                        <Box ref={ref} {...other} component="ul">
                                                                                                            {/* Select All Header */}
                                                                                                            {filteredOpts.length > 0 && (
                                                                                                                <Box
                                                                                                                    sx={{
                                                                                                                        p: 1,
                                                                                                                        borderBottom: '1px solid',
                                                                                                                        borderColor: 'divider',
                                                                                                                        bgcolor: 'primary.50',
                                                                                                                        position: 'sticky',
                                                                                                                        top: 0,
                                                                                                                        zIndex: 1
                                                                                                                    }}
                                                                                                                >
                                                                                                                    <FormControlLabel
                                                                                                                        control={
                                                                                                                            <Checkbox
                                                                                                                                size="small"
                                                                                                                                checked={allFilteredSelected}
                                                                                                                                indeterminate={!allFilteredSelected && filteredOpts.some(opt => currentSelected.has(opt))}
                                                                                                                                onChange={(e) => {
                                                                                                                                    e.stopPropagation();
                                                                                                                                    handleSelectAllTargets(groupIndex, filteredOpts);
                                                                                                                                }}
                                                                                                                                sx={{ p: 0.5 }}
                                                                                                                            />
                                                                                                                        }
                                                                                                                        label={
                                                                                                                            <Typography variant="body2" sx={{ fontWeight: 600 }}>
                                                                                                                                Select All ({filteredOpts.length})
                                                                                                                            </Typography>
                                                                                                                        }
                                                                                                                        sx={{ m: 0 }}
                                                                                                                    />
                                                                                                                </Box>
                                                                                                            )}
                                                                                                            {children}
                                                                                                        </Box>
                                                                                                    );
                                                                                                })}
                                                                                                renderOption={(props, option) => {
                                                                                                    const currentSelected = selectedTargets[groupIndex] || new Set();
                                                                                                    const isSelected = currentSelected.has(option);
                                                                                                    const { key, ...restProps } = props;

                                                                                                    return (
                                                                                                        <Box
                                                                                                            key={key}
                                                                                                            component="li"
                                                                                                            {...restProps}
                                                                                                            sx={{
                                                                                                                display: 'flex',
                                                                                                                alignItems: 'center',
                                                                                                                gap: 1,
                                                                                                                cursor: 'pointer',
                                                                                                                '&:hover': { bgcolor: 'action.hover' }
                                                                                                            }}
                                                                                                        >
                                                                                                            <Checkbox
                                                                                                                size="small"
                                                                                                                checked={isSelected}
                                                                                                                onClick={(e) => {
                                                                                                                    e.stopPropagation();
                                                                                                                    handleTargetCheckboxChange(groupIndex, option, !isSelected);
                                                                                                                }}
                                                                                                                sx={{ p: 0.5 }}
                                                                                                            />
                                                                                                            <Typography
                                                                                                                variant="body2"
                                                                                                                onClick={(e) => {
                                                                                                                    // Clicking on text = single select behavior
                                                                                                                    e.stopPropagation();
                                                                                                                    handleTargetItemClick(groupIndex, rowIndex, option);
                                                                                                                }}
                                                                                                                sx={{ flex: 1, cursor: 'pointer' }}
                                                                                                            >
                                                                                                                {option}
                                                                                                            </Typography>
                                                                                                        </Box>
                                                                                                    );
                                                                                                }}
                                                                                                renderInput={(params) => (
                                                                                                    <TextField
                                                                                                        {...params}
                                                                                                        label={field.label}
                                                                                                        placeholder="Type to search..."
                                                                                                        size="small"
                                                                                                        InputProps={{
                                                                                                            ...params.InputProps,
                                                                                                            startAdornment: (selectedTargets[groupIndex]?.size > 1 && rowIndex === 0) ? (
                                                                                                                <Chip
                                                                                                                    size="small"
                                                                                                                    label={`${selectedTargets[groupIndex].size} selected`}
                                                                                                                    sx={{ mr: 0.5, height: 20, fontSize: '0.7rem' }}
                                                                                                                    color="primary"
                                                                                                                />
                                                                                                            ) : params.InputProps.startAdornment
                                                                                                        }}
                                                                                                    />
                                                                                                )}
                                                                                                freeSolo
                                                                                                disableCloseOnSelect
                                                                                            />
                                                                                        </Grid>
                                                                                    );
                                                                                } else {
                                                                                    // For non-search rows, add "Same as Target" button before first reference field
                                                                                    const isFirstRefField = fieldIndex === 1; // First field after target

                                                                                    return (
                                                                                        <React.Fragment key={field.key}>
                                                                                            {/* Same as Target button between target and ref1 */}
                                                                                            {isFirstRefField && !isSearchRow && (
                                                                                                <Grid item xs="auto" sx={{ display: 'flex', alignItems: 'center', px: 0 }}>
                                                                                                    <Tooltip title="Copy target model to all reference fields">
                                                                                                        <IconButton
                                                                                                            size="small"
                                                                                                            onClick={() => handleApplyTargetToAll(groupIndex, rowIndex)}
                                                                                                            sx={{
                                                                                                                p: 0.5,
                                                                                                                color: 'primary.main',
                                                                                                                '&:hover': { bgcolor: 'primary.50' }
                                                                                                            }}
                                                                                                        >
                                                                                                            <SwapHoriz sx={{ fontSize: 18 }} />
                                                                                                        </IconButton>
                                                                                                    </Tooltip>
                                                                                                </Grid>
                                                                                            )}
                                                                                            <Grid item xs={12} sm={6} md={3}>
                                                                                                <Autocomplete
                                                                                                    size="small"
                                                                                                    options={availableOptions}
                                                                                                    value={modelRow[field.key] || ''}
                                                                                                    onChange={(_, value) => handleInlineModelChange(groupIndex, rowIndex, field.key, value || '')}
                                                                                                    renderInput={(params) => (
                                                                                                        <TextField
                                                                                                            {...params}
                                                                                                            label={field.label}
                                                                                                            placeholder="Type to search..."
                                                                                                            size="small"
                                                                                                        />
                                                                                                    )}
                                                                                                    freeSolo
                                                                                                />
                                                                                            </Grid>
                                                                                        </React.Fragment>
                                                                                    );
                                                                                }
                                                                            })}
                                                                        </Grid>
                                                                    </Box>
                                                                );
                                                            })}

                                                            {/* Action Buttons */}
                                                            <Box sx={{ display: 'flex', gap: 1, mt: 1 }}>
                                                                <Button
                                                                    size="small"
                                                                    variant="contained"
                                                                    color="primary"
                                                                    onClick={() => handleSaveInlineModel(groupIndex)}
                                                                    startIcon={<CheckCircle />}
                                                                >
                                                                    Save {(selectedTargets[groupIndex]?.size || 0) > 1 ? `All (${selectedTargets[groupIndex].size})` : ''}
                                                                </Button>
                                                                <Button
                                                                    size="small"
                                                                    variant="outlined"
                                                                    color="inherit"
                                                                    onClick={() => handleCancelInlineAdd(groupIndex)}
                                                                >
                                                                    Cancel
                                                                </Button>
                                                            </Box>
                                                        </Box>
                                                    ) : (
                                                        <Box sx={{ mt: 2, textAlign: 'center' }}>
                                                            <Button
                                                                size="small"
                                                                startIcon={<Add />}
                                                                onClick={() => handleStartInlineAdd(groupIndex)}
                                                                variant="outlined"
                                                            >
                                                                Add Model
                                                            </Button>
                                                        </Box>
                                                    )}
                                                </CardContent>
                                            </Collapse>
                                        </Card>
                                    ))}
                                </Box>
                            )}
                        </CardContent>
                    </Card>
                )}

                {/* Navigation Buttons */}
                <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                    <Tooltip title={activeStep === 0 ? "You're on the first step" : "Go back to previous step"}>
                        <span>
                            <Button
                                onClick={() => {
                                    if (!isEditMode) {
                                        saveTemporaryData();
                                    }
                                    setActiveStep(prev => Math.max(0, prev - 1));
                                }}
                                disabled={activeStep === 0}
                            >
                                Previous
                            </Button>
                        </span>
                    </Tooltip>

                    <Box sx={{ display: 'flex', gap: 2 }}>
                        {activeStep < steps.length - 1 ? (
                            <Tooltip
                                title={
                                    !canProceedToNext()
                                        ? `Complete all fields in ${steps[activeStep]} to continue`
                                        : `Proceed to ${steps[activeStep + 1]}`
                                }
                            >
                                <span>
                                    <Button
                                        variant="contained"
                                        onClick={() => {
                                            if (!isEditMode) {
                                                saveTemporaryData();
                                            }
                                            setActiveStep(prev => prev + 1);
                                        }}
                                        disabled={!canProceedToNext()}
                                    >
                                        Next
                                    </Button>
                                </span>
                            </Tooltip>
                        ) : (
                            <Tooltip
                                title={
                                    !canProceedToNext() || saving
                                        ? "Add at least one model to any group before finishing"
                                        : isEditMode
                                            ? "Update your project with all configured groups and models"
                                            : "Create your project with all configured groups and models"
                                }
                            >
                                <span>
                                    <Button
                                        variant="contained"
                                        startIcon={<CheckCircle />}
                                        onClick={handleFinish}
                                        disabled={!canProceedToNext() || saving}
                                        sx={{
                                            background: 'linear-gradient(45deg, #4caf50 30%, #66bb6a 90%)',
                                            '&:hover': {
                                                background: 'linear-gradient(45deg, #388e3c 30%, #4caf50 90%)',
                                            },
                                        }}
                                    >
                                        {saving
                                            ? (isEditMode ? 'Updating...' : 'Creating...')
                                            : (isEditMode ? 'Update Configuration' : 'Finish Configuration')
                                        }
                                    </Button>
                                </span>
                            </Tooltip>
                        )}
                    </Box>
                </Box>

                {/* Group Creation/Edit Dialog (updated with FMS Comparison Type) */}
                <Dialog
                    open={groupDialogOpen}
                    onClose={() => setGroupDialogOpen(false)}
                    maxWidth="md"
                    fullWidth
                >
                    <DialogTitle>
                        <Box sx={{ display: 'flex', alignItems: 'center' }}>
                            {editingGroupIndex !== null ? 'Edit Group' : 'Create New Group'}
                            <Tooltip
                                title={
                                    <Box>
                                        <Typography variant="subtitle2" gutterBottom>Group Creation Guide</Typography>
                                        <Typography variant="body2">
                                            1. <strong>Choose a descriptive name</strong> for your group<br />
                                            2. <strong>Select FMS Comparison Type</strong> based on how many branches you want to compare<br />
                                            3. <strong>Configure branches</strong> by mapping each role to a specific code branch<br />
                                            4. All branches must be selected (same branch can be used for multiple roles)
                                        </Typography>
                                    </Box>
                                }
                                arrow
                                placement="bottom"
                            >
                                <IconButton size="small" sx={{ ml: 1 }}>
                                    <InfoOutlined fontSize="small" color="action" />
                                </IconButton>
                            </Tooltip>
                        </Box>
                    </DialogTitle>
                    <DialogContent>
                        <Box sx={{ mt: 2 }}>
                            <Grid container spacing={2}>
                                <Grid item xs={12} md={6}>
                                    <TextField
                                        fullWidth
                                        label="Group Name"
                                        value={newGroup.name}
                                        onChange={(e) => handleGroupFieldChange('name', e.target.value)}
                                        placeholder="e.g., GameBar_Models, PowerSave_Models"
                                    />
                                </Grid>
                                <Grid item xs={12} md={6}>
                                    <FormControl fullWidth>
                                        <InputLabel>FMS Comparison Type</InputLabel>
                                        <Select
                                            value={newGroup.comparisonType}
                                            label="FMS Comparison Type"
                                            onChange={(e) => handleGroupFieldChange('comparisonType', e.target.value)}
                                        >
                                            {comparisonTypes.map((type) => (
                                                <MenuItem key={type.value} value={type.value}>
                                                    {type.label}
                                                </MenuItem>
                                            ))}
                                        </Select>
                                    </FormControl>
                                </Grid>
                            </Grid>

                            {newGroup.comparisonType && (
                                <>
                                    <Typography variant="subtitle1" gutterBottom sx={{ mt: 3 }}>
                                        Branch Configuration ({comparisonTypes.find(t => t.value === newGroup.comparisonType)?.label})
                                    </Typography>

                                    <Grid container spacing={2}>
                                        {getBranchConfig(newGroup.comparisonType).map((branchType) => (
                                            <Grid item xs={12} md={6} key={branchType}>
                                                <Autocomplete
                                                    options={branches}
                                                    value={newGroup.branches[branchType] || ''}
                                                    onChange={(_, value) => handleGroupBranchChange(branchType, value)}
                                                    renderInput={(params) => (
                                                        <TextField
                                                            {...params}
                                                            label={`${branchType.charAt(0).toUpperCase() + branchType.slice(1).replace(/([A-Z])/g, ' $1')} Branch`}
                                                            placeholder="Select or type branch name"
                                                        />
                                                    )}
                                                    freeSolo
                                                />
                                            </Grid>
                                        ))}
                                    </Grid>

                                    {!validateGroupBranches(newGroup.branches, newGroup.comparisonType) && Object.keys(newGroup.branches).length > 0 && (
                                        <Alert severity="warning" sx={{ mt: 2 }}>
                                            All branches must be selected. Same branches can be used for different roles.
                                        </Alert>
                                    )}
                                </>
                            )}
                        </Box>
                    </DialogContent>
                    <DialogActions>
                        <Button onClick={() => setGroupDialogOpen(false)}>Cancel</Button>
                        <Button
                            variant="contained"
                            onClick={handleSaveGroup}
                            startIcon={<Save />}
                        >
                            {editingGroupIndex !== null ? 'Update' : 'Create'} Group
                        </Button>
                    </DialogActions>
                </Dialog>

                {/* Model Dialog (updated to use current group's comparison type) */}
                <Dialog
                    open={modelDialogOpen}
                    onClose={() => setModelDialogOpen(false)}
                    maxWidth="md"
                    fullWidth
                >
                    <DialogTitle>
                        <Box>
                            <Box sx={{ display: 'flex', alignItems: 'center' }}>
                                {editingModel.modelIndex !== null ? 'Edit Model Configuration' : 'Add New Model Configuration'}
                                <Tooltip
                                    title={
                                        <Box>
                                            <Typography variant="subtitle2" gutterBottom>Model Configuration Guide</Typography>
                                            <Typography variant="body2">
                                                • <strong>Model Fields:</strong> Based on your group's comparison type<br />
                                                • <strong>Target:</strong> The main model being analyzed<br />
                                                • <strong>Reference:</strong> Models to compare against the target<br />
                                                • Use autocomplete or type custom model names<br />
                                                • All fields must be filled to save the model
                                            </Typography>
                                        </Box>
                                    }
                                    arrow
                                    placement="bottom"
                                >
                                    <IconButton size="small" sx={{ ml: 1 }}>
                                        <InfoOutlined fontSize="small" color="action" />
                                    </IconButton>
                                </Tooltip>
                            </Box>
                            {currentGroupIndex !== null && (
                                <Typography variant="subtitle2" color="text.secondary">
                                    Group: {groups[currentGroupIndex]?.name} ({comparisonTypes.find(t => t.value === groups[currentGroupIndex]?.comparisonType)?.label})
                                </Typography>
                            )}
                        </Box>
                    </DialogTitle>
                    <DialogContent>
                        <Grid container spacing={2} sx={{ mt: 1 }}>
                            {currentGroupIndex !== null && getModelFields(groups[currentGroupIndex]?.comparisonType).map((field) => (
                                <Grid item xs={12} md={6} key={field.key}>
                                    <Box sx={{ mb: 0.5 }}>
                                        <Typography variant="caption" color="text.secondary">
                                            {(() => {
                                                const branchName = groups[currentGroupIndex]?.branches?.[field.key];
                                                return branchName ? `${field.label} • ${branchName}` : field.label;
                                            })()}
                                        </Typography>
                                    </Box>
                                    <Autocomplete
                                        fullWidth
                                        options={filteredModels.length > 0 ? filteredModels : modelOptions}
                                        value={newModel[field.key] || ''}
                                        onChange={(_, value) => setNewModel(prev => ({
                                            ...prev,
                                            [field.key]: value || ''
                                        }))}
                                        renderInput={(params) => (
                                            <TextField
                                                {...params}
                                                placeholder={filteredModels.length > 0 ? "Select from available models..." : "Search and select model..."}
                                            />
                                        )}
                                        freeSolo
                                    />
                                </Grid>
                            ))}
                        </Grid>
                    </DialogContent>
                    <DialogActions>
                        <Button onClick={() => setModelDialogOpen(false)}>Cancel</Button>
                        <Button
                            variant="contained"
                            onClick={handleSaveModel}
                            startIcon={<Save />}
                        >
                            {editingModel.modelIndex !== null ? 'Update' : 'Add'} Model
                        </Button>
                    </DialogActions>
                </Dialog>
            </Box>
        </Container>
    );
};

export default ProjectConfiguration; 