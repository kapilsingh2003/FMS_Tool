const { executeQuery } = require('./config/database');

async function updateComparisonType() {
  try {
    console.log('Updating comparison_type ENUM...');
    
    const updateQuery = `
      ALTER TABLE \`grps\` 
      MODIFY COLUMN \`comparison_type\` ENUM('2-way', '3-way', '4-way', '2-way-vs-2-way') NOT NULL
    `;
    
    await executeQuery(updateQuery);
    console.log('Successfully updated comparison_type ENUM');
    
    // Verify the change
    const verifyQuery = "SHOW COLUMNS FROM `grps` LIKE 'comparison_type'";
    const result = await executeQuery(verifyQuery);
    console.log('Updated column definition:', result[0]);
    
  } catch (error) {
    console.error('Error updating comparison_type:', error.message);
  } finally {
    process.exit(0);
  }
}

updateComparisonType();
