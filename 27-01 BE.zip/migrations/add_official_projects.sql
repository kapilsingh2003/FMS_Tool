-- Migration: Add Official Project support
-- Run this script on your database to add official project features
-- This includes SWPLM project name, Project Lead, Project Manager, and PM approval workflow

USE samsung_fms_portal;

-- Step 1: Add official project columns to Projects table
ALTER TABLE `Projects` 
ADD COLUMN `is_official` BOOLEAN DEFAULT FALSE AFTER `status`,
ADD COLUMN `swplm_project_name` VARCHAR(255) NULL AFTER `is_official`,
ADD COLUMN `project_lead_username` VARCHAR(50) NULL AFTER `swplm_project_name`,
ADD COLUMN `project_manager_username` VARCHAR(50) NULL AFTER `project_lead_username`,
ADD COLUMN `target_completion_date` DATE NULL AFTER `project_manager_username`,
ADD COLUMN `pm_approval_status` ENUM('not_submitted', 'pending', 'approved', 'rejected') DEFAULT 'not_submitted' AFTER `target_completion_date`,
ADD COLUMN `pm_submitted_at` TIMESTAMP NULL AFTER `pm_approval_status`,
ADD COLUMN `pm_approved_at` TIMESTAMP NULL AFTER `pm_submitted_at`,
ADD COLUMN `pm_rejection_reason` TEXT NULL AFTER `pm_approved_at`;

-- Step 2: Add foreign key constraints for PL and PM (optional - skip if they fail)
-- ALTER TABLE `Projects`
-- ADD CONSTRAINT `fk_projects_pl` FOREIGN KEY (`project_lead_username`) REFERENCES `Users`(`username`) ON DELETE SET NULL,
-- ADD CONSTRAINT `fk_projects_pm` FOREIGN KEY (`project_manager_username`) REFERENCES `Users`(`username`) ON DELETE SET NULL;

-- Step 3: Create indexes for faster filtering
CREATE INDEX `idx_is_official` ON `Projects`(`is_official`);
CREATE INDEX `idx_pm_approval_status` ON `Projects`(`pm_approval_status`);
CREATE INDEX `idx_project_lead` ON `Projects`(`project_lead_username`);
CREATE INDEX `idx_project_manager` ON `Projects`(`project_manager_username`);
CREATE INDEX `idx_target_completion_date` ON `Projects`(`target_completion_date`);

-- Step 4: Update Project_Participants to add 'pl' (Project Lead) and 'pm' (Project Manager) roles
-- Note: We're extending the ENUM to include pl and pm roles
ALTER TABLE `Project_Participants` 
MODIFY COLUMN `participant_role` ENUM('admin', 'reviewer', 'viewer', 'pl', 'pm') NOT NULL DEFAULT 'viewer';

SELECT 'Migration completed: Official project columns added' AS status;
