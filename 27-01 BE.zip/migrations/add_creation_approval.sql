-- Migration: Add Creation Approval for Official Projects
-- Run this script on your database to add creation approval workflow
-- Official projects now require PM approval before they can be accessed

USE samsung_fms_portal;

-- Step 1: Add creation approval columns to Projects table
ALTER TABLE `Projects` 
ADD COLUMN `creation_approval_status` ENUM('not_required', 'pending', 'approved', 'rejected') DEFAULT 'not_required' AFTER `pm_rejection_reason`,
ADD COLUMN `creation_approved_at` TIMESTAMP NULL AFTER `creation_approval_status`,
ADD COLUMN `creation_rejection_reason` TEXT NULL AFTER `creation_approved_at`;

-- Step 2: Update existing official projects to have 'approved' creation status
-- (so they remain accessible)
UPDATE `Projects` 
SET `creation_approval_status` = 'approved' 
WHERE `is_official` = TRUE;

-- Step 3: Create index for faster filtering
CREATE INDEX `idx_creation_approval_status` ON `Projects`(`creation_approval_status`);

-- Step 4: Add new activity log types for creation approval
-- Note: The Activity_Log enum needs to be extended. If this fails, you may need to 
-- manually extend the ENUM or skip this step.
-- ALTER TABLE `Activity_Log` 
-- MODIFY COLUMN `action_type` ENUM(
--     'key_review_update',
--     'comment_add',
--     'comment_edit',
--     'project_create',
--     'project_edit',
--     'project_delete',
--     'project_refresh',
--     'user_login',
--     'user_signup',
--     'participant_add',
--     'participant_remove',
--     'pm_approval_submit',
--     'pm_approval_approve',
--     'pm_approval_reject',
--     'creation_approval_approve',
--     'creation_approval_reject'
-- ) NOT NULL;

SELECT 'Migration completed: Creation approval columns added' AS status;
