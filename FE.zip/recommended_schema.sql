-- Samsung FMS Portal - Recommended Database Schema
-- Based on implemented functionality and requirements

-- Users table with Samsung Knox ID integration
CREATE TABLE Users (
    username VARCHAR(50) PRIMARY KEY,           -- Knox ID
    name VARCHAR(100) NOT NULL,
    password VARCHAR(255) NOT NULL,
    role ENUM('admin', 'reviewer', 'viewer') NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,         -- Generated from Knox ID
    team ENUM('ENT_SM', 'CTV', 'ENT_TV') NOT NULL,
    created_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    last_login DATETIME,
    is_verified BOOLEAN DEFAULT FALSE,          -- OTP verification status
    INDEX idx_role (role),
    INDEX idx_team (team)
);

-- Projects with comparison configuration
CREATE TABLE Projects (
    project_id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(100) NOT NULL,                -- Character limit as implemented
    description VARCHAR(500),                   -- Character limit as implemented  
    admin_username VARCHAR(50) NOT NULL,
    comparison_type ENUM('2-way', '3-way', '4-way', '2-way vs 2-way') NOT NULL,
    refresh_schedule ENUM('Daily', 'Weekly', 'Monthly') DEFAULT 'Weekly',
    status ENUM('active', 'inactive', 'completed') DEFAULT 'active',
    created_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    is_active BOOLEAN DEFAULT TRUE,
    FOREIGN KEY (admin_username) REFERENCES Users(username) ON DELETE RESTRICT,
    INDEX idx_admin (admin_username),
    INDEX idx_status (status)
);

-- Project participants with role-based access
CREATE TABLE Project_Participants (
    project_id INT,
    user_username VARCHAR(50),
    added_by VARCHAR(50) NOT NULL,
    participant_role ENUM('admin', 'reviewer', 'viewer') DEFAULT 'reviewer',
    joined_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (project_id, user_username),
    FOREIGN KEY (project_id) REFERENCES Projects(project_id) ON DELETE CASCADE,
    FOREIGN KEY (user_username) REFERENCES Users(username) ON DELETE CASCADE,
    FOREIGN KEY (added_by) REFERENCES Users(username) ON DELETE RESTRICT,
    INDEX idx_user (user_username)
);

-- Groups within projects (flexible branch configuration)
CREATE TABLE Groups (
    group_id INT AUTO_INCREMENT PRIMARY KEY,
    project_id INT NOT NULL,
    name VARCHAR(100) NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (project_id) REFERENCES Projects(project_id) ON DELETE CASCADE,
    UNIQUE KEY unique_group_per_project (project_id, name),
    INDEX idx_project (project_id)
);

-- Branch configuration per group (supports dynamic branches)
CREATE TABLE Group_Branches (
    group_id INT,
    branch_role ENUM('target', 'reference1', 'reference2', 'reference3') NOT NULL,
    branch_name VARCHAR(255) NOT NULL,
    sort_order INT DEFAULT 0,
    PRIMARY KEY (group_id, branch_role),
    FOREIGN KEY (group_id) REFERENCES Groups(group_id) ON DELETE CASCADE,
    INDEX idx_group (group_id)
);

-- Available branches (reference data)
CREATE TABLE Branches (
    branch_id INT AUTO_INCREMENT PRIMARY KEY,
    branch_name VARCHAR(255) UNIQUE NOT NULL,
    branch_type VARCHAR(50),                    -- e.g., 'release', 'development'
    description TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    INDEX idx_active (is_active)
);

-- Monitor/TV models
CREATE TABLE Models (
    model_id INT AUTO_INCREMENT PRIMARY KEY,
    model_name VARCHAR(50) UNIQUE NOT NULL,     -- M80D, G95SC, etc.
    product_category ENUM('Smart Monitors', 'CTV', 'ENT_TV') NOT NULL,
    specifications JSON,                        -- Flexible specs storage
    is_active BOOLEAN DEFAULT TRUE,
    INDEX idx_category (product_category),
    INDEX idx_active (is_active)
);

-- Models assigned to groups (allows duplicates across groups)
CREATE TABLE Group_Models (
    group_id INT,
    model_id INT,
    added_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (group_id, model_id),
    FOREIGN KEY (group_id) REFERENCES Groups(group_id) ON DELETE CASCADE,
    FOREIGN KEY (model_id) REFERENCES Models(model_id) ON DELETE CASCADE,
    INDEX idx_group (group_id),
    INDEX idx_model (model_id)
);

-- FMS Keys (feature definitions)
CREATE TABLE FMS_Keys (
    fms_key_id INT AUTO_INCREMENT PRIMARY KEY,
    key_name VARCHAR(255) UNIQUE NOT NULL,      -- com.samsung.key_1
    work_assignment VARCHAR(100),               -- TP_GameBar, TP_PowerSave
    owner VARCHAR(100),                         -- Key owner name
    key_category VARCHAR(100),                  -- Categorization
    data_type ENUM('boolean', 'integer', 'string', 'float') DEFAULT 'string',
    description TEXT,
    has_differences BOOLEAN DEFAULT FALSE,      -- Optimization flag
    INDEX idx_work_assignment (work_assignment),
    INDEX idx_owner (owner),
    INDEX idx_differences (has_differences)
);

-- Key review data (the core review table)
CREATE TABLE Key_Reviews (
    key_review_id INT AUTO_INCREMENT PRIMARY KEY,
    fms_key_id INT NOT NULL,
    group_id INT NOT NULL,
    model_id INT NOT NULL,
    target_val TEXT,                            -- Values can be various types
    ref1_val TEXT,
    ref2_val TEXT,
    ref3_val TEXT,
    comment TEXT,
    status ENUM('pending', 'reviewed', 'needs_discussion', 'dev_response') DEFAULT 'pending',
    kona_ids TEXT,                              -- Comma-separated: "RQ250607-0239,RQ250608-0240"
    cl_numbers TEXT,                            -- Comma-separated: "1980283,1980284"
    reviewed_by_username VARCHAR(50),
    created_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    last_modified DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (fms_key_id) REFERENCES FMS_Keys(fms_key_id) ON DELETE CASCADE,
    FOREIGN KEY (group_id) REFERENCES Groups(group_id) ON DELETE CASCADE,
    FOREIGN KEY (model_id) REFERENCES Models(model_id) ON DELETE CASCADE,
    FOREIGN KEY (reviewed_by_username) REFERENCES Users(username) ON DELETE SET NULL,
    UNIQUE KEY unique_review (fms_key_id, group_id, model_id),
    INDEX idx_fms_key (fms_key_id),
    INDEX idx_group (group_id),
    INDEX idx_model (model_id),
    INDEX idx_status (status),
    INDEX idx_reviewer (reviewed_by_username)
);

-- Audit trail for changes (optional but recommended)
CREATE TABLE Audit_Log (
    audit_id INT AUTO_INCREMENT PRIMARY KEY,
    table_name VARCHAR(50) NOT NULL,
    record_id VARCHAR(50) NOT NULL,
    action ENUM('INSERT', 'UPDATE', 'DELETE') NOT NULL,
    old_values JSON,
    new_values JSON,
    changed_by VARCHAR(50),
    changed_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (changed_by) REFERENCES Users(username) ON DELETE SET NULL,
    INDEX idx_table_record (table_name, record_id),
    INDEX idx_user_time (changed_by, changed_at)
);

-- Insert reference data for branches
INSERT INTO Branches (branch_name, branch_type, description) VALUES
('Trunk_25_MonitorRC_MP_Prj', 'release', 'Main trunk for 2025 Monitor RC'),
('SmartMonitor_2025_MP_Prj', 'release', 'Smart Monitor 2025 project branch'),
('OSU_2025_SM_TV_Ready_MP_Prj', 'development', 'OSU 2025 Smart Monitor TV Ready'),
('Feature_GameBar_2025', 'feature', 'Gaming features branch for 2025'),
('CTV_Platform_24Y', 'release', 'CTV Platform 2024 branch'),
('ENT_TV_2025_Release', 'release', 'Enterprise TV 2025 release branch');

-- Insert sample models
INSERT INTO Models (model_name, product_category, specifications) VALUES
('M80D', 'Smart Monitors', '{"size": "32inch", "resolution": "4K", "gaming": true}'),
('M70D', 'Smart Monitors', '{"size": "27inch", "resolution": "4K", "gaming": true}'),
('G95SC', 'Smart Monitors', '{"size": "49inch", "resolution": "5K", "gaming": true, "curved": true}'),
('G95SD', 'Smart Monitors', '{"size": "49inch", "resolution": "5K", "gaming": true, "curved": true}'),
('S90PC', 'CTV', '{"size": "55inch", "resolution": "4K", "smart_tv": true}'),
('M50C', 'Smart Monitors', '{"size": "24inch", "resolution": "FHD", "gaming": false}');

-- Insert sample FMS keys
INSERT INTO FMS_Keys (key_name, work_assignment, owner, key_category, data_type, description) VALUES
('com.samsung.gamebar.responsetime', 'TP_GameBar', 'John Smith', 'Gaming', 'boolean', 'Enable gaming response time optimization'),
('com.samsung.display.powersave', 'TP_PowerSave', 'Jane Doe', 'Power', 'integer', 'Power save mode level (1-3)'),
('com.samsung.audio.enhancement', 'TP_Sound', 'Mike Johnson', 'Audio', 'boolean', 'Audio enhancement feature toggle');
