import mysql.connector
import pandas as pd
import json

# Database connection details
db_config = {
    'host':'localhost',
    'database':'samsung_fms_portal',
    'user':'root',
    'password':'root'
}

def concatenate_with_unique_A(df1, df2):
    # Combine both DataFrames
    combined_df = pd.concat([df1, df2], axis=0, ignore_index=True)
    
    # Check for duplicates in column 'A'
    duplicates = combined_df[combined_df.duplicated('name', keep=False)]
    
    if not duplicates.empty:
        print("Warning: Duplicate values found in column 'name'. Skipping duplicate rows.")
        # Remove duplicate rows
        combined_df = combined_df.drop_duplicates(subset='name', keep='first')
    
    return combined_df

df1 = pd.read_csv(r'E:\MERN Projects\LearningProj\sample key review data\FMS_Keys_1.csv')
df2 = pd.read_csv(r'E:\MERN Projects\LearningProj\sample key review data\FMS_Keys_2.csv')
df1 = concatenate_with_unique_A(df1, df2)

keyName = list(df1['name'])
workAssignment = list(df1['workAssignment'])
workAssignmentOwner = list(df1['workAssignmentOwner'])
description = list(df1['description'])
# json_data = df['chipset'].apply(lambda x: json.dumps({'chipset': x}))
# specifications = json_data.tolist()

# Default values for other attributes
models_default_values = {
    'has_differences': 1
}

# Connect to the database
conn = mysql.connector.connect(**db_config)
cursor = conn.cursor()

# Insert data into the Models table
for name,wa,wao,desc in zip(keyName, workAssignment, workAssignmentOwner, description):
    query = """
    INSERT INTO fms_keys (key_name, work_assignment, work_assignment_owner, description, has_differences)
    VALUES (%s, %s, %s, %s, %s)
    """
    values = (name, wa, wao, desc, models_default_values['has_differences'])
    cursor.execute(query, values)

# Commit the transaction and close the connection
conn.commit()
cursor.close()
conn.close()