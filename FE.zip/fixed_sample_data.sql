-- Samsung FMS Portal - Fixed Sample Data for Current Schema
-- This matches the updated schema with chipset and branch_path columns

USE samsung_fms_portal;

-- Clear existing data (if any) in reverse order to avoid FK constraints
DELETE FROM `Key_Reviews`;
DELETE FROM `Group_Branch_Model_Map`;
DELETE FROM `Group_Branch_Mapping`;
DELETE FROM `Groups`;
DELETE FROM `Project_Participants`;
DELETE FROM `Projects`;
DELETE FROM `FMS_Keys`;
DELETE FROM `Branch_Model_Mapping`;
DELETE FROM `Models`;
DELETE FROM `Branches`;
DELETE FROM `Users`;

-- Insert sample users (Knox ID based) with proper bcrypt hashes
INSERT INTO `Users` (username, name, password, role, email, team, is_verified) VALUES
('admin.john', 'John Kim', '$2b$10$GI0dXfMUox4yyBtmt2Qgm.RBQ1X6pyRp29SEYJNmfaa0oj/CxUHSG', 'admin', 'admin.john@samsung.com', 'ENT_SM', TRUE),
('reviewer.sarah', 'Sarah Lee', '$2b$10$GI0dXfMUox4yyBtmt2Qgm.RBQ1X6pyRp29SEYJNmfaa0oj/CxUHSG', 'reviewer', 'reviewer.sarah@samsung.com', 'CTV', TRUE),
('reviewer.mike', 'Mike Johnson', '$2b$10$GI0dXfMUox4yyBtmt2Qgm.RBQ1X6pyRp29SEYJNmfaa0oj/CxUHSG', 'reviewer', 'reviewer.mike@samsung.com', 'ENT_TV', TRUE),
('viewer.anna', 'Anna Park', '$2b$10$GI0dXfMUox4yyBtmt2Qgm.RBQ1X6pyRp29SEYJNmfaa0oj/CxUHSG', 'viewer', 'viewer.anna@samsung.com', 'ENT_SM', TRUE);

-- Insert branches with branch_path (not description)
INSERT INTO `Branches` (branch_name, branch_type, branch_path, is_active) VALUES
('Trunk_2025_MonitorRC_MP_Prj', 'release', '/samsung/fms/trunk/2025/monitor_rc', TRUE),
('Trunk_2024_MonitorRC_MP_Prj', 'release', '/samsung/fms/trunk/2024/monitor_rc', TRUE),
('SmartMonitor_2025_MP_Prj', 'development', '/samsung/fms/smartmonitor/2025/main_project', TRUE),
('Feature_GameBar_2025', 'feature', '/samsung/fms/features/gamebar/2025', TRUE),
('CTV_Platform_24Y', 'release', '/samsung/fms/ctv/2024/platform', TRUE),
('ENT_TV_2025_Release', 'release', '/samsung/fms/ent_tv/2025/release', TRUE);

-- Insert models with chipset (not specifications)
INSERT INTO `Models` (model_name, product_category, chipset, is_active) VALUES
-- 2025 F series
('M80F', 'Smart Monitors', 'Tizen OS 8.5', TRUE),
('M70F', 'Smart Monitors', 'Tizen OS 8.5', TRUE),
('M50F', 'Smart Monitors', 'Tizen OS 8.0', TRUE),
('G95SF', 'Smart Monitors', 'Tizen OS 8.5', TRUE),
-- 2024 D series
('M80D', 'Smart Monitors', 'Tizen OS 8.0', TRUE),
('M70D', 'Smart Monitors', 'Tizen OS 8.0', TRUE),
('M50D', 'Smart Monitors', 'Tizen OS 7.5', TRUE),
('G95SD', 'Smart Monitors', 'Tizen OS 8.0', TRUE),
-- CTV Models
('S90PC', 'CTV', 'CTV Platform 2024', TRUE),
('S95PD', 'CTV', 'CTV Platform 2024', TRUE),
-- ENT_TV Models
('QM98F', 'ENT_TV', 'ENT Platform 2025', TRUE),
('QM85D', 'ENT_TV', 'ENT Platform 2024', TRUE);

-- Insert Branch-Model mappings
INSERT INTO `Branch_Model_Mapping` (branch_id, model_id, is_available) VALUES
-- 2025 Trunk - F series models
(1, 1, TRUE), (1, 2, TRUE), (1, 3, TRUE), (1, 4, TRUE), (1, 11, TRUE),
-- 2024 Trunk - D series models  
(2, 5, TRUE), (2, 6, TRUE), (2, 7, TRUE), (2, 8, TRUE), (2, 9, TRUE), (2, 12, TRUE),
-- SmartMonitor 2025 - F series
(3, 1, TRUE), (3, 2, TRUE), (3, 3, TRUE), (3, 4, TRUE),
-- Gaming Feature Branch - gaming models
(4, 1, TRUE), (4, 2, TRUE), (4, 4, TRUE), (4, 5, TRUE), (4, 6, TRUE), (4, 8, TRUE),
-- CTV Platform - CTV models
(5, 9, TRUE), (5, 10, TRUE),
-- ENT_TV Release - ENT models
(6, 11, TRUE), (6, 12, TRUE);

-- Insert FMS Keys
INSERT INTO `FMS_Keys` (key_name, work_assignment, work_assignment_owner, key_category, data_type, description, has_differences) VALUES
('gamebar.responsetime', 'TP_GameBar', 'John Smith', 'Gaming', 'boolean', 'Gaming response time optimization', TRUE),
('gamebar.gamemode', 'TP_GameBar', 'John Smith', 'Gaming', 'boolean', 'Automatic game mode detection', TRUE),
('display.powersave.level', 'TP_PowerSave', 'Jane Doe', 'Power Management', 'integer', 'Power save mode level', TRUE),
('audio.enhancement.enable', 'TP_Sound', 'Mike Johnson', 'Audio', 'boolean', 'Audio enhancement features', TRUE),
('connectivity.hdmi.ports', 'TP_Hardware', 'Lisa Chen', 'Hardware', 'integer', 'Number of HDMI ports', TRUE),
('smart.features.voice', 'TP_SmartTV', 'David Lee', 'Smart Features', 'boolean', 'Voice control features', TRUE);

-- Insert sample projects
INSERT INTO `Projects` (title, description, admin_username, refresh_schedule, status) VALUES
('SM_GameBar_Keys_Review_2025', 'Gaming keys review for 2025 Smart Monitors', 'admin.john', 'Weekly', 'active'),
('CTV_Platform_Validation_24Y', 'CTV platform validation for 2024', 'admin.john', 'Daily', 'active');

-- Insert project participants
INSERT INTO `Project_Participants` (project_id, user_username, added_by, participant_role) VALUES
(1, 'admin.john', 'admin.john', 'admin'),
(1, 'reviewer.sarah', 'admin.john', 'reviewer'),
(1, 'reviewer.mike', 'admin.john', 'reviewer'),
(2, 'admin.john', 'admin.john', 'admin'),
(2, 'reviewer.sarah', 'admin.john', 'reviewer');

-- Insert sample groups
INSERT INTO `Groups` (project_id, name, comparison_type) VALUES
(1, 'Gaming_Monitor_2025', '3-way'),
(1, 'Premium_Gaming_Features', '2-way'),
(2, 'CTV_Core_Features', '2-way');

-- Insert group-branch mappings
INSERT INTO `Group_Branch_Mapping` (group_id, branch_role, branch_id, sort_order) VALUES
-- Group 1: Gaming_Monitor_2025 (3-way)
(1, 'target', 1, 1),      -- 2025 Trunk
(1, 'reference1', 2, 2),  -- 2024 Trunk  
(1, 'reference2', 4, 3),  -- Gaming Feature Branch

-- Group 2: Premium_Gaming_Features (2-way)
(2, 'target', 1, 1),      -- 2025 Trunk
(2, 'reference1', 4, 2),  -- Gaming Feature Branch

-- Group 3: CTV_Core_Features (2-way)
(3, 'target', 5, 1),      -- CTV Platform
(3, 'reference1', 2, 2);  -- 2024 Trunk

-- Insert group-branch-model mappings
INSERT INTO `Group_Branch_Model_Map` (gb_id, model_id) VALUES
-- Group 1: Gaming monitors (3-way comparison)
(1, 1), (1, 2), (1, 4),   -- F series from 2025 trunk
(2, 5), (2, 6), (2, 8),   -- D series from 2024 trunk  
(3, 1), (3, 2), (3, 4),   -- F series from gaming branch

-- Group 2: Premium gaming (2-way comparison)
(4, 1), (4, 4),           -- Premium F series from 2025 trunk
(5, 1), (5, 4),           -- Same models from gaming branch

-- Group 3: CTV comparison
(6, 9), (6, 10),          -- CTV models from CTV platform
(7, 5), (7, 6);           -- Monitor models for comparison

-- Insert sample key reviews
INSERT INTO `Key_Reviews` (fms_key_id, gbm_id, target_val, ref1_val, ref2_val, ref3_val, comment, status, kona_ids, cl_numbers, reviewed_by_username) VALUES
-- Gaming response time across models
(1, 1, 'True', 'True', 'True', NULL, 'Gaming feature enabled for 2025 F series', 'reviewed', 'RQ250607-0239', '1980283', 'reviewer.sarah'),
(1, 2, 'True', 'False', 'True', NULL, 'Inconsistent with 2024 models', 'needs_discussion', 'RQ250608-0240', '1980284', 'reviewer.mike'),
(1, 3, 'True', 'True', 'True', NULL, 'Consistent across gaming branch', 'reviewed', NULL, NULL, 'reviewer.sarah'),

-- HDMI ports differences
(5, 1, '4', '2', '4', NULL, 'Upgraded to 4 HDMI ports in F series', 'reviewed', 'RQ250609-0241', '1980285', 'reviewer.sarah'),
(5, 2, '2', '2', '2', NULL, 'Standard 2 HDMI ports in D series', 'pending', NULL, NULL, NULL),

-- Audio enhancement
(4, 4, 'True', 'False', NULL, NULL, 'New audio features in premium models', 'reviewed', 'RQ250610-0242', '1980286', 'reviewer.mike'),
(4, 5, 'True', 'False', NULL, NULL, 'Same audio enhancement pattern', 'reviewed', NULL, NULL, 'reviewer.mike');

-- Display success message
SELECT 'Fixed sample data inserted successfully!' as Status;
SELECT 'Key Reviews created:' as Info, COUNT(*) as Count FROM `Key_Reviews`;
SELECT 'Now try refreshing your frontend!' as Message;
