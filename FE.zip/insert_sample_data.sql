-- Samsung FMS Portal - Sample Data Insertion
-- Insert reference data and sample records for testing

USE samsung_fms_portal;

-- Insert sample users (Knox ID based)
INSERT INTO `Users` (username, name, password, role, email, team, is_verified) VALUES
('admin.john', 'John Kim', '$2b$10$GI0dXfMUox4yyBtmt2Qgm.RBQ1X6pyRp29SEYJNmfaa0oj/CxUHSG', 'admin', 'admin.john@samsung.com', 'ENT_SM', TRUE),
('reviewer.sarah', 'Sarah Lee', '$2b$10$GI0dXfMUox4yyBtmt2Qgm.RBQ1X6pyRp29SEYJNmfaa0oj/CxUHSG', 'reviewer', 'reviewer.sarah@samsung.com', 'CTV', TRUE),
('reviewer.mike', 'Mike Johnson', '$2b$10$GI0dXfMUox4yyBtmt2Qgm.RBQ1X6pyRp29SEYJNmfaa0oj/CxUHSG', 'reviewer', 'reviewer.mike@samsung.com', 'ENT_TV', TRUE),
('viewer.anna', 'Anna Park', '$2b$10$GI0dXfMUox4yyBtmt2Qgm.RBQ1X6pyRp29SEYJNmfaa0oj/CxUHSG', 'viewer', 'viewer.anna@samsung.com', 'ENT_SM', TRUE),
('admin.david', 'David Chen', '$2b$10$GI0dXfMUox4yyBtmt2Qgm.RBQ1X6pyRp29SEYJNmfaa0oj/CxUHSG', 'admin', 'admin.david@samsung.com', 'CTV', TRUE);

-- Insert sample projects
INSERT INTO `Projects` (title, description, admin_username, refresh_schedule, status) VALUES
('25to23.24 SM BizTV OSU', 'Comprehensive review of FMS keys for 25to24.23Y Smart Monitor and BizTV lineup', 'admin.john', 'Daily', 'active');

-- Insert project participants
INSERT INTO `Project_Participants` (project_id, user_username, added_by, participant_role) VALUES
(1, 'admin.john', 'admin.john', 'admin'),
(1, 'reviewer.sarah', 'admin.john', 'reviewer'),
(1, 'reviewer.mike', 'admin.john', 'reviewer'),
(1, 'viewer.anna', 'admin.john', 'viewer');


-- Insert sample groups
INSERT INTO `Grps` (project_id, name, comparison_type) VALUES
(1, '25to23Y SM OSU 2-Way', '2-way'),
(1, '25to23Y SM OSU 3-Way', '3-way'),
(1, '25to23Y BizTV OSU 4-Way', '4-way');

-- Insert group-branch mappings
INSERT INTO `Group_Branch_Mapping` (group_id, branch_role, branch_id, sort_order) VALUES
-- Group 1: 25to23Y SM OSU 2-Way (2-way)
(1, 'target', 1, 1),      -- [TIZENPROD_Prj]
(1, 'reference1', 26, 2),  -- [Trunk_2025_MP_Prj]   

-- Group 2: 25to23Y SM OSU 3-Way (3-way)
(2, 'target', 26, 1),      -- [Trunk_2025_MP_Prj]
(2, 'reference1', 20, 2),  -- [OSU_Trunk2023_T80_Prj]
(2, 'reference2', 29, 3),    -- [SmartMonitor_2025_MP_Prj] 

-- Group 3: 25to23Y BizTV OSU 4-Way (4-way)
(3, 'target', 26, 1),      -- [Trunk_2025_MP_Prj]
(3, 'reference1', 1, 2),  -- [TIZENPROD_Prj]
(3, 'reference2', 21, 3),  -- [Trunk_2024_MonitorRC_MP_Prj]
(3, 'reference3', 33, 4);  -- [BizTV_2025_MP_Prj] 


-- Insert group-branch-model mappings (specific models used in each group)
INSERT INTO `Group_Branch_Model_Map` (gb_id, model_id) VALUES
-- Group 1: 25to23Y SM OSU 2-Way
(1, 133), (1, 287), (1, 132),   -- M80D, M70D, G70D
(2, 133), (2, 287), (2, 132),   -- M80D, M70D, G70D  

-- Group 2: 25to23Y SM OSU 3-Way
(3, 231), (3, 218), (3, 219), (3, 140),
(4, 231), (4, 218), (4, 219), (4, 140),
(5, 159),

-- Group 3: 25to23Y BizTV OSU 4-Way
(6, 263), (6, 262), (6, 132),
(7, 263), (7, 262), (7, 132),
(8, 263), (8, 262), (8, 132),
(9, 9);

-- Insert sample key reviews (demonstrating different statuses and values)
INSERT INTO `Key_Reviews` (fms_key_id, target_gbm_id, ref1_gbm_id, ref2_gbm_id, ref3_gbm_id, target_val, ref1_val, ref2_val, ref3_val, comment, status, kona_ids, cl_numbers, reviewed_by_username) VALUES

-- Group 1: 25to23Y SM OSU 2-Way (2-way comparison)
-- Using gbm_ids: 1, 2, 3, 4 (target, ref1, ref2, ref3)
(70, 1, 2, 3, 4, 'True', 'True', 'True', 'True', 'White balance consistently supported across all models', 'changes_made', 'RQ250607-0239', '1980283', 'reviewer.sarah'),
(296, 1, 2, 3, 4, 'False', 'True', 'False', 'True', '360 audio support varies by model generation', 'pending_response', 'RQ250608-0240', '1980284', 'reviewer.mike'),
(673, 1, 2, 3, 4, 'True', 'False', 'True', 'False', 'Graphic zoom accessibility feature needs review', 'internal_discussion', 'RQ250609-0241', '1980285', 'reviewer.sarah'),

-- Group 2: 25to23Y SM OSU 3-Way (3-way comparison)  
-- Using gbm_ids: 7, 8, 9, 10 (target, ref1, ref2, ref3)
(103, 7, 8, 9, 10, 'True', 'True', 'True', 'True', 'See colors mode consistently available', 'no_change_req', 'RQ250610-0242', '1980286', 'reviewer.mike'),
(510, 7, 8, 9, 10, 'False', 'True', 'False', 'True', 'Relumino mode PC support needs investigation', 'changes_made', 'RQ250611-0243', '1980287', 'reviewer.sarah'),
(225, 7, 8, 9, 10, 'True', 'False', 'True', 'False', 'Sign-in mandatory setting varies by region', 'pending_response', 'RQ250612-0244', '1980288', 'reviewer.mike'),

-- Group 3: 25to23Y BizTV OSU 4-Way (4-way comparison)
-- Using gbm_ids: 16, 17, 18, 19 (target, ref1, ref2, ref3)
(142, 16, 17, 18, 19, 'True', 'False', 'True', 'False', 'China server usage depends on region', 'internal_discussion', 'RQ250613-0245', '1980289', 'reviewer.sarah'),
(536, 16, 17, 18, 19, 'False', 'True', 'False', 'True', 'ACM multi-channel support varies by chipset', 'changes_made', 'RQ250614-0250', '1980290', 'reviewer.mike'),
(151, 16, 17, 18, 19, 'True', 'True', 'True', 'True', 'EQ level adjustment consistently supported', 'no_change_req', 'RQ250615-0251', '1980291', 'reviewer.sarah'),
(294, 16, 17, 18, 19, 'False', 'False', 'True', 'True', 'IAMF support implementation needs review', 'pending_response', 'RQ250616-0252', '1980292', 'reviewer.mike'),

-- Additional reviews for different FMS keys
(70, 4, 5, 6, 7, 'True', 'False', 'True', 'False', 'White balance support differs between model lines', 'changes_made', 'RQ250617-0253', '1980293', 'reviewer.sarah'),
(296, 11, 12, 13, 14, 'True', 'True', 'False', 'True', '360 audio support implementation varies', 'internal_discussion', 'RQ250618-0254', '1980294', 'reviewer.mike'),
(673, 20, 21, 22, 23, 'False', 'True', 'False', 'True', 'Graphic zoom accessibility needs standardization', 'pending_response', 'RQ250619-0255', '1980295', 'reviewer.sarah');

-- Display success message
SELECT 'Sample data inserted successfully!' as Status;
SELECT 'Database is ready for testing!' as Message;
