-- Samsung FMS Portal - Sample Data Insertion
-- Insert reference data and sample records for testing

USE samsung_fms_portal;

-- Insert sample users (Knox ID based)
INSERT INTO `Users` (username, name, password, role, email, team, is_verified) VALUES
('admin.john', 'John Kim', '$2b$10$dummy.hash.for.admin', 'admin', 'admin.john@samsung.com', 'ENT_SM', TRUE),
('reviewer.sarah', 'Sarah Lee', '$2b$10$dummy.hash.for.reviewer', 'reviewer', 'reviewer.sarah@samsung.com', 'CTV', TRUE),
('reviewer.mike', 'Mike Johnson', '$2b$10$dummy.hash.for.reviewer', 'reviewer', 'reviewer.mike@samsung.com', 'ENT_TV', TRUE),
('viewer.anna', 'Anna Park', '$2b$10$dummy.hash.for.viewer', 'viewer', 'viewer.anna@samsung.com', 'ENT_SM', TRUE),
('admin.david', 'David Chen', '$2b$10$dummy.hash.for.admin', 'admin', 'admin.david@samsung.com', 'CTV', TRUE);

-- Insert branch data (Samsung development branches)
INSERT INTO `Branches` (branch_name, branch_type, description, is_active) VALUES
('Trunk_2025_MonitorRC_MP_Prj', 'release', 'Main trunk for 2025 Monitor RC release', TRUE),
('Trunk_2024_MonitorRC_MP_Prj', 'release', 'Main trunk for 2024 Monitor RC release', TRUE),
('Trunk_2023_MonitorRC_MP_Prj', 'release', 'Main trunk for 2023 Monitor RC release', TRUE),
('SmartMonitor_2025_MP_Prj', 'development', 'Smart Monitor 2025 project branch', TRUE),
('OSU_2025_SM_TV_Ready_MP_Prj', 'development', 'OSU 2025 Smart Monitor TV Ready branch', TRUE),
('Feature_GameBar_2025', 'feature', 'Gaming features development branch for 2025', TRUE),
('CTV_Platform_24Y', 'release', 'CTV Platform 2024 release branch', TRUE),
('ENT_TV_2025_Release', 'release', 'Enterprise TV 2025 release branch', TRUE),
('PowerSave_Feature_Branch', 'feature', 'Power saving features development', TRUE),
('Audio_Enhancement_2025', 'feature', 'Audio enhancement features for 2025', TRUE);

-- Insert model data (Samsung monitor and TV models)
INSERT INTO `Models` (model_name, product_category, specifications, is_active) VALUES
-- 2025 Models (F series)
('M80F', 'Smart Monitors', '{"year": "2025", "size": "32inch", "resolution": "4K", "gaming": true, "series": "F"}', TRUE),
('M70F', 'Smart Monitors', '{"year": "2025", "size": "27inch", "resolution": "4K", "gaming": true, "series": "F"}', TRUE),
('M50F', 'Smart Monitors', '{"year": "2025", "size": "24inch", "resolution": "FHD", "gaming": false, "series": "F"}', TRUE),
('G95SF', 'Smart Monitors', '{"year": "2025", "size": "49inch", "resolution": "5K", "gaming": true, "curved": true, "series": "F"}', TRUE),
-- 2024 Models (D series)
('M80D', 'Smart Monitors', '{"year": "2024", "size": "32inch", "resolution": "4K", "gaming": true, "series": "D"}', TRUE),
('M70D', 'Smart Monitors', '{"year": "2024", "size": "27inch", "resolution": "4K", "gaming": true, "series": "D"}', TRUE),
('M50D', 'Smart Monitors', '{"year": "2024", "size": "24inch", "resolution": "FHD", "gaming": false, "series": "D"}', TRUE),
('G95SD', 'Smart Monitors', '{"year": "2024", "size": "49inch", "resolution": "5K", "gaming": true, "curved": true, "series": "D"}', TRUE),
('G85SD', 'Smart Monitors', '{"year": "2024", "size": "34inch", "resolution": "UWQHD", "gaming": true, "curved": true, "series": "D"}', TRUE),
-- 2023 Models (C series)
('M80C', 'Smart Monitors', '{"year": "2023", "size": "32inch", "resolution": "4K", "gaming": true, "series": "C"}', TRUE),
('M70C', 'Smart Monitors', '{"year": "2023", "size": "27inch", "resolution": "4K", "gaming": true, "series": "C"}', TRUE),
('M50C', 'Smart Monitors', '{"year": "2023", "size": "24inch", "resolution": "FHD", "gaming": false, "series": "C"}', TRUE),
('G95SC', 'Smart Monitors', '{"year": "2023", "size": "49inch", "resolution": "5K", "gaming": true, "curved": true, "series": "C"}', TRUE),
-- CTV Models
('S90PC', 'CTV', '{"year": "2023", "size": "55inch", "resolution": "4K", "smart_tv": true, "series": "C"}', TRUE),
('S95PD', 'CTV', '{"year": "2024", "size": "65inch", "resolution": "4K", "smart_tv": true, "series": "D"}', TRUE),
-- ENT_TV Models
('QM98F', 'ENT_TV', '{"year": "2025", "size": "98inch", "resolution": "4K", "commercial": true, "series": "F"}', TRUE),
('QM85D', 'ENT_TV', '{"year": "2024", "size": "85inch", "resolution": "4K", "commercial": true, "series": "D"}', TRUE);

-- Insert Branch-Model mappings (CRITICAL: defines which models exist in which branches)
INSERT INTO `Branch_Model_Mapping` (branch_id, model_id, is_available) VALUES
-- 2025 Trunk - has 2025 F series + some 2024 D series for compatibility
(1, 1, TRUE), (1, 2, TRUE), (1, 3, TRUE), (1, 4, TRUE),  -- All F series in 2025 trunk
(1, 5, TRUE), (1, 6, TRUE), (1, 8, TRUE),                 -- Some D series for compatibility
(1, 16, TRUE),                                             -- QM98F ENT_TV

-- 2024 Trunk - has 2024 D series + some 2023 C series for compatibility  
(2, 5, TRUE), (2, 6, TRUE), (2, 7, TRUE), (2, 8, TRUE), (2, 9, TRUE),  -- All D series
(2, 10, TRUE), (2, 11, TRUE), (2, 13, TRUE),                            -- Some C series
(2, 15, TRUE), (2, 17, TRUE),                                            -- CTV and ENT_TV D series

-- 2023 Trunk - only 2023 C series models
(3, 10, TRUE), (3, 11, TRUE), (3, 12, TRUE), (3, 13, TRUE),  -- All C series monitors
(3, 14, TRUE),                                                -- S90PC CTV

-- SmartMonitor 2025 - Focus on 2025 F series smart monitors
(4, 1, TRUE), (4, 2, TRUE), (4, 3, TRUE), (4, 4, TRUE),     -- All F series
(4, 5, TRUE), (4, 8, TRUE),                                  -- Some premium D series

-- OSU 2025 - Mixed models for testing
(5, 1, TRUE), (5, 5, TRUE), (5, 8, TRUE), (5, 13, TRUE),    -- Mixed years for comparison

-- Gaming Feature Branch - Gaming monitors only
(6, 1, TRUE), (6, 2, TRUE), (6, 4, TRUE),                   -- F series gaming
(6, 5, TRUE), (6, 6, TRUE), (6, 8, TRUE), (6, 9, TRUE),     -- D series gaming
(6, 10, TRUE), (6, 11, TRUE), (6, 13, TRUE),                -- C series gaming

-- CTV Platform - CTV models only  
(7, 14, TRUE), (7, 15, TRUE),                                -- CTV models

-- ENT_TV Release - ENT_TV models only
(8, 16, TRUE), (8, 17, TRUE);                                -- ENT_TV models

-- Insert FMS Keys (sample feature management keys)
INSERT INTO `FMS_Keys` (key_name, work_assignment, work_assignment_owner, key_category, data_type, description, has_differences) VALUES
('com.samsung.gamebar.responsetime', 'TP_GameBar', 'John Smith', 'Gaming', 'boolean', 'Enable gaming response time optimization for low latency gaming', TRUE),
('com.samsung.gamebar.gamemode', 'TP_GameBar', 'John Smith', 'Gaming', 'boolean', 'Automatic game mode detection and switching', TRUE),
('com.samsung.display.powersave.level', 'TP_PowerSave', 'Jane Doe', 'Power Management', 'integer', 'Power save mode level (1=Low, 2=Medium, 3=High)', TRUE),
('com.samsung.display.powersave.auto', 'TP_PowerSave', 'Jane Doe', 'Power Management', 'boolean', 'Automatic power save mode based on usage', FALSE),
('com.samsung.audio.enhancement.enable', 'TP_Sound', 'Mike Johnson', 'Audio', 'boolean', 'Enable audio enhancement features', TRUE),
('com.samsung.audio.surround.mode', 'TP_Sound', 'Mike Johnson', 'Audio', 'string', 'Surround sound mode configuration', TRUE),
('com.samsung.display.brightness.auto', 'TP_Display', 'Sarah Kim', 'Display', 'boolean', 'Automatic brightness adjustment based on ambient light', FALSE),
('com.samsung.smart.features.voice', 'TP_SmartTV', 'David Lee', 'Smart Features', 'boolean', 'Voice control feature enablement', TRUE),
('com.samsung.connectivity.hdmi.ports', 'TP_Hardware', 'Lisa Chen', 'Hardware', 'integer', 'Number of available HDMI ports', TRUE),
('com.samsung.enterprise.kiosk.mode', 'TP_Enterprise', 'Tom Wilson', 'Enterprise', 'boolean', 'Kiosk mode for commercial displays', TRUE);

-- Insert sample projects
INSERT INTO `Projects` (title, description, admin_username, refresh_schedule, status) VALUES
('SM_GameBar_Keys_Review_2025', 'Comprehensive review of gaming-related FMS keys for 2025 Smart Monitor lineup', 'admin.john', 'Weekly', 'active'),
('CTV_Platform_Validation_24Y', 'Validation of CTV platform keys for 2024 year models', 'admin.david', 'Daily', 'active'),
('Power_Management_Optimization', 'Review and optimization of power management features across all product lines', 'admin.john', 'Monthly', 'active');

-- Insert project participants
INSERT INTO `Project_Participants` (project_id, user_username, added_by, participant_role) VALUES
(1, 'admin.john', 'admin.john', 'admin'),
(1, 'reviewer.sarah', 'admin.john', 'reviewer'),
(1, 'reviewer.mike', 'admin.john', 'reviewer'),
(1, 'viewer.anna', 'admin.john', 'viewer'),
(2, 'admin.david', 'admin.david', 'admin'),
(2, 'reviewer.sarah', 'admin.david', 'reviewer'),
(3, 'admin.john', 'admin.john', 'admin'),
(3, 'reviewer.mike', 'admin.john', 'reviewer');

-- Insert sample groups
INSERT INTO `Groups` (project_id, name, comparison_type) VALUES
(1, 'Gaming_Monitor_2025_vs_2024', '3-way'),
(1, 'Premium_Gaming_Features', '2-way'),
(2, 'CTV_Core_Features', '4-way'),
(3, 'Power_Save_Modes', '2-way vs 2-way');

-- Insert group-branch mappings
INSERT INTO `Group_Branch_Mapping` (group_id, branch_role, branch_id, sort_order) VALUES
-- Group 1: Gaming_Monitor_2025_vs_2024 (3-way)
(1, 'target', 1, 1),      -- Trunk_2025_MonitorRC_MP_Prj
(1, 'reference1', 2, 2),  -- Trunk_2024_MonitorRC_MP_Prj  
(1, 'reference2', 6, 3),  -- Feature_GameBar_2025

-- Group 2: Premium_Gaming_Features (2-way)
(2, 'target', 1, 1),      -- Trunk_2025_MonitorRC_MP_Prj
(2, 'reference1', 6, 2),  -- Feature_GameBar_2025

-- Group 3: CTV_Core_Features (4-way)
(3, 'target', 7, 1),      -- CTV_Platform_24Y
(3, 'reference1', 2, 2),  -- Trunk_2024_MonitorRC_MP_Prj
(3, 'reference2', 3, 3),  -- Trunk_2023_MonitorRC_MP_Prj
(3, 'reference3', 4, 4),  -- SmartMonitor_2025_MP_Prj

-- Group 4: Power_Save_Modes (2-way vs 2-way)
(4, 'target', 1, 1),      -- Trunk_2025_MonitorRC_MP_Prj (Target 1)
(4, 'reference1', 9, 2),  -- PowerSave_Feature_Branch (Ref 1)
(4, 'reference2', 2, 3),  -- Trunk_2024_MonitorRC_MP_Prj (Target 2)  
(4, 'reference3', 3, 4);  -- Trunk_2023_MonitorRC_MP_Prj (Ref 2)

-- Insert group-branch-model mappings (specific models used in each group)
INSERT INTO `Group_Branch_Model_Map` (gb_id, model_id) VALUES
-- Group 1: Gaming monitors from appropriate branches
(1, 1), (1, 2), (1, 4),   -- F series from 2025 trunk
(2, 5), (2, 6), (2, 8),   -- D series from 2024 trunk  
(3, 1), (3, 2), (3, 4),   -- F series from gaming branch

-- Group 2: Premium gaming models
(4, 1), (4, 4),           -- Premium F series from 2025 trunk
(5, 1), (5, 4),           -- Same models from gaming branch

-- Group 3: CTV models (demonstrating cross-platform comparison)
(6, 15), (6, 16),         -- CTV models from CTV branch
(7, 16),                  -- D series CTV from 2024 trunk
(8, 15),                  -- C series CTV from 2023 trunk  
(9, 1), (9, 2);           -- Smart monitors for comparison

-- Insert sample key reviews (demonstrating different statuses and values)
INSERT INTO `Key_Reviews` (fms_key_id, gbm_id, target_val, ref1_val, ref2_val, ref3_val, comment, status, kona_ids, cl_numbers, reviewed_by_username) VALUES
-- Gaming response time key across different models
(1, 1, 'True', 'True', 'False', NULL, 'Gaming feature enabled for 2025 F series', 'reviewed', 'RQ250607-0239,RQ250608-0240', '1980283,1980284', 'reviewer.sarah'),
(1, 2, 'True', 'False', 'False', NULL, 'Needs verification with gaming team', 'needs_discussion', 'RQ250609-0241', '1980285', 'reviewer.mike'),
(1, 3, 'True', 'True', 'True', NULL, 'Consistent across all gaming branches', 'reviewed', NULL, NULL, 'reviewer.sarah'),

-- Power save levels
(3, 1, '3', '2', '1', NULL, 'Enhanced power saving in latest models', 'reviewed', 'RQ250610-0242', '1980286', 'reviewer.mike'),
(3, 2, '2', '2', '1', NULL, 'Standard power save configuration', 'pending', NULL, NULL, NULL),

-- HDMI ports (hardware difference)
(9, 1, '4', '2', '2', NULL, 'Upgraded to 4 HDMI ports in F series', 'dev_response', 'RQ250611-0243', '1980287,1980288', 'reviewer.sarah'),
(9, 2, '2', '2', '2', NULL, 'Consistent HDMI port count across D series', 'reviewed', NULL, NULL, 'reviewer.mike');

-- Display success message
SELECT 'Sample data inserted successfully!' as Status;
SELECT 'Database is ready for testing!' as Message;
