-- Add Missing Data for Samsung FMS Portal
-- Run this if debug_database.sql shows missing data

USE samsung_fms_portal;

-- =====================================================
-- ADD FMS KEYS (if missing)
-- =====================================================

-- Check if FMS_Keys is empty, then insert
INSERT IGNORE INTO `FMS_Keys` (key_name, work_assignment, work_assignment_owner, key_category, data_type, has_differences) VALUES
('gamebar.responsetime', 'TP_GameBar', 'John Smith', 'Gaming', 'boolean', TRUE),
('display.hdmi.numports', 'TP_Display', 'Jane Doe', 'Hardware', 'integer', TRUE),
('audio.dolby.support', 'TP_Audio', 'Mike Johnson', 'Audio', 'boolean', TRUE),
('platform.os.version', 'TP_Platform', 'Sarah Lee', 'Software', 'string', TRUE),
('network.wifi.standard', 'TP_Network', 'David Kim', 'Connectivity', 'string', FALSE),
('display.resolution.4k', 'TP_Display', 'Jane Doe', 'Hardware', 'boolean', TRUE),
('gamebar.hdr.support', 'TP_GameBar', 'John Smith', 'Gaming', 'boolean', TRUE),
('audio.soundbar.connection', 'TP_Audio', 'Mike Johnson', 'Audio', 'boolean', TRUE);

-- =====================================================
-- ADD SAMPLE KEY REVIEWS (if missing)
-- =====================================================

-- Add some sample key reviews for the gaming monitors group
-- These link FMS keys to specific Group-Branch-Model combinations

-- First, let's insert some key reviews for project 1, group 1 (Gaming monitors)
-- We need to find the gbm_ids first

-- For gamebar.responsetime key in different models
INSERT IGNORE INTO `Key_Reviews` 
(fms_key_id, gbm_id, target_val, ref1_val, ref2_val, comment, status, reviewed_by_username)
SELECT 
    1 as fms_key_id,  -- gamebar.responsetime
    gbmm.gbm_id,
    'True' as target_val,
    'False' as ref1_val, 
    'True' as ref2_val,
    'Gaming monitors should have fast response time enabled' as comment,
    'pending' as status,
    'admin.john' as reviewed_by_username
FROM `Group_Branch_Model_Map` gbmm
JOIN `Group_Branch_Mapping` gbm ON gbmm.gb_id = gbm.gb_id
JOIN `Groups` g ON gbm.group_id = g.group_id
JOIN `Models` m ON gbmm.model_id = m.model_id
WHERE g.project_id = 1 
AND g.name = 'Group_25Y_SM_Gaming'
AND m.model_name IN ('G95SD', 'G97NC', 'S90PC')
LIMIT 3;

-- For display.hdmi.numports key
INSERT IGNORE INTO `Key_Reviews` 
(fms_key_id, gbm_id, target_val, ref1_val, ref2_val, comment, status, reviewed_by_username)
SELECT 
    2 as fms_key_id,  -- display.hdmi.numports
    gbmm.gbm_id,
    '4' as target_val,
    '2' as ref1_val,
    '4' as ref2_val,
    'High-end monitors should have 4 HDMI ports' as comment,
    'reviewed' as status,
    'reviewer.jane' as reviewed_by_username
FROM `Group_Branch_Model_Map` gbmm
JOIN `Group_Branch_Mapping` gbm ON gbmm.gb_id = gbm.gb_id
JOIN `Groups` g ON gbm.group_id = g.group_id
JOIN `Models` m ON gbmm.model_id = m.model_id
WHERE g.project_id = 1 
AND g.name = 'Group_25Y_SM_Gaming'
AND m.model_name IN ('G95SD', 'G97NC')
LIMIT 2;

-- =====================================================
-- VERIFICATION
-- =====================================================

-- Check if data was added
SELECT 'Added FMS Keys:' as Info, COUNT(*) as Count FROM `FMS_Keys`;
SELECT 'Added Key Reviews:' as Info, COUNT(*) as Count FROM `Key_Reviews`;

-- Show sample data that should appear in frontend
SELECT 
    fk.key_name,
    g.name as group_name,
    m.model_name,
    kr.target_val,
    kr.ref1_val,
    kr.status,
    kr.comment
FROM `Key_Reviews` kr
JOIN `FMS_Keys` fk ON kr.fms_key_id = fk.fms_key_id
JOIN `Group_Branch_Model_Map` gbmm ON kr.gbm_id = gbmm.gbm_id
JOIN `Models` m ON gbmm.model_id = m.model_id
JOIN `Group_Branch_Mapping` gbm ON gbmm.gb_id = gbm.gb_id
JOIN `Groups` g ON gbm.group_id = g.group_id
WHERE g.project_id = 1
ORDER BY fk.key_name, m.model_name;

SELECT 'Data insertion completed! Try refreshing the frontend.' as Status;
