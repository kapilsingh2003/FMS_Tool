-- Debug Queries for Samsung FMS Portal
-- Run these to check if data exists in your work laptop database

USE samsung_fms_portal;

-- =====================================================
-- CHECK BASIC DATA EXISTENCE
-- =====================================================

SELECT 'Checking basic table data...' as Status;

-- Check Users
SELECT 'Users count:' as Table_Name, COUNT(*) as Record_Count FROM `Users`;
SELECT username, name, role FROM `Users`;

-- Check Projects  
SELECT 'Projects count:' as Table_Name, COUNT(*) as Record_Count FROM `Projects`;
SELECT project_id, title, admin_username FROM `Projects`;

-- Check Groups
SELECT 'Groups count:' as Table_Name, COUNT(*) as Record_Count FROM `Groups`;
SELECT group_id, project_id, name, comparison_type FROM `Groups`;

-- Check Branches
SELECT 'Branches count:' as Table_Name, COUNT(*) as Record_Count FROM `Branches`;
SELECT branch_id, branch_name, branch_type FROM `Branches`;

-- Check Models
SELECT 'Models count:' as Table_Name, COUNT(*) as Record_Count FROM `Models`;
SELECT model_id, model_name, product_category, chipset FROM `Models`;

-- =====================================================
-- CHECK RELATIONSHIP MAPPINGS
-- =====================================================

SELECT 'Checking relationship tables...' as Status;

-- Check Branch-Model Mappings
SELECT 'Branch_Model_Mapping count:' as Table_Name, COUNT(*) as Record_Count FROM `Branch_Model_Mapping`;
SELECT bm.bm_id, b.branch_name, m.model_name 
FROM `Branch_Model_Mapping` bm
JOIN `Branches` b ON bm.branch_id = b.branch_id
JOIN `Models` m ON bm.model_id = m.model_id
LIMIT 10;

-- Check Group-Branch Mappings
SELECT 'Group_Branch_Mapping count:' as Table_Name, COUNT(*) as Record_Count FROM `Group_Branch_Mapping`;
SELECT gbm.gb_id, g.name as group_name, gbm.branch_role, b.branch_name
FROM `Group_Branch_Mapping` gbm
JOIN `Groups` g ON gbm.group_id = g.group_id
JOIN `Branches` b ON gbm.branch_id = b.branch_id;

-- Check Group-Branch-Model Mappings
SELECT 'Group_Branch_Model_Map count:' as Table_Name, COUNT(*) as Record_Count FROM `Group_Branch_Model_Map`;
SELECT gbmm.gbm_id, gbm.gb_id, m.model_name
FROM `Group_Branch_Model_Map` gbmm
JOIN `Group_Branch_Mapping` gbm ON gbmm.gb_id = gbm.gb_id
JOIN `Models` m ON gbmm.model_id = m.model_id
LIMIT 10;

-- =====================================================
-- CHECK FMS KEYS AND REVIEWS
-- =====================================================

SELECT 'Checking FMS Keys and Reviews...' as Status;

-- Check FMS Keys
SELECT 'FMS_Keys count:' as Table_Name, COUNT(*) as Record_Count FROM `FMS_Keys`;
SELECT fms_key_id, key_name, work_assignment, work_assignment_owner FROM `FMS_Keys`;

-- Check Key Reviews
SELECT 'Key_Reviews count:' as Table_Name, COUNT(*) as Record_Count FROM `Key_Reviews`;
SELECT kr.key_review_id, fk.key_name, kr.status, kr.comment
FROM `Key_Reviews` kr
JOIN `FMS_Keys` fk ON kr.fms_key_id = fk.fms_key_id
LIMIT 10;

-- =====================================================
-- SPECIFIC CHECKS FOR PROJECT ID = 1
-- =====================================================

SELECT 'Checking Project ID = 1 specifically...' as Status;

-- Get project 1 details
SELECT * FROM `Projects` WHERE project_id = 1;

-- Get groups for project 1
SELECT g.group_id, g.name, g.comparison_type 
FROM `Groups` g 
WHERE g.project_id = 1;

-- Check what the API query should return (hierarchical data for project 1)
SELECT 
    fk.fms_key_id,
    fk.key_name,
    fk.work_assignment,
    fk.work_assignment_owner,
    g.group_id,
    g.name as group_name,
    m.model_id,
    m.model_name,
    kr.key_review_id,
    kr.target_val,
    kr.ref1_val,
    kr.status
FROM `Key_Reviews` kr
JOIN `FMS_Keys` fk ON kr.fms_key_id = fk.fms_key_id
JOIN `Group_Branch_Model_Map` gbmm ON kr.gbm_id = gbmm.gbm_id
JOIN `Models` m ON gbmm.model_id = m.model_id
JOIN `Group_Branch_Mapping` gbm ON gbmm.gb_id = gbm.gb_id
JOIN `Groups` g ON gbm.group_id = g.group_id
WHERE g.project_id = 1
ORDER BY fk.work_assignment, fk.key_name, g.group_id, m.model_name;

-- =====================================================
-- FINAL SUMMARY
-- =====================================================

SELECT 'Debug Summary - Check these results:' as Summary;
SELECT 'If any count is 0, that table is missing data' as Note1;
SELECT 'Key_Reviews table is most likely empty - this causes empty array in frontend' as Note2;
SELECT 'FMS_Keys table might also be empty' as Note3;
