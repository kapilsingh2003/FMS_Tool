const { executeQuery } = require('../config/database');

class Comment {
    // Create a new comment
    // isAdmin: if true, the comment is auto-verified
    static async create(commentData, isAdmin = false) {
        const { key_review_id, comment_text, commented_by_username } = commentData;

        // If user is admin, auto-verify the comment
        if (isAdmin) {
            const query = `
              INSERT INTO \`Comments\` (key_review_id, comment_text, commented_by_username, verification_status, verified_by_username, verified_at)
              VALUES (?, ?, ?, 'verified', ?, CURRENT_TIMESTAMP)
            `;
            const result = await executeQuery(query, [key_review_id, comment_text, commented_by_username, commented_by_username]);
            return { comment_id: result.insertId, ...commentData, verification_status: 'verified' };
        } else {
            const query = `
              INSERT INTO \`Comments\` (key_review_id, comment_text, commented_by_username, verification_status)
              VALUES (?, ?, ?, 'pending')
            `;
            const result = await executeQuery(query, [key_review_id, comment_text, commented_by_username]);
            return { comment_id: result.insertId, ...commentData, verification_status: 'pending' };
        }
    }

    // Get all comments for a key review
    static async getByKeyReview(keyReviewId) {
        const query = `
      SELECT 
        c.*,
        u.name as commented_by_name,
        u.team as commented_by_team,
        v.name as verified_by_name
      FROM \`Comments\` c
      JOIN \`Users\` u ON c.commented_by_username = u.username
      LEFT JOIN \`Users\` v ON c.verified_by_username = v.username
      WHERE c.key_review_id = ?
      ORDER BY c.created_at ASC
    `;

        return await executeQuery(query, [keyReviewId]);
    }

    // Get a specific comment by ID
    static async getById(commentId) {
        const query = `
      SELECT 
        c.*,
        u.name as commented_by_name,
        u.team as commented_by_team,
        v.name as verified_by_name
      FROM \`Comments\` c
      JOIN \`Users\` u ON c.commented_by_username = u.username
      LEFT JOIN \`Users\` v ON c.verified_by_username = v.username
      WHERE c.comment_id = ?
    `;

        const result = await executeQuery(query, [commentId]);
        return result[0] || null;
    }

    // Update a comment
    static async update(commentId, updateData) {
        const { comment_text } = updateData;

        const query = `
      UPDATE \`Comments\` 
      SET comment_text = ?, updated_at = CURRENT_TIMESTAMP
      WHERE comment_id = ?
    `;

        const result = await executeQuery(query, [comment_text, commentId]);
        return result.affectedRows > 0;
    }

    // Delete a comment
    static async delete(commentId) {
        const query = 'DELETE FROM \`Comments\` WHERE comment_id = ?';
        const result = await executeQuery(query, [commentId]);
        return result.affectedRows > 0;
    }

    // Get latest comment for a key review (for display in main table)
    static async getLatestByKeyReview(keyReviewId) {
        const query = `
      SELECT 
        c.*,
        u.name as commented_by_name,
        u.team as commented_by_team
      FROM \`Comments\` c
      JOIN \`Users\` u ON c.commented_by_username = u.username
      WHERE c.key_review_id = ?
      ORDER BY c.created_at DESC
      LIMIT 1
    `;

        const result = await executeQuery(query, [keyReviewId]);
        return result[0] || null;
    }

    // Get comment count for a key review
    static async getCountByKeyReview(keyReviewId) {
        const query = 'SELECT COUNT(*) as comment_count FROM \`Comments\` WHERE key_review_id = ?';
        const result = await executeQuery(query, [keyReviewId]);
        return result[0].comment_count;
    }

    // Check if user can edit/delete comment (only the author can edit/delete)
    static async canUserModify(commentId, username) {
        const query = 'SELECT commented_by_username FROM \`Comments\` WHERE comment_id = ?';
        const result = await executeQuery(query, [commentId]);

        if (result.length === 0) {
            return false; // Comment doesn't exist
        }

        return result[0].commented_by_username === username;
    }

    // Verify a single comment
    static async verify(commentId, verifiedByUsername) {
        const query = `
          UPDATE \`Comments\` 
          SET verification_status = 'verified', 
              verified_by_username = ?, 
              verified_at = CURRENT_TIMESTAMP
          WHERE comment_id = ? AND verification_status = 'pending'
        `;
        const result = await executeQuery(query, [verifiedByUsername, commentId]);
        return result.affectedRows > 0;
    }

    // Verify all comments for a key review
    static async verifyAllForKeyReview(keyReviewId, verifiedByUsername) {
        const query = `
          UPDATE \`Comments\` 
          SET verification_status = 'verified', 
              verified_by_username = ?, 
              verified_at = CURRENT_TIMESTAMP
          WHERE key_review_id = ? AND verification_status = 'pending'
        `;
        const result = await executeQuery(query, [verifiedByUsername, keyReviewId]);
        return result.affectedRows;
    }

    // Bulk verify comments by IDs
    static async verifyBulk(commentIds, verifiedByUsername) {
        if (!commentIds || commentIds.length === 0) return 0;
        
        const placeholders = commentIds.map(() => '?').join(',');
        const query = `
          UPDATE \`Comments\` 
          SET verification_status = 'verified', 
              verified_by_username = ?, 
              verified_at = CURRENT_TIMESTAMP
          WHERE comment_id IN (${placeholders}) AND verification_status = 'pending'
        `;
        const result = await executeQuery(query, [verifiedByUsername, ...commentIds]);
        return result.affectedRows;
    }

    // Bulk verify all comments for multiple key reviews
    static async verifyAllForKeyReviews(keyReviewIds, verifiedByUsername) {
        if (!keyReviewIds || keyReviewIds.length === 0) return 0;
        
        const placeholders = keyReviewIds.map(() => '?').join(',');
        const query = `
          UPDATE \`Comments\` 
          SET verification_status = 'verified', 
              verified_by_username = ?, 
              verified_at = CURRENT_TIMESTAMP
          WHERE key_review_id IN (${placeholders}) AND verification_status = 'pending'
        `;
        const result = await executeQuery(query, [verifiedByUsername, ...keyReviewIds]);
        return result.affectedRows;
    }

    // Get only verified comments for a key review (for All Comments section)
    static async getVerifiedByKeyReview(keyReviewId) {
        const query = `
          SELECT 
            c.*,
            u.name as commented_by_name,
            u.team as commented_by_team,
            v.name as verified_by_name
          FROM \`Comments\` c
          JOIN \`Users\` u ON c.commented_by_username = u.username
          LEFT JOIN \`Users\` v ON c.verified_by_username = v.username
          WHERE c.key_review_id = ? AND c.verification_status = 'verified'
          ORDER BY c.created_at ASC
        `;

        return await executeQuery(query, [keyReviewId]);
    }

    // Get pending comments count for a project (for admin dashboard)
    static async getPendingCountByProject(projectId) {
        const query = `
          SELECT COUNT(*) as pending_count
          FROM \`Comments\` c
          JOIN \`Key_Reviews\` kr ON c.key_review_id = kr.key_review_id
          JOIN \`grps\` g ON kr.group_id = g.group_id
          WHERE g.project_id = ? AND c.verification_status = 'pending'
        `;
        const result = await executeQuery(query, [projectId]);
        return result[0].pending_count;
    }

    // Get project ID for a comment (to check admin permissions)
    static async getProjectIdForComment(commentId) {
        const query = `
          SELECT g.project_id
          FROM \`Comments\` c
          JOIN \`Key_Reviews\` kr ON c.key_review_id = kr.key_review_id
          JOIN \`grps\` g ON kr.group_id = g.group_id
          WHERE c.comment_id = ?
        `;
        const result = await executeQuery(query, [commentId]);
        return result[0]?.project_id || null;
    }
}

module.exports = Comment;

