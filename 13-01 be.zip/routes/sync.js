// Sync Routes - Samsung FMS Portal (System-only routes for syncing keys, models, branches)
const express = require('express');
const { spawn } = require('child_process');
const path = require('path');
const { executeQuery } = require('../config/database');
const { authenticateToken } = require('./auth');
const router = express.Router();

// Middleware to check if user is system
const requireSystemUser = (req, res, next) => {
    if (req.user.username !== 'system') {
        return res.status(403).json({
            success: false,
            message: 'Access denied. Only system user can access this resource.'
        });
    }
    next();
};

// Apply authentication middleware to all routes
router.use(authenticateToken);
router.use(requireSystemUser);

// Helper function to run Python script with timeout
const runPythonScript = (scriptPath, timeoutMs = 130000) => {
    return new Promise((resolve, reject) => {
        const pythonProcess = spawn('python', [scriptPath], {
            cwd: path.dirname(scriptPath)
        });

        let stdout = '';
        let stderr = '';
        let timedOut = false;

        // Set timeout
        const timeout = setTimeout(() => {
            timedOut = true;
            pythonProcess.kill('SIGTERM');
            reject(new Error(`Script timed out after ${timeoutMs / 1000} seconds`));
        }, timeoutMs);

        pythonProcess.stdout.on('data', (data) => {
            stdout += data.toString();
            console.log(`[Python stdout]: ${data.toString()}`);
        });

        pythonProcess.stderr.on('data', (data) => {
            stderr += data.toString();
            console.error(`[Python stderr]: ${data.toString()}`);
        });

        pythonProcess.on('close', (code) => {
            clearTimeout(timeout);
            if (timedOut) return;

            if (code === 0) {
                resolve({
                    success: true,
                    output: stdout,
                    exitCode: code
                });
            } else {
                reject(new Error(`Script exited with code ${code}: ${stderr || stdout}`));
            }
        });

        pythonProcess.on('error', (err) => {
            clearTimeout(timeout);
            reject(new Error(`Failed to start Python script: ${err.message}`));
        });
    });
};

// GET /api/sync/keys - Get all FMS keys
router.get('/keys', async (req, res) => {
    try {
        const keys = await executeQuery(`
            SELECT 
                fms_key_id,
                key_name,
                work_assignment,
                work_assignment_owner,
                description,
                has_differences,
                created_at
            FROM FMS_Keys
            ORDER BY key_name ASC
        `);

        res.json({
            success: true,
            data: keys,
            count: keys.length
        });
    } catch (error) {
        console.error('Get keys error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to fetch keys'
        });
    }
});

// GET /api/sync/models - Get all models
router.get('/models', async (req, res) => {
    try {
        const models = await executeQuery(`
            SELECT 
                model_id,
                model_name,
                product_category
            FROM Models
            ORDER BY model_name ASC
        `);

        res.json({
            success: true,
            data: models,
            count: models.length
        });
    } catch (error) {
        console.error('Get models error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to fetch models'
        });
    }
});

// GET /api/sync/branches - Get all branches
router.get('/branches', async (req, res) => {
    try {
        const branches = await executeQuery(`
            SELECT 
                branch_id,
                branch_name
            FROM Branches
            ORDER BY branch_name ASC
        `);

        res.json({
            success: true,
            data: branches,
            count: branches.length
        });
    } catch (error) {
        console.error('Get branches error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to fetch branches'
        });
    }
});

// POST /api/sync/keys/run - Run keys sync script
router.post('/keys/run', async (req, res) => {
    try {
        console.log('Starting keys sync script...');
        const scriptPath = path.resolve(__dirname, '../../sample key review data/keys.py');
        
        const result = await runPythonScript(scriptPath, 130000);
        
        // Get updated key count
        const countResult = await executeQuery('SELECT COUNT(*) as count FROM FMS_Keys');
        
        res.json({
            success: true,
            message: 'Keys sync completed successfully',
            output: result.output,
            keyCount: countResult[0].count
        });
    } catch (error) {
        console.error('Keys sync error:', error);
        res.status(500).json({
            success: false,
            message: error.message || 'Keys sync failed',
            timedOut: error.message.includes('timed out')
        });
    }
});

// POST /api/sync/models/run - Run models sync script
router.post('/models/run', async (req, res) => {
    try {
        console.log('Starting models sync script...');
        const scriptPath = path.resolve(__dirname, '../../sample key review data/models.py');
        
        const result = await runPythonScript(scriptPath, 130000);
        
        // Get updated model count
        const countResult = await executeQuery('SELECT COUNT(*) as count FROM Models');
        
        res.json({
            success: true,
            message: 'Models sync completed successfully',
            output: result.output,
            modelCount: countResult[0].count
        });
    } catch (error) {
        console.error('Models sync error:', error);
        res.status(500).json({
            success: false,
            message: error.message || 'Models sync failed',
            timedOut: error.message.includes('timed out')
        });
    }
});

// POST /api/sync/branches/run - Run branches sync script
router.post('/branches/run', async (req, res) => {
    try {
        console.log('Starting branches sync script...');
        const scriptPath = path.resolve(__dirname, '../../sample key review data/branches.py');
        
        const result = await runPythonScript(scriptPath, 130000);
        
        // Get updated branch count
        const countResult = await executeQuery('SELECT COUNT(*) as count FROM Branches');
        
        res.json({
            success: true,
            message: 'Branches sync completed successfully',
            output: result.output,
            branchCount: countResult[0].count
        });
    } catch (error) {
        console.error('Branches sync error:', error);
        res.status(500).json({
            success: false,
            message: error.message || 'Branches sync failed',
            timedOut: error.message.includes('timed out')
        });
    }
});

// GET /api/sync/stats - Get sync statistics
router.get('/stats', async (req, res) => {
    try {
        const [keysCount, modelsCount, branchesCount] = await Promise.all([
            executeQuery('SELECT COUNT(*) as count FROM FMS_Keys'),
            executeQuery('SELECT COUNT(*) as count FROM Models'),
            executeQuery('SELECT COUNT(*) as count FROM Branches')
        ]);

        res.json({
            success: true,
            data: {
                keys: keysCount[0].count,
                models: modelsCount[0].count,
                branches: branchesCount[0].count
            }
        });
    } catch (error) {
        console.error('Get sync stats error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to fetch sync statistics'
        });
    }
});

module.exports = router;

