const express = require('express');
const router = express.Router();
const Comment = require('../models/Comment');
const User = require('../models/User');
const { executeQuery } = require('../config/database');
const { authenticateToken } = require('./auth');

// Apply authentication middleware to all routes
router.use(authenticateToken);

// Helper function to check if user is admin of a project
async function isProjectAdmin(username, projectId) {
    // Check if user is the project creator
    const projectQuery = 'SELECT admin_username FROM Projects WHERE project_id = ?';
    const projectResult = await executeQuery(projectQuery, [projectId]);
    if (projectResult.length > 0 && projectResult[0].admin_username === username) {
        return true;
    }
    
    // Check if user is a participant with admin role
    const participantQuery = `
        SELECT participant_role FROM Project_Participants 
        WHERE project_id = ? AND user_username = ? AND participant_role = 'admin'
    `;
    const participantResult = await executeQuery(participantQuery, [projectId, username]);
    return participantResult.length > 0;
}

// Helper function to get project ID from key_review_id
async function getProjectIdFromKeyReview(keyReviewId) {
    const query = `
        SELECT g.project_id
        FROM Key_Reviews kr
        JOIN grps g ON kr.group_id = g.group_id
        WHERE kr.key_review_id = ?
    `;
    const result = await executeQuery(query, [keyReviewId]);
    return result[0]?.project_id || null;
}

// GET /api/comments/:keyReviewId - Get all comments for a key review
router.get('/:keyReviewId', async (req, res) => {
    try {
        const { keyReviewId } = req.params;

        const comments = await Comment.getByKeyReview(keyReviewId);

        res.json({
            success: true,
            comments: comments
        });
    } catch (error) {
        console.error('Get comments error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to fetch comments',
            error: error.message
        });
    }
});

// POST /api/comments - Create a new comment
router.post('/', async (req, res) => {
    try {
        const { key_review_id, comment_text } = req.body;
        const commented_by_username = req.user.username;

        // Validate input
        if (!key_review_id || !comment_text || !comment_text.trim()) {
            return res.status(400).json({
                success: false,
                message: 'Key review ID and comment text are required'
            });
        }

        // Check if user is admin of THIS project (project creator or participant with admin role)
        // Note: Global admin status (user_type) does NOT auto-verify comments - only project-level admin role does
        const projectId = await getProjectIdFromKeyReview(key_review_id);
        const isAdmin = projectId && await isProjectAdmin(commented_by_username, projectId);

        const commentData = {
            key_review_id,
            comment_text: comment_text.trim(),
            commented_by_username
        };

        // Pass isAdmin flag to auto-verify if user is admin
        const newComment = await Comment.create(commentData, isAdmin);

        // Get the full comment with user details
        const fullComment = await Comment.getById(newComment.comment_id);

        res.status(201).json({
            success: true,
            message: isAdmin ? 'Comment created and auto-verified' : 'Comment created (pending verification)',
            comment: fullComment
        });
    } catch (error) {
        console.error('Create comment error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to create comment',
            error: error.message
        });
    }
});

// PUT /api/comments/:commentId - Update a comment
router.put('/:commentId', async (req, res) => {
    try {
        const { commentId } = req.params;
        const { comment_text } = req.body;
        const username = req.user.username;

        // Validate input
        if (!comment_text || !comment_text.trim()) {
            return res.status(400).json({
                success: false,
                message: 'Comment text is required'
            });
        }

        // Check if user can modify this comment
        const canModify = await Comment.canUserModify(commentId, username);
        if (!canModify) {
            return res.status(403).json({
                success: false,
                message: 'You can only edit your own comments'
            });
        }

        const updateData = {
            comment_text: comment_text.trim()
        };

        const updated = await Comment.update(commentId, updateData);

        if (!updated) {
            return res.status(404).json({
                success: false,
                message: 'Comment not found'
            });
        }

        // Get the updated comment
        const updatedComment = await Comment.getById(commentId);

        res.json({
            success: true,
            message: 'Comment updated successfully',
            comment: updatedComment
        });
    } catch (error) {
        console.error('Update comment error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to update comment',
            error: error.message
        });
    }
});

// DELETE /api/comments/:commentId - Delete a comment
router.delete('/:commentId', async (req, res) => {
    try {
        const { commentId } = req.params;
        const username = req.user.username;

        // Check if user can modify this comment
        const canModify = await Comment.canUserModify(commentId, username);
        if (!canModify) {
            return res.status(403).json({
                success: false,
                message: 'You can only delete your own comments'
            });
        }

        const deleted = await Comment.delete(commentId);

        if (!deleted) {
            return res.status(404).json({
                success: false,
                message: 'Comment not found'
            });
        }

        res.json({
            success: true,
            message: 'Comment deleted successfully'
        });
    } catch (error) {
        console.error('Delete comment error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to delete comment',
            error: error.message
        });
    }
});

// GET /api/comments/:keyReviewId/latest - Get latest comment for a key review
router.get('/:keyReviewId/latest', async (req, res) => {
    try {
        const { keyReviewId } = req.params;

        const latestComment = await Comment.getLatestByKeyReview(keyReviewId);

        res.json({
            success: true,
            comment: latestComment
        });
    } catch (error) {
        console.error('Get latest comment error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to fetch latest comment',
            error: error.message
        });
    }
});

// GET /api/comments/:keyReviewId/count - Get comment count for a key review
router.get('/:keyReviewId/count', async (req, res) => {
    try {
        const { keyReviewId } = req.params;

        const count = await Comment.getCountByKeyReview(keyReviewId);

        res.json({
            success: true,
            count: count
        });
    } catch (error) {
        console.error('Get comment count error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to fetch comment count',
            error: error.message
        });
    }
});

// POST /api/comments/bulk - Create a comment for multiple key reviews (Apply to Group)
router.post('/bulk', async (req, res) => {
    try {
        const { key_review_ids, comment_text } = req.body;
        const commented_by_username = req.user.username;

        // Validate input
        if (!key_review_ids || !Array.isArray(key_review_ids) || key_review_ids.length === 0) {
            return res.status(400).json({
                success: false,
                message: 'Key review IDs array is required'
            });
        }

        if (!comment_text || !comment_text.trim()) {
            return res.status(400).json({
                success: false,
                message: 'Comment text is required'
            });
        }

        let successCount = 0;
        let failCount = 0;
        const createdComments = [];

        // Create comment for each key_review_id
        for (const key_review_id of key_review_ids) {
            try {
                // Check if user is admin of THIS project (project creator or participant with admin role)
                const projectId = await getProjectIdFromKeyReview(key_review_id);
                const isAdmin = projectId && await isProjectAdmin(commented_by_username, projectId);

                const commentData = {
                    key_review_id,
                    comment_text: comment_text.trim(),
                    commented_by_username
                };

                const newComment = await Comment.create(commentData, isAdmin);
                const fullComment = await Comment.getById(newComment.comment_id);
                createdComments.push(fullComment);
                successCount++;
            } catch (error) {
                console.error(`Failed to create comment for key_review_id ${key_review_id}:`, error);
                failCount++;
            }
        }

        res.status(201).json({
            success: true,
            message: `Comment added to ${successCount} key reviews${failCount > 0 ? `, ${failCount} failed` : ''}`,
            successCount,
            failCount,
            comments: createdComments
        });
    } catch (error) {
        console.error('Bulk create comment error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to create comments',
            error: error.message
        });
    }
});

// POST /api/comments/:commentId/verify - Verify a single comment (admin only)
router.post('/:commentId/verify', async (req, res) => {
    try {
        const { commentId } = req.params;
        const username = req.user.username;

        // Get project ID for this comment
        const projectId = await Comment.getProjectIdForComment(commentId);
        if (!projectId) {
            return res.status(404).json({
                success: false,
                message: 'Comment not found'
            });
        }

        // Check if user is admin of THIS project (project creator or participant with admin role)
        const isAdmin = await isProjectAdmin(username, projectId);
        if (!isAdmin) {
            return res.status(403).json({
                success: false,
                message: 'Only project admins can verify comments'
            });
        }

        const verified = await Comment.verify(commentId, username);
        
        if (!verified) {
            return res.status(400).json({
                success: false,
                message: 'Comment already verified or not found'
            });
        }

        // Get updated comment
        const updatedComment = await Comment.getById(commentId);

        res.json({
            success: true,
            message: 'Comment verified successfully',
            comment: updatedComment
        });
    } catch (error) {
        console.error('Verify comment error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to verify comment',
            error: error.message
        });
    }
});

// POST /api/comments/verify-all/:keyReviewId - Verify all comments for a key review (admin only)
router.post('/verify-all/:keyReviewId', async (req, res) => {
    try {
        const { keyReviewId } = req.params;
        const username = req.user.username;

        // Get project ID for this key review
        const projectId = await getProjectIdFromKeyReview(keyReviewId);
        if (!projectId) {
            return res.status(404).json({
                success: false,
                message: 'Key review not found'
            });
        }

        // Check if user is admin of THIS project (project creator or participant with admin role)
        const isAdmin = await isProjectAdmin(username, projectId);
        if (!isAdmin) {
            return res.status(403).json({
                success: false,
                message: 'Only project admins can verify comments'
            });
        }

        const verifiedCount = await Comment.verifyAllForKeyReview(keyReviewId, username);

        res.json({
            success: true,
            message: `${verifiedCount} comment(s) verified successfully`,
            verifiedCount
        });
    } catch (error) {
        console.error('Verify all comments error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to verify comments',
            error: error.message
        });
    }
});

// POST /api/comments/verify-bulk - Bulk verify comments for multiple key reviews (admin only)
router.post('/verify-bulk', async (req, res) => {
    try {
        const { key_review_ids } = req.body;
        const username = req.user.username;

        // Validate input
        if (!key_review_ids || !Array.isArray(key_review_ids) || key_review_ids.length === 0) {
            return res.status(400).json({
                success: false,
                message: 'Key review IDs array is required'
            });
        }

        // Check if user is admin of at least one project (we'll verify per key review)
        let totalVerified = 0;
        let failCount = 0;

        for (const keyReviewId of key_review_ids) {
            try {
                const projectId = await getProjectIdFromKeyReview(keyReviewId);
                if (!projectId) continue;

                const isAdmin = await isProjectAdmin(username, projectId);
                if (!isAdmin) {
                    failCount++;
                    continue;
                }

                const verifiedCount = await Comment.verifyAllForKeyReview(keyReviewId, username);
                totalVerified += verifiedCount;
            } catch (error) {
                console.error(`Failed to verify comments for key_review_id ${keyReviewId}:`, error);
                failCount++;
            }
        }

        res.json({
            success: true,
            message: `${totalVerified} comment(s) verified across ${key_review_ids.length - failCount} key reviews`,
            totalVerified,
            failCount
        });
    } catch (error) {
        console.error('Bulk verify comments error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to verify comments',
            error: error.message
        });
    }
});

// GET /api/comments/pending-count/:projectId - Get pending comments count for a project (admin only)
router.get('/pending-count/:projectId', async (req, res) => {
    try {
        const { projectId } = req.params;
        const username = req.user.username;

        // Check if user is admin of THIS project (project creator or participant with admin role)
        const isAdmin = await isProjectAdmin(username, projectId);
        if (!isAdmin) {
            return res.status(403).json({
                success: false,
                message: 'Only project admins can view pending comments count'
            });
        }

        const pendingCount = await Comment.getPendingCountByProject(projectId);

        res.json({
            success: true,
            pendingCount
        });
    } catch (error) {
        console.error('Get pending count error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to get pending count',
            error: error.message
        });
    }
});

module.exports = router;
