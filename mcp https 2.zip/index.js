#!/usr/bin/env node
/**
 * FMS Portal MCP Server
 * 
 * This MCP server provides tools to query FMS key values from the Samsung FMS Portal.
 * It allows chatbots and AI assistants to query key values, comments, KONA IDs, and CL numbers
 * for specific models and branches within a project.
 * 
 * Usage:
 *   - Run this server via stdio transport for local chatbot integration
 *   - Configure your MCP client to connect to this server
 */

import { Server } from '@modelcontextprotocol/sdk/server/index.js';
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';
import {
    CallToolRequestSchema,
    ListToolsRequestSchema,
    ListResourcesRequestSchema,
    ReadResourceRequestSchema,
} from '@modelcontextprotocol/sdk/types.js';
import { createConnection } from './db.js';
import { config } from './config.js';

// Create the MCP server instance
const server = new Server(
    {
        name: 'fms-portal-mcp-server',
        version: '1.0.0',
    },
    {
        capabilities: {
            tools: {},
            resources: {},
        },
    }
);

// ============================================================================
// TOOL: get_fms_key_values
// ============================================================================
// This tool fetches FMS key values for specified models/branches within a project

/**
 * List available tools
 */
server.setRequestHandler(ListToolsRequestSchema, async () => {
    return {
        tools: [
            {
                name: 'get_fms_key_values',
                description: `Query FMS key values across different models and branches in the Samsung FMS Portal.
                
This tool retrieves:
- Key values for target and reference models
- Comments associated with the key review
- KONA IDs (ticket references)
- CL numbers (changelist numbers)
- Review status

The query is performed within a specific project context (configured on server).
You can search for keys by name (partial match supported).`,
                inputSchema: {
                    type: 'object',
                    properties: {
                        key_name: {
                            type: 'string',
                            description: 'The FMS key name to search for (e.g., "com.samsung.key_1"). Partial matches are supported.',
                        },
                        target_model: {
                            type: 'string',
                            description: 'The target model to compare (e.g., "M80D"). Optional - if not provided, returns all models.',
                        },
                        reference_model: {
                            type: 'string',
                            description: 'The reference model to compare against (e.g., "M80F"). Optional.',
                        },
                        include_comments: {
                            type: 'boolean',
                            description: 'Whether to include detailed comments. Default: true',
                            default: true,
                        },
                    },
                    required: ['key_name'],
                },
            },
            {
                name: 'list_fms_keys',
                description: `List all FMS keys available in the configured project.
                
Returns a list of key names with their work assignments and owners.
Useful for discovering what keys are available before querying specific values.`,
                inputSchema: {
                    type: 'object',
                    properties: {
                        work_assignment: {
                            type: 'string',
                            description: 'Filter keys by work assignment (e.g., "TP_GameBar"). Optional.',
                        },
                        limit: {
                            type: 'number',
                            description: 'Maximum number of keys to return. Default: 50',
                            default: 50,
                        },
                    },
                    required: [],
                },
            },
            {
                name: 'get_project_info',
                description: `Get information about the configured project including groups, branches, and models.`,
                inputSchema: {
                    type: 'object',
                    properties: {},
                    required: [],
                },
            },
        ],
    };
});

/**
 * Handle tool calls
 */
server.setRequestHandler(CallToolRequestSchema, async (request) => {
    const { name, arguments: args } = request.params;

    let db;
    try {
        db = await createConnection();

        switch (name) {
            case 'get_fms_key_values':
                return await handleGetFmsKeyValues(db, args);

            case 'list_fms_keys':
                return await handleListFmsKeys(db, args);

            case 'get_project_info':
                return await handleGetProjectInfo(db, args);

            default:
                return {
                    content: [
                        {
                            type: 'text',
                            text: `Unknown tool: ${name}`,
                        },
                    ],
                    isError: true,
                };
        }
    } catch (error) {
        console.error('Tool execution error:', error);
        return {
            content: [
                {
                    type: 'text',
                    text: `Error executing tool: ${error.message}`,
                },
            ],
            isError: true,
        };
    } finally {
        if (db) {
            await db.end();
        }
    }
});

// ============================================================================
// Tool Handlers
// ============================================================================

/**
 * Handle get_fms_key_values tool
 */
async function handleGetFmsKeyValues(db, args) {
    const { key_name, target_model, reference_model, include_comments = true } = args;
    const projectId = config.projectId;

    // Build the query to fetch key values
    let query = `
        SELECT 
            fk.fms_key_id,
            fk.key_name,
            fk.work_assignment,
            fk.work_assignment_owner,
            fk.description,
            kr.key_review_id,
            kr.target_val,
            kr.ref1_val,
            kr.ref2_val,
            kr.ref3_val,
            kr.status,
            kr.kona_ids,
            kr.cl_numbers,
            kr.comment,
            kr.reviewed_by_username,
            kr.reviewed_at,
            g.name as group_name,
            g.comparison_type,
            target_m.model_name as target_model_name,
            ref1_m.model_name as ref1_model_name,
            ref2_m.model_name as ref2_model_name,
            ref3_m.model_name as ref3_model_name,
            target_b.branch_name as target_branch_name,
            ref1_b.branch_name as ref1_branch_name,
            ref2_b.branch_name as ref2_branch_name,
            ref3_b.branch_name as ref3_branch_name
        FROM Key_Reviews kr
        JOIN FMS_Keys fk ON kr.fms_key_id = fk.fms_key_id
        JOIN grps g ON kr.group_id = g.group_id
        JOIN Group_Model_Mapping gmm ON kr.gm_id = gmm.gm_id
        LEFT JOIN Models target_m ON gmm.target_model_id = target_m.model_id
        LEFT JOIN Models ref1_m ON gmm.ref1_model_id = ref1_m.model_id
        LEFT JOIN Models ref2_m ON gmm.ref2_model_id = ref2_m.model_id
        LEFT JOIN Models ref3_m ON gmm.ref3_model_id = ref3_m.model_id
        LEFT JOIN Branches target_b ON g.target_branch_id = target_b.branch_id
        LEFT JOIN Branches ref1_b ON g.ref1_branch_id = ref1_b.branch_id
        LEFT JOIN Branches ref2_b ON g.ref2_branch_id = ref2_b.branch_id
        LEFT JOIN Branches ref3_b ON g.ref3_branch_id = ref3_b.branch_id
        WHERE g.project_id = ?
        AND fk.key_name LIKE ?
    `;

    const params = [projectId, `%${key_name}%`];

    // Add model filters if specified
    if (target_model) {
        query += ` AND target_m.model_name = ?`;
        params.push(target_model);
    }

    if (reference_model) {
        query += ` AND (ref1_m.model_name = ? OR ref2_m.model_name = ? OR ref3_m.model_name = ?)`;
        params.push(reference_model, reference_model, reference_model);
    }

    query += ` ORDER BY fk.key_name, g.name`;

    const [rows] = await db.execute(query, params);

    if (rows.length === 0) {
        return {
            content: [
                {
                    type: 'text',
                    text: `No FMS keys found matching "${key_name}" in the configured project (ID: ${projectId}).`,
                },
            ],
        };
    }

    // Fetch comments if requested
    let commentsMap = {};
    if (include_comments) {
        const keyReviewIds = rows.map(r => r.key_review_id).filter(Boolean);
        if (keyReviewIds.length > 0) {
            const placeholders = keyReviewIds.map(() => '?').join(',');
            const commentsQuery = `
                SELECT 
                    key_review_id,
                    comment_text,
                    commented_by_username,
                    created_at,
                    verification_status
                FROM Comments
                WHERE key_review_id IN (${placeholders})
                ORDER BY created_at DESC
            `;
            const [comments] = await db.execute(commentsQuery, keyReviewIds);

            // Group comments by key_review_id
            for (const comment of comments) {
                if (!commentsMap[comment.key_review_id]) {
                    commentsMap[comment.key_review_id] = [];
                }
                commentsMap[comment.key_review_id].push(comment);
            }
        }
    }

    // Format the results
    const results = rows.map(row => {
        const result = {
            key_name: row.key_name,
            work_assignment: row.work_assignment,
            owner: row.work_assignment_owner,
            description: row.description,
            group: row.group_name,
            comparison_type: row.comparison_type,
            status: row.status,
            values: {
                target: {
                    model: row.target_model_name,
                    branch: row.target_branch_name,
                    value: row.target_val,
                },
                reference1: {
                    model: row.ref1_model_name,
                    branch: row.ref1_branch_name,
                    value: row.ref1_val,
                },
            },
            kona_ids: row.kona_ids || null,
            cl_numbers: row.cl_numbers || null,
            inline_comment: row.comment || null,
            reviewed_by: row.reviewed_by_username,
            reviewed_at: row.reviewed_at,
        };

        // Add reference2 and reference3 if they exist
        if (row.ref2_model_name) {
            result.values.reference2 = {
                model: row.ref2_model_name,
                branch: row.ref2_branch_name,
                value: row.ref2_val,
            };
        }

        if (row.ref3_model_name) {
            result.values.reference3 = {
                model: row.ref3_model_name,
                branch: row.ref3_branch_name,
                value: row.ref3_val,
            };
        }

        // Add detailed comments if requested
        if (include_comments && commentsMap[row.key_review_id]) {
            result.comments = commentsMap[row.key_review_id].map(c => ({
                text: c.comment_text,
                author: c.commented_by_username,
                date: c.created_at,
                verified: c.verification_status === 'verified',
            }));
        }

        return result;
    });

    // Create a formatted text response
    let textResponse = `## FMS Key Query Results\n\n`;
    textResponse += `**Search Term:** ${key_name}\n`;
    textResponse += `**Results Found:** ${results.length}\n\n`;

    for (const result of results) {
        textResponse += `### ${result.key_name}\n`;
        textResponse += `- **Work Assignment:** ${result.work_assignment || 'N/A'}\n`;
        textResponse += `- **Owner:** ${result.owner || 'N/A'}\n`;
        textResponse += `- **Group:** ${result.group}\n`;
        textResponse += `- **Status:** ${result.status}\n\n`;

        textResponse += `**Values:**\n`;
        textResponse += `| Model | Branch | Value |\n`;
        textResponse += `|-------|--------|-------|\n`;
        textResponse += `| ${result.values.target.model} (Target) | ${result.values.target.branch} | ${result.values.target.value || 'N/A'} |\n`;
        textResponse += `| ${result.values.reference1.model} (Ref1) | ${result.values.reference1.branch} | ${result.values.reference1.value || 'N/A'} |\n`;

        if (result.values.reference2) {
            textResponse += `| ${result.values.reference2.model} (Ref2) | ${result.values.reference2.branch} | ${result.values.reference2.value || 'N/A'} |\n`;
        }
        if (result.values.reference3) {
            textResponse += `| ${result.values.reference3.model} (Ref3) | ${result.values.reference3.branch} | ${result.values.reference3.value || 'N/A'} |\n`;
        }

        textResponse += `\n`;

        if (result.kona_ids) {
            textResponse += `**KONA IDs:** ${result.kona_ids}\n`;
        }
        if (result.cl_numbers) {
            textResponse += `**CL Numbers:** ${result.cl_numbers}\n`;
        }
        if (result.inline_comment) {
            textResponse += `**Inline Comment:** ${result.inline_comment}\n`;
        }

        if (result.comments && result.comments.length > 0) {
            textResponse += `\n**Comments:**\n`;
            for (const comment of result.comments) {
                const verified = comment.verified ? ' ✓' : '';
                textResponse += `- ${comment.text} (by ${comment.author}${verified})\n`;
            }
        }

        textResponse += `\n---\n\n`;
    }

    return {
        content: [
            {
                type: 'text',
                text: textResponse,
            },
        ],
    };
}

/**
 * Handle list_fms_keys tool
 */
async function handleListFmsKeys(db, args) {
    const { work_assignment, limit = 50 } = args;
    const projectId = config.projectId;

    let query = `
        SELECT DISTINCT
            fk.fms_key_id,
            fk.key_name,
            fk.work_assignment,
            fk.work_assignment_owner
        FROM FMS_Keys fk
        JOIN Key_Reviews kr ON fk.fms_key_id = kr.fms_key_id
        JOIN grps g ON kr.group_id = g.group_id
        WHERE g.project_id = ?
    `;

    const params = [projectId];

    if (work_assignment) {
        query += ` AND fk.work_assignment LIKE ?`;
        params.push(`%${work_assignment}%`);
    }

    // Use parseInt to ensure limit is a valid integer (LIMIT doesn't work with prepared statement placeholders in some MySQL versions)
    const safeLimit = Math.min(Math.max(1, parseInt(limit) || 50), 500);
    query += ` ORDER BY fk.key_name LIMIT ${safeLimit}`;

    const [rows] = await db.execute(query, params);

    if (rows.length === 0) {
        return {
            content: [
                {
                    type: 'text',
                    text: `No FMS keys found in the configured project (ID: ${projectId}).`,
                },
            ],
        };
    }

    let textResponse = `## FMS Keys in Project\n\n`;
    textResponse += `**Total Keys:** ${rows.length}\n\n`;
    textResponse += `| Key Name | Work Assignment | Owner |\n`;
    textResponse += `|----------|-----------------|-------|\n`;

    for (const row of rows) {
        textResponse += `| ${row.key_name} | ${row.work_assignment || 'N/A'} | ${row.work_assignment_owner || 'N/A'} |\n`;
    }

    return {
        content: [
            {
                type: 'text',
                text: textResponse,
            },
        ],
    };
}

/**
 * Handle get_project_info tool
 */
async function handleGetProjectInfo(db, args) {
    const projectId = config.projectId;

    // Get project details
    const [projects] = await db.execute(`
        SELECT p.*, u.name as admin_name
        FROM Projects p
        JOIN Users u ON p.admin_username = u.username
        WHERE p.project_id = ?
    `, [projectId]);

    if (projects.length === 0) {
        return {
            content: [
                {
                    type: 'text',
                    text: `Project with ID ${projectId} not found.`,
                },
            ],
            isError: true,
        };
    }

    const project = projects[0];

    // Get groups with branches
    const [groups] = await db.execute(`
        SELECT g.*,
            target_b.branch_name as target_branch_name,
            ref1_b.branch_name as ref1_branch_name,
            ref2_b.branch_name as ref2_branch_name,
            ref3_b.branch_name as ref3_branch_name
        FROM grps g
        LEFT JOIN Branches target_b ON g.target_branch_id = target_b.branch_id
        LEFT JOIN Branches ref1_b ON g.ref1_branch_id = ref1_b.branch_id
        LEFT JOIN Branches ref2_b ON g.ref2_branch_id = ref2_b.branch_id
        LEFT JOIN Branches ref3_b ON g.ref3_branch_id = ref3_b.branch_id
        WHERE g.project_id = ?
        ORDER BY g.created_at
    `, [projectId]);

    // Get models for each group
    for (const group of groups) {
        const [models] = await db.execute(`
            SELECT DISTINCT
                target_m.model_name AS target,
                ref1_m.model_name AS reference1,
                ref2_m.model_name AS reference2,
                ref3_m.model_name AS reference3
            FROM Group_Model_Mapping gmm
            LEFT JOIN Models target_m ON gmm.target_model_id = target_m.model_id
            LEFT JOIN Models ref1_m ON gmm.ref1_model_id = ref1_m.model_id
            LEFT JOIN Models ref2_m ON gmm.ref2_model_id = ref2_m.model_id
            LEFT JOIN Models ref3_m ON gmm.ref3_model_id = ref3_m.model_id
            WHERE gmm.group_id = ?
        `, [group.group_id]);
        group.models = models;
    }

    // Get key count
    const [keyCount] = await db.execute(`
        SELECT COUNT(DISTINCT kr.fms_key_id) as count
        FROM Key_Reviews kr
        JOIN grps g ON kr.group_id = g.group_id
        WHERE g.project_id = ?
    `, [projectId]);

    let textResponse = `## Project Information\n\n`;
    textResponse += `**Title:** ${project.title}\n`;
    textResponse += `**Description:** ${project.description || 'N/A'}\n`;
    textResponse += `**Admin:** ${project.admin_name}\n`;
    textResponse += `**Status:** ${project.status || 'active'}\n`;
    textResponse += `**Total Keys:** ${keyCount[0].count}\n\n`;

    textResponse += `### Groups\n\n`;

    for (const group of groups) {
        textResponse += `#### ${group.name}\n`;
        textResponse += `- **Comparison Type:** ${group.comparison_type}\n`;
        textResponse += `- **Branches:**\n`;
        textResponse += `  - Target: ${group.target_branch_name || 'N/A'}\n`;
        textResponse += `  - Reference 1: ${group.ref1_branch_name || 'N/A'}\n`;
        if (group.ref2_branch_name) {
            textResponse += `  - Reference 2: ${group.ref2_branch_name}\n`;
        }
        if (group.ref3_branch_name) {
            textResponse += `  - Reference 3: ${group.ref3_branch_name}\n`;
        }

        textResponse += `- **Model Combinations:**\n`;
        for (const model of group.models) {
            const models = [model.target, model.reference1, model.reference2, model.reference3]
                .filter(Boolean)
                .join(' vs ');
            textResponse += `  - ${models}\n`;
        }
        textResponse += `\n`;
    }

    return {
        content: [
            {
                type: 'text',
                text: textResponse,
            },
        ],
    };
}

// ============================================================================
// RESOURCES: Expose project data as MCP resources
// ============================================================================

server.setRequestHandler(ListResourcesRequestSchema, async () => {
    return {
        resources: [
            {
                uri: `fms://project/${config.projectId}`,
                name: 'Current Project',
                description: 'The currently configured FMS project',
                mimeType: 'application/json',
            },
        ],
    };
});

server.setRequestHandler(ReadResourceRequestSchema, async (request) => {
    const { uri } = request.params;

    if (uri === `fms://project/${config.projectId}`) {
        let db;
        try {
            db = await createConnection();
            const [projects] = await db.execute(`
                SELECT p.*, u.name as admin_name
                FROM Projects p
                JOIN Users u ON p.admin_username = u.username
                WHERE p.project_id = ?
            `, [config.projectId]);

            if (projects.length === 0) {
                throw new Error('Project not found');
            }

            return {
                contents: [
                    {
                        uri,
                        mimeType: 'application/json',
                        text: JSON.stringify(projects[0], null, 2),
                    },
                ],
            };
        } finally {
            if (db) {
                await db.end();
            }
        }
    }

    throw new Error(`Unknown resource: ${uri}`);
});

// ============================================================================
// Server Startup
// ============================================================================

async function main() {
    console.error('Starting FMS Portal MCP Server...');
    console.error(`Configured Project ID: ${config.projectId}`);

    const transport = new StdioServerTransport();
    await server.connect(transport);

    console.error('FMS Portal MCP Server running on stdio');
}

main().catch((error) => {
    console.error('Failed to start MCP server:', error);
    process.exit(1);
});
