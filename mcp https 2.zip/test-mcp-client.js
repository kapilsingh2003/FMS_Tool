#!/usr/bin/env node
/**
 * MCP Client Test Script
 * 
 * This script tests the MCP server by acting as an MCP client.
 * It connects to the server via stdio and makes actual tool calls.
 * 
 * Run with: node test-mcp-client.js
 */

import { Client } from '@modelcontextprotocol/sdk/client/index.js';
import { StdioClientTransport } from '@modelcontextprotocol/sdk/client/stdio.js';
import { spawn } from 'child_process';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

async function testMCPServer() {
    console.log('🔌 MCP Client Test\n');
    console.log('='.repeat(50));
    
    // Spawn the MCP server as a child process
    const serverPath = join(__dirname, 'index.js');
    
    console.log('\n📡 Starting MCP server...');
    
    const transport = new StdioClientTransport({
        command: 'node',
        args: [serverPath],
    });
    
    const client = new Client(
        {
            name: 'test-client',
            version: '1.0.0',
        },
        {
            capabilities: {},
        }
    );
    
    try {
        await client.connect(transport);
        console.log('✅ Connected to MCP server\n');
        
        // Test 1: List available tools
        console.log('📋 Test 1: List Tools');
        console.log('-'.repeat(30));
        
        const tools = await client.listTools();
        console.log(`Found ${tools.tools.length} tool(s):`);
        for (const tool of tools.tools) {
            console.log(`   - ${tool.name}: ${tool.description.split('\n')[0]}`);
        }
        
        // Test 2: Get project info
        console.log('\n📋 Test 2: Get Project Info');
        console.log('-'.repeat(30));
        
        const projectInfo = await client.callTool({
            name: 'get_project_info',
            arguments: {},
        });
        
        // Show first 500 chars of the response
        const projectText = projectInfo.content[0].text;
        console.log(projectText.substring(0, 500) + (projectText.length > 500 ? '...' : ''));
        
        // Test 3: List FMS keys
        console.log('\n📋 Test 3: List FMS Keys');
        console.log('-'.repeat(30));
        
        const keysList = await client.callTool({
            name: 'list_fms_keys',
            arguments: { limit: 5 },
        });
        
        console.log(keysList.content[0].text);
        
        // Test 4: Query specific key
        console.log('\n📋 Test 4: Query Key Values');
        console.log('-'.repeat(30));
        
        const keyValues = await client.callTool({
            name: 'get_fms_key_values',
            arguments: {
                key_name: 'analog_clean_view',
                include_comments: true,
            },
        });
        
        // Show first 800 chars
        const keyText = keyValues.content[0].text;
        console.log(keyText.substring(0, 800) + (keyText.length > 800 ? '...' : ''));
        
        console.log('\n' + '='.repeat(50));
        console.log('✅ All MCP tests passed!');
        console.log('\n🎉 Your MCP server is ready for integration with your chatbot.');
        
    } catch (error) {
        console.error('❌ MCP Test Error:', error.message);
        if (error.stack) {
            console.error(error.stack);
        }
    } finally {
        await client.close();
    }
}

testMCPServer().catch(console.error);
