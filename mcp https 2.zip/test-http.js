#!/usr/bin/env node
/**
 * HTTP MCP Server Test Script
 * 
 * Tests the HTTP/SSE MCP server endpoints and MCP protocol over HTTP.
 * 
 * Run with: node test-http.js
 */

const SERVER_URL = process.env.MCP_SERVER_URL || 'http://localhost:3001';

async function testHTTPServer() {
    console.log('🧪 HTTP MCP Server Test Suite\n');
    console.log('='.repeat(50));
    console.log(`Testing server at: ${SERVER_URL}\n`);
    
    let allPassed = true;
    
    // Test 1: Health Check
    console.log('📋 Test 1: Health Check');
    console.log('-'.repeat(30));
    
    try {
        const healthResponse = await fetch(`${SERVER_URL}/health`);
        const health = await healthResponse.json();
        
        if (health.status === 'ok') {
            console.log('✅ Health check passed');
            console.log(`   Server: ${health.server}`);
            console.log(`   Version: ${health.version}`);
            console.log(`   Project ID: ${health.projectId}`);
        } else {
            console.log('❌ Health check failed');
            allPassed = false;
        }
    } catch (error) {
        console.log('❌ Health check failed:', error.message);
        console.log('   Make sure the HTTP server is running: npm run start:http');
        allPassed = false;
        return;
    }
    
    // Test 2: Server Info
    console.log('\n📋 Test 2: Server Info');
    console.log('-'.repeat(30));
    
    try {
        const infoResponse = await fetch(`${SERVER_URL}/info`);
        const info = await infoResponse.json();
        
        console.log('✅ Server info retrieved');
        console.log(`   Transport: ${info.transport}`);
        console.log(`   Project: ${info.project?.title || 'N/A'}`);
        console.log(`   Active Sessions: ${info.activeSessions}`);
        console.log(`   Endpoints: ${Object.keys(info.endpoints).join(', ')}`);
    } catch (error) {
        console.log('❌ Server info failed:', error.message);
        allPassed = false;
    }
    
    // Test 3: SSE Connection
    console.log('\n📋 Test 3: SSE Connection Test');
    console.log('-'.repeat(30));
    
    try {
        // We can't fully test SSE with fetch, but we can check if the endpoint responds
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 2000);
        
        const sseResponse = await fetch(`${SERVER_URL}/sse`, {
            signal: controller.signal,
            headers: {
                'Accept': 'text/event-stream',
            },
        }).catch(err => {
            if (err.name === 'AbortError') {
                return { ok: true, status: 200 }; // SSE keeps connection open, abort is expected
            }
            throw err;
        });
        
        clearTimeout(timeout);
        
        if (sseResponse.ok || sseResponse.status === 200) {
            console.log('✅ SSE endpoint is accessible');
            console.log('   The endpoint accepts connections for MCP communication');
        } else {
            console.log('⚠️ SSE endpoint returned status:', sseResponse.status);
        }
    } catch (error) {
        if (error.name === 'AbortError') {
            console.log('✅ SSE endpoint is accessible (connection kept alive)');
        } else {
            console.log('❌ SSE connection test failed:', error.message);
            allPassed = false;
        }
    }
    
    // Test 4: MCP Protocol via HTTP (using a simplified approach)
    console.log('\n📋 Test 4: Direct Tool Call via HTTP');
    console.log('-'.repeat(30));
    console.log('ℹ️ Note: Full MCP protocol requires SSE. Testing direct endpoints...');
    
    // Since the full MCP protocol over SSE is complex, let's just verify the server setup is correct
    // The actual MCP SDK handles the SSE communication
    
    // Test 5: Network accessibility info
    console.log('\n📋 Test 5: Network Access Information');
    console.log('-'.repeat(30));
    
    try {
        // Get local network interfaces
        const os = await import('os');
        const networkInterfaces = os.networkInterfaces();
        
        console.log('✅ Server can be accessed from:');
        console.log(`   Local: ${SERVER_URL}`);
        
        for (const [name, interfaces] of Object.entries(networkInterfaces)) {
            for (const iface of interfaces) {
                if (iface.family === 'IPv4' && !iface.internal) {
                    console.log(`   Network (${name}): http://${iface.address}:3001`);
                }
            }
        }
    } catch (error) {
        console.log('⚠️ Could not determine network interfaces');
    }
    
    // Summary
    console.log('\n' + '='.repeat(50));
    console.log('📊 Test Summary');
    console.log('='.repeat(50));
    
    if (allPassed) {
        console.log('\n✅ All HTTP server tests passed!');
        console.log('\n🎉 Your MCP server is ready for network access.');
        console.log('\n📖 How to connect from your chatbot:');
        console.log('   1. Use the MCP SDK with SSE transport');
        console.log('   2. SSE URL: http://<your-ip>:3001/sse');
        console.log('   3. Message URL: http://<your-ip>:3001/message');
    } else {
        console.log('\n⚠️ Some tests failed. Please check the errors above.');
    }
    
    console.log('\n');
}

// Test with MCP SDK
async function testMCPOverHTTP() {
    console.log('\n📋 Test 6: Full MCP Protocol Test');
    console.log('-'.repeat(30));
    
    try {
        const { Client } = await import('@modelcontextprotocol/sdk/client/index.js');
        const { SSEClientTransport } = await import('@modelcontextprotocol/sdk/client/sse.js');
        
        console.log('Creating MCP client with SSE transport...');
        
        const transport = new SSEClientTransport(
            new URL(`${SERVER_URL}/sse`)
        );
        
        const client = new Client(
            { name: 'test-http-client', version: '1.0.0' },
            { capabilities: {} }
        );
        
        await client.connect(transport);
        console.log('✅ Connected to MCP server via SSE');
        
        // List tools
        const tools = await client.listTools();
        console.log(`✅ Found ${tools.tools.length} tools:`);
        for (const tool of tools.tools) {
            console.log(`   - ${tool.name}`);
        }
        
        // Call get_project_info
        console.log('\nCalling get_project_info tool...');
        const projectInfo = await client.callTool({
            name: 'get_project_info',
            arguments: {},
        });
        
        const projectText = projectInfo.content[0].text;
        const firstLine = projectText.split('\n').slice(0, 5).join('\n');
        console.log('✅ Tool call successful:');
        console.log(firstLine + '...');
        
        // Call get_fms_key_values
        console.log('\nCalling get_fms_key_values tool...');
        const keyValues = await client.callTool({
            name: 'get_fms_key_values',
            arguments: { key_name: 'analog', include_comments: true },
        });
        
        const keyText = keyValues.content[0].text;
        console.log('✅ Key query successful:');
        console.log(keyText.substring(0, 300) + '...');
        
        await client.close();
        console.log('\n✅ MCP protocol test completed successfully!');
        
    } catch (error) {
        console.log('❌ MCP protocol test failed:', error.message);
        if (error.message.includes('SSEClientTransport')) {
            console.log('   Note: SSEClientTransport may require additional setup');
        }
    }
}

// Run tests
async function main() {
    await testHTTPServer();
    await testMCPOverHTTP();
}

main().catch(console.error);
