# FMS Portal MCP Server

A Model Context Protocol (MCP) server for the Samsung FMS Portal. This server allows chatbots and AI assistants to query FMS key values, comments, KONA IDs, and CL numbers from the portal.

**Two Transport Modes:**
- **Stdio** (`index.js`): For local integrations (Claude Desktop on same machine)
- **HTTP/SSE** (`index-http.js`): For network access from other machines

## Features

- **Query FMS Key Values**: Search for FMS keys and retrieve their values across different models and branches
- **List Available Keys**: Get a list of all FMS keys in the configured project
- **Project Information**: Get details about the project including groups, branches, and models
- **Comments Support**: Retrieve detailed comments associated with key reviews

## Installation

1. Navigate to the mcp-server directory:
   ```bash
   cd mcp-server
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

3. Create a `.env` file based on `.env.example`:
   ```bash
   cp .env.example .env
   ```

4. Configure the environment variables in `.env`:
   - `DB_HOST`, `DB_PORT`, `DB_USER`, `DB_PASSWORD`, `DB_NAME` - Database connection settings
   - `MCP_PROJECT_ID` - The project ID to query (hardcoded for this MCP server)

## Usage

### Running the Server (Local - Stdio)

For local use with Claude Desktop on the same machine:

```bash
npm start
```

### Running the Server (Network - HTTP/SSE)

For network access from other machines:

```bash
npm run start:http
```

The HTTP server will start on port 3001 and be accessible from any machine on your network:
- Local: `http://localhost:3001`
- Network: `http://<your-ip>:3001`

**Find your IP address:**
```bash
# Windows
ipconfig

# Linux/Mac
ifconfig
```

### Development Mode

```bash
npm run dev       # Stdio with auto-reload
npm run dev:http  # HTTP with auto-reload
```

### Configuring in Claude Desktop

Add the following to your Claude Desktop configuration file:

**Windows**: `%APPDATA%\Claude\claude_desktop_config.json`
**macOS**: `~/Library/Application Support/Claude/claude_desktop_config.json`

```json
{
  "mcpServers": {
    "fms-portal": {
      "command": "node",
      "args": ["E:\\MERN Projects\\LearningProj\\mcp-server\\index.js"],
      "env": {
        "MCP_PROJECT_ID": "1"
      }
    }
  }
}
```

### Configuring for Network Access (HTTP/SSE)

If your chatbot or MCP client is on a different machine, use the HTTP server:

1. Start the HTTP server:
   ```bash
   npm run start:http
   ```

2. The server exposes these endpoints:
   - `GET /sse` - SSE endpoint for MCP communication
   - `POST /message` - Message endpoint for requests
   - `GET /health` - Health check
   - `GET /info` - Server info

3. Configure your MCP client to connect via SSE:
   ```
   SSE URL: http://<server-ip>:3001/sse
   Message URL: http://<server-ip>:3001/message
   ```

### Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `DB_HOST` | localhost | MySQL host |
| `DB_PORT` | 3306 | MySQL port |
| `DB_USER` | root | MySQL user |
| `DB_PASSWORD` | root | MySQL password |
| `DB_NAME` | samsung_fms_portal | Database name |
| `MCP_PROJECT_ID` | 1 | Project ID to query |
| `MCP_HTTP_PORT` | 3001 | HTTP server port |

### Configuring in Other MCP Clients

For other MCP-compatible clients, use the stdio transport and point to the server's entry point.

## Available Tools

### 1. `get_fms_key_values`

Query FMS key values across different models and branches.

**Parameters:**
- `key_name` (required): The FMS key name to search for (partial matches supported)
- `target_model` (optional): Filter by target model name (e.g., "M80D")
- `reference_model` (optional): Filter by reference model name (e.g., "M80F")
- `include_comments` (optional): Whether to include detailed comments (default: true)

**Example:**
```
What are the values of com.samsung.key_1 in M80D vs M80F?
```

The chatbot will call:
```json
{
  "tool": "get_fms_key_values",
  "arguments": {
    "key_name": "com.samsung.key_1",
    "target_model": "M80D",
    "reference_model": "M80F"
  }
}
```

### 2. `list_fms_keys`

List all FMS keys available in the configured project.

**Parameters:**
- `work_assignment` (optional): Filter keys by work assignment (e.g., "TP_GameBar")
- `limit` (optional): Maximum number of keys to return (default: 50)

**Example:**
```
What FMS keys are related to GameBar?
```

### 3. `get_project_info`

Get information about the configured project including groups, branches, and models.

**Parameters:** None

**Example:**
```
Tell me about the current FMS project configuration.
```

## Example Queries for Your Chatbot

Here are some example questions your chatbot can answer using this MCP server:

1. **Key Value Comparison:**
   - "What are the values of XYZ FMS Key in M80D (Trunk_2025) vs M80F (Trunk_2026)?"
   - "Compare the values of com.samsung.gamemode_key across all models"

2. **Key Discovery:**
   - "List all FMS keys related to GameBar"
   - "What keys does the PowerSave work assignment have?"

3. **Status and Comments:**
   - "What is the review status of com.samsung.key_1?"
   - "Are there any comments on the key_2 review?"

4. **KONA and CL Information:**
   - "What KONA tickets are associated with com.samsung.key_3?"
   - "What CL numbers have been submitted for the GameBar keys?"

## Response Format

The server returns responses in Markdown format that's suitable for display in chat interfaces. For example:

```markdown
## FMS Key Query Results

**Search Term:** com.samsung.key_1
**Results Found:** 2

### com.samsung.key_1
- **Work Assignment:** TP_GameBar
- **Owner:** John Smith
- **Group:** Group_25Y_SM
- **Status:** reviewed

**Values:**
| Model | Branch | Value |
|-------|--------|-------|
| M80D (Target) | Trunk_2025 | True |
| M80F (Ref1) | Trunk_2026 | False |

**KONA IDs:** RQ250607-0239
**CL Numbers:** 1980283

**Comments:**
- Value is correct for new models (by John Smith ✓)
```

## Security Considerations

- The MCP server connects to your database directly. Ensure proper network security.
- The project ID is hardcoded to prevent querying unauthorized projects.
- Consider running the MCP server on the same machine as your database.

## Troubleshooting

### Server won't start
1. Check that MySQL is running
2. Verify database credentials in `.env`
3. Ensure the project ID exists in the database

### No results returned
1. Verify the project has key reviews
2. Check that the key name search is correct
3. Ensure models exist in the specified project groups

### Connection refused
1. Check database host and port
2. Verify firewall rules allow connections
3. Ensure MySQL user has SELECT permissions

## License

ISC
