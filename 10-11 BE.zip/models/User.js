// User Model - Samsung FMS Portal
const { executeQuery } = require('../config/database');
const bcrypt = require('bcryptjs');

class User {
  // Create a new user
  static async create(userData) {
    const { username, name, password, user_type, email, team } = userData;
    const hashedPassword = await bcrypt.hash(password, 10);

    const query = `
      INSERT INTO \`Users\` (username, name, password, user_type, email, team, is_verified)
      VALUES (?, ?, ?, ?, ?, ?, true)
    `;

    await executeQuery(query, [username, name, hashedPassword, user_type || 'user', email, team]);
    return this.findByUsername(username);
  }

  // Find user by username
  static async findByUsername(username) {
    const query = `
      SELECT username, name, user_type, email, team, created_date, last_login, is_verified
      FROM \`Users\`
      WHERE username = ?
    `;

    const users = await executeQuery(query, [username]);
    return users[0] || null;
  }

  // Find user by email
  static async findByEmail(email) {
    const query = `
      SELECT username, name, user_type, email, team, created_date, last_login, is_verified
      FROM \`Users\`
      WHERE email = ?
    `;

    const users = await executeQuery(query, [email]);
    return users[0] || null;
  }

  // Verify user password
  static async verifyPassword(username, password) {
    const query = `
      SELECT username, password, user_type, email, team, name
      FROM \`Users\`
      WHERE username = ?
    `;

    const users = await executeQuery(query, [username]);
    if (!users[0]) return null;

    const isValid = await bcrypt.compare(password, users[0].password);
    if (!isValid) return null;

    // Update last login
    await this.updateLastLogin(username);

    // Return user without password
    const { password: _, ...user } = users[0];
    return user;
  }

  // Update last login timestamp
  static async updateLastLogin(username) {
    const query = `
      UPDATE \`Users\`
      SET last_login = CURRENT_TIMESTAMP
      WHERE username = ?
    `;

    await executeQuery(query, [username]);
  }

  // Get all users (admin only)
  static async getAll() {
    const query = `
      SELECT username, name, user_type, email, team, created_date, last_login, is_verified
      FROM \`Users\`
      ORDER BY created_date DESC
    `;

    return await executeQuery(query);
  }

  // Update user type (admin/user)
  static async updateUserType(username, user_type) {
    const query = `
      UPDATE \`Users\`
      SET user_type = ?
      WHERE username = ?
    `;

    await executeQuery(query, [user_type, username]);
    return this.findByUsername(username);
  }

  // Check if username exists
  static async usernameExists(username) {
    const query = `SELECT username FROM \`Users\` WHERE username = ?`;
    const users = await executeQuery(query, [username]);
    return users.length > 0;
  }

  // Check if email exists
  static async emailExists(email) {
    const query = `SELECT email FROM \`Users\` WHERE email = ?`;
    const users = await executeQuery(query, [email]);
    return users.length > 0;
  }

  // Add user to project with specific role
  static async addToProject(username, projectId, role, addedBy) {
    const query = `
      INSERT INTO \`Project_Participants\` (project_id, user_username, added_by, participant_role)
      VALUES (?, ?, ?, ?)
      ON DUPLICATE KEY UPDATE 
        participant_role = VALUES(participant_role),
        updated_at = CURRENT_TIMESTAMP
    `;

    await executeQuery(query, [projectId, username, addedBy, role]);
    return this.getProjectParticipant(username, projectId);
  }

  // Remove user from project
  static async removeFromProject(username, projectId) {
    const query = `
      DELETE FROM \`Project_Participants\`
      WHERE user_username = ? AND project_id = ?
    `;

    await executeQuery(query, [username, projectId]);
    return { success: true };
  }

  // Update user's role in project
  static async updateProjectRole(username, projectId, role) {
    const query = `
      UPDATE \`Project_Participants\`
      SET participant_role = ?, updated_at = CURRENT_TIMESTAMP
      WHERE user_username = ? AND project_id = ?
    `;

    await executeQuery(query, [role, username, projectId]);
    return this.getProjectParticipant(username, projectId);
  }

  // Get user's role in a specific project
  static async getProjectParticipant(username, projectId) {
    const query = `
      SELECT pp.participant_role, pp.joined_at, pp.updated_at,
             u.username, u.name, u.email, u.team, u.user_type
      FROM \`Project_Participants\` pp
      JOIN \`Users\` u ON pp.user_username = u.username
      WHERE pp.user_username = ? AND pp.project_id = ?
    `;

    const participants = await executeQuery(query, [username, projectId]);
    return participants[0] || null;
  }

  // Get all participants of a project
  static async getProjectParticipants(projectId) {
    const query = `
      SELECT pp.participant_role, pp.joined_at, pp.updated_at,
             u.username, u.name, u.email, u.team, u.user_type
      FROM \`Project_Participants\` pp
      JOIN \`Users\` u ON pp.user_username = u.username
      WHERE pp.project_id = ?
      ORDER BY pp.joined_at DESC
    `;

    return await executeQuery(query, [projectId]);
  }

  // Get all projects for a user
  static async getUserProjects(username) {
    const query = `
      SELECT p.project_id, p.title, p.description, p.status, p.created_date,
             pp.participant_role, pp.joined_at,
             admin.name as admin_name
      FROM \`Project_Participants\` pp
      JOIN \`Projects\` p ON pp.project_id = p.project_id
      JOIN \`Users\` admin ON p.admin_username = admin.username
      WHERE pp.user_username = ?
      ORDER BY pp.joined_at DESC
    `;

    return await executeQuery(query, [username]);
  }

  // Change user password
  static async changePassword(username, oldPassword, newPassword) {
    // First verify the old password
    const query = `
      SELECT username, password
      FROM \`Users\`
      WHERE username = ?
    `;

    const users = await executeQuery(query, [username]);
    if (!users[0]) {
      throw new Error('User not found');
    }

    const isValid = await bcrypt.compare(oldPassword, users[0].password);
    if (!isValid) {
      throw new Error('Current password is incorrect');
    }

    // Hash the new password
    const hashedPassword = await bcrypt.hash(newPassword, 10);

    // Update the password
    const updateQuery = `
      UPDATE \`Users\`
      SET password = ?
      WHERE username = ?
    `;

    await executeQuery(updateQuery, [hashedPassword, username]);
    return { success: true };
  }
}

module.exports = User;
