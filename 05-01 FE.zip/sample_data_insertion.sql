-- Samsung FMS Portal - Sample Data Insertion
-- This file inserts dummy data that works with the current database schema
-- Run this AFTER creating the database with current_database_schema.sql

USE samsung_fms_portal;

-- Clear existing data (if any) in proper order to respect foreign key constraints
DELETE FROM `Key_Reviews`;
DELETE FROM `Group_Branch_Model_Map`;
DELETE FROM `Group_Branch_Mapping`;
DELETE FROM `grps`;
DELETE FROM `Project_Participants`;
DELETE FROM `Projects`;
DELETE FROM `FMS_Keys`;
DELETE FROM `Branch_Model_Mapping`;
DELETE FROM `Models`;
DELETE FROM `Branches`;
DELETE FROM `Users`;

-- 1. Insert Users with proper bcrypt hashes (password: password123)
INSERT INTO `Users` (username, name, password, role, email, team, is_verified) VALUES
('admin.john', 'John Kim', '$2b$10$GI0dXfMUox4yyBtmt2Qgm.RBQ1X6pyRp29SEYJNmfaa0oj/CxUHSG', 'admin', 'admin.john@samsung.com', 'ENT_SM', TRUE),
('reviewer.sarah', 'Sarah Lee', '$2b$10$GI0dXfMUox4yyBtmt2Qgm.RBQ1X6pyRp29SEYJNmfaa0oj/CxUHSG', 'reviewer', 'reviewer.sarah@samsung.com', 'CTV', TRUE),
('reviewer.mike', 'Mike Johnson', '$2b$10$GI0dXfMUox4yyBtmt2Qgm.RBQ1X6pyRp29SEYJNmfaa0oj/CxUHSG', 'reviewer', 'reviewer.mike@samsung.com', 'ENT_TV', TRUE),
('viewer.anna', 'Anna Park', '$2b$10$GI0dXfMUox4yyBtmt2Qgm.RBQ1X6pyRp29SEYJNmfaa0oj/CxUHSG', 'viewer', 'viewer.anna@samsung.com', 'ENT_SM', TRUE);

SELECT 'Users inserted successfully!' as Status;

-- 2. Insert Branches (using 'branch_path' column)
INSERT INTO `Branches` (branch_name, branch_type, branch_path, is_active) VALUES
('Trunk_2025_MonitorRC_MP_Prj', 'release', '/repo/trunk/2025/MonitorRC/MP_Prj', TRUE),
('Trunk_2024_MonitorRC_MP_Prj', 'release', '/repo/trunk/2024/MonitorRC/MP_Prj', TRUE),
('SmartMonitor_2025_MP_Prj', 'development', '/repo/dev/SmartMonitor/2025/MP_Prj', TRUE),
('Feature_GameBar_2025', 'feature', '/repo/feature/GameBar/2025', TRUE),
('CTV_Platform_24Y', 'release', '/repo/release/CTV/Platform_24Y', TRUE),
('ENT_TV_2025_Release', 'release', '/repo/release/ENT_TV/2025', TRUE);

SELECT 'Branches inserted successfully!' as Status;

-- 3. Insert Models (using 'chipset' column)
INSERT INTO `Models` (model_name, product_category, chipset, is_active) VALUES
-- 2025 F series monitors
('M80F', 'Smart Monitors', 'Tizen OS 8.5', TRUE),
('M70F', 'Smart Monitors', 'Tizen OS 8.5', TRUE),
('M50F', 'Smart Monitors', 'Tizen OS 8.0', TRUE),
('G95SF', 'Smart Monitors', 'Tizen OS 8.5', TRUE),
-- 2024 D series monitors
('M80D', 'Smart Monitors', 'Tizen OS 8.0', TRUE),
('M70D', 'Smart Monitors', 'Tizen OS 8.0', TRUE),
('M50D', 'Smart Monitors', 'Tizen OS 7.5', TRUE),
('G95SD', 'Smart Monitors', 'Tizen OS 8.0', TRUE),
-- CTV models
('S90PC', 'CTV', 'CTV Platform 2023', TRUE),
('S95PD', 'CTV', 'CTV Platform 2024', TRUE),
-- ENT_TV models
('QM98F', 'ENT_TV', 'ENT Platform 2025', TRUE),
('QM85D', 'ENT_TV', 'ENT Platform 2024', TRUE);

SELECT 'Models inserted successfully!' as Status;

-- 4. Insert Branch-Model mappings (which models exist in which branches)
INSERT INTO `Branch_Model_Mapping` (branch_id, model_id, is_available) VALUES
-- 2025 Trunk (branch_id=1) - F series models (model_ids=1,2,3,4) + QM98F (model_id=11)
(1, 1, TRUE), (1, 2, TRUE), (1, 3, TRUE), (1, 4, TRUE), (1, 11, TRUE),
-- 2024 Trunk (branch_id=2) - D series models (model_ids=5,6,7,8) + S95PD + QM85D (model_ids=10,12)
(2, 5, TRUE), (2, 6, TRUE), (2, 7, TRUE), (2, 8, TRUE), (2, 10, TRUE), (2, 12, TRUE),
-- SmartMonitor 2025 (branch_id=3) - F series monitors only (model_ids=1,2,3,4)
(3, 1, TRUE), (3, 2, TRUE), (3, 3, TRUE), (3, 4, TRUE),
-- Gaming Feature Branch (branch_id=4) - Gaming models (model_ids=1,2,4,5,6,8)
(4, 1, TRUE), (4, 2, TRUE), (4, 4, TRUE), (4, 5, TRUE), (4, 6, TRUE), (4, 8, TRUE),
-- CTV Platform (branch_id=5) - CTV models (model_ids=9,10)
(5, 9, TRUE), (5, 10, TRUE),
-- ENT_TV Release (branch_id=6) - ENT models (model_ids=11,12)
(6, 11, TRUE), (6, 12, TRUE);

SELECT 'Branch-Model mappings inserted successfully!' as Status;

-- 5. Insert FMS Keys
INSERT INTO `FMS_Keys` (key_name, work_assignment, work_assignment_owner, key_category, data_type, description, has_differences) VALUES
('gamebar.responsetime', 'TP_GameBar', 'John Smith', 'Gaming', 'boolean', 'Gaming response time optimization feature', TRUE),
('gamebar.gamemode', 'TP_GameBar', 'John Smith', 'Gaming', 'string', 'Automatic game mode detection and switching', TRUE),
('display.powersave.level', 'TP_PowerSave', 'Jane Doe', 'Power Management', 'integer', 'Power save mode level (1=Low, 2=Medium, 3=High)', TRUE),
('audio.enhancement.enable', 'TP_Sound', 'Mike Johnson', 'Audio', 'boolean', 'Audio enhancement features enablement', TRUE),
('connectivity.hdmi.ports', 'TP_Hardware', 'Lisa Chen', 'Hardware', 'integer', 'Number of available HDMI ports', TRUE),
('smart.features.voice', 'TP_SmartTV', 'David Lee', 'Smart Features', 'boolean', 'Voice control features enablement', TRUE);

SELECT 'FMS Keys inserted successfully!' as Status;

-- 6. Insert Projects
INSERT INTO `Projects` (title, description, admin_username, refresh_schedule, status) VALUES
('SM_GameBar_Keys_Review_2025', 'Comprehensive review of gaming-related FMS keys for 2025 Smart Monitor lineup', 'admin.john', 'Weekly', 'active'),
('CTV_Platform_Validation_24Y', 'Validation of CTV platform keys for 2024 year models comparison', 'admin.john', 'Daily', 'active');

SELECT 'Projects inserted successfully!' as Status;

-- 7. Insert Project Participants
INSERT INTO `Project_Participants` (project_id, user_username, added_by, participant_role) VALUES
(1, 'admin.john', 'admin.john', 'admin'),
(1, 'reviewer.sarah', 'admin.john', 'reviewer'),
(1, 'reviewer.mike', 'admin.john', 'reviewer'),
(1, 'viewer.anna', 'admin.john', 'viewer'),
(2, 'admin.john', 'admin.john', 'admin'),
(2, 'reviewer.sarah', 'admin.john', 'reviewer');

SELECT 'Project participants inserted successfully!' as Status;

-- 8. Insert Groups (using grps table to avoid reserved word)
INSERT INTO `grps` (project_id, name, comparison_type) VALUES
(1, 'Gaming_Monitor_2025_vs_2024', '3-way'),
(1, 'Premium_Gaming_Features', '2-way'),
(2, 'CTV_Core_Features', '2-way');

SELECT 'Groups inserted successfully!' as Status;

-- 9. Insert Group-Branch mappings
INSERT INTO `Group_Branch_Mapping` (group_id, branch_role, branch_id, sort_order) VALUES
-- Group 1: Gaming_Monitor_2025_vs_2024 (3-way comparison)
(1, 'target', 1, 1),      -- 2025 Trunk
(1, 'reference1', 2, 2),  -- 2024 Trunk  
(1, 'reference2', 4, 3),  -- Gaming Feature Branch

-- Group 2: Premium_Gaming_Features (2-way comparison)
(2, 'target', 1, 1),      -- 2025 Trunk
(2, 'reference1', 4, 2),  -- Gaming Feature Branch

-- Group 3: CTV_Core_Features (2-way comparison)
(3, 'target', 5, 1),      -- CTV Platform
(3, 'reference1', 2, 2);  -- 2024 Trunk

SELECT 'Group-Branch mappings inserted successfully!' as Status;

-- 10. Insert Group-Branch-Model mappings
INSERT INTO `Group_Branch_Model_Map` (gb_id, model_id) VALUES
-- Group 1 mappings (3-way comparison: 2025 vs 2024 vs Gaming)
(1, 1), (1, 2), (1, 4),   -- F series from 2025 trunk (M80F, M70F, G95SF)
(2, 5), (2, 6), (2, 8),   -- D series from 2024 trunk (M80D, M70D, G95SD)
(3, 1), (3, 2), (3, 4),   -- Gaming models from gaming branch

-- Group 2 mappings (2-way comparison: Premium gaming)
(4, 1), (4, 4),           -- Premium F series from 2025 trunk (M80F, G95SF)
(5, 1), (5, 4),           -- Same models from gaming branch

-- Group 3 mappings (2-way comparison: CTV features)
(6, 9), (6, 10),          -- CTV models from CTV platform (S90PC, S95PD)
(7, 5), (7, 6);           -- Monitor models for comparison (M80D, M70D)

SELECT 'Group-Branch-Model mappings inserted successfully!' as Status;

-- 11. Insert sample Key Reviews (using ACTUAL IDs from your database)
INSERT INTO `Key_Reviews` (fms_key_id, gbm_id, target_val, ref1_val, ref2_val, ref3_val, comment, status, kona_ids, cl_numbers, reviewed_by_username) VALUES
-- Gaming response time (fms_key_id=11: gamebar.responsetime) across different models
(11, 20, 'True', 'True', 'True', NULL, 'Gaming feature enabled for M80F', 'changes_made', 'RQ250607-0239', '1980283', 'reviewer.sarah'),
(11, 23, 'True', 'False', 'True', NULL, 'M80D needs gaming feature update', 'internal_discussion', 'RQ250608-0240', '1980284', 'reviewer.mike'),
(11, 26, 'True', 'True', 'True', NULL, 'Gaming branch M80F consistent', 'changes_made', NULL, NULL, 'reviewer.sarah'),

-- HDMI ports (fms_key_id=15: connectivity.hdmi.ports) differences
(15, 20, '4', '2', '4', NULL, 'M80F upgraded to 4 HDMI ports', 'changes_made', 'RQ250609-0241', '1980285', 'reviewer.sarah'),
(15, 23, '2', '2', '2', NULL, 'M80D standard 2 HDMI ports', 'unreviewed', NULL, NULL, NULL),
(15, 22, '4', '4', NULL, NULL, 'Premium G95SF consistent ports', 'pending_response', 'RQ250612-0244', '1980288', 'reviewer.mike'),

-- Audio enhancement (fms_key_id=14: audio.enhancement.enable)
(14, 29, 'True', 'False', NULL, NULL, 'Premium audio in G95SF', 'changes_made', 'RQ250610-0242', '1980286', 'reviewer.mike'),
(14, 24, 'False', 'False', NULL, NULL, 'CTV audio standard', 'unreviewed', NULL, NULL, NULL),

-- Game mode (fms_key_id=12: gamebar.gamemode)
(12, 20, 'Auto', 'Manual', 'Auto', NULL, 'Auto game mode in M80F', 'no_change_req', 'RQ250611-0243', '1980287', 'reviewer.sarah'),
(12, 23, 'Manual', 'Manual', 'Manual', NULL, 'Manual mode in M80D', 'unreviewed', NULL, NULL, NULL),

-- Power save (fms_key_id=13: display.powersave.level)
(13, 21, '3', '2', '3', NULL, 'Enhanced power save in M70F', 'changes_made', 'RQ250613-0245', '1980289', 'reviewer.mike'),
(13, 24, '2', '2', '2', NULL, 'Standard power save in M70D', 'unreviewed', NULL, NULL, NULL);

-- Final success messages
SELECT '🎉 ALL SAMPLE DATA INSERTED SUCCESSFULLY! 🎉' as Status;
SELECT 'Users created:' as Info, COUNT(*) as Count FROM `Users`;
SELECT 'Projects created:' as Info, COUNT(*) as Count FROM `Projects`;
SELECT 'FMS Keys created:' as Info, COUNT(*) as Count FROM `FMS_Keys`;
SELECT 'Key Reviews created:' as Info, COUNT(*) as Count FROM `Key_Reviews`;
SELECT '✅ Your React app should now work with this data!' as Message;
SELECT '✅ Login with: admin.john / password123' as LoginInfo;
