import React, { useState, useEffect, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import {
    Box,
    Container,
    Paper,
    Typography,
    Tabs,
    Tab,
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TableRow,
    TablePagination,
    TextField,
    InputAdornment,
    Button,
    Chip,
    CircularProgress,
    Alert,
    IconButton,
    Tooltip,
    AppBar,
    Toolbar,
    FormControl,
    InputLabel,
    Select,
    MenuItem,
    LinearProgress,
    Divider
} from '@mui/material';
import {
    Search,
    Sync,
    Key,
    DevicesOther,
    AccountTree,
    Refresh,
    Logout,
    Dashboard,
    CheckCircle,
    Error,
    Timer,
    FilterList,
    Clear
} from '@mui/icons-material';
import { toast } from 'react-toastify';
import { useAuth } from '../../contexts/AuthContext';
import { syncAPI } from '../../services/api';

// Tab Panel component
const TabPanel = ({ children, value, index }) => (
    <div role="tabpanel" hidden={value !== index} style={{ width: '100%' }}>
        {value === index && children}
    </div>
);

const SystemManagement = () => {
    const { user, logout } = useAuth();
    const navigate = useNavigate();

    // State
    const [tabValue, setTabValue] = useState(0);
    const [loading, setLoading] = useState(true);
    const [syncing, setSyncing] = useState({ keys: false, models: false, branches: false });
    const [syncStatus, setSyncStatus] = useState({ keys: null, models: null, branches: null });
    const [stats, setStats] = useState({ keys: 0, models: 0, branches: 0 });

    // Data states
    const [keys, setKeys] = useState([]);
    const [models, setModels] = useState([]);
    const [branches, setBranches] = useState([]);

    // Filter states
    const [keysSearch, setKeysSearch] = useState('');
    const [modelsSearch, setModelsSearch] = useState('');
    const [branchesSearch, setBranchesSearch] = useState('');
    const [categoryFilter, setCategoryFilter] = useState('');
    const [workAssignmentFilter, setWorkAssignmentFilter] = useState('');

    // Pagination states
    const [keysPage, setKeysPage] = useState(0);
    const [keysRowsPerPage, setKeysRowsPerPage] = useState(25);
    const [modelsPage, setModelsPage] = useState(0);
    const [modelsRowsPerPage, setModelsRowsPerPage] = useState(25);
    const [branchesPage, setBranchesPage] = useState(0);
    const [branchesRowsPerPage, setBranchesRowsPerPage] = useState(25);

    useEffect(() => {
        // Check if user is system
        if (user?.username !== 'system') {
            toast.error('Access denied. Only system user can access this page.');
            navigate('/');
            return;
        }
        fetchAllData();
    }, [user, navigate]);

    const fetchAllData = async () => {
        setLoading(true);
        try {
            const [keysResult, modelsResult, branchesResult, statsResult] = await Promise.all([
                syncAPI.getKeys(),
                syncAPI.getModels(),
                syncAPI.getBranches(),
                syncAPI.getStats()
            ]);

            if (keysResult.success) setKeys(keysResult.data || []);
            if (modelsResult.success) setModels(modelsResult.data || []);
            if (branchesResult.success) setBranches(branchesResult.data || []);
            if (statsResult.success) setStats(statsResult.data);
        } catch (err) {
            console.error('Fetch error:', err);
            toast.error('Failed to fetch data');
        } finally {
            setLoading(false);
        }
    };

    const handleSync = async (type) => {
        setSyncing(prev => ({ ...prev, [type]: true }));
        setSyncStatus(prev => ({ ...prev, [type]: null }));

        try {
            let result;
            switch (type) {
                case 'keys':
                    result = await syncAPI.runKeysSync();
                    break;
                case 'models':
                    result = await syncAPI.runModelsSync();
                    break;
                case 'branches':
                    result = await syncAPI.runBranchesSync();
                    break;
                default:
                    throw new Error('Invalid sync type');
            }

            if (result.success) {
                setSyncStatus(prev => ({ ...prev, [type]: 'success' }));
                toast.success(`${type.charAt(0).toUpperCase() + type.slice(1)} sync completed successfully!`);
                // Refresh data after sync
                fetchAllData();
            } else {
                setSyncStatus(prev => ({ 
                    ...prev, 
                    [type]: result.timedOut ? 'timeout' : 'error' 
                }));
                toast.error(result.error || `${type} sync failed`);
            }
        } catch (error) {
            setSyncStatus(prev => ({ ...prev, [type]: 'error' }));
            toast.error(`${type} sync failed: ${error.message}`);
        } finally {
            setSyncing(prev => ({ ...prev, [type]: false }));
        }
    };

    // Get unique values for filters
    const uniqueCategories = useMemo(() => {
        const categories = [...new Set(models.map(m => m.product_category).filter(Boolean))];
        return categories.sort();
    }, [models]);

    const uniqueWorkAssignments = useMemo(() => {
        const wa = [...new Set(keys.map(k => k.work_assignment).filter(Boolean))];
        return wa.sort();
    }, [keys]);

    // Filtered data
    const filteredKeys = useMemo(() => {
        return keys.filter(key => {
            const matchesSearch = !keysSearch || 
                key.key_name?.toLowerCase().includes(keysSearch.toLowerCase()) ||
                key.work_assignment?.toLowerCase().includes(keysSearch.toLowerCase()) ||
                key.work_assignment_owner?.toLowerCase().includes(keysSearch.toLowerCase());
            const matchesWA = !workAssignmentFilter || key.work_assignment === workAssignmentFilter;
            return matchesSearch && matchesWA;
        });
    }, [keys, keysSearch, workAssignmentFilter]);

    const filteredModels = useMemo(() => {
        return models.filter(model => {
            const matchesSearch = !modelsSearch || 
                model.model_name?.toLowerCase().includes(modelsSearch.toLowerCase());
            const matchesCategory = !categoryFilter || model.product_category === categoryFilter;
            return matchesSearch && matchesCategory;
        });
    }, [models, modelsSearch, categoryFilter]);

    const filteredBranches = useMemo(() => {
        return branches.filter(branch => {
            return !branchesSearch || 
                branch.branch_name?.toLowerCase().includes(branchesSearch.toLowerCase());
        });
    }, [branches, branchesSearch]);

    const handleLogout = () => {
        logout();
        navigate('/login');
    };

    const getSyncStatusIcon = (status) => {
        switch (status) {
            case 'success':
                return <CheckCircle color="success" />;
            case 'error':
                return <Error color="error" />;
            case 'timeout':
                return <Timer color="warning" />;
            default:
                return null;
        }
    };

    const renderSyncButton = (type, label, icon) => (
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
            <Button
                variant="contained"
                color="primary"
                startIcon={syncing[type] ? <CircularProgress size={20} color="inherit" /> : icon}
                onClick={() => handleSync(type)}
                disabled={syncing[type]}
                sx={{ minWidth: 150 }}
            >
                {syncing[type] ? 'Syncing...' : `Sync ${label}`}
            </Button>
            {syncStatus[type] && (
                <Tooltip title={
                    syncStatus[type] === 'success' ? 'Sync completed' :
                    syncStatus[type] === 'timeout' ? 'Sync timed out (130s)' :
                    'Sync failed'
                }>
                    {getSyncStatusIcon(syncStatus[type])}
                </Tooltip>
            )}
        </Box>
    );

    if (loading) {
        return (
            <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh' }}>
                <CircularProgress size={60} />
            </Box>
        );
    }

    return (
        <Box sx={{ flexGrow: 1, bgcolor: '#f5f7fa', minHeight: '100vh' }}>
            {/* App Bar */}
            <AppBar position="static" sx={{ bgcolor: '#0d459c' }}>
                <Toolbar>
                    <AccountTree sx={{ mr: 2 }} />
                    <Typography variant="h6" component="div" sx={{ flexGrow: 1 }}>
                        System Management
                    </Typography>
                    <Tooltip title="Go to KPI Dashboard">
                        <IconButton color="inherit" onClick={() => navigate('/kpi')}>
                            <Dashboard />
                        </IconButton>
                    </Tooltip>
                    <Tooltip title="Refresh Data">
                        <IconButton color="inherit" onClick={fetchAllData}>
                            <Refresh />
                        </IconButton>
                    </Tooltip>
                    <Tooltip title="Logout">
                        <IconButton color="inherit" onClick={handleLogout}>
                            <Logout />
                        </IconButton>
                    </Tooltip>
                </Toolbar>
            </AppBar>

            <Container maxWidth="xl" sx={{ mt: 3, mb: 3 }}>
                {/* Stats Summary */}
                <Paper sx={{ p: 2, mb: 3 }}>
                    <Box sx={{ display: 'flex', justifyContent: 'space-around', alignItems: 'center' }}>
                        <Box sx={{ textAlign: 'center' }}>
                            <Typography variant="h4" color="primary" fontWeight="bold">
                                {stats.keys?.toLocaleString() || 0}
                            </Typography>
                            <Typography variant="body2" color="text.secondary">
                                Total Keys
                            </Typography>
                        </Box>
                        <Divider orientation="vertical" flexItem />
                        <Box sx={{ textAlign: 'center' }}>
                            <Typography variant="h4" color="primary" fontWeight="bold">
                                {stats.models?.toLocaleString() || 0}
                            </Typography>
                            <Typography variant="body2" color="text.secondary">
                                Total Models
                            </Typography>
                        </Box>
                        <Divider orientation="vertical" flexItem />
                        <Box sx={{ textAlign: 'center' }}>
                            <Typography variant="h4" color="primary" fontWeight="bold">
                                {stats.branches?.toLocaleString() || 0}
                            </Typography>
                            <Typography variant="body2" color="text.secondary">
                                Total Branches
                            </Typography>
                        </Box>
                    </Box>
                </Paper>

                {/* Tabs */}
                <Paper sx={{ mb: 2 }}>
                    <Tabs
                        value={tabValue}
                        onChange={(e, newValue) => setTabValue(newValue)}
                        indicatorColor="primary"
                        textColor="primary"
                        variant="fullWidth"
                    >
                        <Tab 
                            icon={<Key />} 
                            label={`Key Management (${filteredKeys.length})`} 
                            iconPosition="start"
                        />
                        <Tab 
                            icon={<DevicesOther />} 
                            label={`Model Management (${filteredModels.length})`} 
                            iconPosition="start"
                        />
                        <Tab 
                            icon={<AccountTree />} 
                            label={`Branch Management (${filteredBranches.length})`} 
                            iconPosition="start"
                        />
                    </Tabs>
                </Paper>

                {/* Keys Tab */}
                <TabPanel value={tabValue} index={0}>
                    <Paper sx={{ p: 2 }}>
                        {/* Header with Sync Button */}
                        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
                            <Typography variant="h6">FMS Keys</Typography>
                            {renderSyncButton('keys', 'Keys', <Sync />)}
                        </Box>

                        {syncing.keys && <LinearProgress sx={{ mb: 2 }} />}

                        {/* Filters */}
                        <Box sx={{ display: 'flex', gap: 2, mb: 2, flexWrap: 'wrap' }}>
                            <TextField
                                size="small"
                                placeholder="Search keys..."
                                value={keysSearch}
                                onChange={(e) => { setKeysSearch(e.target.value); setKeysPage(0); }}
                                InputProps={{
                                    startAdornment: (
                                        <InputAdornment position="start">
                                            <Search />
                                        </InputAdornment>
                                    ),
                                    endAdornment: keysSearch && (
                                        <InputAdornment position="end">
                                            <IconButton size="small" onClick={() => setKeysSearch('')}>
                                                <Clear fontSize="small" />
                                            </IconButton>
                                        </InputAdornment>
                                    )
                                }}
                                sx={{ minWidth: 300 }}
                            />
                            <FormControl size="small" sx={{ minWidth: 200 }}>
                                <InputLabel>Work Assignment</InputLabel>
                                <Select
                                    value={workAssignmentFilter}
                                    label="Work Assignment"
                                    onChange={(e) => { setWorkAssignmentFilter(e.target.value); setKeysPage(0); }}
                                >
                                    <MenuItem value="">All</MenuItem>
                                    {uniqueWorkAssignments.map(wa => (
                                        <MenuItem key={wa} value={wa}>{wa}</MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                            {(keysSearch || workAssignmentFilter) && (
                                <Button
                                    variant="outlined"
                                    startIcon={<FilterList />}
                                    onClick={() => { setKeysSearch(''); setWorkAssignmentFilter(''); }}
                                >
                                    Clear Filters
                                </Button>
                            )}
                        </Box>

                        {/* Table */}
                        <TableContainer sx={{ maxHeight: 500 }}>
                            <Table stickyHeader size="small">
                                <TableHead>
                                    <TableRow>
                                        <TableCell sx={{ fontWeight: 'bold', bgcolor: '#f5f5f5' }}>Key Name</TableCell>
                                        <TableCell sx={{ fontWeight: 'bold', bgcolor: '#f5f5f5' }}>Work Assignment</TableCell>
                                        <TableCell sx={{ fontWeight: 'bold', bgcolor: '#f5f5f5' }}>Owner</TableCell>
                                        <TableCell sx={{ fontWeight: 'bold', bgcolor: '#f5f5f5' }}>Description</TableCell>
                                        <TableCell sx={{ fontWeight: 'bold', bgcolor: '#f5f5f5' }}>Has Differences</TableCell>
                                    </TableRow>
                                </TableHead>
                                <TableBody>
                                    {filteredKeys
                                        .slice(keysPage * keysRowsPerPage, keysPage * keysRowsPerPage + keysRowsPerPage)
                                        .map((key) => (
                                            <TableRow key={key.fms_key_id} hover>
                                                <TableCell sx={{ fontFamily: 'monospace', fontSize: '0.85rem' }}>
                                                    {key.key_name}
                                                </TableCell>
                                                <TableCell>{key.work_assignment || '-'}</TableCell>
                                                <TableCell>{key.work_assignment_owner || '-'}</TableCell>
                                                <TableCell sx={{ maxWidth: 300, overflow: 'hidden', textOverflow: 'ellipsis' }}>
                                                    {key.description || '-'}
                                                </TableCell>
                                                <TableCell>
                                                    <Chip
                                                        size="small"
                                                        label={key.has_differences ? 'Yes' : 'No'}
                                                        color={key.has_differences ? 'warning' : 'default'}
                                                    />
                                                </TableCell>
                                            </TableRow>
                                        ))}
                                </TableBody>
                            </Table>
                        </TableContainer>
                        <TablePagination
                            component="div"
                            count={filteredKeys.length}
                            page={keysPage}
                            onPageChange={(e, newPage) => setKeysPage(newPage)}
                            rowsPerPage={keysRowsPerPage}
                            onRowsPerPageChange={(e) => { setKeysRowsPerPage(parseInt(e.target.value, 10)); setKeysPage(0); }}
                            rowsPerPageOptions={[10, 25, 50, 100]}
                        />
                    </Paper>
                </TabPanel>

                {/* Models Tab */}
                <TabPanel value={tabValue} index={1}>
                    <Paper sx={{ p: 2 }}>
                        {/* Header with Sync Button */}
                        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
                            <Typography variant="h6">Models</Typography>
                            {renderSyncButton('models', 'Models', <Sync />)}
                        </Box>

                        {syncing.models && <LinearProgress sx={{ mb: 2 }} />}

                        {/* Filters */}
                        <Box sx={{ display: 'flex', gap: 2, mb: 2, flexWrap: 'wrap' }}>
                            <TextField
                                size="small"
                                placeholder="Search models..."
                                value={modelsSearch}
                                onChange={(e) => { setModelsSearch(e.target.value); setModelsPage(0); }}
                                InputProps={{
                                    startAdornment: (
                                        <InputAdornment position="start">
                                            <Search />
                                        </InputAdornment>
                                    ),
                                    endAdornment: modelsSearch && (
                                        <InputAdornment position="end">
                                            <IconButton size="small" onClick={() => setModelsSearch('')}>
                                                <Clear fontSize="small" />
                                            </IconButton>
                                        </InputAdornment>
                                    )
                                }}
                                sx={{ minWidth: 300 }}
                            />
                            <FormControl size="small" sx={{ minWidth: 200 }}>
                                <InputLabel>Product Category</InputLabel>
                                <Select
                                    value={categoryFilter}
                                    label="Product Category"
                                    onChange={(e) => { setCategoryFilter(e.target.value); setModelsPage(0); }}
                                >
                                    <MenuItem value="">All</MenuItem>
                                    {uniqueCategories.map(cat => (
                                        <MenuItem key={cat} value={cat}>{cat}</MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                            {(modelsSearch || categoryFilter) && (
                                <Button
                                    variant="outlined"
                                    startIcon={<FilterList />}
                                    onClick={() => { setModelsSearch(''); setCategoryFilter(''); }}
                                >
                                    Clear Filters
                                </Button>
                            )}
                        </Box>

                        {/* Table */}
                        <TableContainer sx={{ maxHeight: 500 }}>
                            <Table stickyHeader size="small">
                                <TableHead>
                                    <TableRow>
                                        <TableCell sx={{ fontWeight: 'bold', bgcolor: '#f5f5f5' }}>Model ID</TableCell>
                                        <TableCell sx={{ fontWeight: 'bold', bgcolor: '#f5f5f5' }}>Model Name</TableCell>
                                        <TableCell sx={{ fontWeight: 'bold', bgcolor: '#f5f5f5' }}>Product Category</TableCell>
                                    </TableRow>
                                </TableHead>
                                <TableBody>
                                    {filteredModels
                                        .slice(modelsPage * modelsRowsPerPage, modelsPage * modelsRowsPerPage + modelsRowsPerPage)
                                        .map((model) => (
                                            <TableRow key={model.model_id} hover>
                                                <TableCell>{model.model_id}</TableCell>
                                                <TableCell sx={{ fontWeight: 500 }}>{model.model_name}</TableCell>
                                                <TableCell>
                                                    <Chip size="small" label={model.product_category || 'N/A'} />
                                                </TableCell>
                                            </TableRow>
                                        ))}
                                </TableBody>
                            </Table>
                        </TableContainer>
                        <TablePagination
                            component="div"
                            count={filteredModels.length}
                            page={modelsPage}
                            onPageChange={(e, newPage) => setModelsPage(newPage)}
                            rowsPerPage={modelsRowsPerPage}
                            onRowsPerPageChange={(e) => { setModelsRowsPerPage(parseInt(e.target.value, 10)); setModelsPage(0); }}
                            rowsPerPageOptions={[10, 25, 50, 100]}
                        />
                    </Paper>
                </TabPanel>

                {/* Branches Tab */}
                <TabPanel value={tabValue} index={2}>
                    <Paper sx={{ p: 2 }}>
                        {/* Header with Sync Button */}
                        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
                            <Typography variant="h6">Branches</Typography>
                            {renderSyncButton('branches', 'Branches', <Sync />)}
                        </Box>

                        {syncing.branches && <LinearProgress sx={{ mb: 2 }} />}

                        {/* Filters */}
                        <Box sx={{ display: 'flex', gap: 2, mb: 2 }}>
                            <TextField
                                size="small"
                                placeholder="Search branches..."
                                value={branchesSearch}
                                onChange={(e) => { setBranchesSearch(e.target.value); setBranchesPage(0); }}
                                InputProps={{
                                    startAdornment: (
                                        <InputAdornment position="start">
                                            <Search />
                                        </InputAdornment>
                                    ),
                                    endAdornment: branchesSearch && (
                                        <InputAdornment position="end">
                                            <IconButton size="small" onClick={() => setBranchesSearch('')}>
                                                <Clear fontSize="small" />
                                            </IconButton>
                                        </InputAdornment>
                                    )
                                }}
                                sx={{ minWidth: 300 }}
                            />
                            {branchesSearch && (
                                <Button
                                    variant="outlined"
                                    startIcon={<FilterList />}
                                    onClick={() => setBranchesSearch('')}
                                >
                                    Clear Filter
                                </Button>
                            )}
                        </Box>

                        {/* Table */}
                        <TableContainer sx={{ maxHeight: 500 }}>
                            <Table stickyHeader size="small">
                                <TableHead>
                                    <TableRow>
                                        <TableCell sx={{ fontWeight: 'bold', bgcolor: '#f5f5f5' }}>Branch ID</TableCell>
                                        <TableCell sx={{ fontWeight: 'bold', bgcolor: '#f5f5f5' }}>Branch Name</TableCell>
                                    </TableRow>
                                </TableHead>
                                <TableBody>
                                    {filteredBranches
                                        .slice(branchesPage * branchesRowsPerPage, branchesPage * branchesRowsPerPage + branchesRowsPerPage)
                                        .map((branch) => (
                                            <TableRow key={branch.branch_id} hover>
                                                <TableCell>{branch.branch_id}</TableCell>
                                                <TableCell sx={{ fontWeight: 500 }}>{branch.branch_name}</TableCell>
                                            </TableRow>
                                        ))}
                                </TableBody>
                            </Table>
                        </TableContainer>
                        <TablePagination
                            component="div"
                            count={filteredBranches.length}
                            page={branchesPage}
                            onPageChange={(e, newPage) => setBranchesPage(newPage)}
                            rowsPerPage={branchesRowsPerPage}
                            onRowsPerPageChange={(e) => { setBranchesRowsPerPage(parseInt(e.target.value, 10)); setBranchesPage(0); }}
                            rowsPerPageOptions={[10, 25, 50, 100]}
                        />
                    </Paper>
                </TabPanel>
            </Container>
        </Box>
    );
};

export default SystemManagement;

