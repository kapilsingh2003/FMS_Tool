import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Container,
  Paper,
  Box,
  Typography,
  Button,
  Card,
  CardContent,
  Grid,
  Chip,
  Avatar,
  Fab,
  CardActions,
  Divider,
  IconButton,
  Tooltip,
  Alert,
  CircularProgress,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  DialogContentText
} from '@mui/material';
import {
  ExitToApp,
  AdminPanelSettings,
  RateReview,
  Visibility,
  Add,
  Search,
  People,
  Assessment,
  ManageAccounts,
  Settings,
  Delete
} from '@mui/icons-material';
import { useAuth } from '../../contexts/AuthContext';
import { projectsAPI } from '../../services/api';
import { toast } from 'react-toastify';

const Dashboard = () => {
  const { user, logout, USER_ROLES, isGlobalAdmin } = useAuth();
  const navigate = useNavigate();
  const [projects, setProjects] = useState([]);
  const [createdProjects, setCreatedProjects] = useState([]); // Projects created by user
  const [participantProjects, setParticipantProjects] = useState([]); // Projects user participates in
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [projectToDelete, setProjectToDelete] = useState(null);

  useEffect(() => {
    fetchProjects();
  }, [user]);

  const fetchProjects = async () => {
    try {
      setLoading(true);
      setError(null);

      // Don't fetch projects if user is not logged in
      if (!user) {
        setLoading(false);
        return;
      }

      const result = await projectsAPI.getAllProjects();

      if (result.success) {
        // Filter projects based on user role and participation
        let userProjects = [];

        const projects = result.data.projects || [];

        // Transform backend data to match frontend expectations
        const transformedProjects = projects.map(project => ({
          ...project,
          id: project.project_id,
          adminId: project.admin_username,
          adminName: project.admin_name,
          participants: project.participants || [], // Use actual participants from backend
          status: project.status || 'syncing',
          productCategory: 'Smart Monitor',
          createdDate: new Date(project.created_date).toISOString().split('T')[0]
        }));

        if (isGlobalAdmin()) {
          // For admins, split projects into created vs participating
          const created = transformedProjects.filter(project => project.admin_username === user.username);
          const participating = transformedProjects.filter(project =>
            project.admin_username !== user.username &&
            (project.participants && project.participants.includes(user.username))
          );

          console.log('Dashboard Debug - Current user:', user.username);
          console.log('Dashboard Debug - All projects:', transformedProjects.map(p => ({
            id: p.project_id,
            admin: p.admin_username,
            participants: p.participants
          })));
          console.log('Dashboard Debug - Created projects:', created.length);
          console.log('Dashboard Debug - Participating projects:', participating.length);

          setCreatedProjects(created);
          setParticipantProjects(participating);
          setProjects(transformedProjects); // Keep all for compatibility
        } else {
          // Non-admin users see projects they're part of
          userProjects = transformedProjects.filter(project =>
            project.admin_username === user.username ||
            (project.participants && project.participants.includes(user.username))
          );
          setProjects(userProjects);
        }
      } else {
        setError(result.error);
        toast.error(result.error);
      }
    } catch (error) {
      setError('Failed to fetch projects');
      toast.error('Failed to fetch projects');
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = () => {
    logout();
  };

  const handleCreateProject = () => {
    navigate('/projects/configure');
  };

  const handleExploreProjects = () => {
    // TODO: Navigate to explore projects page
    console.log('Navigate to explore projects');
  };

  const handleOpenProject = (projectId) => {
    console.log('Opening project:', projectId);
    navigate(`/projects/${projectId}/review`);
  };

  const handleProjectUserManagement = (event, projectId) => {
    event.stopPropagation(); // Prevent card click from opening project
    navigate(`/projects/${projectId}/users`);
  };

  const handleProjectConfigEdit = (event, projectId) => {
    event.stopPropagation(); // Prevent card click from opening project
    navigate(`/projects/${projectId}/edit`);
  };

  const handleDeleteProject = (event, project) => {
    event.stopPropagation(); // Prevent card click from opening project
    setProjectToDelete(project);
    setDeleteDialogOpen(true);
  };

  const handleConfirmDelete = async () => {
    if (!projectToDelete) return;

    try {
      const result = await projectsAPI.deleteProject(projectToDelete.id);

      if (result.success) {
        // Remove project from local state
        setProjects(prevProjects =>
          prevProjects.filter(project => project.id !== projectToDelete.id)
        );
        toast.success(`Project "${projectToDelete.title}" deleted successfully`);
      } else {
        toast.error(result.error || 'Failed to delete project');
      }
    } catch (error) {
      toast.error('Failed to delete project');
    }

    // Close dialog and reset state
    setDeleteDialogOpen(false);
    setProjectToDelete(null);
  };

  const handleCancelDelete = () => {
    setDeleteDialogOpen(false);
    setProjectToDelete(null);
  };

  const getRoleIcon = (userType) => {
    switch (userType) {
      case 'admin':
        return <AdminPanelSettings />;
      case 'user':
        return <Visibility />;
      default:
        return <Visibility />;
    }
  };

  const getRoleColor = (userType) => {
    switch (userType) {
      case 'admin':
        return 'error';
      case 'user':
        return 'info';
      default:
        return 'default';
    }
  };

  // Project Card Component
  const ProjectCard = ({ project, isCreator = false }) => {
    return (
      <Card
        sx={{
          height: '100%',
          display: 'flex',
          flexDirection: 'column',
          transition: 'all 0.3s ease',
          '&:hover': {
            transform: 'translateY(-4px)',
            boxShadow: 4,
          },
          cursor: 'pointer',
          position: 'relative', // For absolute positioning of delete button
        }}
        onClick={() => handleOpenProject(project.id)}
      >
        {/* Delete button in top-right corner for project creators only */}
        {isGlobalAdmin() && isCreator && (
          <IconButton
            onClick={(e) => handleDeleteProject(e, project)}
            sx={{
              position: 'absolute',
              top: 8,
              right: 8,
              color: 'error.main',
              backgroundColor: 'background.paper',
              border: '1px solid',
              borderColor: 'error.main',
              borderRadius: 2, // Rounded square instead of circle
              width: 32,       // Fixed width for square shape
              height: 32,      // Fixed height for square shape
              boxShadow: 1,
              '&:hover': {
                backgroundColor: 'error.light',
                color: 'white',
                borderColor: 'error.light',
              },
              zIndex: 1,
            }}
            size="small"
          >
            <Delete fontSize="small" />
          </IconButton>
        )}
        <CardContent sx={{
          flexGrow: 1,
          paddingTop: isGlobalAdmin() && isCreator ? 4 : 3 // Extra top padding for creator delete button
        }}>
          <Box sx={{ mb: 2 }}>
            <Typography
              variant="h6"
              component="h3"
              sx={{
                fontWeight: 600,
                mb: 2,
                wordWrap: 'break-word',
                wordBreak: 'break-word',
                hyphens: 'auto',
                lineHeight: 1.3
              }}
              title={project.title} // Show full title on hover
            >
              {project.title.length > 30 ? `${project.title.substring(0, 30)}...` : project.title}
            </Typography>
          </Box>

          <Typography variant="body2" color="text.secondary" sx={{ mb: 2, minHeight: 40 }}>
            {project.description}
          </Typography>

          <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 2 }}>
            <Box sx={{ display: 'flex', alignItems: 'center' }}>
              <Avatar sx={{ width: 32, height: 32, mr: 1, bgcolor: 'primary.main' }}>
                {project.adminName.split(' ').map(n => n[0]).join('')}
              </Avatar>
              <Typography variant="body2" color="text.secondary">
                Created by <strong>{project.adminName}</strong>
              </Typography>
            </Box>
            <Chip
              label={project.status}
              size="small"
              sx={{
                bgcolor:
                  project.status === 'active' ? 'success.main' :
                    project.status === 'syncing' ? 'info.main' :
                      project.status === 'sync error' ? 'error.main' : 'default',
                color: 'common.white'
              }}
            />
          </Box>

          {isGlobalAdmin() && isCreator && (
            <Box sx={{ mt: 2, display: 'flex', flexDirection: 'column', gap: 1 }}>
              <Button
                fullWidth
                variant="outlined"
                startIcon={<ManageAccounts />}
                onClick={(e) => handleProjectUserManagement(e, project.id)}
                size="small"
                sx={{
                  '&:hover': {
                    borderColor: 'primary.main',
                    backgroundColor: 'primary.main',
                    color: 'white'
                  }
                }}
              >
                Manage Users
              </Button>
              <Button
                fullWidth
                variant="outlined"
                startIcon={<Settings />}
                onClick={(e) => handleProjectConfigEdit(e, project.id)}
                size="small"
                sx={{
                  color: 'error.main',
                  borderColor: 'error.main',
                  '&:hover': {
                    borderColor: 'error.main',
                    backgroundColor: 'error.light',
                    color: 'white'
                  }
                }}
              >
                Edit Configuration
              </Button>
            </Box>
          )}
        </CardContent>

        <CardActions sx={{ justifyContent: 'space-between', px: 2, py: 1 }}>
          <Box sx={{ display: 'flex', alignItems: 'center' }}>
            <People sx={{ fontSize: 16, mr: 0.5, color: 'text.secondary' }} />
            <Typography variant="caption" color="text.secondary">
              {project.participants.length} members
            </Typography>
          </Box>
          <Typography variant="caption" color="text.secondary">
            {new Date(project.createdDate).toLocaleDateString()}
          </Typography>
        </CardActions>
      </Card>
    );
  };

  // Empty State Component
  const EmptyState = () => {
    if (isGlobalAdmin()) {
      return (
        <Box
          sx={{
            textAlign: 'center',
            py: 8,
            px: 4,
          }}
        >
          <Assessment sx={{ fontSize: 80, color: 'text.secondary', mb: 3 }} />
          <Typography variant="h5" gutterBottom sx={{ fontWeight: 600 }}>
            Welcome, Project Admin!
          </Typography>
          <Typography variant="body1" color="text.secondary" sx={{ mb: 4, maxWidth: 500, mx: 'auto' }}>
            You haven't created any FMS key review projects yet. Start by creating your first project to configure model comparisons and invite team members.
          </Typography>
          <Button
            variant="contained"
            size="large"
            startIcon={<Add />}
            onClick={handleCreateProject}
            sx={{
              px: 4,
              py: 1.5,
              background: 'linear-gradient(45deg, #1976d2 30%, #42a5f5 90%)',
              '&:hover': {
                background: 'linear-gradient(45deg, #1565c0 30%, #1976d2 90%)',
              },
            }}
          >
            Create Your First Project
          </Button>
        </Box>
      );
    } else {
      return (
        <Box
          sx={{
            textAlign: 'center',
            py: 8,
            px: 4,
          }}
        >
          <Search sx={{ fontSize: 80, color: 'text.secondary', mb: 3 }} />
          <Typography variant="h5" gutterBottom sx={{ fontWeight: 600 }}>
            No Projects Found
          </Typography>
          <Typography variant="body1" color="text.secondary" sx={{ mb: 4, maxWidth: 500, mx: 'auto' }}>
            You haven't joined any FMS key review projects yet. Explore available projects or wait for an admin to invite you to a project.
          </Typography>
          <Button
            variant="contained"
            size="large"
            startIcon={<Search />}
            onClick={handleExploreProjects}
            sx={{
              px: 4,
              py: 1.5,
              background: 'linear-gradient(45deg, #1976d2 30%, #42a5f5 90%)',
              '&:hover': {
                background: 'linear-gradient(45deg, #1565c0 30%, #1976d2 90%)',
              },
            }}
          >
            Explore Projects
          </Button>
        </Box>
      );
    }
  };

  // Loading State
  if (loading) {
    return (
      <Container maxWidth="xl">
        <Box sx={{ mt: 4, mb: 4, display: 'flex', justifyContent: 'center', alignItems: 'center', height: '50vh' }}>
          <CircularProgress />
        </Box>
      </Container>
    );
  }

  // Error State
  if (error) {
    return (
      <Container maxWidth="xl">
        <Box sx={{ mt: 4, mb: 4 }}>
          <Alert severity="error" sx={{ mb: 3 }}>
            {error}
          </Alert>
          <Button variant="contained" onClick={fetchProjects}>
            Retry
          </Button>
        </Box>
      </Container>
    );
  }

  return (
    <Container maxWidth="lg">
      <Box sx={{ mt: 4, mb: 4 }}>
        {/* Header */}
        <Paper sx={{ p: 3, mb: 3 }}>
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <Box sx={{ display: 'flex', alignItems: 'center' }}>
              <Box sx={{ display: 'flex', mr: 2 }}>
                <img
                  src="/icon.svg"
                  alt="FMS Icon"
                  style={{ width: 40, height: 40 }}
                />
              </Box>
              <Typography
                variant="h4"
                sx={{
                  color: 'primary.main',
                  fontWeight: 700,
                }}
              >
                FMS Review Manager
              </Typography>
            </Box>
            <Button
              variant="outlined"
              startIcon={<ExitToApp />}
              onClick={handleLogout}
              color="primary"
            >
              Logout
            </Button>
          </Box>
        </Paper>

        {/* Welcome Section */}
        <Card sx={{ mb: 3 }}>
          <CardContent>
            <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
              <Avatar
                sx={{
                  bgcolor: 'primary.main',
                  mr: 2,
                  width: 56,
                  height: 56,
                }}
              >
                {user?.name?.charAt(0).toUpperCase()}
              </Avatar>
              <Box sx={{ flexGrow: 1 }}>
                <Typography variant="h5" gutterBottom>
                  Welcome back, {user?.name}!
                </Typography>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                  <Chip
                    icon={getRoleIcon(user?.user_type)}
                    label={user?.user_type === 'admin' ? 'Administrator' : 'User'}
                    color={getRoleColor(user?.user_type)}
                    variant="outlined"
                  />
                  <Typography variant="body2" color="text.secondary">
                    {user?.department || user?.team} • {user?.username || user?.email?.split('@')[0]}
                  </Typography>
                </Box>
              </Box>

              {/* Action Buttons */}
              <Box sx={{ display: 'flex', gap: 1 }}>
                {isGlobalAdmin() && (
                  <Button
                    variant="contained"
                    startIcon={<Add />}
                    onClick={handleCreateProject}
                    sx={{
                      background: 'linear-gradient(45deg, #1976d2 30%, #42a5f5 90%)',
                      '&:hover': {
                        background: 'linear-gradient(45deg, #1565c0 30%, #1976d2 90%)',
                      },
                    }}
                  >
                    Create Project
                  </Button>
                )}
              </Box>
            </Box>
            <Typography variant="body1" color="text.secondary">
              You are logged in as a <strong>{user?.user_type === 'admin' ? 'Administrator' : 'User'}</strong>.
              {isGlobalAdmin() && " You can create and manage FMS key review projects."}
              {!isGlobalAdmin() && " You can participate in assigned FMS key review projects."}
            </Typography>
          </CardContent>
        </Card>

        {/* Projects Section */}
        {isGlobalAdmin() ? (
          // Admin dashboard with two sections
          <>
            {/* Created Projects Section */}
            <Box sx={{ mb: 4 }}>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
                <Typography variant="h5" sx={{ fontWeight: 600 }}>
                  Created by You
                </Typography>
                {createdProjects.length > 0 && (
                  <Typography variant="body2" color="text.secondary">
                    {createdProjects.length} project{createdProjects.length > 1 ? 's' : ''}
                  </Typography>
                )}
              </Box>

              {createdProjects.length === 0 ? (
                <EmptyState />
              ) : (
                <Grid container spacing={3}>
                  {createdProjects.map((project) => (
                    <Grid item xs={12} md={6} lg={4} key={project.id}>
                      <ProjectCard project={project} isCreator={true} />
                    </Grid>
                  ))}
                </Grid>
              )}
            </Box>

            {/* Other Projects Section */}
            {participantProjects.length > 0 && (
              <Box sx={{ mb: 3 }}>
                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
                  <Typography variant="h5" sx={{ fontWeight: 600 }}>
                    Other Projects
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    {participantProjects.length} project{participantProjects.length > 1 ? 's' : ''}
                  </Typography>
                </Box>
                <Grid container spacing={3}>
                  {participantProjects.map((project) => (
                    <Grid item xs={12} md={6} lg={4} key={project.id}>
                      <ProjectCard project={project} isCreator={false} />
                    </Grid>
                  ))}
                </Grid>
              </Box>
            )}
          </>
        ) : (
          // Non-admin dashboard
          <Box sx={{ mb: 3 }}>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
              <Typography variant="h5" sx={{ fontWeight: 600 }}>
                Assigned Projects
              </Typography>
              {projects.length > 0 && (
                <Typography variant="body2" color="text.secondary">
                  {projects.length} project{projects.length > 1 ? 's' : ''}
                </Typography>
              )}
            </Box>

            {projects.length === 0 ? (
              <EmptyState />
            ) : (
              <Grid container spacing={3}>
                {projects.map((project) => (
                  <Grid item xs={12} md={6} lg={4} key={project.id}>
                    <ProjectCard project={project} isCreator={false} />
                  </Grid>
                ))}
              </Grid>
            )}
          </Box>
        )}

        {/* Floating Action Button for Mobile */}
        {user?.role === USER_ROLES.ADMIN && (
          <Fab
            color="primary"
            aria-label="create project"
            onClick={handleCreateProject}
            sx={{
              position: 'fixed',
              bottom: 24,
              right: 24,
              display: { xs: 'flex', md: 'none' },
            }}
          >
            <Add />
          </Fab>
        )}

        {/* Delete Confirmation Dialog */}
        <Dialog
          open={deleteDialogOpen}
          onClose={handleCancelDelete}
          aria-labelledby="delete-dialog-title"
          aria-describedby="delete-dialog-description"
        >
          <DialogTitle id="delete-dialog-title" sx={{ color: 'error.main' }}>
            Delete Project
          </DialogTitle>
          <DialogContent>
            <DialogContentText id="delete-dialog-description">
              Are you sure you want to delete the project "{projectToDelete?.title}"?
              <br />
              <br />
              <strong>This action cannot be undone and will remove the project for all users.</strong>
            </DialogContentText>
          </DialogContent>
          <DialogActions>
            <Button onClick={handleCancelDelete} color="primary">
              Cancel
            </Button>
            <Button onClick={handleConfirmDelete} color="error" variant="contained">
              Delete Project
            </Button>
          </DialogActions>
        </Dialog>

      </Box>
    </Container>
  );
};

export default Dashboard; 