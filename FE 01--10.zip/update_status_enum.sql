-- Update the status enum in Key_Reviews table to include new status types
-- Run this script to update your existing database

USE samsung_fms_portal;

-- Add new status types to the existing enum
ALTER TABLE `Key_Reviews` 
MODIFY COLUMN `status` ENUM(
    'unreviewed', 
    'changes_made', 
    'pending_response', 
    'no_change_req', 
    'internal_discussion', 
    'changes_in_progress', 
    'value_changed'
) DEFAULT 'unreviewed';

-- Verify the changes
DESCRIBE `Key_Reviews`;
