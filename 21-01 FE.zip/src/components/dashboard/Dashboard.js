import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Container,
  Paper,
  Box,
  Typography,
  Button,
  Card,
  CardContent,
  Grid,
  Chip,
  Avatar,
  Fab,
  CardActions,
  Divider,
  IconButton,
  Tooltip,
  Alert,
  CircularProgress,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  DialogContentText,
  TextField,
  InputAdornment,
  Tabs,
  Tab
} from '@mui/material';
import {
  ExitToApp,
  AdminPanelSettings,
  RateReview,
  Visibility,
  VisibilityOff,
  Add,
  Search,
  People,
  Assessment,
  ManageAccounts,
  Settings,
  Delete,
  Refresh,
  VpnKey,
  Dashboard as DashboardIcon,
  BarChart,
  ChatBubble,
  Star,
  Send,
  CheckCircle,
  Cancel,
  Schedule
} from '@mui/icons-material';
import AllComments from './AllComments';
import LinearProgress from '@mui/material/LinearProgress';
import { useAuth } from '../../contexts/AuthContext';
import { projectsAPI, authAPI } from '../../services/api';
import { toast } from 'react-toastify';

const Dashboard = () => {
  const { user, logout, USER_ROLES, isGlobalAdmin } = useAuth();
  const navigate = useNavigate();
  const [projects, setProjects] = useState([]);
  const [createdProjects, setCreatedProjects] = useState([]); // Projects created by user
  const [participantProjects, setParticipantProjects] = useState([]); // Projects user participates in
  const [officialProjects, setOfficialProjects] = useState([]); // Official projects user is part of
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [projectToDelete, setProjectToDelete] = useState(null);
  const [refreshingProjects, setRefreshingProjects] = useState(new Set());
  const [pollingInterval, setPollingInterval] = useState(null);
  // PM approval dialog
  const [pmApprovalDialogOpen, setPmApprovalDialogOpen] = useState(false);
  const [pmApprovalAction, setPmApprovalAction] = useState(null); // 'submit', 'approve', 'reject'
  const [pmApprovalProject, setPmApprovalProject] = useState(null);
  const [rejectionReason, setRejectionReason] = useState('');

  // Tab state
  const [activeTab, setActiveTab] = useState(0);

  // Change password dialog states
  const [changePasswordOpen, setChangePasswordOpen] = useState(false);
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showCurrentPassword, setShowCurrentPassword] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [passwordChangeLoading, setPasswordChangeLoading] = useState(false);

  useEffect(() => {
    fetchProjects();

    // Listen for project creation polling events
    const handleProjectPolling = (event) => {
      const { projectId } = event.detail;
      startPolling(projectId);
    };

    window.addEventListener('startProjectPolling', handleProjectPolling);

    // Cleanup polling on unmount
    return () => {
      if (pollingInterval) {
        clearInterval(pollingInterval);
      }
      window.removeEventListener('startProjectPolling', handleProjectPolling);
    };
  }, [user]);

  // Start polling for a specific project
  const startPolling = (projectId) => {
    // Clear any existing interval
    if (pollingInterval) {
      clearInterval(pollingInterval);
    }

    // Poll every 2 seconds
    const interval = setInterval(async () => {
      try {
        const result = await projectsAPI.getAllProjects();
        if (result.success) {
          const projects = result.data.projects || [];
          const project = projects.find(p => p.project_id === projectId);

          if (project && (project.status === 'active' || project.status === 'sync error')) {
            // Project is no longer syncing, stop polling and update state
            clearInterval(interval);
            setPollingInterval(null);
            fetchProjects();

            // Show appropriate toast message
            if (project.status === 'active') {
              toast.success('Project sync completed successfully');
            } else if (project.status === 'sync error') {
              toast.error('Project sync failed');
            }
          }
        }
      } catch (error) {
        console.error('Polling error:', error);
      }
    }, 2000);

    setPollingInterval(interval);
  };

  const fetchProjects = async () => {
    try {
      setLoading(true);
      setError(null);

      // Don't fetch projects if user is not logged in
      if (!user) {
        setLoading(false);
        return;
      }

      // Fetch regular projects and official projects in parallel
      const [result, officialResult] = await Promise.all([
        projectsAPI.getAllProjects(),
        projectsAPI.getOfficialProjects()
      ]);

      if (result.success) {
        // Filter projects based on user role and participation
        let userProjects = [];

        const projects = result.data.projects || [];

        // Transform backend data to match frontend expectations
        const transformedProjects = projects.map(project => ({
          ...project,
          id: project.project_id,
          adminId: project.admin_username,
          adminName: project.admin_name,
          participants: project.participants || [], // Use actual participants from backend
          status: project.status || 'syncing',
          productCategory: 'Smart Monitor',
          createdDate: new Date(project.created_date).toISOString().split('T')[0],
          lastRefreshedAt: project.last_refreshed_at || null
        }));

        // Filter out official projects from the regular list (they'll be shown separately)
        const regularProjects = transformedProjects.filter(p => !p.is_official);

        if (isGlobalAdmin()) {
          // For admins, split projects into created vs participating
          const created = regularProjects.filter(project => project.admin_username === user.username);
          const participating = regularProjects.filter(project =>
            project.admin_username !== user.username &&
            (project.participants && project.participants.includes(user.username))
          );

          console.log('Dashboard Debug - Current user:', user.username);
          console.log('Dashboard Debug - All projects:', regularProjects.map(p => ({
            id: p.project_id,
            admin: p.admin_username,
            participants: p.participants
          })));
          console.log('Dashboard Debug - Created projects:', created.length);
          console.log('Dashboard Debug - Participating projects:', participating.length);

          setCreatedProjects(created);
          setParticipantProjects(participating);
          setProjects(regularProjects); // Keep all for compatibility
        } else {
          // Non-admin users see projects they're part of
          userProjects = regularProjects.filter(project =>
            project.admin_username === user.username ||
            (project.participants && project.participants.includes(user.username))
          );
          setProjects(userProjects);
        }
      } else {
        setError(result.error);
        toast.error(result.error);
      }

      // Set official projects if fetch was successful
      if (officialResult.success) {
        console.log('Official Projects Debug:', officialResult.data);
        setOfficialProjects(officialResult.data || []);
      } else {
        console.log('Official Projects Error:', officialResult.error);
      }

      // Debug: Log is_official field from regular projects
      console.log('All projects is_official values:', (result.data?.projects || []).map(p => ({
        id: p.project_id,
        title: p.title,
        is_official: p.is_official
      })));
    } catch (error) {
      setError('Failed to fetch projects');
      toast.error('Failed to fetch projects');
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = () => {
    logout();
  };

  const handleCreateProject = () => {
    navigate('/projects/configure');
  };

  const handleExploreProjects = () => {
    // TODO: Navigate to explore projects page
    console.log('Navigate to explore projects');
  };

  const handleOpenProject = (projectId) => {
    console.log('Opening project:', projectId);
    navigate(`/projects/${projectId}/review`);
  };

  const handleProjectUserManagement = (event, projectId) => {
    event.stopPropagation(); // Prevent card click from opening project
    navigate(`/projects/${projectId}/users`);
  };

  const handleProjectConfigEdit = (event, projectId) => {
    event.stopPropagation(); // Prevent card click from opening project
    navigate(`/projects/${projectId}/edit`);
  };

  const handleDeleteProject = (event, project) => {
    event.stopPropagation(); // Prevent card click from opening project
    setProjectToDelete(project);
    setDeleteDialogOpen(true);
  };

  const handleConfirmDelete = async () => {
    if (!projectToDelete) return;

    try {
      const result = await projectsAPI.deleteProject(projectToDelete.id);

      if (result.success) {
        // Remove project from all local states
        setProjects(prevProjects =>
          prevProjects.filter(project => project.id !== projectToDelete.id)
        );
        setCreatedProjects(prevProjects =>
          prevProjects.filter(project => project.id !== projectToDelete.id)
        );
        setParticipantProjects(prevProjects =>
          prevProjects.filter(project => project.id !== projectToDelete.id)
        );
        toast.success(`Project "${projectToDelete.title}" deleted successfully`);
      } else {
        toast.error(result.error || 'Failed to delete project');
      }
    } catch (error) {
      toast.error('Failed to delete project');
    }

    // Close dialog and reset state
    setDeleteDialogOpen(false);
    setProjectToDelete(null);
  };

  const handleCancelDelete = () => {
    setDeleteDialogOpen(false);
    setProjectToDelete(null);
  };

  const handleRefreshProject = async (event, projectId) => {
    event.stopPropagation(); // Prevent card click from opening project

    try {
      // Add project to refreshing set and set status to syncing
      setRefreshingProjects(prev => new Set(prev).add(projectId));

      // Optimistically update the project status to 'syncing'
      setProjects(prevProjects =>
        prevProjects.map(project =>
          project.id === projectId ? { ...project, status: 'syncing' } : project
        )
      );
      setCreatedProjects(prevProjects =>
        prevProjects.map(project =>
          project.id === projectId ? { ...project, status: 'syncing' } : project
        )
      );
      setParticipantProjects(prevProjects =>
        prevProjects.map(project =>
          project.id === projectId ? { ...project, status: 'syncing' } : project
        )
      );

      const result = await projectsAPI.refreshProject(projectId);

      if (result.success) {
        toast.success('Project refresh started');
        // Start polling to check when project becomes active
        startPolling(projectId);
      } else {
        toast.error(result.error || 'Failed to refresh project data');
        // Revert status on error
        fetchProjects();
      }
    } catch (error) {
      console.error('Refresh error:', error);
      toast.error('Failed to refresh project data');
      // Revert status on error
      fetchProjects();
    } finally {
      // Remove project from refreshing set
      setRefreshingProjects(prev => {
        const newSet = new Set(prev);
        newSet.delete(projectId);
        return newSet;
      });
    }
  };

  const getRoleIcon = (userType) => {
    switch (userType) {
      case 'admin':
        return <AdminPanelSettings />;
      case 'user':
        return <Visibility />;
      default:
        return <Visibility />;
    }
  };

  const getRoleColor = (userType) => {
    switch (userType) {
      case 'admin':
        return 'error';
      case 'user':
        return 'info';
      default:
        return 'default';
    }
  };

  // Change password handlers
  const handleOpenChangePassword = () => {
    setChangePasswordOpen(true);
  };

  const handleCloseChangePassword = () => {
    setChangePasswordOpen(false);
    setCurrentPassword('');
    setNewPassword('');
    setConfirmPassword('');
    setShowCurrentPassword(false);
    setShowNewPassword(false);
    setShowConfirmPassword(false);
  };

  const handleChangePassword = async () => {
    // Validation
    if (!currentPassword || !newPassword || !confirmPassword) {
      toast.error('All fields are required');
      return;
    }

    if (newPassword.length < 6) {
      toast.error('New password must be at least 6 characters');
      return;
    }

    if (newPassword !== confirmPassword) {
      toast.error('New password and confirm password do not match');
      return;
    }

    setPasswordChangeLoading(true);

    try {
      const result = await authAPI.changePassword(currentPassword, newPassword);

      if (result.success) {
        toast.success('Password changed successfully!');
        handleCloseChangePassword();
      } else {
        toast.error(result.error || 'Failed to change password');
      }
    } catch (error) {
      console.error('Change password error:', error);
      toast.error('An error occurred while changing password');
    } finally {
      setPasswordChangeLoading(false);
    }
  };

  // Project Card Component
  const ProjectCard = ({ project, isCreator = false }) => {
    return (
      <Card
        sx={{
          height: '100%',
          display: 'flex',
          flexDirection: 'column',
          transition: 'all 0.3s ease',
          '&:hover': {
            transform: 'translateY(-4px)',
            boxShadow: 4,
          },
          cursor: 'pointer',
          position: 'relative', // For absolute positioning of delete button
          overflow: 'hidden', // To contain the progress bar
        }}
        onClick={() => handleOpenProject(project.id)}
      >
        {/* Linear progress bar at the top when syncing */}
        {project.status === 'syncing' && (
          <LinearProgress
            sx={{
              position: 'absolute',
              top: 0,
              left: 0,
              right: 0,
              zIndex: 2
            }}
          />
        )}

        {/* Delete button in top-right corner for project creators only */}
        {isGlobalAdmin() && isCreator && (
          <IconButton
            onClick={(e) => handleDeleteProject(e, project)}
            sx={{
              position: 'absolute',
              top: 8,
              right: 8,
              color: 'error.main',
              backgroundColor: 'background.paper',
              border: '1px solid',
              borderColor: 'error.main',
              borderRadius: 2, // Rounded square instead of circle
              width: 32,       // Fixed width for square shape
              height: 32,      // Fixed height for square shape
              boxShadow: 1,
              '&:hover': {
                backgroundColor: 'error.light',
                color: 'white',
                borderColor: 'error.light',
              },
              zIndex: 1,
            }}
            size="small"
          >
            <Delete fontSize="small" />
          </IconButton>
        )}
        <CardContent sx={{
          flexGrow: 1,
          paddingTop: isGlobalAdmin() && isCreator ? 4 : 3 // Extra top padding for creator delete button
        }}>
          <Box sx={{ mb: 2 }}>
            <Typography
              variant="h6"
              component="h3"
              sx={{
                fontWeight: 600,
                mb: 2,
                wordWrap: 'break-word',
                wordBreak: 'break-word',
                hyphens: 'auto',
                lineHeight: 1.3
              }}
              title={project.title} // Show full title on hover
            >
              {project.title.length > 30 ? `${project.title.substring(0, 30)}...` : project.title}
            </Typography>
          </Box>

          <Typography variant="body2" color="text.secondary" sx={{ mb: 2, minHeight: 40 }}>
            {project.description}
          </Typography>

          <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 2 }}>
            <Typography variant="body2" color="text.secondary">
              Created by <strong>{project.adminName}</strong>
            </Typography>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
              <Tooltip 
                title={
                  <Box>
                    <Typography variant="caption" display="block">
                      Refresh project data
                    </Typography>
                    {project.lastRefreshedAt && (
                      <Typography variant="caption" display="block" sx={{ mt: 0.5, fontStyle: 'italic' }}>
                        Last refreshed: {new Date(project.lastRefreshedAt).toLocaleString()}
                      </Typography>
                    )}
                    {!project.lastRefreshedAt && (
                      <Typography variant="caption" display="block" sx={{ mt: 0.5, fontStyle: 'italic', color: 'warning.light' }}>
                        Never refreshed
                      </Typography>
                    )}
                  </Box>
                }
              >
                <IconButton
                  onClick={(e) => handleRefreshProject(e, project.id)}
                  disabled={refreshingProjects.has(project.id)}
                  size="small"
                  sx={{
                    color: 'primary.main',
                    '&:hover': {
                      backgroundColor: 'primary.light',
                      color: 'white'
                    }
                  }}
                >
                  {refreshingProjects.has(project.id) ? (
                    <CircularProgress size={16} />
                  ) : (
                    <Refresh fontSize="small" />
                  )}
                </IconButton>
              </Tooltip>
              <Chip
                label={project.status}
                size="small"
                sx={{
                  bgcolor:
                    project.status === 'active' ? 'success.main' :
                      project.status === 'syncing' ? 'info.main' :
                        project.status === 'sync error' ? 'error.main' : 'default',
                  color: 'common.white'
                }}
              />
            </Box>
          </Box>

          {isGlobalAdmin() && isCreator && (
            <Box sx={{ mt: 2, display: 'flex', flexDirection: 'column', gap: 1 }}>
              <Button
                fullWidth
                variant="outlined"
                startIcon={<ManageAccounts />}
                onClick={(e) => handleProjectUserManagement(e, project.id)}
                size="small"
                sx={{
                  '&:hover': {
                    borderColor: 'primary.main',
                    backgroundColor: 'primary.main',
                    color: 'white'
                  }
                }}
              >
                Manage Users
              </Button>
              <Button
                fullWidth
                variant="outlined"
                startIcon={<Settings />}
                onClick={(e) => handleProjectConfigEdit(e, project.id)}
                size="small"
                sx={{
                  color: 'error.main',
                  borderColor: 'error.main',
                  '&:hover': {
                    borderColor: 'error.main',
                    backgroundColor: 'error.light',
                    color: 'white'
                  }
                }}
              >
                Edit Configuration
              </Button>
            </Box>
          )}
        </CardContent>

        <CardActions sx={{ justifyContent: 'space-between', px: 2, py: 1 }}>
          <Box sx={{ display: 'flex', alignItems: 'center' }}>
            <People sx={{ fontSize: 16, mr: 0.5, color: 'text.secondary' }} />
            <Typography variant="caption" color="text.secondary">
              {project.participants.length} members
            </Typography>
          </Box>
          <Typography variant="caption" color="text.secondary">
            {new Date(project.createdDate).toLocaleDateString()}
          </Typography>
        </CardActions>
      </Card>
    );
  };

  // Official Project Card Component
  const OfficialProjectCard = ({ project }) => {
    // Calculate days remaining
    const targetDate = project.targetCompletionDate ? new Date(project.targetCompletionDate) : null;
    const today = new Date();
    const daysRemaining = targetDate ? Math.ceil((targetDate - today) / (1000 * 60 * 60 * 24)) : null;

    // Check user roles
    const isCreator = project.adminUsername === user.username;
    const isProjectLead = project.projectLeadUsername === user.username;
    const isProjectManager = project.projectManagerUsername === user.username;
    const isApproved = project.pmApprovalStatus === 'approved';

    // Get approval status color and label
    const getApprovalStatus = () => {
      switch (project.pmApprovalStatus) {
        case 'not_submitted':
          return { color: 'default', label: 'Not Submitted', icon: <Schedule fontSize="small" /> };
        case 'pending':
          return { color: 'warning', label: 'Awaiting PM Approval', icon: <Schedule fontSize="small" /> };
        case 'approved':
          return { color: 'success', label: 'Approved by PM', icon: <CheckCircle fontSize="small" /> };
        case 'rejected':
          return { color: 'error', label: 'Rejected by PM', icon: <Cancel fontSize="small" /> };
        default:
          return { color: 'default', label: 'Unknown', icon: null };
      }
    };

    const approvalStatus = getApprovalStatus();

    return (
      <Card
        sx={{
          height: '100%',
          display: 'flex',
          flexDirection: 'column',
          transition: 'all 0.3s ease',
          border: '2px solid',
          borderColor: 'primary.main',
          '&:hover': {
            transform: 'translateY(-4px)',
            boxShadow: 4,
          },
          cursor: 'pointer',
          position: 'relative',
          overflow: 'hidden',
        }}
        onClick={() => handleOpenProject(project.id)}
      >
        {/* Top right corner: Delete button (if creator) + Official Badge */}
        <Box sx={{ position: 'absolute', top: 8, right: 8, display: 'flex', gap: 0.5, alignItems: 'center', zIndex: 1 }}>
          {isGlobalAdmin() && isCreator && (
            <IconButton
              onClick={(e) => handleDeleteProject(e, project)}
              sx={{
                color: 'error.main',
                backgroundColor: 'background.paper',
                border: '1px solid',
                borderColor: 'error.main',
                borderRadius: 2,
                width: 28,
                height: 28,
                boxShadow: 1,
                '&:hover': {
                  backgroundColor: 'error.light',
                  color: 'white',
                  borderColor: 'error.light',
                },
              }}
              size="small"
            >
              <Delete fontSize="small" />
            </IconButton>
          )}
          <Chip
            icon={<Star />}
            label="Official"
            color="primary"
            size="small"
          />
        </Box>

        {/* Linear progress bar when syncing */}
        {project.status === 'syncing' && (
          <LinearProgress
            sx={{
              position: 'absolute',
              top: 0,
              left: 0,
              right: 0,
              zIndex: 2
            }}
          />
        )}

        <CardContent sx={{ flexGrow: 1, pt: 5 }}>
          <Box sx={{ mb: 2 }}>
            <Typography
              variant="h6"
              component="h3"
              sx={{
                fontWeight: 600,
                mb: 1,
                wordWrap: 'break-word',
                lineHeight: 1.3,
                pr: 8 // Space for badge
              }}
              title={project.title}
            >
              {project.title.length > 25 ? `${project.title.substring(0, 25)}...` : project.title}
            </Typography>
            <Typography variant="caption" color="text.secondary" sx={{ display: 'block' }}>
              SWPLM: {project.swplmProjectName}
            </Typography>
          </Box>

          <Typography variant="body2" color="text.secondary" sx={{ mb: 2, minHeight: 40 }}>
            {project.description}
          </Typography>

          {/* Days Countdown - Hide after PM approval */}
          {daysRemaining !== null && !isApproved && (
            <Box
              sx={{
                display: 'flex',
                alignItems: 'center',
                gap: 1,
                mb: 2,
                p: 1,
                borderRadius: 1,
                bgcolor: daysRemaining < 0 ? 'error.light' :
                  daysRemaining <= 7 ? 'warning.light' : 'success.light',
                color: daysRemaining < 0 ? 'error.dark' :
                  daysRemaining <= 7 ? 'warning.dark' : 'success.dark'
              }}
            >
              <Schedule fontSize="small" />
              <Typography variant="body2" fontWeight="medium">
                {daysRemaining < 0
                  ? `${Math.abs(daysRemaining)} days overdue`
                  : daysRemaining === 0
                    ? 'Due today!'
                    : `${daysRemaining} days remaining`}
              </Typography>
            </Box>
          )}

          {/* PL and PM Info */}
          <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap', mb: 2 }}>
            <Chip
              label={`PL: ${project.projectLeadName || project.projectLeadUsername}`}
              size="small"
              variant={isProjectLead ? 'filled' : 'outlined'}
              color={isProjectLead ? 'primary' : 'default'}
            />
            <Chip
              label={`PM: ${project.projectManagerName || project.projectManagerUsername}`}
              size="small"
              variant={isProjectManager ? 'filled' : 'outlined'}
              color={isProjectManager ? 'secondary' : 'default'}
            />
          </Box>

          {/* Approval Status */}
          <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 2 }}>
            <Chip
              icon={approvalStatus.icon}
              label={approvalStatus.label}
              size="small"
              color={approvalStatus.color}
            />
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
              <Tooltip title="Refresh project data">
                <IconButton
                  onClick={(e) => handleRefreshProject(e, project.id)}
                  disabled={refreshingProjects.has(project.id)}
                  size="small"
                  sx={{
                    color: 'primary.main',
                    '&:hover': {
                      backgroundColor: 'primary.light',
                      color: 'white'
                    }
                  }}
                >
                  {refreshingProjects.has(project.id) ? (
                    <CircularProgress size={16} />
                  ) : (
                    <Refresh fontSize="small" />
                  )}
                </IconButton>
              </Tooltip>
              <Chip
                label={project.status}
                size="small"
                sx={{
                  bgcolor:
                    project.status === 'active' ? 'success.main' :
                      project.status === 'syncing' ? 'info.main' :
                        project.status === 'sync error' ? 'error.main' : 'default',
                  color: 'common.white'
                }}
              />
            </Box>
          </Box>

          {/* Admin buttons - Manage Users & Edit Config */}
          {isGlobalAdmin() && isCreator && (
            <Box sx={{ mt: 2, display: 'flex', flexDirection: 'column', gap: 1 }}>
              <Button
                fullWidth
                variant="outlined"
                startIcon={<ManageAccounts />}
                onClick={(e) => handleProjectUserManagement(e, project.id)}
                size="small"
                sx={{
                  '&:hover': {
                    borderColor: 'primary.main',
                    backgroundColor: 'primary.main',
                    color: 'white'
                  }
                }}
              >
                Manage Users
              </Button>
              <Button
                fullWidth
                variant="outlined"
                startIcon={<Settings />}
                onClick={(e) => handleProjectConfigEdit(e, project.id)}
                size="small"
                sx={{
                  color: 'error.main',
                  borderColor: 'error.main',
                  '&:hover': {
                    borderColor: 'error.main',
                    backgroundColor: 'error.light',
                    color: 'white'
                  }
                }}
              >
                Edit Configuration
              </Button>
            </Box>
          )}

          {/* Action Button for PL */}
          {isProjectLead && project.pmApprovalStatus === 'not_submitted' && (
            <Button
              fullWidth
              variant="contained"
              color="primary"
              startIcon={<Send />}
              onClick={(e) => {
                e.stopPropagation();
                setPmApprovalProject(project);
                setPmApprovalAction('submit');
                setPmApprovalDialogOpen(true);
              }}
              size="small"
              sx={{ mt: 1 }}
            >
              Send for PM Approval
            </Button>
          )}

          {/* Action Buttons for PM */}
          {isProjectManager && project.pmApprovalStatus === 'pending' && (
            <Box sx={{ display: 'flex', gap: 1, mt: 1 }}>
              <Button
                fullWidth
                variant="contained"
                color="success"
                startIcon={<CheckCircle />}
                onClick={(e) => {
                  e.stopPropagation();
                  setPmApprovalProject(project);
                  setPmApprovalAction('approve');
                  setPmApprovalDialogOpen(true);
                }}
                size="small"
              >
                Approve
              </Button>
              <Button
                fullWidth
                variant="outlined"
                color="error"
                startIcon={<Cancel />}
                onClick={(e) => {
                  e.stopPropagation();
                  setPmApprovalProject(project);
                  setPmApprovalAction('reject');
                  setRejectionReason('');
                  setPmApprovalDialogOpen(true);
                }}
                size="small"
              >
                Reject
              </Button>
            </Box>
          )}

          {/* Show rejection reason if rejected */}
          {project.pmApprovalStatus === 'rejected' && project.pmRejectionReason && (
            <Alert severity="error" sx={{ mt: 1 }}>
              <Typography variant="caption">
                <strong>Rejection reason:</strong> {project.pmRejectionReason}
              </Typography>
            </Alert>
          )}

          {/* Resubmit button for PL if rejected */}
          {isProjectLead && project.pmApprovalStatus === 'rejected' && (
            <Button
              fullWidth
              variant="outlined"
              color="primary"
              startIcon={<Send />}
              onClick={(e) => {
                e.stopPropagation();
                setPmApprovalProject(project);
                setPmApprovalAction('submit');
                setPmApprovalDialogOpen(true);
              }}
              size="small"
              sx={{ mt: 1 }}
            >
              Resubmit for Approval
            </Button>
          )}
        </CardContent>

        <CardActions sx={{ justifyContent: 'space-between', px: 2, py: 1 }}>
          <Box sx={{ display: 'flex', alignItems: 'center' }}>
            <People sx={{ fontSize: 16, mr: 0.5, color: 'text.secondary' }} />
            <Typography variant="caption" color="text.secondary">
              Target: {targetDate?.toLocaleDateString() || 'Not set'}
            </Typography>
          </Box>
          <Typography variant="caption" color="text.secondary">
            Created by {project.admin || project.adminUsername}
          </Typography>
        </CardActions>
      </Card>
    );
  };

  // Handle PM approval actions
  const handlePmApprovalConfirm = async () => {
    if (!pmApprovalProject || !pmApprovalAction) return;

    try {
      let result;
      if (pmApprovalAction === 'submit') {
        result = await projectsAPI.submitForPMApproval(pmApprovalProject.id);
      } else if (pmApprovalAction === 'approve') {
        result = await projectsAPI.approveProject(pmApprovalProject.id);
      } else if (pmApprovalAction === 'reject') {
        result = await projectsAPI.rejectProject(pmApprovalProject.id, rejectionReason);
      }

      if (result.success) {
        toast.success(result.data.message || 'Action completed successfully');
        fetchProjects(); // Refresh projects
      } else {
        toast.error(result.error || 'Action failed');
      }
    } catch (error) {
      toast.error('Failed to process approval action');
    } finally {
      setPmApprovalDialogOpen(false);
      setPmApprovalProject(null);
      setPmApprovalAction(null);
      setRejectionReason('');
    }
  };

  // Empty State Component
  const EmptyState = () => {
    if (isGlobalAdmin()) {
      return (
        <Box
          sx={{
            textAlign: 'center',
            py: 8,
            px: 4,
          }}
        >
          <Typography variant="body1" color="text.secondary" sx={{ mb: 4, maxWidth: 500, mx: 'auto' }}>
            You haven't created any FMS key review projects yet. Start by creating your first project to configure model comparisons and invite team members.
          </Typography>
          <Button
            variant="contained"
            size="large"
            startIcon={<Add />}
            onClick={handleCreateProject}
            sx={{
              px: 4,
              py: 1.5,
              background: 'linear-gradient(45deg, #1976d2 30%, #42a5f5 90%)',
              '&:hover': {
                background: 'linear-gradient(45deg, #1565c0 30%, #1976d2 90%)',
              },
            }}
          >
            Create Your First Project
          </Button>
        </Box>
      );
    } else {
      return (
        <Box
          sx={{
            textAlign: 'center',
            py: 8,
            px: 4,
          }}
        >
          <Typography variant="h5" gutterBottom sx={{ fontWeight: 600 }}>
            No Projects Found
          </Typography>
          <Typography variant="body1" color="text.secondary" sx={{ mb: 4, maxWidth: 500, mx: 'auto' }}>
            You haven't joined any FMS key review projects yet. Explore available projects or wait for an admin to invite you to a project.
          </Typography>
          <Button
            variant="contained"
            size="large"
            startIcon={<Search />}
            onClick={handleExploreProjects}
            sx={{
              px: 4,
              py: 1.5,
              background: 'linear-gradient(45deg, #1976d2 30%, #42a5f5 90%)',
              '&:hover': {
                background: 'linear-gradient(45deg, #1565c0 30%, #1976d2 90%)',
              },
            }}
          >
            Explore Projects
          </Button>
        </Box>
      );
    }
  };

  // Loading State
  if (loading) {
    return (
      <Container maxWidth="xl">
        <Box sx={{ mt: 4, mb: 4, display: 'flex', justifyContent: 'center', alignItems: 'center', height: '50vh' }}>
          <CircularProgress />
        </Box>
      </Container>
    );
  }

  // Error State
  if (error) {
    return (
      <Container maxWidth="xl">
        <Box sx={{ mt: 4, mb: 4 }}>
          <Alert severity="error" sx={{ mb: 3 }}>
            {error}
          </Alert>
          <Button variant="contained" onClick={fetchProjects}>
            Retry
          </Button>
        </Box>
      </Container>
    );
  }

  return (
    <Container maxWidth="lg">
      <Box sx={{ mt: 4, mb: 4 }}>
        {/* Header */}
        <Paper sx={{ p: 3, mb: 3 }}>
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <Box sx={{ display: 'flex', alignItems: 'center' }}>
              <Box sx={{ display: 'flex', mr: 2 }}>
                <img
                  src="/icon.svg"
                  alt="FMS Icon"
                  style={{ width: 40, height: 40 }}
                />
              </Box>
              <Typography
                variant="h4"
                sx={{
                  color: 'primary.main',
                  fontWeight: 700,
                }}
              >
                FMS Review Manager
              </Typography>
            </Box>
            <Box sx={{ display: 'flex', gap: 1 }}>
              <Button
                variant="outlined"
                startIcon={<VpnKey />}
                onClick={handleOpenChangePassword}
                color="primary"
              >
                Change Password
              </Button>
              <Button
                variant="outlined"
                startIcon={<ExitToApp />}
                onClick={handleLogout}
                color="primary"
              >
                Logout
              </Button>
            </Box>
          </Box>
        </Paper>

        {/* System User KPI Dashboard Banner */}
        {user?.username === 'system' && (
          <Card sx={{ 
            mb: 3, 
            background: 'linear-gradient(45deg, #1976d2 30%, #42a5f5 90%)',
            color: 'white'
          }}>
            <CardContent>
              <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                  <Avatar sx={{ bgcolor: 'rgba(255,255,255,0.2)', width: 56, height: 56 }}>
                    <BarChart sx={{ fontSize: 32 }} />
                  </Avatar>
                  <Box>
                    <Typography variant="h5" sx={{ fontWeight: 600 }}>
                      KPI Dashboard Available
                    </Typography>
                    <Typography variant="body2" sx={{ opacity: 0.9 }}>
                      View portal analytics, user activity, and performance metrics
                    </Typography>
                  </Box>
                </Box>
                <Button
                  variant="contained"
                  size="large"
                  startIcon={<DashboardIcon />}
                  onClick={() => navigate('/kpi')}
                  sx={{
                    bgcolor: 'white',
                    color: '#1976d2',
                    '&:hover': {
                      bgcolor: 'rgba(255,255,255,0.9)',
                    },
                  }}
                >
                  Open KPI Dashboard
                </Button>
              </Box>
            </CardContent>
          </Card>
        )}

        {/* Navigation Tabs */}
        <Paper sx={{ mb: 3 }}>
          <Tabs 
            value={activeTab} 
            onChange={(_, newValue) => setActiveTab(newValue)}
            sx={{ borderBottom: 1, borderColor: 'divider' }}
          >
            <Tab 
              icon={<DashboardIcon sx={{ fontSize: 20 }} />} 
              iconPosition="start" 
              label="My Projects" 
              sx={{ minHeight: 56 }}
            />
            <Tab 
              icon={<ChatBubble sx={{ fontSize: 20 }} />} 
              iconPosition="start" 
              label="All Comments" 
              sx={{ minHeight: 56 }}
            />
          </Tabs>
        </Paper>

        {/* Tab Content */}
        {activeTab === 0 && (
          <>
        {/* Welcome Section */}
        <Card sx={{ mb: 3 }}>
          <CardContent>
            <Box sx={{ display: 'flex', alignItems: 'center' }}>
              <Avatar
                sx={{
                  bgcolor: 'primary.main',
                  mr: 2,
                  width: 56,
                  height: 56,
                }}
              >
                {user?.name?.charAt(0).toUpperCase()}
              </Avatar>
              <Box sx={{ flexGrow: 1 }}>
                <Typography variant="h5" gutterBottom>
                  Welcome back, {user?.name}!
                </Typography>
                <Typography variant="body2" color="text.secondary" gutterBottom>
                  {user?.department || user?.team} • {user?.username || user?.email?.split('@')[0]}
                </Typography>
                <Typography variant="body2" color="text.secondary" sx={{ mt: 0.5 }}>
                  Manage your FMS key review projects and collaborate with your team
                </Typography>
              </Box>

              {/* Action Buttons */}
              <Box sx={{ display: 'flex', gap: 1 }}>
                {user?.username === 'system' && (
                  <Button
                    variant="outlined"
                    startIcon={<BarChart />}
                    onClick={() => navigate('/kpi')}
                    sx={{
                      borderColor: 'primary.main',
                      color: 'primary.main',
                      '&:hover': {
                        borderColor: 'primary.dark',
                        bgcolor: 'primary.light',
                        color: 'white',
                      },
                    }}
                  >
                    KPI Dashboard
                  </Button>
                )}
                {isGlobalAdmin() && (
                  <Button
                    variant="contained"
                    startIcon={<Add />}
                    onClick={handleCreateProject}
                    sx={{
                      background: 'linear-gradient(45deg, #1976d2 30%, #42a5f5 90%)',
                      '&:hover': {
                        background: 'linear-gradient(45deg, #1565c0 30%, #1976d2 90%)',
                      },
                    }}
                  >
                    Create Project
                  </Button>
                )}
              </Box>
            </Box>
          </CardContent>
        </Card>

        {/* Official Projects Section - Shown only if user has official projects */}
        {officialProjects.length > 0 && (
          <Box sx={{ mb: 4 }}>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                <Star sx={{ color: 'primary.main' }} />
                <Typography variant="h5" sx={{ fontWeight: 600, color: 'primary.main' }}>
                  Official Projects
                </Typography>
              </Box>
              <Typography variant="body2" color="text.secondary">
                {officialProjects.length} project{officialProjects.length > 1 ? 's' : ''}
              </Typography>
            </Box>
            <Grid container spacing={3}>
              {officialProjects.map((project) => (
                <Grid item xs={12} md={6} lg={4} key={project.id}>
                  <OfficialProjectCard project={project} />
                </Grid>
              ))}
            </Grid>
            <Divider sx={{ my: 4 }} />
          </Box>
        )}

        {/* Projects Section */}
        {isGlobalAdmin() ? (
          // Admin dashboard with two sections
          <>
            {/* Created Projects Section */}
            <Box sx={{ mb: 4 }}>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
                <Typography variant="h5" sx={{ fontWeight: 600 }}>
                  Created by You
                </Typography>
                {createdProjects.length > 0 && (
                  <Typography variant="body2" color="text.secondary">
                    {createdProjects.length} project{createdProjects.length > 1 ? 's' : ''}
                  </Typography>
                )}
              </Box>

              {createdProjects.length === 0 ? (
                <EmptyState />
              ) : (
                <Grid container spacing={3}>
                  {createdProjects.map((project) => (
                    <Grid item xs={12} md={6} lg={4} key={project.id}>
                      <ProjectCard project={project} isCreator={true} />
                    </Grid>
                  ))}
                </Grid>
              )}
            </Box>

            {/* Other Projects Section */}
            {participantProjects.length > 0 && (
              <Box sx={{ mb: 3 }}>
                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
                  <Typography variant="h5" sx={{ fontWeight: 600 }}>
                    Other Projects
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    {participantProjects.length} project{participantProjects.length > 1 ? 's' : ''}
                  </Typography>
                </Box>
                <Grid container spacing={3}>
                  {participantProjects.map((project) => (
                    <Grid item xs={12} md={6} lg={4} key={project.id}>
                      <ProjectCard project={project} isCreator={false} />
                    </Grid>
                  ))}
                </Grid>
              </Box>
            )}
          </>
        ) : (
          // Non-admin dashboard
          <Box sx={{ mb: 3 }}>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
              <Typography variant="h5" sx={{ fontWeight: 600 }}>
                Assigned Projects
              </Typography>
              {projects.length > 0 && (
                <Typography variant="body2" color="text.secondary">
                  {projects.length} project{projects.length > 1 ? 's' : ''}
                </Typography>
              )}
            </Box>

            {projects.length === 0 ? (
              <EmptyState />
            ) : (
              <Grid container spacing={3}>
                {projects.map((project) => (
                  <Grid item xs={12} md={6} lg={4} key={project.id}>
                    <ProjectCard project={project} isCreator={false} />
                  </Grid>
                ))}
              </Grid>
            )}
          </Box>
        )}

        {/* Floating Action Button for Mobile */}
        {user?.role === USER_ROLES.ADMIN && (
          <Fab
            color="primary"
            aria-label="create project"
            onClick={handleCreateProject}
            sx={{
              position: 'fixed',
              bottom: 24,
              right: 24,
              display: { xs: 'flex', md: 'none' },
            }}
          >
            <Add />
          </Fab>
        )}
          </>
        )}

        {/* All Comments Tab */}
        {activeTab === 1 && (
          <AllComments />
        )}

        {/* Delete Confirmation Dialog */}
        <Dialog
          open={deleteDialogOpen}
          onClose={handleCancelDelete}
          aria-labelledby="delete-dialog-title"
          aria-describedby="delete-dialog-description"
        >
          <DialogTitle id="delete-dialog-title" sx={{ color: 'error.main' }}>
            Delete Project
          </DialogTitle>
          <DialogContent>
            <DialogContentText id="delete-dialog-description">
              Are you sure you want to delete the project "{projectToDelete?.title}"?
              <br />
              <br />
              <strong>This action cannot be undone and will remove the project for all users.</strong>
            </DialogContentText>
          </DialogContent>
          <DialogActions>
            <Button onClick={handleCancelDelete} color="primary">
              Cancel
            </Button>
            <Button onClick={handleConfirmDelete} color="error" variant="contained">
              Delete Project
            </Button>
          </DialogActions>
        </Dialog>

        {/* PM Approval Dialog */}
        <Dialog
          open={pmApprovalDialogOpen}
          onClose={() => {
            setPmApprovalDialogOpen(false);
            setPmApprovalProject(null);
            setPmApprovalAction(null);
            setRejectionReason('');
          }}
          maxWidth="sm"
          fullWidth
        >
          <DialogTitle sx={{ 
            color: pmApprovalAction === 'submit' ? 'primary.main' : 
                   pmApprovalAction === 'approve' ? 'success.main' : 'error.main' 
          }}>
            {pmApprovalAction === 'submit' && 'Submit for PM Approval'}
            {pmApprovalAction === 'approve' && 'Approve Project'}
            {pmApprovalAction === 'reject' && 'Reject Project'}
          </DialogTitle>
          <DialogContent>
            {pmApprovalAction === 'submit' && (
              <DialogContentText>
                Are you sure you want to submit "{pmApprovalProject?.title}" for PM approval?
                <br /><br />
                The project will be sent to <strong>{pmApprovalProject?.projectManagerName || pmApprovalProject?.projectManagerUsername}</strong> for review.
                You will be notified once the PM makes a decision.
              </DialogContentText>
            )}
            {pmApprovalAction === 'approve' && (
              <DialogContentText>
                Are you sure you want to approve "{pmApprovalProject?.title}"?
                <br /><br />
                This will mark the project as PM-approved and the Project Lead will be notified.
              </DialogContentText>
            )}
            {pmApprovalAction === 'reject' && (
              <>
                <DialogContentText sx={{ mb: 2 }}>
                  Are you sure you want to reject "{pmApprovalProject?.title}"?
                  <br /><br />
                  Please provide a reason for rejection:
                </DialogContentText>
                <TextField
                  fullWidth
                  multiline
                  rows={3}
                  label="Rejection Reason"
                  value={rejectionReason}
                  onChange={(e) => setRejectionReason(e.target.value)}
                  placeholder="Explain why the project is being rejected..."
                  required
                />
              </>
            )}
          </DialogContent>
          <DialogActions>
            <Button 
              onClick={() => {
                setPmApprovalDialogOpen(false);
                setPmApprovalProject(null);
                setPmApprovalAction(null);
                setRejectionReason('');
              }}
            >
              Cancel
            </Button>
            <Button
              onClick={handlePmApprovalConfirm}
              variant="contained"
              color={pmApprovalAction === 'submit' ? 'primary' : 
                     pmApprovalAction === 'approve' ? 'success' : 'error'}
              disabled={pmApprovalAction === 'reject' && !rejectionReason.trim()}
            >
              {pmApprovalAction === 'submit' && 'Submit'}
              {pmApprovalAction === 'approve' && 'Approve'}
              {pmApprovalAction === 'reject' && 'Reject'}
            </Button>
          </DialogActions>
        </Dialog>

        {/* Change Password Dialog */}
        <Dialog
          open={changePasswordOpen}
          onClose={handleCloseChangePassword}
          aria-labelledby="change-password-dialog-title"
          maxWidth="sm"
          fullWidth
        >
          <DialogTitle id="change-password-dialog-title">
            Change Password
          </DialogTitle>
          <DialogContent>
            <Box sx={{ pt: 2, display: 'flex', flexDirection: 'column', gap: 2 }}>
              <TextField
                label="Current Password"
                type={showCurrentPassword ? 'text' : 'password'}
                value={currentPassword}
                onChange={(e) => setCurrentPassword(e.target.value)}
                fullWidth
                variant="outlined"
                InputProps={{
                  endAdornment: (
                    <InputAdornment position="end">
                      <IconButton
                        onClick={() => setShowCurrentPassword(!showCurrentPassword)}
                        edge="end"
                      >
                        {showCurrentPassword ? <VisibilityOff /> : <Visibility />}
                      </IconButton>
                    </InputAdornment>
                  ),
                }}
              />
              <TextField
                label="New Password"
                type={showNewPassword ? 'text' : 'password'}
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                fullWidth
                variant="outlined"
                helperText="Password must be at least 6 characters"
                InputProps={{
                  endAdornment: (
                    <InputAdornment position="end">
                      <IconButton
                        onClick={() => setShowNewPassword(!showNewPassword)}
                        edge="end"
                      >
                        {showNewPassword ? <VisibilityOff /> : <Visibility />}
                      </IconButton>
                    </InputAdornment>
                  ),
                }}
              />
              <TextField
                label="Confirm New Password"
                type={showConfirmPassword ? 'text' : 'password'}
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                fullWidth
                variant="outlined"
                error={confirmPassword && newPassword !== confirmPassword}
                helperText={
                  confirmPassword && newPassword !== confirmPassword
                    ? 'Passwords do not match'
                    : ''
                }
                InputProps={{
                  endAdornment: (
                    <InputAdornment position="end">
                      <IconButton
                        onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                        edge="end"
                      >
                        {showConfirmPassword ? <VisibilityOff /> : <Visibility />}
                      </IconButton>
                    </InputAdornment>
                  ),
                }}
              />
            </Box>
          </DialogContent>
          <DialogActions>
            <Button onClick={handleCloseChangePassword} color="primary">
              Cancel
            </Button>
            <Button
              onClick={handleChangePassword}
              color="primary"
              variant="contained"
              disabled={passwordChangeLoading}
            >
              {passwordChangeLoading ? <CircularProgress size={24} /> : 'Change Password'}
            </Button>
          </DialogActions>
        </Dialog>

      </Box>
    </Container>
  );
};

export default Dashboard; 