const { executeQuery } = require('../config/database');

class Comment {
    // Create a new comment
    static async create(commentData) {
        const { key_review_id, comment_text, commented_by_username } = commentData;

        const query = `
      INSERT INTO \`Comments\` (key_review_id, comment_text, commented_by_username)
      VALUES (?, ?, ?)
    `;

        const result = await executeQuery(query, [key_review_id, comment_text, commented_by_username]);
        return { comment_id: result.insertId, ...commentData };
    }

    // Get all comments for a key review
    static async getByKeyReview(keyReviewId) {
        const query = `
      SELECT 
        c.*,
        u.name as commented_by_name,
        u.team as commented_by_team
      FROM \`Comments\` c
      JOIN \`Users\` u ON c.commented_by_username = u.username
      WHERE c.key_review_id = ?
      ORDER BY c.created_at ASC
    `;

        return await executeQuery(query, [keyReviewId]);
    }

    // Get a specific comment by ID
    static async getById(commentId) {
        const query = `
      SELECT 
        c.*,
        u.name as commented_by_name,
        u.team as commented_by_team
      FROM \`Comments\` c
      JOIN \`Users\` u ON c.commented_by_username = u.username
      WHERE c.comment_id = ?
    `;

        const result = await executeQuery(query, [commentId]);
        return result[0] || null;
    }

    // Update a comment
    static async update(commentId, updateData) {
        const { comment_text } = updateData;

        const query = `
      UPDATE \`Comments\` 
      SET comment_text = ?, updated_at = CURRENT_TIMESTAMP
      WHERE comment_id = ?
    `;

        const result = await executeQuery(query, [comment_text, commentId]);
        return result.affectedRows > 0;
    }

    // Delete a comment
    static async delete(commentId) {
        const query = 'DELETE FROM \`Comments\` WHERE comment_id = ?';
        const result = await executeQuery(query, [commentId]);
        return result.affectedRows > 0;
    }

    // Get latest comment for a key review (for display in main table)
    static async getLatestByKeyReview(keyReviewId) {
        const query = `
      SELECT 
        c.*,
        u.name as commented_by_name,
        u.team as commented_by_team
      FROM \`Comments\` c
      JOIN \`Users\` u ON c.commented_by_username = u.username
      WHERE c.key_review_id = ?
      ORDER BY c.created_at DESC
      LIMIT 1
    `;

        const result = await executeQuery(query, [keyReviewId]);
        return result[0] || null;
    }

    // Get comment count for a key review
    static async getCountByKeyReview(keyReviewId) {
        const query = 'SELECT COUNT(*) as comment_count FROM \`Comments\` WHERE key_review_id = ?';
        const result = await executeQuery(query, [keyReviewId]);
        return result[0].comment_count;
    }

    // Check if user can edit/delete comment (only the author can edit/delete)
    static async canUserModify(commentId, username) {
        const query = 'SELECT commented_by_username FROM \`Comments\` WHERE comment_id = ?';
        const result = await executeQuery(query, [commentId]);

        if (result.length === 0) {
            return false; // Comment doesn't exist
        }

        return result[0].commented_by_username === username;
    }
}

module.exports = Comment;

