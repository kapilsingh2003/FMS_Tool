-- Migration: Add Activity_Log table for KPI tracking
-- Run this script on your database to add activity logging

USE samsung_fms_portal;

-- 13. Activity_Log table (tracks user activities for KPIs)
CREATE TABLE IF NOT EXISTS `Activity_Log` (
    log_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL,
    action_type ENUM(
        'key_review_update',      -- KONA, Comment, CL, Status change
        'comment_add',            -- New comment added
        'comment_edit',           -- Comment edited
        'project_create',         -- Project created
        'project_edit',           -- Project configuration edited
        'project_delete',         -- Project deleted
        'project_refresh',        -- Project refreshed
        'user_login',             -- User logged in
        'user_signup',            -- New user registered
        'participant_add',        -- User added to project
        'participant_remove'      -- User removed from project
    ) NOT NULL,
    entity_type ENUM('project', 'key_review', 'comment', 'user') NOT NULL,
    entity_id INT,                -- ID of the affected entity
    project_id INT,               -- Associated project (if applicable)
    details JSON,                 -- Additional details about the action
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (username) REFERENCES `Users`(username) ON DELETE CASCADE,
    INDEX idx_username (username),
    INDEX idx_action_type (action_type),
    INDEX idx_entity_type (entity_type),
    INDEX idx_project_id (project_id),
    INDEX idx_created_at (created_at)
);

-- Ensure 'system' user exists for system-generated comments
INSERT IGNORE INTO `Users` (username, name, password, user_type, email, team, is_verified)
VALUES ('system', 'System', '$2a$10$systempasswordhashnotusedforlogin', 'admin', 'system@samsung.com', 'ENT_SM', true);

-- Add last_refreshed_at column to Projects (for tracking refresh times)
-- Note: Run this only if the column doesn't already exist
-- Check first: SHOW COLUMNS FROM Projects LIKE 'last_refreshed_at';
-- If it doesn't exist, run:
-- ALTER TABLE `Projects` ADD COLUMN `last_refreshed_at` TIMESTAMP NULL DEFAULT NULL;

SELECT 'Activity_Log table created successfully!' AS result;

