// Authentication Routes - Samsung FMS Portal
const express = require('express');
const jwt = require('jsonwebtoken');
const User = require('../models/User');
const router = express.Router();

const JWT_SECRET = 'samsung_fms_portal_jwt_secret_key_2024';
const JWT_EXPIRE = '24h';

// Generate JWT token
const generateToken = (user) => {
  return jwt.sign(
    {
      username: user.username,
      user_type: user.user_type,
      team: user.team
    },
    JWT_SECRET,
    { expiresIn: JWT_EXPIRE }
  );
};

// POST /api/auth/login
router.post('/login', async (req, res) => {
  try {
    const { username, password } = req.body;

    // Validate input
    if (!username || !password) {
      return res.status(400).json({
        success: false,
        message: 'Username and password are required'
      });
    }

    // Verify user credentials
    const user = await User.verifyPassword(username, password);
    if (!user) {
      return res.status(401).json({
        success: false,
        message: 'Invalid username or password'
      });
    }

    // Generate JWT token
    const token = generateToken(user);

    res.json({
      success: true,
      message: 'Login successful',
      token,
      user: {
        username: user.username,
        name: user.name,
        user_type: user.user_type,
        email: user.email,
        team: user.team
      }
    });
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
});

// POST /api/auth/signup
router.post('/signup', async (req, res) => {
  try {
    const { knoxId, name, password, user_type, team } = req.body;

    // Validate input
    if (!knoxId || !name || !password || !user_type || !team) {
      return res.status(400).json({
        success: false,
        message: 'All fields are required'
      });
    }

    // Generate email from Knox ID
    const email = `${knoxId}@samsung.com`;

    // Check if user already exists
    const existingUser = await User.findByUsername(knoxId);
    if (existingUser) {
      return res.status(400).json({
        success: false,
        message: 'Username already exists'
      });
    }

    // Check if email already exists
    const existingEmail = await User.emailExists(email);
    if (existingEmail) {
      return res.status(400).json({
        success: false,
        message: 'Email already exists'
      });
    }

    // Create new user
    const userData = {
      username: knoxId,
      name,
      password,
      user_type,
      email,
      team
    };

    const newUser = await User.create(userData);

    // Generate JWT token
    const token = generateToken(newUser);

    res.status(201).json({
      success: true,
      message: 'Account created successfully',
      token,
      user: {
        username: newUser.username,
        name: newUser.name,
        user_type: newUser.user_type,
        email: newUser.email,
        team: newUser.team
      }
    });
  } catch (error) {
    console.error('Signup error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
});

// POST /api/auth/verify-otp (simulated)
router.post('/verify-otp', async (req, res) => {
  try {
    const { knoxId, otp } = req.body;

    // Simulate OTP verification (always accept 123456)
    if (otp === '123456') {
      res.json({
        success: true,
        message: 'OTP verified successfully'
      });
    } else {
      res.status(400).json({
        success: false,
        message: 'Invalid OTP'
      });
    }
  } catch (error) {
    console.error('OTP verification error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
});

// POST /api/auth/send-otp (simulated)
router.post('/send-otp', async (req, res) => {
  try {
    const { knoxId } = req.body;

    if (!knoxId) {
      return res.status(400).json({
        success: false,
        message: 'Knox ID is required'
      });
    }

    // Simulate sending OTP (always succeeds)
    res.json({
      success: true,
      message: 'OTP sent successfully to your Samsung email'
    });
  } catch (error) {
    console.error('Send OTP error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
});

// Middleware to verify JWT token
const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({
      success: false,
      message: 'Access token required'
    });
  }

  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) {
      return res.status(403).json({
        success: false,
        message: 'Invalid or expired token'
      });
    }
    req.user = user;
    next();
  });
};

// GET /api/auth/me - Get current user info
router.get('/me', authenticateToken, async (req, res) => {
  try {
    const user = await User.findByUsername(req.user.username);
    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }

    res.json({
      success: true,
      user
    });
  } catch (error) {
    console.error('Get user info error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
});

module.exports = { router, authenticateToken };