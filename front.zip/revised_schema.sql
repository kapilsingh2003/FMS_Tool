-- Samsung FMS Portal Database Schema (Latest Version)
-- Updated for Work Machine Setup
-- MySQL Database with all tables, constraints, and sample data

-- Create the database
CREATE DATABASE IF NOT EXISTS samsung_fms_portal;
USE samsung_fms_portal;

-- Drop tables if they exist (for clean setup)
DROP TABLE IF EXISTS `Key_Reviews`;
DROP TABLE IF EXISTS `Group_Branch_Model_Map`;
DROP TABLE IF EXISTS `Group_Branch_Mapping`;
DROP TABLE IF EXISTS `Branch_Model_Mapping`;
DROP TABLE IF EXISTS `Project_Participants`;
DROP TABLE IF EXISTS `Groups`;
DROP TABLE IF EXISTS `Projects`;
DROP TABLE IF EXISTS `FMS_Keys`;
DROP TABLE IF EXISTS `Models`;
DROP TABLE IF EXISTS `Branches`;
DROP TABLE IF EXISTS `Users`;

-- 1. Users table (Knox ID based authentication)
CREATE TABLE `Users` (
    username VARCHAR(50) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    password VARCHAR(255) NOT NULL,
    role ENUM('admin', 'reviewer', 'viewer') NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    team ENUM('ENT_SM', 'CTV', 'ENT_TV') NOT NULL,
    created_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    last_login DATETIME,
    is_verified BOOLEAN DEFAULT FALSE,
    INDEX idx_role (role),
    INDEX idx_team (team)
);

-- 2. Projects table (project-level configuration)
CREATE TABLE `Projects` (
    project_id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(100) NOT NULL,
    description VARCHAR(500),
    admin_username VARCHAR(50) NOT NULL,
    refresh_schedule ENUM('Daily', 'Weekly', 'Monthly') DEFAULT 'Weekly',
    status ENUM('active', 'inactive', 'completed') DEFAULT 'active',
    created_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    is_active BOOLEAN DEFAULT TRUE,
    FOREIGN KEY (admin_username) REFERENCES `Users`(username) ON DELETE RESTRICT,
    INDEX idx_admin (admin_username),
    INDEX idx_status (status)
);

-- 3. Project_Participants table (many-to-many: users and projects)
CREATE TABLE `Project_Participants` (
    project_id INT,
    user_username VARCHAR(50),
    added_by VARCHAR(50) NOT NULL,
    participant_role ENUM('admin', 'reviewer', 'viewer') DEFAULT 'reviewer',
    joined_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (project_id, user_username),
    FOREIGN KEY (project_id) REFERENCES `Projects`(project_id) ON DELETE CASCADE,
    FOREIGN KEY (user_username) REFERENCES `Users`(username) ON DELETE CASCADE,
    FOREIGN KEY (added_by) REFERENCES `Users`(username) ON DELETE RESTRICT,
    INDEX idx_user (user_username)
);

-- 4. Groups table (group-level comparison configuration)
CREATE TABLE `Groups` (
    group_id INT AUTO_INCREMENT PRIMARY KEY,
    project_id INT NOT NULL,
    name VARCHAR(100) NOT NULL,
    comparison_type ENUM('2-way', '3-way', '4-way', '2-way vs 2-way') NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (project_id) REFERENCES `Projects`(project_id) ON DELETE CASCADE,
    UNIQUE KEY unique_group_per_project (project_id, name),
    INDEX idx_project (project_id)
);

-- 5. Branches table (available branches for comparison)
CREATE TABLE `Branches` (
    branch_id INT AUTO_INCREMENT PRIMARY KEY,
    branch_name VARCHAR(255) UNIQUE NOT NULL,
    branch_type VARCHAR(50),
    branch_path VARCHAR(500),
    is_active BOOLEAN DEFAULT TRUE,
    INDEX idx_active (is_active),
    INDEX idx_type (branch_type),
    INDEX idx_branch_path (branch_path)
);

-- 6. Models table (monitor/TV models)
CREATE TABLE `Models` (
    model_id INT AUTO_INCREMENT PRIMARY KEY,
    model_name VARCHAR(50) UNIQUE NOT NULL,
    product_category ENUM('Smart Monitors', 'CTV', 'ENT_TV'),
    chipset VARCHAR(100),
    is_active BOOLEAN DEFAULT TRUE,
    INDEX idx_category (product_category),
    INDEX idx_active (is_active),
    INDEX idx_chipset (chipset)
);

-- 7. Branch_Model_Mapping table (CRITICAL: which models exist in which branches)
CREATE TABLE `Branch_Model_Mapping` (
    bm_id INT AUTO_INCREMENT PRIMARY KEY,
    branch_id INT NOT NULL,
    model_id INT NOT NULL,
    is_available BOOLEAN DEFAULT TRUE,
    date_added DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (branch_id) REFERENCES `Branches`(branch_id) ON DELETE CASCADE,
    FOREIGN KEY (model_id) REFERENCES `Models`(model_id) ON DELETE CASCADE,
    UNIQUE KEY unique_branch_model (branch_id, model_id),
    INDEX idx_branch (branch_id),
    INDEX idx_model (model_id),
    INDEX idx_available (is_available),
    INDEX idx_branch_available (branch_id, is_available)
);

-- 8. Group_Branch_Mapping table (which branches are assigned to which groups)
CREATE TABLE `Group_Branch_Mapping` (
    gb_id INT AUTO_INCREMENT PRIMARY KEY,
    group_id INT NOT NULL,
    branch_role ENUM('target', 'reference1', 'reference2', 'reference3') NOT NULL,
    branch_id INT NOT NULL,
    sort_order INT DEFAULT 0,
    FOREIGN KEY (group_id) REFERENCES `Groups`(group_id) ON DELETE CASCADE,
    FOREIGN KEY (branch_id) REFERENCES `Branches`(branch_id) ON DELETE RESTRICT,
    UNIQUE KEY unique_group_branch_role (group_id, branch_role),
    INDEX idx_group (group_id),
    INDEX idx_branch (branch_id)
);

-- 9. Group_Branch_Model_Map table (specific models used in group-branch combinations)
CREATE TABLE `Group_Branch_Model_Map` (
    gbm_id INT AUTO_INCREMENT PRIMARY KEY,
    gb_id INT NOT NULL,
    model_id INT NOT NULL,
    added_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (gb_id) REFERENCES `Group_Branch_Mapping`(gb_id) ON DELETE CASCADE,
    FOREIGN KEY (model_id) REFERENCES `Models`(model_id) ON DELETE CASCADE,
    UNIQUE KEY unique_gb_model (gb_id, model_id),
    INDEX idx_gb (gb_id),
    INDEX idx_model (model_id),
    INDEX idx_gb_model (gb_id, model_id)
);

-- 10. FMS_Keys table (feature management system keys)
CREATE TABLE `FMS_Keys` (
    fms_key_id INT AUTO_INCREMENT PRIMARY KEY,
    key_name VARCHAR(255) UNIQUE NOT NULL,
    work_assignment VARCHAR(100),
    work_assignment_owner VARCHAR(100),
    key_category VARCHAR(100),
    data_type ENUM('boolean', 'integer', 'string', 'float') DEFAULT 'string',
    description TEXT,
    has_differences BOOLEAN DEFAULT FALSE,
    INDEX idx_work_assignment (work_assignment),
    INDEX idx_owner (work_assignment_owner),
    INDEX idx_differences (has_differences),
    INDEX idx_key_name (key_name)
);

-- 11. Key_Reviews table (the core review data)
CREATE TABLE `Key_Reviews` (
    key_review_id INT AUTO_INCREMENT PRIMARY KEY,
    fms_key_id INT NOT NULL,
    gbm_id INT NOT NULL,
    target_val TEXT,
    ref1_val TEXT,
    ref2_val TEXT,
    ref3_val TEXT,
    comment TEXT,
    status ENUM('pending', 'reviewed', 'needs_discussion', 'dev_response') DEFAULT 'pending',
    kona_ids TEXT,
    cl_numbers TEXT,
    reviewed_by_username VARCHAR(50),
    created_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    last_modified DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (fms_key_id) REFERENCES `FMS_Keys`(fms_key_id) ON DELETE CASCADE,
    FOREIGN KEY (gbm_id) REFERENCES `Group_Branch_Model_Map`(gbm_id) ON DELETE CASCADE,
    FOREIGN KEY (reviewed_by_username) REFERENCES `Users`(username) ON DELETE SET NULL,
    UNIQUE KEY unique_key_gbm_review (fms_key_id, gbm_id),
    INDEX idx_fms_key (fms_key_id),
    INDEX idx_gbm (gbm_id),
    INDEX idx_status (status),
    INDEX idx_reviewer (reviewed_by_username)
);

-- Insert sample data for development/testing

-- Insert Users with bcrypt hashed passwords (password: 'password123')
INSERT INTO `Users` (username, name, password, role, email, team) VALUES
('admin.john', 'John Admin', '$2b$10$GI0dXfMUox4yyBtmt2Qgm.RBQ1X6pyRp29SEYJNmfaa0oj/CxUHSG', 'admin', 'admin.john@samsung.com', 'ENT_SM'),
('reviewer.jane', 'Jane Reviewer', '$2b$10$GI0dXfMUox4yyBtmt2Qgm.RBQ1X6pyRp29SEYJNmfaa0oj/CxUHSG', 'reviewer', 'reviewer.jane@samsung.com', 'CTV'),
('reviewer.mike', 'Mike Reviewer', '$2b$10$GI0dXfMUox4yyBtmt2Qgm.RBQ1X6pyRp29SEYJNmfaa0oj/CxUHSG', 'reviewer', 'reviewer.mike@samsung.com', 'ENT_TV'),
('viewer.sarah', 'Sarah Viewer', '$2b$10$GI0dXfMUox4yyBtmt2Qgm.RBQ1X6pyRp29SEYJNmfaa0oj/CxUHSG', 'viewer', 'viewer.sarah@samsung.com', 'ENT_SM');

-- Insert Sample Projects
INSERT INTO `Projects` (title, description, admin_username, refresh_schedule) VALUES
('SM_GameBar_Keys_Review', 'Review of Samsung GameBar FMS keys for 2025 models', 'admin.john', 'Weekly'),
('CTV_24Y_Platform_Keys_Review', 'Platform validation for 2024 CTV models', 'admin.john', 'Daily');

-- Insert Branches
INSERT INTO `Branches` (branch_name, branch_type, branch_path) VALUES
('Trunk_25_MonitorRC_MP_Prj', 'target', '/samsung/fms/trunk/2025/monitor_rc'),
('SmartMonitor_2025_MP_Prj', 'reference', '/samsung/fms/smartmonitor/2025/main_project'),
('OSU_2025_SM_TV_Ready_MP_Prj', 'reference', '/samsung/fms/osu/2025/sm_tv_ready'),
('Feature_GameBar_2025', 'feature', '/samsung/fms/features/gamebar/2025'),
('CTV_2024_Platform', 'platform', '/samsung/fms/ctv/2024/platform'),
('ENT_TV_2025_Base', 'reference', '/samsung/fms/ent_tv/2025/base');

-- Insert Models
INSERT INTO `Models` (model_name, product_category, chipset) VALUES
('M50D', 'Smart Monitors', 'Tizen OS 7.0'),
('M70D', 'Smart Monitors', 'Tizen OS 7.0'),
('M80D', 'Smart Monitors', 'Tizen OS 8.0'),
('G95SD', 'Smart Monitors', 'Tizen OS 8.0'),
('G97NC', 'Smart Monitors', 'Tizen OS 8.0'),
('S90PC', 'Smart Monitors', 'Tizen OS 7.5'),
('CTV_2024_A', 'CTV', 'CTV Platform 2024'),
('CTV_2024_B', 'CTV', 'CTV Platform 2024'),
('ENT_55_2025', 'ENT_TV', 'ENT Platform 2025'),
('ENT_65_2025', 'ENT_TV', 'ENT Platform 2025');

-- Insert Branch-Model Mappings (which models exist in which branches)
INSERT INTO `Branch_Model_Mapping` (branch_id, model_id) VALUES
-- 2025 Monitor models in 2025 branches
(1, 1), (1, 2), (1, 3), (1, 4), (1, 5), (1, 6), -- Trunk_25 with all 2025 monitors
(2, 1), (2, 2), (2, 3), (2, 4), (2, 5), (2, 6), -- SmartMonitor_2025 with all monitors
(3, 1), (3, 2), (3, 3), -- OSU branch with selected monitors
(4, 4), (4, 5), (4, 6), -- GameBar feature with gaming monitors
-- CTV models in CTV branch
(5, 7), (5, 8), -- CTV platform with CTV models
-- ENT TV models in ENT branch
(6, 9), (6, 10); -- ENT branch with ENT models

-- Insert Sample Groups for the projects
INSERT INTO `Groups` (project_id, name, comparison_type) VALUES
(1, 'Group_25Y_SM_Gaming', '3-way'),
(1, 'Group_25Y_SM_Office', '2-way'),
(2, 'Group_CTV_Platform', '2-way');

-- Insert Group-Branch Mappings (which branches are used in each group)
INSERT INTO `Group_Branch_Mapping` (group_id, branch_role, branch_id) VALUES
-- Group 1: 3-way comparison (Gaming monitors)
(1, 'target', 1),     -- Trunk_25 as target
(1, 'reference1', 2), -- SmartMonitor_2025 as ref1
(1, 'reference2', 4), -- GameBar feature as ref2
-- Group 2: 2-way comparison (Office monitors)
(2, 'target', 1),     -- Trunk_25 as target
(2, 'reference1', 3), -- OSU branch as ref1
-- Group 3: CTV platform comparison
(3, 'target', 5),     -- CTV platform as target
(3, 'reference1', 6); -- ENT base as ref1

-- Insert Group-Branch-Model mappings (specific models used in each group-branch combo)
INSERT INTO `Group_Branch_Model_Map` (gb_id, model_id) VALUES
-- Group 1 (Gaming): Gaming monitors in each branch
(1, 4), (1, 5), (1, 6), -- Target branch: G95SD, G97NC, S90PC
(2, 4), (2, 5), (2, 6), -- Ref1 branch: same models
(3, 4), (3, 5), (3, 6), -- Ref2 branch: same models
-- Group 2 (Office): Office monitors
(4, 1), (4, 2), (4, 3), -- Target: M50D, M70D, M80D
(5, 1), (5, 2), (5, 3), -- Ref1: same models
-- Group 3 (CTV): CTV models
(6, 7), (6, 8), -- Target: CTV models
(7, 9), (7, 10); -- Ref1: ENT models for comparison

-- Insert Sample FMS Keys
INSERT INTO `FMS_Keys` (key_name, work_assignment, work_assignment_owner, key_category, data_type, has_differences) VALUES
('gamebar.responsetime', 'TP_GameBar', 'John Smith', 'Gaming', 'boolean', TRUE),
('display.hdmi.numports', 'TP_Display', 'Jane Doe', 'Hardware', 'integer', TRUE),
('audio.dolby.support', 'TP_Audio', 'Mike Johnson', 'Audio', 'boolean', TRUE),
('platform.os.version', 'TP_Platform', 'Sarah Lee', 'Software', 'string', TRUE),
('network.wifi.standard', 'TP_Network', 'David Kim', 'Connectivity', 'string', FALSE);

-- Insert Project Participants
INSERT INTO `Project_Participants` (project_id, user_username, added_by, participant_role) VALUES
(1, 'admin.john', 'admin.john', 'admin'),
(1, 'reviewer.jane', 'admin.john', 'reviewer'),
(1, 'reviewer.mike', 'admin.john', 'reviewer'),
(2, 'admin.john', 'admin.john', 'admin'),
(2, 'reviewer.jane', 'admin.john', 'reviewer');

-- Display success message
SELECT 'Samsung FMS Portal database with sample data created successfully!' as Status;
SELECT 'Default login credentials:' as Info;
SELECT 'Username: admin.john, Password: password123' as Credentials;