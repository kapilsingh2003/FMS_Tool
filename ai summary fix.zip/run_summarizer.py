import sys
import json
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

def log(msg):
    print(f'[run_summarizer] {msg}', file=sys.stderr, flush=True)

if __name__ == '__main__':
    try:
        if len(sys.argv) < 2:
            raise ValueError('No input file path provided as argument')

        temp_file = sys.argv[1]
        log(f'Reading input from temp file: {temp_file}')

        with open(temp_file, 'r', encoding='utf-8') as f:
            data = json.load(f)

        log(f'Input received. Calling summarize_key_differences for key: {data.get("fmsKey")}')

        from summarizer import summarize_key_differences
        result = summarize_key_differences(
            data['fmsKey'],
            data['fmsKeyDescription'],
            data['jsonData']
        )

        log('summarize_key_differences returned. Writing output...')
        print(json.dumps({'success': True, 'summary': result}), flush=True)
        sys.stdout.flush()
        log('Output written. Exiting.')

    except Exception as e:
        log(f'ERROR: {type(e).__name__}: {e}')
        print(json.dumps({'success': False, 'error': f'{type(e).__name__}: {e}'}), flush=True)
        sys.stdout.flush()
        os._exit(1)

    os._exit(0)
