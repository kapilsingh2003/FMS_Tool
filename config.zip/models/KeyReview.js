// Key Review Model - Samsung FMS Portal
const { executeQuery } = require('../config/database');

class KeyReview {
  // Get all key reviews for a project
  static async getByProject(projectId) {
    const query = `
      SELECT 
        kr.*,
        fk.key_name,
        fk.work_assignment,
        fk.work_assignment_owner,
        fk.key_category,
        fk.data_type,
        fk.description,
        m.model_name,
        m.product_category,
        g.group_id,
        g.name as group_name,
        g.comparison_type,
        gb.branch_role,
        b.branch_name,
        gbm.gbm_id
      FROM \`Key_Reviews\` kr
      JOIN \`FMS_Keys\` fk ON kr.fms_key_id = fk.fms_key_id
      JOIN \`Group_Branch_Model_Map\` gbm ON kr.gbm_id = gbm.gbm_id
      JOIN \`Models\` m ON gbm.model_id = m.model_id
      JOIN \`Group_Branch_Mapping\` gb ON gbm.gb_id = gb.gb_id
      JOIN \`grps\` g ON gb.group_id = g.group_id
      JOIN \`Branches\` b ON gb.branch_id = b.branch_id
      WHERE g.project_id = ?
      ORDER BY fk.work_assignment, fk.key_name, g.group_id, gb.sort_order, m.model_name
    `;

    return await executeQuery(query, [projectId]);
  }

  // Get key reviews by group
  static async getByGroup(groupId) {
    const query = `
      SELECT 
        kr.*,
        fk.key_name,
        fk.work_assignment,
        fk.work_assignment_owner,
        fk.key_category,
        fk.data_type,
        fk.description,
        m.model_name,
        m.product_category
      FROM \`Key_Reviews\` kr
      JOIN \`FMS_Keys\` fk ON kr.fms_key_id = fk.fms_key_id
      JOIN \`Group_Branch_Model_Map\` gbmm ON kr.gbm_id = gbmm.gbm_id
      JOIN \`Models\` m ON gbmm.model_id = m.model_id
      JOIN \`Group_Branch_Mapping\` gbm ON gbmm.gb_id = gbm.gb_id
      WHERE gbm.group_id = ?
      ORDER BY fk.work_assignment, fk.key_name, m.model_name
    `;

    return await executeQuery(query, [groupId]);
  }

  // Get hierarchical key review data for project (organized by keys -> groups -> models)
  static async getHierarchicalData(projectId) {
    const reviews = await this.getByProject(projectId);

    // Organize data hierarchically: keys -> groups -> models with branch values
    const keyMap = new Map();

    reviews.forEach(review => {
      const keyId = review.fms_key_id;
      const groupId = review.group_id;
      const modelId = review.model_id;

      // Initialize key if not exists
      if (!keyMap.has(keyId)) {
        keyMap.set(keyId, {
          fms_key_id: keyId,
          key_name: review.key_name,
          work_assignment: review.work_assignment,
          work_assignment_owner: review.work_assignment_owner,
          key_category: review.key_category,
          data_type: review.data_type,
          description: review.description,
          groups: new Map()
        });
      }

      const key = keyMap.get(keyId);

      // Initialize group if not exists
      if (!key.groups.has(groupId)) {
        key.groups.set(groupId, {
          group_id: groupId,
          group_name: review.group_name,
          comparison_type: review.comparison_type,
          models: new Map()
        });
      }

      const group = key.groups.get(groupId);

      // Initialize model if not exists (group by model across branches)
      const modelKey = `${modelId}`;
      if (!group.models.has(modelKey)) {
        group.models.set(modelKey, {
          model_id: modelId,
          model_name: review.model_name,
          product_category: review.product_category,
          comment: review.comment,
          status: review.status,
          kona_ids: review.kona_ids,
          cl_numbers: review.cl_numbers,
          reviewed_by_username: review.reviewed_by_username,
          last_modified: review.last_modified,
          key_review_id: review.key_review_id,
          gbm_id: review.gbm_id
        });
      }

      const model = group.models.get(modelKey);

      // Add branch-specific value based on branch_role
      if (review.branch_role === 'target') {
        model.target = review.target_val;
      } else if (review.branch_role === 'reference1') {
        model.ref1 = review.ref1_val;
      } else if (review.branch_role === 'reference2') {
        model.ref2 = review.ref2_val;
      } else if (review.branch_role === 'reference3') {
        model.ref3 = review.ref3_val;
      }
    });

    // Convert Maps to Arrays for JSON serialization
    const result = Array.from(keyMap.values()).map(key => ({
      ...key,
      groups: Array.from(key.groups.values()).map(group => ({
        ...group,
        models: Array.from(group.models.values())
      }))
    }));

    return result;
  }

  // Create or update a key review
  static async upsert(reviewData) {
    const {
      fms_key_id,
      gbm_id,
      target_val,
      ref1_val,
      ref2_val,
      ref3_val,
      comment,
      status,
      kona_ids,
      cl_numbers,
      reviewed_by_username
    } = reviewData;

    const query = `
      INSERT INTO \`Key_Reviews\` (
        fms_key_id, gbm_id, target_val, ref1_val, ref2_val, ref3_val,
        comment, status, kona_ids, cl_numbers, reviewed_by_username
      )
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      ON DUPLICATE KEY UPDATE
        target_val = VALUES(target_val),
        ref1_val = VALUES(ref1_val),
        ref2_val = VALUES(ref2_val),
        ref3_val = VALUES(ref3_val),
        comment = VALUES(comment),
        status = VALUES(status),
        kona_ids = VALUES(kona_ids),
        cl_numbers = VALUES(cl_numbers),
        reviewed_by_username = VALUES(reviewed_by_username),
        last_modified = CURRENT_TIMESTAMP
    `;

    await executeQuery(query, [
      fms_key_id, gbm_id, target_val, ref1_val, ref2_val, ref3_val,
      comment, status, kona_ids, cl_numbers, reviewed_by_username
    ]);

    return this.findByKeyAndGBM(fms_key_id, gbm_id);
  }

  // Find specific key review
  static async findByKeyAndGBM(fmsKeyId, gbmId) {
    const query = `
      SELECT kr.*, fk.key_name
      FROM \`Key_Reviews\` kr
      JOIN \`FMS_Keys\` fk ON kr.fms_key_id = fk.fms_key_id
      WHERE kr.fms_key_id = ? AND kr.gbm_id = ?
    `;

    const reviews = await executeQuery(query, [fmsKeyId, gbmId]);
    return reviews[0] || null;
  }

  // Update review status
  static async updateStatus(keyReviewId, status, reviewedBy) {
    const query = `
      UPDATE \`Key_Reviews\`
      SET status = ?, reviewed_by_username = ?, last_modified = CURRENT_TIMESTAMP
      WHERE key_review_id = ?
    `;

    await executeQuery(query, [status, reviewedBy, keyReviewId]);
  }

  // Update review values
  static async updateValues(keyReviewId, values) {
    const { target_val, ref1_val, ref2_val, ref3_val } = values;

    const query = `
      UPDATE \`Key_Reviews\`
      SET target_val = ?, ref1_val = ?, ref2_val = ?, ref3_val = ?, last_modified = CURRENT_TIMESTAMP
      WHERE key_review_id = ?
    `;

    await executeQuery(query, [target_val, ref1_val, ref2_val, ref3_val, keyReviewId]);
  }

  // Add or update comment
  static async updateComment(keyReviewId, comment, reviewedBy) {
    const query = `
      UPDATE \`Key_Reviews\`
      SET comment = ?, reviewed_by_username = ?, last_modified = CURRENT_TIMESTAMP
      WHERE key_review_id = ?
    `;

    await executeQuery(query, [comment, reviewedBy, keyReviewId]);
  }

  // Update KONA IDs
  static async updateKonaIds(keyReviewId, konaIds, reviewedBy) {
    const query = `
      UPDATE \`Key_Reviews\`
      SET kona_ids = ?, reviewed_by_username = ?, last_modified = CURRENT_TIMESTAMP
      WHERE key_review_id = ?
    `;

    await executeQuery(query, [konaIds, reviewedBy, keyReviewId]);
  }

  // Update CL numbers
  static async updateClNumbers(keyReviewId, clNumbers, reviewedBy) {
    const query = `
      UPDATE \`Key_Reviews\`
      SET cl_numbers = ?, reviewed_by_username = ?, last_modified = CURRENT_TIMESTAMP
      WHERE key_review_id = ?
    `;

    await executeQuery(query, [clNumbers, reviewedBy, keyReviewId]);
  }

  // Get review statistics for a project
  static async getProjectStats(projectId) {
    const query = `
      SELECT 
        COUNT(DISTINCT kr.fms_key_id) as total_keys,
        COUNT(DISTINCT CASE WHEN kr.status = 'reviewed' THEN kr.fms_key_id END) as reviewed_keys,
        COUNT(DISTINCT CASE WHEN kr.status = 'pending' THEN kr.fms_key_id END) as pending_keys,
        COUNT(DISTINCT CASE WHEN kr.status = 'needs_discussion' THEN kr.fms_key_id END) as discussion_keys,
        COUNT(DISTINCT CASE WHEN kr.status = 'dev_response' THEN kr.fms_key_id END) as dev_response_keys
      FROM \`Key_Reviews\` kr
      JOIN \`Group_Branch_Model_Map\` gbmm ON kr.gbm_id = gbmm.gbm_id
      JOIN \`Group_Branch_Mapping\` gbm ON gbmm.gb_id = gbm.gb_id
      JOIN \`grps\` g ON gbm.group_id = g.group_id
      WHERE g.project_id = ?
    `;

    const stats = await executeQuery(query, [projectId]);
    return stats[0];
  }

  // Delete key review
  static async delete(keyReviewId) {
    const query = `DELETE FROM \`Key_Reviews\` WHERE key_review_id = ?`;
    await executeQuery(query, [keyReviewId]);
  }

  // Get recent review activity
  static async getRecentActivity(projectId, limit = 10) {
    const query = `
      SELECT 
        kr.last_modified,
        kr.status,
        kr.comment,
        fk.key_name,
        m.model_name,
        g.name as group_name,
        u.name as reviewer_name
      FROM \`Key_Reviews\` kr
      JOIN \`FMS_Keys\` fk ON kr.fms_key_id = fk.fms_key_id
      JOIN \`Group_Branch_Model_Map\` gbmm ON kr.gbm_id = gbmm.gbm_id
      JOIN \`Models\` m ON gbmm.model_id = m.model_id
      JOIN \`Group_Branch_Mapping\` gbm ON gbmm.gb_id = gbm.gb_id
      JOIN \`grps\` g ON gbm.group_id = g.group_id
      LEFT JOIN \`Users\` u ON kr.reviewed_by_username = u.username
      WHERE g.project_id = ?
      ORDER BY kr.last_modified DESC
      LIMIT ?
    `;

    return await executeQuery(query, [projectId, limit]);
  }
}

module.exports = KeyReview;
