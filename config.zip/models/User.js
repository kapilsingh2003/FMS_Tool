// User Model - Samsung FMS Portal
const { executeQuery } = require('../config/database');
const bcrypt = require('bcryptjs');

class User {
    // Create a new user
    static async create(userData) {
        const { username, name, password, role, email, team } = userData;
        const hashedPassword = await bcrypt.hash(password, 10);

        const query = `
      INSERT INTO \`users\` (username, name, password, role, email, team, is_verified)
      VALUES (?, ?, ?, ?, ?, ?, true)
    `;

        await executeQuery(query, [username, name, hashedPassword, role, email, team]);
        return this.findByUsername(username);
    }

    // Find user by username
    static async findByUsername(username) {
        const query = `
      SELECT username, name, role, email, team, created_date, last_login, is_verified
      FROM \`users\`
      WHERE username = ?
    `;

        const users = await executeQuery(query, [username]);
        return users[0] || null;
    }

    // Find user by email
    static async findByEmail(email) {
        const query = `
      SELECT username, name, role, email, team, created_date, last_login, is_verified
      FROM \`users\`
      WHERE email = ?
    `;

        const users = await executeQuery(query, [username]);
        return users[0] || null;
    }

    // Verify user password
    static async verifyPassword(username, password) {
        const query = `
      SELECT username, password, role, email, team, name
      FROM \`users\`
      WHERE username = ?
    `;

        const users = await executeQuery(query, [username]);
        if (!users[0]) return null;

        const isValid = await bcrypt.compare(password, users[0].password);
        if (!isValid) return null;

        // Update last login
        await this.updateLastLogin(username);

        // Return user without password
        const { password: _, ...user } = users[0];
        return user;
    }

    // Update last login timestamp
    static async updateLastLogin(username) {
        const query = `
      UPDATE \`users\`
      SET last_login = CURRENT_TIMESTAMP
      WHERE username = ?
    `;

        await executeQuery(query, [username]);
    }

    // Get all users (admin only)
    static async getAll() {
        const query = `
      SELECT username, name, role, email, team, created_date, last_login, is_verified
      FROM \`users\`
      ORDER BY created_date DESC
    `;

        return await executeQuery(query);
    }

    // Update user role
    static async updateRole(username, role) {
        const query = `
      UPDATE \`users\`
      SET role = ?
      WHERE username = ?
    `;

        await executeQuery(query, [role, username]);
        return this.findByUsername(username);
    }

    // Check if username exists
    static async usernameExists(username) {
        const query = `SELECT username FROM \`users\` WHERE username = ?`;
        const users = await executeQuery(query, [username]);
        return users.length > 0;
    }

    // Check if email exists
    static async emailExists(email) {
        const query = `SELECT email FROM \`users\` WHERE email = ?`;
        const users = await executeQuery(query, [email]);
        return users.length > 0;
    }
}

module.exports = User;
