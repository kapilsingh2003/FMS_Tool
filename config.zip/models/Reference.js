// Reference Data Model - Samsung FMS Portal (Branches, Models, FMS Keys)
const { executeQuery } = require('../config/database');

class Reference {
  // Get all branches
  static async getAllBranches() {
    const query = `
      SELECT * FROM \`branches\`
      WHERE is_active = true
      ORDER BY branch_name
    `;

    return await executeQuery(query);
  }

  // Get branch by ID
  static async getBranchById(branchId) {
    const query = `
      SELECT * FROM \`branches\`
      WHERE branch_id = ?
    `;

    const branches = await executeQuery(query, [branchId]);
    return branches[0] || null;
  }

  // Get branch by name
  static async getBranchByName(branchName) {
    const query = `
      SELECT * FROM \`branches\`
      WHERE branch_name = ?
    `;

    const branches = await executeQuery(query, [branchName]);
    return branches[0] || null;
  }

  // Get all models
  static async getAllModels() {
    const query = `
      SELECT * FROM \`models\`
      WHERE is_active = true
      ORDER BY product_category, model_name
    `;

    return await executeQuery(query);
  }

  // Get models by product category
  static async getModelsByCategory(category) {
    const query = `
      SELECT * FROM \`models\`
      WHERE product_category = ? AND is_active = true
      ORDER BY model_name
    `;

    return await executeQuery(query, [category]);
  }

  // Get models available in a specific branch
  static async getModelsInBranch(branchId) {
    const query = `
      SELECT m.*
      FROM \`models\` m
      JOIN \`branch_model_mapping\` bmm ON m.model_id = bmm.model_id
      WHERE bmm.branch_id = ? AND bmm.is_available = true AND m.is_active = true
      ORDER BY m.model_name
    `;

    return await executeQuery(query, [branchId]);
  }

  // Get all FMS keys
  static async getAllFMSKeys() {
    const query = `
      SELECT * FROM \`fms_keys\`
      ORDER BY work_assignment, key_name
    `;

    return await executeQuery(query);
  }

  // Get FMS keys with differences (for review)
  static async getFMSKeysWithDifferences() {
    const query = `
      SELECT * FROM \`fms_keys\`
      WHERE has_differences = true
      ORDER BY work_assignment, key_name
    `;

    return await executeQuery(query);
  }

  // Get FMS keys by work assignment
  static async getFMSKeysByWorkAssignment(workAssignment) {
    const query = `
      SELECT * FROM \`fms_keys\`
      WHERE work_assignment = ?
      ORDER BY key_name
    `;

    return await executeQuery(query, [workAssignment]);
  }

  // Get unique work assignments
  static async getWorkAssignments() {
    const query = `
      SELECT DISTINCT work_assignment
      FROM \`fms_keys\`
      WHERE work_assignment IS NOT NULL
      ORDER BY work_assignment
    `;

    const results = await executeQuery(query);
    return results.map(row => row.work_assignment);
  }

  // Get unique key owners
  static async getKeyOwners() {
    const query = `
      SELECT DISTINCT work_assignment_owner
      FROM \`fms_keys\`
      WHERE work_assignment_owner IS NOT NULL
      ORDER BY work_assignment_owner
    `;

    const results = await executeQuery(query);
    return results.map(row => row.work_assignment_owner);
  }

  // Search branches by name
  static async searchBranches(searchTerm) {
    const query = `
      SELECT * FROM \`branches\`
      WHERE branch_name LIKE ? AND is_active = true
      ORDER BY branch_name
      LIMIT 20
    `;

    return await executeQuery(query, [`%${searchTerm}%`]);
  }

  // Search models by name
  static async searchModels(searchTerm) {
    const query = `
      SELECT * FROM \`models\`
      WHERE model_name LIKE ? AND is_active = true
      ORDER BY model_name
      LIMIT 20
    `;

    return await executeQuery(query, [`%${searchTerm}%`]);
  }

  // Get branch-model compatibility matrix
  static async getBranchModelMatrix() {
    const query = `
      SELECT 
        b.branch_name,
        b.branch_type,
        m.model_name,
        m.product_category,
        bmm.is_available
      FROM \`branches\` b
      JOIN \`branch_model_mapping\` bmm ON b.branch_id = bmm.branch_id
      JOIN \`models\` m ON bmm.model_id = m.model_id
      WHERE b.is_active = true AND m.is_active = true
      ORDER BY b.branch_name, m.model_name
    `;

    return await executeQuery(query);
  }

  // Validate branch-model compatibility
  static async validateBranchModelCompatibility(branchId, modelId) {
    const query = `
      SELECT bmm.is_available
      FROM \`branch_model_mapping\` bmm
      WHERE bmm.branch_id = ? AND bmm.model_id = ?
    `;

    const results = await executeQuery(query, [branchId, modelId]);
    return results.length > 0 && results[0].is_available;
  }

  // Get database statistics
  static async getStats() {
    const queries = {
      totalBranches: 'SELECT COUNT(*) as count FROM `Branches` WHERE is_active = true',
      totalModels: 'SELECT COUNT(*) as count FROM `Models` WHERE is_active = true',
      totalFMSKeys: 'SELECT COUNT(*) as count FROM `FMS_Keys`',
      keysWithDifferences: 'SELECT COUNT(*) as count FROM `FMS_Keys` WHERE has_differences = true',
      branchModelMappings: 'SELECT COUNT(*) as count FROM `Branch_Model_Mapping` WHERE is_available = true'
    };

    const results = {};
    for (const [key, query] of Object.entries(queries)) {
      const result = await executeQuery(query);
      results[key] = result[0].count;
    }

    return results;
  }
}

module.exports = Reference;
