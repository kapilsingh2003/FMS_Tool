// Group Model - Samsung FMS Portal
const { executeQuery } = require('../config/database');

class Group {
    // Create a new group
    static async create(groupData) {
        const { project_id, name, comparison_type } = groupData;

        const query = `
      INSERT INTO \`grps\` (project_id, name, comparison_type)
      VALUES (?, ?, ?)
    `;

        const result = await executeQuery(query, [project_id, name, comparison_type]);
        return this.findById(result.insertId);
    }

    // Find group by ID
    static async findById(groupId) {
        const query = `
      SELECT g.*, p.title as project_title
      FROM \`grps\` g
      JOIN \`Projects\` p ON g.project_id = p.project_id
      WHERE g.group_id = ?
    `;

        const groups = await executeQuery(query, [groupId]);
        return groups[0] || null;
    }

    // Get groups by project
    static async getByProject(projectId) {
        const query = `
      SELECT * FROM \`grps\`
      WHERE project_id = ?
      ORDER BY created_at
    `;

        return await executeQuery(query, [projectId]);
    }

    // Add branch to group
    static async addBranch(groupId, branchRole, branchId, sortOrder = 0) {
        const query = `
      INSERT INTO \`Group_Branch_Mapping\` (group_id, branch_role, branch_id, sort_order)
      VALUES (?, ?, ?, ?)
      ON DUPLICATE KEY UPDATE branch_id = VALUES(branch_id), sort_order = VALUES(sort_order)
    `;

        await executeQuery(query, [groupId, branchRole, branchId, sortOrder]);
    }

    // Get group branches
    static async getBranches(groupId) {
        const query = `
      SELECT gbm.*, b.branch_name, b.branch_type
      FROM \`Group_Branch_Mapping\` gbm
      JOIN \`Branches\` b ON gbm.branch_id = b.branch_id
      WHERE gbm.group_id = ?
      ORDER BY gbm.sort_order
    `;

        return await executeQuery(query, [groupId]);
    }

    // Add model to group (through specific branch mapping)
    static async addModel(groupId, modelId, branchRole) {
        // First get the group_branch_mapping ID
        const gbQuery = `
      SELECT gb_id FROM \`Group_Branch_Mapping\`
      WHERE group_id = ? AND branch_role = ?
    `;

        const gbResults = await executeQuery(gbQuery, [groupId, branchRole]);
        if (gbResults.length === 0) {
            throw new Error(`No branch mapping found for group ${groupId} and role ${branchRole}`);
        }

        const gbId = gbResults[0].gb_id;

        // Add model to group-branch-model mapping
        const query = `
      INSERT IGNORE INTO \`Group_Branch_Model_Map\` (gb_id, model_id)
      VALUES (?, ?)
    `;

        await executeQuery(query, [gbId, modelId]);
    }

    // Get models for group
    static async getModels(groupId) {
        const query = `
      SELECT DISTINCT m.*, gbm.branch_role
      FROM \`Models\` m
      JOIN \`Group_Branch_Model_Map\` gbmm ON m.model_id = gbmm.model_id
      JOIN \`Group_Branch_Mapping\` gbm ON gbmm.gb_id = gbm.gb_id
      WHERE gbm.group_id = ?
      ORDER BY m.model_name
    `;

        return await executeQuery(query, [groupId]);
    }

    // Get available models for a branch (used in UI model selection)
    static async getAvailableModelsForBranch(branchId) {
        const query = `
      SELECT m.*
      FROM \`Models\` m
      JOIN \`Branch_Model_Mapping\` bmm ON m.model_id = bmm.model_id
      WHERE bmm.branch_id = ? AND bmm.is_available = true
      ORDER BY m.model_name
    `;

        return await executeQuery(query, [branchId]);
    }

    // Remove model from group
    static async removeModel(groupId, modelId) {
        const query = `
      DELETE gbmm FROM \`Group_Branch_Model_Map\` gbmm
      JOIN \`Group_Branch_Mapping\` gbm ON gbmm.gb_id = gbm.gb_id
      WHERE gbm.group_id = ? AND gbmm.model_id = ?
    `;

        await executeQuery(query, [groupId, modelId]);
    }

    // Update group
    static async update(groupId, updateData) {
        const { name, comparison_type } = updateData;

        const query = `
      UPDATE \`grps\`
      SET name = ?, comparison_type = ?, updated_at = CURRENT_TIMESTAMP
      WHERE group_id = ?
    `;

        await executeQuery(query, [name, comparison_type, groupId]);
        return this.findById(groupId);
    }

    // Delete group
    static async delete(groupId) {
        const query = `DELETE FROM \`grps\` WHERE group_id = ?`;
        await executeQuery(query, [groupId]);
    }

    // Get group with full configuration (branches + models)
    static async getFullConfig(groupId) {
        const group = await this.findById(groupId);
        if (!group) return null;

        const branches = await this.getBranches(groupId);
        const models = await this.getModels(groupId);

        return {
            ...group,
            branches,
            models
        };
    }

    // Set complete branch configuration for group
    static async setBranchConfig(groupId, branchConfig) {
        // Delete existing branch mappings
        await executeQuery('DELETE FROM `Group_Branch_Mapping` WHERE group_id = ?', [groupId]);

        // Add new branch mappings
        const branchRoles = Object.keys(branchConfig);
        for (let i = 0; i < branchRoles.length; i++) {
            const role = branchRoles[i];
            const branchName = branchConfig[role];

            // Get branch ID by name
            const branchQuery = `SELECT branch_id FROM \`Branches\` WHERE branch_name = ?`;
            const branchResults = await executeQuery(branchQuery, [branchName]);

            if (branchResults.length > 0) {
                await this.addBranch(groupId, role, branchResults[0].branch_id, i + 1);
            }
        }
    }
}

module.exports = Group;
