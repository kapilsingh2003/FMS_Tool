// Project Routes - Samsung FMS Portal
const express = require('express');
const Project = require('../models/Project');
const KeyReview = require('../models/KeyReview');
const { executeQuery } = require('../config/database');
const { authenticateToken } = require('./auth');
const router = express.Router();
const fs = require('fs');
const path = require('path');
const { spawnSync, spawn } = require('child_process');

// Apply authentication middleware to all routes
router.use(authenticateToken);

// Helper function to get branch ID by name
async function getBranchIdByName(branchName) {
  const query = 'SELECT branch_id FROM Branches WHERE branch_name = ?';
  const result = await executeQuery(query, [branchName]);
  return result[0]?.branch_id || null;
}

// GET /api/projects - Get projects for current user
router.get('/', async (req, res) => {
  try {
    console.log('Getting projects for user:', req.user.username);
    const projects = await Project.getByUser(req.user.username);
    console.log('Found projects:', projects.length);

    // Get statistics for each project
    const projectsWithStats = await Promise.all(
      projects.map(async (project) => {
        try {
          const stats = await Project.getStats(project.project_id);
          return {
            ...project,
            ...stats
          };
        } catch (statsError) {
          console.error('Error getting stats for project', project.project_id, ':', statsError);
          return {
            ...project,
            keyDifferences: 0,
            reviewedKeys: 0
          };
        }
      })
    );

    res.json({
      success: true,
      projects: projectsWithStats
    });
  } catch (error) {
    console.error('Get projects error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch projects',
      error: error.message
    });
  }
});

// GET /api/projects/:id - Get project details
router.get('/:id', async (req, res) => {
  try {
    const projectId = req.params.id;

    // Check if user has access to this project
    const hasAccess = await Project.hasAccess(projectId, req.user.username);
    if (!hasAccess) {
      return res.status(403).json({
        success: false,
        message: 'Access denied to this project'
      });
    }

    const project = await Project.getFullDetails(projectId);
    if (!project) {
      return res.status(404).json({
        success: false,
        message: 'Project not found'
      });
    }

    res.json({
      success: true,
      project
    });
  } catch (error) {
    console.error('Get project details error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch project details'
    });
  }
});

// POST /api/projects - Create new project
router.post('/', async (req, res) => {
  try {
    const { title, description, refreshSchedule, groups } = req.body;

    // Only admins can create projects
    if (req.user.role !== 'admin') {
      return res.status(403).json({
        success: false,
        message: 'Only admins can create projects'
      });
    }

    // Validate input
    if (!title) {
      return res.status(400).json({
        success: false,
        message: 'Project title is required'
      });
    }

    const projectData = {
      title: title.substring(0, 100), // Enforce character limit
      description: description ? description.substring(0, 500) : '',
      admin_username: req.user.username,
      refresh_schedule: refreshSchedule || 'Weekly'
    };

    const project = await Project.create(projectData);

    // Add creator as admin participant
    await Project.addParticipant(project.project_id, req.user.username, req.user.username, 'admin');

    // Create groups with the new structure (grps table with branch data)
    if (groups && Array.isArray(groups) && groups.length > 0) {
      for (const groupData of groups) {
        const { name, comparisonType, branches, models } = groupData;

        // Get branch IDs
        const targetBranchId = branches?.target ? await getBranchIdByName(branches.target) : null;
        const ref1BranchId = branches?.reference1 ? await getBranchIdByName(branches.reference1) : null;
        const ref2BranchId = branches?.reference2 ? await getBranchIdByName(branches.reference2) : null;
        const ref3BranchId = branches?.reference3 ? await getBranchIdByName(branches.reference3) : null;

        // Create the group with branch data directly in grps table
        const group = await Project.createGroup({
          project_id: project.project_id,
          name,
          comparison_type: comparisonType,
          target_branch_id: targetBranchId,
          ref1_branch_id: ref1BranchId,
          ref2_branch_id: ref2BranchId,
          ref3_branch_id: ref3BranchId
        });

        // Add models to the group if provided
        if (models && Array.isArray(models) && models.length > 0) {
          for (const modelData of models) {
            await Project.addModelToGroup(group.group_id, modelData);
          }
        }
      }
    }

    // Get the complete project with all details
    const completeProject = await Project.getFullDetails(project.project_id);

    // Build branch_models_dict for P4 script
    let branchModelsDict = null;
    try {
      const branchList2D = [];
      const modelList3D = [];

      for (const group of completeProject.groups) {
        const comparisonType = group.comparison_type || group.comparisonType;
        const branches = [];
        if (group.target_branch_name || group.branches?.target) branches.push(group.target_branch_name || group.branches?.target);
        if (comparisonType && (comparisonType.includes('2-way') || comparisonType.includes('3-way') || comparisonType.includes('4-way'))) {
          if (group.ref1_branch_name || group.branches?.reference1) branches.push(group.ref1_branch_name || group.branches?.reference1);
          if (comparisonType.includes('3-way') || comparisonType.includes('4-way')) {
            if (group.ref2_branch_name || group.branches?.reference2) branches.push(group.ref2_branch_name || group.branches?.reference2);
            if (comparisonType.includes('4-way')) {
              if (group.ref3_branch_name || group.branches?.reference3) branches.push(group.ref3_branch_name || group.branches?.reference3);
            }
          }
        }
        branchList2D.push(branches);

        // Fetch model combinations for the group
        const modelCombinations = await Project.getGroupModelCombinations(group.group_id);
        const modelRows = modelCombinations.map((row) => {
          const models = [];
          if (row.target) models.push(row.target);
          if (branches.length >= 2) models.push(row.ref1 || row.target);
          if (branches.length >= 3) models.push(row.ref2 || row.target);
          if (branches.length >= 4) models.push(row.ref3 || row.target);
          return models;
        });
        modelList3D.push(modelRows);
      }

      branchModelsDict = { branch: branchList2D, model: modelList3D };
      console.log('branch_models_dict for project', project.project_id, JSON.stringify(branchModelsDict));

      // Persist dict as a .py file named by project_id
      try {
        const dictDir = path.join(__dirname, '..', '..', 'sample key review data', 'project_wise_dict_data');
        if (!fs.existsSync(dictDir)) {
          fs.mkdirSync(dictDir, { recursive: true });
        }
        const dictFile = path.join(dictDir, `project_${project.project_id}_branch_models.py`);
        const fileContent = `branch_models_dict = ${JSON.stringify(branchModelsDict, null, 2)}\n`;
        fs.writeFileSync(dictFile, fileContent, 'utf8');
        console.log('Saved branch_models_dict to', dictFile);

        // Set project status to Syncing before starting async job
        try {
          await Project.update(project.project_id, {
            title: completeProject.title,
            description: completeProject.description,
            refresh_schedule: completeProject.refresh_schedule,
            status: 'Syncing'
          });
          console.log(`Project ${project.project_id} status set to Syncing`);
        } catch (_) { }
      } catch (persistErr) {
        console.error('Failed to persist branch_models_dict:', persistErr.message);
      }

      // Fire-and-forget: spawn Python process to call get_dif_from_p4 and flip status back to active on exit
      try {
        const pythonPath = 'python';
        const scriptPath = path.join(__dirname, '..', '..', 'sample key review data', 'new_p4_diff_code.py');
        const jsonArg = JSON.stringify(branchModelsDict);

        // We will call the Python script with a small shim to read the JSON and call the function
        const shimCode = `import sys,json;\nfrom pathlib import Path;\nfp = ${JSON.stringify(scriptPath) !== undefined ? `r'''${scriptPath.replace(/\\/g, '\\\\')}'''` : `''`};\nimport importlib.util;\nspec = importlib.util.spec_from_file_location('p4mod', fp);\nmod = importlib.util.module_from_spec(spec);\nspec.loader.exec_module(mod);\narg=json.loads(sys.argv[1]);\nprint('P4 shim start');\nres = mod.get_dif_from_p4(arg, mod.model_data, mod.branch_data);\nprint('P4 shim done', len(res) if res else 0)`;

        const child = spawn(pythonPath, ['-c', shimCode, jsonArg], { stdio: 'ignore', detached: true });
        child.on('exit', async (code) => {
          try {
            await Project.update(project.project_id, {
              title: completeProject.title,
              description: completeProject.description,
              refresh_schedule: completeProject.refresh_schedule,
              status: 'active'
            });
            console.log(`Project ${project.project_id} sync finished with code ${code}. Status set to active.`);
          } catch (statusErr) {
            console.error('Failed to set project status to active:', statusErr.message);
          }
        });
        child.unref();
      } catch (pyErr) {
        console.error('Failed to spawn P4 Python process:', pyErr.message);
      }
    } catch (buildErr) {
      console.error('Failed to build/send branch_models_dict:', buildErr.message);
    }

    res.status(201).json({
      success: true,
      message: 'Project created successfully',
      data: completeProject,
      branchModelsDict
    });
  } catch (error) {
    console.error('Create project error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to create project'
    });
  }
});

// POST /api/projects/:id/export-dict - Build and save branch_models_dict for a project (manual trigger)
router.post('/:id/export-dict', async (req, res) => {
  try {
    const projectId = req.params.id;

    // Check access
    const hasAccess = await Project.hasAccess(projectId, req.user.username);
    if (!hasAccess) {
      return res.status(403).json({ success: false, message: 'Access denied to this project' });
    }

    // Build project details
    const completeProject = await Project.getFullDetails(projectId);
    if (!completeProject) {
      return res.status(404).json({ success: false, message: 'Project not found' });
    }

    const branchList2D = [];
    const modelList3D = [];

    for (const group of completeProject.groups) {
      const comparisonType = group.comparison_type || group.comparisonType;
      const branches = [];
      if (group.target_branch_name || group.branches?.target) branches.push(group.target_branch_name || group.branches?.target);
      if (comparisonType && (comparisonType.includes('2-way') || comparisonType.includes('3-way') || comparisonType.includes('4-way'))) {
        if (group.ref1_branch_name || group.branches?.reference1) branches.push(group.ref1_branch_name || group.branches?.reference1);
        if (comparisonType.includes('3-way') || comparisonType.includes('4-way')) {
          if (group.ref2_branch_name || group.branches?.reference2) branches.push(group.ref2_branch_name || group.branches?.reference2);
          if (comparisonType.includes('4-way')) {
            if (group.ref3_branch_name || group.branches?.reference3) branches.push(group.ref3_branch_name || group.branches?.reference3);
          }
        }
      }
      branchList2D.push(branches);

      const modelCombinations = await Project.getGroupModelCombinations(group.group_id);
      const modelRows = modelCombinations.map((row) => {
        const models = [];
        if (row.target) models.push(row.target);
        if (branches.length >= 2) models.push(row.ref1 || row.target);
        if (branches.length >= 3) models.push(row.ref2 || row.target);
        if (branches.length >= 4) models.push(row.ref3 || row.target);
        return models;
      });
      modelList3D.push(modelRows);
    }

    const branchModelsDict = { branch: branchList2D, model: modelList3D };

    // Persist to file
    const dictDir = path.join(__dirname, '..', '..', 'sample key review data', 'project_wise_dict_data');
    if (!fs.existsSync(dictDir)) {
      fs.mkdirSync(dictDir, { recursive: true });
    }
    const dictFile = path.join(dictDir, `project_${projectId}_branch_models.py`);
    const fileContent = `branch_models_dict = ${JSON.stringify(branchModelsDict, null, 2)}\n`;
    fs.writeFileSync(dictFile, fileContent, 'utf8');
    console.log('Saved branch_models_dict to', dictFile);

    return res.json({ success: true, path: dictFile, branchModelsDict });
  } catch (error) {
    console.error('Export dict error:', error);
    return res.status(500).json({ success: false, message: 'Failed to export branch_models_dict', error: error.message });
  }
});

// PUT /api/projects/:id - Update project
router.put('/:id', async (req, res) => {
  try {
    const projectId = req.params.id;
    const { title, description, refreshSchedule, groups } = req.body;

    // Check if user is admin of this project
    const project = await Project.findById(projectId);
    if (!project || project.admin_username !== req.user.username) {
      return res.status(403).json({
        success: false,
        message: 'Only project admin can update project'
      });
    }

    // Update basic project information
    const updateData = {
      title: title ? title.substring(0, 100) : project.title,
      description: description !== undefined ? description.substring(0, 500) : project.description,
      refresh_schedule: refreshSchedule || project.refresh_schedule
    };

    const updatedProject = await Project.update(projectId, updateData);

    // Update groups and their configurations if provided
    if (groups && Array.isArray(groups)) {
      // Delete existing groups and their mappings
      await executeQuery('DELETE FROM `Group_Branch_Model_Map` WHERE gb_id IN (SELECT gb_id FROM `Group_Branch_Mapping` WHERE group_id IN (SELECT group_id FROM `grps` WHERE project_id = ?))', [projectId]);
      await executeQuery('DELETE FROM `Group_Branch_Mapping` WHERE group_id IN (SELECT group_id FROM `grps` WHERE project_id = ?)', [projectId]);
      await executeQuery('DELETE FROM `grps` WHERE project_id = ?', [projectId]);

      // Create new groups
      for (const groupData of groups) {
        const { name, comparisonType, branches, models } = groupData;

        // Create the group
        const group = await Group.create({
          project_id: projectId,
          name,
          comparison_type: comparisonType
        });

        // Set branch configuration if provided
        if (branches && typeof branches === 'object') {
          await Group.setBranchConfig(group.group_id, branches);
        }

        // Add models to the group if provided
        if (models && Array.isArray(models) && models.length > 0) {
          for (const modelName of models) {
            await Group.addModel(group.group_id, modelName);
          }
        }
      }
    }

    // Get the complete updated project with all details
    const completeProject = await Project.getFullDetails(projectId);

    res.json({
      success: true,
      message: 'Project updated successfully',
      data: completeProject
    });
  } catch (error) {
    console.error('Update project error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to update project'
    });
  }
});

// DELETE /api/projects/:id - Delete project
router.delete('/:id', async (req, res) => {
  try {
    const projectId = req.params.id;

    // Check if user is admin of this project
    const project = await Project.findById(projectId);
    if (!project || project.admin_username !== req.user.username) {
      return res.status(403).json({
        success: false,
        message: 'Only project admin can delete project'
      });
    }

    await Project.delete(projectId);

    res.json({
      success: true,
      message: 'Project deleted successfully'
    });
  } catch (error) {
    console.error('Delete project error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to delete project'
    });
  }
});

// POST /api/projects/:id/participants - Add participant to project
router.post('/:id/participants', async (req, res) => {
  try {
    const projectId = req.params.id;
    const { username, role } = req.body;

    // Check if user is admin of this project
    const project = await Project.findById(projectId);
    if (!project || project.admin_username !== req.user.username) {
      return res.status(403).json({
        success: false,
        message: 'Only project admin can add participants'
      });
    }

    await Project.addParticipant(projectId, username, req.user.username, role || 'reviewer');

    res.json({
      success: true,
      message: 'Participant added successfully'
    });
  } catch (error) {
    console.error('Add participant error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to add participant'
    });
  }
});

// DELETE /api/projects/:id/participants/:username - Remove participant
router.delete('/:id/participants/:username', async (req, res) => {
  try {
    const projectId = req.params.id;
    const username = req.params.username;

    // Check if user is admin of this project
    const project = await Project.findById(projectId);
    if (!project || project.admin_username !== req.user.username) {
      return res.status(403).json({
        success: false,
        message: 'Only project admin can remove participants'
      });
    }

    await Project.removeParticipant(projectId, username);

    res.json({
      success: true,
      message: 'Participant removed successfully'
    });
  } catch (error) {
    console.error('Remove participant error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to remove participant'
    });
  }
});

// GET /api/projects/:id/groups - Get project groups
router.get('/:id/groups', async (req, res) => {
  try {
    const projectId = req.params.id;

    // Check access
    const hasAccess = await Project.hasAccess(projectId, req.user.username);
    if (!hasAccess) {
      return res.status(403).json({
        success: false,
        message: 'Access denied to this project'
      });
    }

    const groups = await Group.getByProject(projectId);

    res.json({
      success: true,
      groups
    });
  } catch (error) {
    console.error('Get project groups error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch project groups'
    });
  }
});

// POST /api/projects/:id/groups - Create group in project
router.post('/:id/groups', async (req, res) => {
  try {
    const projectId = req.params.id;
    const { name, comparison_type, branchConfig } = req.body;

    // Check if user is admin of this project
    const project = await Project.findById(projectId);
    if (!project || project.admin_username !== req.user.username) {
      return res.status(403).json({
        success: false,
        message: 'Only project admin can create groups'
      });
    }

    // Validate input
    if (!name || !comparison_type) {
      return res.status(400).json({
        success: false,
        message: 'Group name and comparison type are required'
      });
    }

    const groupData = {
      project_id: projectId,
      name,
      comparison_type
    };

    const group = await Group.create(groupData);

    // Set branch configuration if provided
    if (branchConfig) {
      await Group.setBranchConfig(group.group_id, branchConfig);
    }

    res.status(201).json({
      success: true,
      message: 'Group created successfully',
      group
    });
  } catch (error) {
    console.error('Create group error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to create group'
    });
  }
});

// GET /api/projects/:id/reviews - Get key reviews for project
router.get('/:id/reviews', async (req, res) => {
  try {
    const projectId = req.params.id;

    // Check access
    const hasAccess = await Project.hasAccess(projectId, req.user.username);
    if (!hasAccess) {
      return res.status(403).json({
        success: false,
        message: 'Access denied to this project'
      });
    }

    const reviews = await KeyReview.getHierarchicalData(projectId);

    res.json({
      success: true,
      reviews
    });
  } catch (error) {
    console.error('Get project reviews error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch project reviews'
    });
  }
});

// GET /api/projects/:id/stats - Get project statistics
router.get('/:id/stats', async (req, res) => {
  try {
    const projectId = req.params.id;

    // Check access
    const hasAccess = await Project.hasAccess(projectId, req.user.username);
    if (!hasAccess) {
      return res.status(403).json({
        success: false,
        message: 'Access denied to this project'
      });
    }

    const stats = await KeyReview.getProjectStats(projectId);

    res.json({
      success: true,
      stats
    });
  } catch (error) {
    console.error('Get project stats error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch project statistics'
    });
  }
});

module.exports = router;