// Project Routes - Samsung FMS Portal
const express = require('express');
const Project = require('../models/Project');
const Group = require('../models/Group');
const KeyReview = require('../models/KeyReview');
const { authenticateToken } = require('./auth');
const router = express.Router();

// Apply authentication middleware to all routes
router.use(authenticateToken);

// GET /api/projects - Get projects for current user
router.get('/', async (req, res) => {
  try {
    const projects = await Project.getByUser(req.user.username);

    // Get statistics for each project
    const projectsWithStats = await Promise.all(
      projects.map(async (project) => {
        const stats = await Project.getStats(project.project_id);
        return {
          ...project,
          ...stats
        };
      })
    );

    res.json({
      success: true,
      projects: projectsWithStats
    });
  } catch (error) {
    console.error('Get projects error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch projects'
    });
  }
});

// GET /api/projects/:id - Get project details
router.get('/:id', async (req, res) => {
  try {
    const projectId = req.params.id;

    // Check if user has access to this project
    const hasAccess = await Project.hasAccess(projectId, req.user.username);
    if (!hasAccess) {
      return res.status(403).json({
        success: false,
        message: 'Access denied to this project'
      });
    }

    const project = await Project.getFullDetails(projectId);
    if (!project) {
      return res.status(404).json({
        success: false,
        message: 'Project not found'
      });
    }

    res.json({
      success: true,
      project
    });
  } catch (error) {
    console.error('Get project details error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch project details'
    });
  }
});

// POST /api/projects - Create new project
router.post('/', async (req, res) => {
  try {
    const { title, description, refresh_schedule } = req.body;

    // Only admins can create projects
    if (req.user.role !== 'admin') {
      return res.status(403).json({
        success: false,
        message: 'Only admins can create projects'
      });
    }

    // Validate input
    if (!title) {
      return res.status(400).json({
        success: false,
        message: 'Project title is required'
      });
    }

    const projectData = {
      title: title.substring(0, 100), // Enforce character limit
      description: description ? description.substring(0, 500) : '',
      admin_username: req.user.username,
      refresh_schedule: refresh_schedule || 'Weekly'
    };

    const project = await Project.create(projectData);

    // Add creator as admin participant
    await Project.addParticipant(project.project_id, req.user.username, req.user.username, 'admin');

    res.status(201).json({
      success: true,
      message: 'Project created successfully',
      project
    });
  } catch (error) {
    console.error('Create project error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to create project'
    });
  }
});

// PUT /api/projects/:id - Update project
router.put('/:id', async (req, res) => {
  try {
    const projectId = req.params.id;
    const { title, description, refresh_schedule, status } = req.body;

    // Check if user is admin of this project
    const project = await Project.findById(projectId);
    if (!project || project.admin_username !== req.user.username) {
      return res.status(403).json({
        success: false,
        message: 'Only project admin can update project'
      });
    }

    const updateData = {
      title: title ? title.substring(0, 100) : project.title,
      description: description !== undefined ? description.substring(0, 500) : project.description,
      refresh_schedule: refresh_schedule || project.refresh_schedule,
      status: status || project.status
    };

    const updatedProject = await Project.update(projectId, updateData);

    res.json({
      success: true,
      message: 'Project updated successfully',
      project: updatedProject
    });
  } catch (error) {
    console.error('Update project error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to update project'
    });
  }
});

// DELETE /api/projects/:id - Delete project
router.delete('/:id', async (req, res) => {
  try {
    const projectId = req.params.id;

    // Check if user is admin of this project
    const project = await Project.findById(projectId);
    if (!project || project.admin_username !== req.user.username) {
      return res.status(403).json({
        success: false,
        message: 'Only project admin can delete project'
      });
    }

    await Project.delete(projectId);

    res.json({
      success: true,
      message: 'Project deleted successfully'
    });
  } catch (error) {
    console.error('Delete project error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to delete project'
    });
  }
});

// POST /api/projects/:id/participants - Add participant to project
router.post('/:id/participants', async (req, res) => {
  try {
    const projectId = req.params.id;
    const { username, role } = req.body;

    // Check if user is admin of this project
    const project = await Project.findById(projectId);
    if (!project || project.admin_username !== req.user.username) {
      return res.status(403).json({
        success: false,
        message: 'Only project admin can add participants'
      });
    }

    await Project.addParticipant(projectId, username, req.user.username, role || 'reviewer');

    res.json({
      success: true,
      message: 'Participant added successfully'
    });
  } catch (error) {
    console.error('Add participant error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to add participant'
    });
  }
});

// DELETE /api/projects/:id/participants/:username - Remove participant
router.delete('/:id/participants/:username', async (req, res) => {
  try {
    const projectId = req.params.id;
    const username = req.params.username;

    // Check if user is admin of this project
    const project = await Project.findById(projectId);
    if (!project || project.admin_username !== req.user.username) {
      return res.status(403).json({
        success: false,
        message: 'Only project admin can remove participants'
      });
    }

    await Project.removeParticipant(projectId, username);

    res.json({
      success: true,
      message: 'Participant removed successfully'
    });
  } catch (error) {
    console.error('Remove participant error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to remove participant'
    });
  }
});

// GET /api/projects/:id/groups - Get project groups
router.get('/:id/groups', async (req, res) => {
  try {
    const projectId = req.params.id;

    // Check access
    const hasAccess = await Project.hasAccess(projectId, req.user.username);
    if (!hasAccess) {
      return res.status(403).json({
        success: false,
        message: 'Access denied to this project'
      });
    }

    const groups = await Group.getByProject(projectId);

    res.json({
      success: true,
      groups
    });
  } catch (error) {
    console.error('Get project groups error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch project groups'
    });
  }
});

// POST /api/projects/:id/groups - Create group in project
router.post('/:id/groups', async (req, res) => {
  try {
    const projectId = req.params.id;
    const { name, comparison_type, branchConfig } = req.body;

    // Check if user is admin of this project
    const project = await Project.findById(projectId);
    if (!project || project.admin_username !== req.user.username) {
      return res.status(403).json({
        success: false,
        message: 'Only project admin can create groups'
      });
    }

    // Validate input
    if (!name || !comparison_type) {
      return res.status(400).json({
        success: false,
        message: 'Group name and comparison type are required'
      });
    }

    const groupData = {
      project_id: projectId,
      name,
      comparison_type
    };

    const group = await Group.create(groupData);

    // Set branch configuration if provided
    if (branchConfig) {
      await Group.setBranchConfig(group.group_id, branchConfig);
    }

    res.status(201).json({
      success: true,
      message: 'Group created successfully',
      group
    });
  } catch (error) {
    console.error('Create group error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to create group'
    });
  }
});

// GET /api/projects/:id/reviews - Get key reviews for project
router.get('/:id/reviews', async (req, res) => {
  try {
    const projectId = req.params.id;

    // Check access
    const hasAccess = await Project.hasAccess(projectId, req.user.username);
    if (!hasAccess) {
      return res.status(403).json({
        success: false,
        message: 'Access denied to this project'
      });
    }

    const reviews = await KeyReview.getHierarchicalData(projectId);

    res.json({
      success: true,
      reviews
    });
  } catch (error) {
    console.error('Get project reviews error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch project reviews'
    });
  }
});

// GET /api/projects/:id/stats - Get project statistics
router.get('/:id/stats', async (req, res) => {
  try {
    const projectId = req.params.id;

    // Check access
    const hasAccess = await Project.hasAccess(projectId, req.user.username);
    if (!hasAccess) {
      return res.status(403).json({
        success: false,
        message: 'Access denied to this project'
      });
    }

    const stats = await KeyReview.getProjectStats(projectId);

    res.json({
      success: true,
      stats
    });
  } catch (error) {
    console.error('Get project stats error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch project statistics'
    });
  }
});

module.exports = router;