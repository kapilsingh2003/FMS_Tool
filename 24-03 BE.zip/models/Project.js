// Project Model - Samsung FMS Portal
const { executeQuery } = require('../config/database');

class Project {
  // Create a new project (supports both regular and official projects)
  static async create(projectData) {
    const {
      title,
      description,
      admin_username,
      refresh_schedule,
      // Official project fields
      is_official = false,
      swplm_project_name = null,
      project_lead_username = null,
      project_manager_username = null,
      target_completion_date = null
    } = projectData;

    // For official projects, set creation_approval_status to 'pending'
    // For regular projects, set it to 'not_required'
    const creation_approval_status = is_official ? 'pending' : 'not_required';

    const query = `
      INSERT INTO \`Projects\` (
        title, description, admin_username, refresh_schedule,
        is_official, swplm_project_name, project_lead_username, 
        project_manager_username, target_completion_date, creation_approval_status
      )
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `;

    const result = await executeQuery(query, [
      title, description, admin_username, refresh_schedule,
      is_official, swplm_project_name, project_lead_username,
      project_manager_username, target_completion_date, creation_approval_status
    ]);
    return this.findById(result.insertId);
  }

  // Find project by ID (includes PL and PM names for official projects)
  static async findById(projectId) {
    const query = `
      SELECT p.*, 
        u.name as admin_name,
        pl.name as project_lead_name,
        pm.name as project_manager_name
      FROM \`Projects\` p
      JOIN \`Users\` u ON p.admin_username = u.username
      LEFT JOIN \`Users\` pl ON p.project_lead_username = pl.username
      LEFT JOIN \`Users\` pm ON p.project_manager_username = pm.username
      WHERE p.project_id = ?
    `;

    const projects = await executeQuery(query, [projectId]);
    return projects[0] || null;
  }

  // Get all projects for a user (includes official project info)
  static async getByUser(username) {
    const query = `
      SELECT DISTINCT p.*, 
        u.name as admin_name,
        pl.name as project_lead_name,
        pm.name as project_manager_name
      FROM \`Projects\` p
      JOIN \`Users\` u ON p.admin_username = u.username
      LEFT JOIN \`Users\` pl ON p.project_lead_username = pl.username
      LEFT JOIN \`Users\` pm ON p.project_manager_username = pm.username
      LEFT JOIN \`Project_Participants\` pp ON p.project_id = pp.project_id
      WHERE p.admin_username = ? OR pp.user_username = ?
      ORDER BY p.created_date DESC
    `;

    return await executeQuery(query, [username, username]);
  }

  // Get official projects for a user (projects where user is PL, PM, or participant)
  static async getOfficialProjectsForUser(username) {
    const query = `
      SELECT DISTINCT p.*, 
        u.name as admin_name,
        pl.name as project_lead_name,
        pm.name as project_manager_name,
        (SELECT COUNT(*) FROM \`Key_Reviews\` kr2
         JOIN \`grps\` g2 ON kr2.group_id = g2.group_id
         WHERE g2.project_id = p.project_id AND kr2.status = 'unreviewed') AS unreviewed_count
      FROM \`Projects\` p
      JOIN \`Users\` u ON p.admin_username = u.username
      LEFT JOIN \`Users\` pl ON p.project_lead_username = pl.username
      LEFT JOIN \`Users\` pm ON p.project_manager_username = pm.username
      LEFT JOIN \`Project_Participants\` pp ON p.project_id = pp.project_id
      WHERE p.is_official = TRUE 
        AND (p.admin_username = ? 
          OR p.project_lead_username = ? 
          OR p.project_manager_username = ? 
          OR pp.user_username = ?)
      ORDER BY p.target_completion_date ASC, p.created_date DESC
    `;

    return await executeQuery(query, [username, username, username, username]);
  }

  // Get all projects (for scheduler)
  static async getAll() {
    const query = `
      SELECT p.*, 
        u.name as admin_name,
        pl.name as project_lead_name,
        pm.name as project_manager_name
      FROM \`Projects\` p
      JOIN \`Users\` u ON p.admin_username = u.username
      LEFT JOIN \`Users\` pl ON p.project_lead_username = pl.username
      LEFT JOIN \`Users\` pm ON p.project_manager_username = pm.username
      ORDER BY p.created_date DESC
    `;

    return await executeQuery(query);
  }

  // Submit project for PM approval (called by PL)
  static async submitForPMApproval(projectId) {
    const query = `
      UPDATE \`Projects\`
      SET pm_approval_status = 'pending',
          pm_submitted_at = CURRENT_TIMESTAMP,
          pm_approved_at = NULL,
          pm_rejection_reason = NULL
      WHERE project_id = ? AND is_official = TRUE
    `;

    await executeQuery(query, [projectId]);
    return this.findById(projectId);
  }

  // Approve project by PM
  static async approvePMApproval(projectId) {
    const query = `
      UPDATE \`Projects\`
      SET pm_approval_status = 'approved',
          pm_approved_at = CURRENT_TIMESTAMP
      WHERE project_id = ? AND is_official = TRUE
    `;

    await executeQuery(query, [projectId]);
    return this.findById(projectId);
  }

  // Reject project by PM
  static async rejectPMApproval(projectId, reason) {
    const query = `
      UPDATE \`Projects\`
      SET pm_approval_status = 'rejected',
          pm_approved_at = CURRENT_TIMESTAMP,
          pm_rejection_reason = ?
      WHERE project_id = ? AND is_official = TRUE
    `;

    await executeQuery(query, [reason, projectId]);
    return this.findById(projectId);
  }

  // Approve project creation by PM (for official projects)
  static async approveCreation(projectId) {
    const query = `
      UPDATE \`Projects\`
      SET creation_approval_status = 'approved',
          creation_approved_at = CURRENT_TIMESTAMP,
          creation_rejection_reason = NULL
      WHERE project_id = ? AND is_official = TRUE
    `;

    await executeQuery(query, [projectId]);
    return this.findById(projectId);
  }

  // Reject project creation by PM (for official projects)
  static async rejectCreation(projectId, reason) {
    const query = `
      UPDATE \`Projects\`
      SET creation_approval_status = 'rejected',
          creation_approved_at = CURRENT_TIMESTAMP,
          creation_rejection_reason = ?
      WHERE project_id = ? AND is_official = TRUE
    `;

    await executeQuery(query, [reason, projectId]);
    return this.findById(projectId);
  }

  // Get official projects pending creation approval for a PM
  static async getPendingCreationApproval(pmUsername) {
    const query = `
      SELECT p.*, 
        u.name as admin_name,
        pl.name as project_lead_name,
        pm.name as project_manager_name
      FROM \`Projects\` p
      JOIN \`Users\` u ON p.admin_username = u.username
      LEFT JOIN \`Users\` pl ON p.project_lead_username = pl.username
      LEFT JOIN \`Users\` pm ON p.project_manager_username = pm.username
      WHERE p.is_official = TRUE 
        AND p.project_manager_username = ?
        AND p.creation_approval_status = 'pending'
      ORDER BY p.created_date DESC
    `;

    return await executeQuery(query, [pmUsername]);
  }

  // Check if user is the Project Lead
  static async isProjectLead(projectId, username) {
    const query = `
      SELECT 1 FROM \`Projects\`
      WHERE project_id = ? AND project_lead_username = ?
    `;
    const result = await executeQuery(query, [projectId, username]);
    return result.length > 0;
  }

  // Check if user is the Project Manager
  static async isProjectManager(projectId, username) {
    const query = `
      SELECT 1 FROM \`Projects\`
      WHERE project_id = ? AND project_manager_username = ?
    `;
    const result = await executeQuery(query, [projectId, username]);
    return result.length > 0;
  }

  // Get project with full details (groups, models, etc.)
  static async getFullDetails(projectId) {
    const project = await this.findById(projectId);
    if (!project) return null;

    // Get participants
    const participants = await this.getParticipants(projectId);

    // Get groups with branches
    const groups = await this.getGroups(projectId);

    return {
      ...project,
      participants,
      groups
    };
  }

  // Get project participants
  static async getParticipants(projectId) {
    const query = `
      SELECT pp.*, u.name, u.email, u.team
      FROM \`Project_Participants\` pp
      JOIN \`Users\` u ON pp.user_username = u.username
      WHERE pp.project_id = ?
      ORDER BY pp.participant_role, u.name
    `;

    return await executeQuery(query, [projectId]);
  }

  // Get project groups with branches and models
  static async getGroups(projectId) {
    const query = `
      SELECT g.*,
        target_b.branch_name as target_branch_name,
        ref1_b.branch_name as ref1_branch_name,
        ref2_b.branch_name as ref2_branch_name,
        ref3_b.branch_name as ref3_branch_name
      FROM \`grps\` g
      LEFT JOIN \`Branches\` target_b ON g.target_branch_id = target_b.branch_id
      LEFT JOIN \`Branches\` ref1_b ON g.ref1_branch_id = ref1_b.branch_id
      LEFT JOIN \`Branches\` ref2_b ON g.ref2_branch_id = ref2_b.branch_id
      LEFT JOIN \`Branches\` ref3_b ON g.ref3_branch_id = ref3_b.branch_id
      WHERE g.project_id = ?
      ORDER BY g.created_at
    `;

    const groups = await executeQuery(query, [projectId]);

    // Get model combinations for each group
    for (let group of groups) {
      group.models = await this.getGroupModelCombinations(group.group_id);

      // Create branch configuration object
      group.branchConfig = {};
      group.branches = {}; // Create branches object for frontend compatibility

      if (group.target_branch_name) {
        group.branchConfig.target = group.target_branch_name;
        group.branches.target = group.target_branch_name;
      }
      if (group.ref1_branch_name) {
        group.branchConfig.reference1 = group.ref1_branch_name;
        group.branches.reference1 = group.ref1_branch_name;
      }
      if (group.ref2_branch_name) {
        group.branchConfig.reference2 = group.ref2_branch_name;
        group.branches.reference2 = group.ref2_branch_name;
      }
      if (group.ref3_branch_name) {
        group.branchConfig.reference3 = group.ref3_branch_name;
        group.branches.reference3 = group.ref3_branch_name;
      }
    }

    return groups;
  }

  // Get models for a specific group
  static async getGroupModels(groupId) {
    const query = `
      SELECT DISTINCT m.*
      FROM \`Models\` m
      JOIN \`Group_Model_Mapping\` gmm 
        ON m.model_id IN (gmm.target_model_id, gmm.ref1_model_id, gmm.ref2_model_id, gmm.ref3_model_id)
      WHERE gmm.group_id = ?
      ORDER BY m.model_name
    `;

    return await executeQuery(query, [groupId]);
  }

  // Get model combinations for a specific group (each row is a combination)
  static async getGroupModelCombinations(groupId) {
    // First, deduplicate any existing duplicates in the database
    await this.deduplicateGroupModels(groupId);

    const query = `
      SELECT DISTINCT
        gmm.gm_id,
        target_m.model_name AS target,
        ref1_m.model_name AS reference,
        ref1_m.model_name AS reference1,
        ref2_m.model_name AS reference2,
        ref3_m.model_name AS reference3,
        target_m.model_name AS target1,
        ref2_m.model_name AS target2
      FROM \`Group_Model_Mapping\` gmm
      LEFT JOIN \`Models\` target_m ON gmm.target_model_id = target_m.model_id
      LEFT JOIN \`Models\` ref1_m ON gmm.ref1_model_id = ref1_m.model_id
      LEFT JOIN \`Models\` ref2_m ON gmm.ref2_model_id = ref2_m.model_id
      LEFT JOIN \`Models\` ref3_m ON gmm.ref3_model_id = ref3_m.model_id
      WHERE gmm.group_id = ?
      ORDER BY gmm.gm_id
    `;

    return await executeQuery(query, [groupId]);
  }

  // Deduplicate model combinations in a group
  static async deduplicateGroupModels(groupId) {
    // Find duplicate entries based on the unique constraint columns
    const findDuplicatesQuery = `
      SELECT 
        target_model_id, 
        ref1_model_id, 
        ref2_model_id, 
        ref3_model_id,
        MIN(gm_id) as keep_id,
        GROUP_CONCAT(gm_id ORDER BY gm_id) as all_ids,
        COUNT(*) as count
      FROM \`Group_Model_Mapping\`
      WHERE group_id = ?
      GROUP BY target_model_id, ref1_model_id, ref2_model_id, ref3_model_id
      HAVING count > 1
    `;

    const duplicates = await executeQuery(findDuplicatesQuery, [groupId]);

    // For each duplicate set, keep the first one and delete the rest
    for (const dup of duplicates) {
      const idsToDelete = dup.all_ids.split(',').filter(id => parseInt(id) !== dup.keep_id);
      if (idsToDelete.length > 0) {
        const deleteQuery = `DELETE FROM \`Group_Model_Mapping\` WHERE gm_id IN (${idsToDelete.join(',')})`;
        await executeQuery(deleteQuery);
        console.log(`🧹 Cleaned up ${idsToDelete.length} duplicate model combination(s) for group ${groupId}`);
      }
    }
  }

  // Add participant to project
  static async addParticipant(projectId, username, addedBy, role = 'reviewer') {
    const query = `
      INSERT INTO \`Project_Participants\` (project_id, user_username, added_by, participant_role)
      VALUES (?, ?, ?, ?)
      ON DUPLICATE KEY UPDATE participant_role = VALUES(participant_role)
    `;

    await executeQuery(query, [projectId, username, addedBy, role]);
  }

  // Remove participant from project
  static async removeParticipant(projectId, username) {
    const query = `
        DELETE FROM \`Project_Participants\`
      WHERE project_id = ? AND user_username = ?
    `;

    await executeQuery(query, [projectId, username]);
  }

  // Update project (supports both regular and official project fields)
  static async update(projectId, updateData) {
    const {
      title,
      description,
      refresh_schedule,
      status,
      // Official project fields
      is_official,
      swplm_project_name,
      project_lead_username,
      project_manager_username,
      target_completion_date
    } = updateData;

    // Build dynamic query based on provided fields
    const fields = [];
    const values = [];

    if (title !== undefined) {
      fields.push('title = ?');
      values.push(title);
    }
    if (description !== undefined) {
      fields.push('description = ?');
      values.push(description);
    }
    if (refresh_schedule !== undefined) {
      fields.push('refresh_schedule = ?');
      values.push(refresh_schedule);
    }
    if (status !== undefined) {
      fields.push('status = ?');
      values.push(status);
    }
    // Official project fields
    if (is_official !== undefined) {
      fields.push('is_official = ?');
      values.push(is_official);
    }
    if (swplm_project_name !== undefined) {
      fields.push('swplm_project_name = ?');
      values.push(swplm_project_name);
    }
    if (project_lead_username !== undefined) {
      fields.push('project_lead_username = ?');
      values.push(project_lead_username);
    }
    if (project_manager_username !== undefined) {
      fields.push('project_manager_username = ?');
      values.push(project_manager_username);
    }
    if (target_completion_date !== undefined) {
      fields.push('target_completion_date = ?');
      values.push(target_completion_date);
    }

    // Always update the updated_at timestamp
    fields.push('updated_at = CURRENT_TIMESTAMP');

    if (fields.length === 1) {
      // Only updated_at is being updated, no other fields
      const query = `UPDATE \`Projects\` SET updated_at = CURRENT_TIMESTAMP WHERE project_id = ?`;
      await executeQuery(query, [projectId]);
    } else {
      const query = `
        UPDATE \`Projects\`
        SET ${fields.join(', ')}
        WHERE project_id = ?
      `;
      values.push(projectId);
      await executeQuery(query, values);
    }

    return this.findById(projectId);
  }

  // Delete project
  static async delete(projectId) {
    const query = `DELETE FROM \`Projects\` WHERE project_id = ?`;
    await executeQuery(query, [projectId]);
  }

  // Check if user has access to project
  static async hasAccess(projectId, username) {
    const query = `
      SELECT 1 FROM \`Projects\` p
      LEFT JOIN \`Project_Participants\` pp ON p.project_id = pp.project_id
      WHERE p.project_id = ? AND (p.admin_username = ? OR pp.user_username = ?)
    `;

    const result = await executeQuery(query, [projectId, username, username]);
    return result.length > 0;
  }

  // Get project statistics
  static async getStats(projectId) {
    try {
      // Get per-status counts for this specific project (join through grps)
      const statusCountQuery = `
        SELECT kr.status, COUNT(*) as count
        FROM \`Key_Reviews\` kr
        JOIN \`grps\` g ON kr.group_id = g.group_id
        WHERE g.project_id = ?
        GROUP BY kr.status
      `;

      const statusRows = await executeQuery(statusCountQuery, [projectId]);

      // Build a status map
      const statusMap = {};
      let totalKeys = 0;
      statusRows.forEach(row => {
        statusMap[row.status] = Number(row.count);
        totalKeys += Number(row.count);
      });

      const statusCounts = {
        unreviewed: statusMap['unreviewed'] || 0,
        changes_made: statusMap['changes_made'] || 0,
        pending_response: statusMap['pending_response'] || 0,
        no_change_req: statusMap['no_change_req'] || 0,
        internal_discussion: statusMap['internal_discussion'] || 0,
        changes_in_progress: statusMap['changes_in_progress'] || 0,
        value_changed: statusMap['value_changed'] || 0,
      };

      const reviewedKeys = totalKeys - statusCounts.unreviewed;

      return {
        keyDifferences: totalKeys,
        reviewedKeys,
        totalKeys,
        statusCounts
      };
    } catch (error) {
      console.error('Error getting project stats:', error);
      return {
        keyDifferences: 0,
        reviewedKeys: 0,
        totalKeys: 0,
        statusCounts: {
          unreviewed: 0, changes_made: 0, pending_response: 0,
          no_change_req: 0, internal_discussion: 0,
          changes_in_progress: 0, value_changed: 0
        }
      };
    }
  }

  // Create a group with the new structure (grps table with branch data)
  static async createGroup(groupData) {
    const { project_id, name, comparison_type, target_branch_id, ref1_branch_id, ref2_branch_id, ref3_branch_id } = groupData;

    const query = `
      INSERT INTO \`grps\` (project_id, name, comparison_type, target_branch_id, ref1_branch_id, ref2_branch_id, ref3_branch_id)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `;

    const result = await executeQuery(query, [
      project_id, name, comparison_type, target_branch_id, ref1_branch_id, ref2_branch_id, ref3_branch_id
    ]);

    return this.getGroupById(result.insertId);
  }

  // Get group by ID
  static async getGroupById(groupId) {
    const query = `
      SELECT g.*,
        target_b.branch_name as target_branch_name,
        ref1_b.branch_name as ref1_branch_name,
        ref2_b.branch_name as ref2_branch_name,
        ref3_b.branch_name as ref3_branch_name
      FROM \`grps\` g
      LEFT JOIN \`Branches\` target_b ON g.target_branch_id = target_b.branch_id
      LEFT JOIN \`Branches\` ref1_b ON g.ref1_branch_id = ref1_b.branch_id
      LEFT JOIN \`Branches\` ref2_b ON g.ref2_branch_id = ref2_b.branch_id
      LEFT JOIN \`Branches\` ref3_b ON g.ref3_branch_id = ref3_b.branch_id
      WHERE g.group_id = ?
    `;

    const groups = await executeQuery(query, [groupId]);
    return groups[0] || null;
  }

  // Add model to group
  static async addModelToGroup(groupId, modelData) {
    // Handle both string model names and model objects
    let targetModelName, ref1ModelName, ref2ModelName, ref3ModelName;

    if (typeof modelData === 'string') {
      // Legacy support for string model names
      targetModelName = modelData;
      ref1ModelName = null;
      ref2ModelName = null;
      ref3ModelName = null;
    } else if (typeof modelData === 'object' && modelData !== null) {
      // Handle model object with different roles
      // Be tolerant to multiple shapes coming from UI (2-way, 3-way, 4-way, 2-way-vs-2-way)
      targetModelName =
        modelData.target ||
        modelData.target1 ||
        modelData.model ||
        modelData.model_name ||
        null;
      // Support 2-way key 'reference' and 3+/4-way 'reference1'
      ref1ModelName =
        modelData.reference ||
        modelData.reference1 ||
        modelData.ref1 ||
        null;

      // Handle 2-way-vs-2-way vs regular 3-way/4-way
      // If target2 exists, it's 2-way-vs-2-way: target2 → ref2, reference2 → ref3
      // Otherwise, it's regular: reference2 → ref2, reference3 → ref3
      if (modelData.target2 && !modelData.reference3) {
        // 2-way-vs-2-way mode
        ref2ModelName = modelData.target2 || null;
        ref3ModelName = modelData.reference2 || null;
      } else {
        // Regular 3-way/4-way mode
        ref2ModelName = modelData.reference2 || modelData.ref2 || null;
        ref3ModelName = modelData.reference3 || modelData.ref3 || null;
      }
    } else {
      throw new Error('Invalid model data format');
    }

    // Get model IDs for each role
    const getModelId = async (modelName) => {
      if (!modelName) return null;
      const modelQuery = 'SELECT model_id FROM Models WHERE model_name = ?';
      const modelResult = await executeQuery(modelQuery, [modelName]);
      return modelResult.length > 0 ? modelResult[0].model_id : null;
    };

    const targetModelId = await getModelId(targetModelName);
    const ref1ModelId = await getModelId(ref1ModelName);
    const ref2ModelId = await getModelId(ref2ModelName);
    const ref3ModelId = await getModelId(ref3ModelName);

    // If no valid target specified or not found, skip inserting this row instead of throwing
    if (!targetModelName) {
      console.warn('addModelToGroup: missing target model name, skipping insert for group', groupId);
      return;
    }

    if (!targetModelId) {
      console.warn(`addModelToGroup: target model not found in DB (${String(targetModelName)}), skipping insert for group ${groupId}`);
      return;
    }

    // Insert the model mapping (ignore duplicates by unique key)
    const insertQuery = `
      INSERT INTO \`Group_Model_Mapping\` (group_id, target_model_id, ref1_model_id, ref2_model_id, ref3_model_id)
      VALUES (?, ?, ?, ?, ?)
      ON DUPLICATE KEY UPDATE group_id = group_id
    `;

    await executeQuery(insertQuery, [groupId, targetModelId, ref1ModelId, ref2ModelId, ref3ModelId]);
  }

  // Insert DataFrame data into Key_Reviews table
  static async insertDataFrameData(projectId, groupId, records) {
    if (!records || records.length === 0) return;

    console.log(`Inserting ${records.length} records for project ${projectId}, group ${groupId}`);

    // Clear existing data for this project and group
    const deleteQuery = 'DELETE FROM `Key_Reviews` WHERE project_id = ? AND group_id = ?';
    await executeQuery(deleteQuery, [projectId, groupId]);

    // Insert new records
    for (const record of records) {
      const insertQuery = `
        INSERT INTO \`Key_Reviews\` (
          project_id, group_id, fms_key_id, key_name, work_assignment, 
          work_assignment_owner, target_model_name, ref1_model_name, 
          ref2_model_name, ref3_model_name, target_model_data, ref1_model_data, 
          ref2_model_data, ref3_model_data, status, comment, kona_ids, cl_numbers
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `;

      const values = [
        projectId,
        groupId,
        record['key name'] || record.key_name || null,
        record['key name'] || record.key_name || null,
        record['work assignment'] || record.work_assignment || null,
        record['work assignment owner'] || record.work_assignment_owner || null,
        record['target model'] || record.target_model || null,
        record['ref1 model'] || record.ref1_model || null,
        record['ref2 model'] || record.ref2_model || null,
        record['ref3 model'] || record.ref3_model || null,
        record['target_model data'] || record.target_model_data || null,
        record['ref1 model data'] || record.ref1_model_data || null,
        record['ref2 model data'] || record.ref2_model_data || null,
        record['ref3 model data'] || record.ref3_model_data || null,
        'unreviewed', // Default status
        record.comment || null,
        record.kona_ids || null,
        record.cl_numbers || null
      ];

      try {
        await executeQuery(insertQuery, values);
      } catch (error) {
        console.error('Error inserting record:', error.message);
        console.error('Record:', record);
      }
    }

    console.log(`Successfully inserted ${records.length} records for project ${projectId}, group ${groupId}`);
  }
}

module.exports = Project;
