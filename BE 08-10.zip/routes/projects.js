// Project Routes - Samsung FMS Portal
const express = require('express');
const Project = require('../models/Project');
const KeyReview = require('../models/KeyReview');
const Group = require('../models/Group');
const { executeQuery } = require('../config/database');
const { authenticateToken } = require('./auth');
const router = express.Router();
const fs = require('fs');
const path = require('path');
const { spawnSync, spawn } = require('child_process');

// Apply authentication middleware to all routes
router.use(authenticateToken);

// Helper function to get branch ID by name
async function getBranchIdByName(branchName) {
  const query = 'SELECT branch_id FROM Branches WHERE branch_name = ?';
  const result = await executeQuery(query, [branchName]);
  return result[0]?.branch_id || null;
}

// GET /api/projects - Get projects for current user
router.get('/', async (req, res) => {
  try {
    console.log('Getting projects for user:', req.user.username);
    const projects = await Project.getByUser(req.user.username);
    console.log('Found projects:', projects.length);

    // Get statistics and participants for each project
    const projectsWithStats = await Promise.all(
      projects.map(async (project) => {
        try {
          const [stats, participants] = await Promise.all([
            Project.getStats(project.project_id),
            Project.getParticipants(project.project_id)
          ]);

          const participantUsernames = participants.map(p => p.user_username);
          console.log(`Project ${project.project_id} participants:`, participantUsernames);

          return {
            ...project,
            ...stats,
            participants: participantUsernames // Just the usernames
          };
        } catch (statsError) {
          console.error('Error getting stats for project', project.project_id, ':', statsError);
          return {
            ...project,
            keyDifferences: 0,
            reviewedKeys: 0,
            participants: []
          };
        }
      })
    );

    res.json({
      success: true,
      projects: projectsWithStats
    });
  } catch (error) {
    console.error('Get projects error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch projects',
      error: error.message
    });
  }
});

// GET /api/projects/:id - Get project details
router.get('/:id', async (req, res) => {
  try {
    const projectId = req.params.id;

    // Check if user has access to this project
    const hasAccess = await Project.hasAccess(projectId, req.user.username);
    if (!hasAccess) {
      return res.status(403).json({
        success: false,
        message: 'Access denied to this project'
      });
    }

    const project = await Project.getFullDetails(projectId);
    if (!project) {
      return res.status(404).json({
        success: false,
        message: 'Project not found'
      });
    }

    // Get current user's role in this project
    const User = require('../models/User');
    const userRole = await User.getProjectParticipant(req.user.username, projectId);

    res.json({
      success: true,
      project: {
        ...project,
        currentUserRole: userRole?.participant_role || null,
        isProjectAdmin: project.admin_username === req.user.username
      }
    });
  } catch (error) {
    console.error('Get project details error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch project details'
    });
  }
});

// POST /api/projects - Create new project
router.post('/', async (req, res) => {
  try {
    const { title, description, refreshSchedule, groups } = req.body;

    // Only admins can create projects
    if (req.user.user_type !== 'admin') {
      return res.status(403).json({
        success: false,
        message: 'Only admins can create projects'
      });
    }

    // Validate input
    if (!title) {
      return res.status(400).json({
        success: false,
        message: 'Project title is required'
      });
    }

    const projectData = {
      title: title.substring(0, 100), // Enforce character limit
      description: description ? description.substring(0, 500) : '',
      admin_username: req.user.username,
      refresh_schedule: refreshSchedule || 'Weekly'
    };

    const project = await Project.create(projectData);

    // Add creator as admin participant
    await Project.addParticipant(project.project_id, req.user.username, req.user.username, 'admin');

    // Create groups with the new structure (grps table with branch data)
    if (groups && Array.isArray(groups) && groups.length > 0) {
      for (const groupData of groups) {
        const { name, comparisonType, branches, models } = groupData;

        // Get branch IDs - handle both reference1 and reference for 2-way comparisons
        const targetBranchId = branches?.target ? await getBranchIdByName(branches.target) : null;
        const ref1BranchId = branches?.reference1 || branches?.reference ? await getBranchIdByName(branches.reference1 || branches.reference) : null;
        const ref2BranchId = branches?.reference2 ? await getBranchIdByName(branches.reference2) : null;
        const ref3BranchId = branches?.reference3 ? await getBranchIdByName(branches.reference3) : null;

        // Create the group with branch data directly in grps table
        const group = await Project.createGroup({
          project_id: project.project_id,
          name,
          comparison_type: comparisonType,
          target_branch_id: targetBranchId,
          ref1_branch_id: ref1BranchId,
          ref2_branch_id: ref2BranchId,
          ref3_branch_id: ref3BranchId
        });

        // Add models to the group if provided
        if (models && Array.isArray(models) && models.length > 0) {
          for (const modelData of models) {
            await Project.addModelToGroup(group.group_id, modelData);
          }
        }
      }
    }

    // Get the complete project with all details
    const completeProject = await Project.getFullDetails(project.project_id);

    // Build branch_models_dict for P4 script
    let branchModelsDict = null;
    try {
      const branchList2D = [];
      const modelList3D = [];

      for (const group of completeProject.groups) {
        const comparisonType = group.comparison_type || group.comparisonType;
        const branches = [];

        // Always add target branch
        if (group.target_branch_name || group.branches?.target) {
          branches.push(group.target_branch_name || group.branches?.target);
        }

        // Add reference branches based on comparison type
        if (comparisonType === '2-way' || comparisonType === '3-way' || comparisonType === '4-way' || comparisonType === '2-way-vs-2-way') {
          // For 2-way, check both reference1 and reference fields
          const ref1Branch = group.ref1_branch_name || group.branches?.reference1 || group.branches?.reference;
          if (ref1Branch) {
            branches.push(ref1Branch);
          }
        }

        if (comparisonType === '3-way' || comparisonType === '4-way') {
          if (group.ref2_branch_name || group.branches?.reference2) {
            branches.push(group.ref2_branch_name || group.branches?.reference2);
          }
        }

        if (comparisonType === '4-way') {
          if (group.ref3_branch_name || group.branches?.reference3) {
            branches.push(group.ref3_branch_name || group.branches?.reference3);
          }
        }

        branchList2D.push(branches);

        // Fetch model combinations for the group
        const modelCombinations = await Project.getGroupModelCombinations(group.group_id);
        const modelRows = modelCombinations.map((row) => {
          const models = [];
          if (row.target) models.push(row.target);
          if (branches.length >= 2) models.push(row.reference || row.reference1 || row.target);
          if (branches.length >= 3) models.push(row.reference2 || row.target);
          if (branches.length >= 4) models.push(row.reference3 || row.target);
          return models;
        });
        modelList3D.push(modelRows);
      }

      branchModelsDict = { branch: branchList2D, model: modelList3D };
      console.log('branch_models_dict for project', project.project_id, JSON.stringify(branchModelsDict));

      // Set project status to syncing before starting async job
      try {
        await Project.update(project.project_id, {
          title: completeProject.title,
          description: completeProject.description,
          refresh_schedule: completeProject.refresh_schedule,
          status: 'syncing'
        });
        console.log(`Project ${project.project_id} status set to syncing`);
      } catch (_) { }

      // Fire-and-forget: spawn Python process to call get_dif_from_p4 and flip status back to active on exit
      try {
        const pythonPath = 'python';
        const scriptPath = path.join(__dirname, '..', '..', 'sample key review data', 'new_p4_diff_code.py');
        const jsonArg = JSON.stringify(branchModelsDict);

        // We will call the Python script with a small shim to read the JSON and call the function
        const shimCode = `import sys,json;\nfrom pathlib import Path;\nfp = ${JSON.stringify(scriptPath) !== undefined ? `r'''${scriptPath.replace(/\\/g, '\\\\')}'''` : `''`};\nimport importlib.util;\nspec = importlib.util.spec_from_file_location('p4mod', fp);\nmod = importlib.util.module_from_spec(spec);\nspec.loader.exec_module(mod);\narg=json.loads(sys.argv[1]);\nprint('P4 shim start');\nres = mod.get_dif_from_p4(arg, mod.model_data, mod.branch_data);\nprint('P4 shim done', len(res) if res else 0);\nprint('DF_COUNT:', len(res) if res else 0);\nimport pandas as pd;\nprint('DF_DATA_START');\nfor i, df in enumerate(res or []):\n    # Transform column names to match expected format safely (4-way -> 3-way -> 2-way)\n    df_processed = df.copy()\n    ncols = len(df_processed.columns)\n    try:\n        if ncols >= 5:\n            df_processed = df_processed.iloc[:, :5]\n            df_processed.columns = ['key name', 'target_model data', 'ref1 model data', 'ref2 model data', 'ref3 model data']\n        elif ncols == 4:\n            df_processed = df_processed.iloc[:, :4]\n            df_processed.columns = ['key name', 'target_model data', 'ref1 model data', 'ref2 model data']\n        elif ncols == 3:\n            df_processed = df_processed.iloc[:, :3]\n            df_processed.columns = ['key name', 'target_model data', 'ref1 model data']\n        else:\n            print('Skipping DF index', i, 'unsupported column count', ncols)\n            continue\n    except Exception as e:\n        print('Column rename error for DF', i, 'with ncols', ncols, ':', e)\n        continue\n    print('DF_START', i);\n    print(df_processed.to_json(orient='records'));\n    print('DF_END', i);\nprint('DF_DATA_END')`;

        const child = spawn(pythonPath, ['-c', shimCode, jsonArg], {
          stdio: ['ignore', 'pipe', 'pipe'],
          detached: false
        });

        let output = '';
        let errorOutput = '';

        child.stdout.on('data', (data) => {
          output += data.toString();
        });

        child.stderr.on('data', (data) => {
          errorOutput += data.toString();
        });

        // Set 10 minute timeout
        const timeout = setTimeout(async () => {
          child.kill('SIGTERM');
          try {
            await Project.update(project.project_id, {
              title: completeProject.title,
              description: completeProject.description,
              refresh_schedule: completeProject.refresh_schedule,
              status: 'sync error'
            });
            console.log(`Project ${project.project_id} sync timed out after 10 minutes. Status set to 'sync error'.`);
          } catch (statusErr) {
            console.error('Failed to set project status to error syncing:', statusErr.message);
          }
        }, 10 * 60 * 1000); // 10 minutes

        child.on('exit', async (code) => {
          clearTimeout(timeout);

          // Extract DataFrame count from output
          const dfCountMatch = output.match(/DF_COUNT:\s*(\d+)/);
          const dfCount = dfCountMatch ? parseInt(dfCountMatch[1]) : 0;

          console.log(`Project ${project.project_id} Python output:`, output.trim());
          if (errorOutput) {
            console.error(`Project ${project.project_id} Python error:`, errorOutput.trim());
          }
          console.log(`Project ${project.project_id} returned ${dfCount} DataFrames`);

          // Parse DataFrame data if available
          if (code === 0 && dfCount > 0) {
            try {
              console.log('\n=== PARSING DATAFRAME DATA ===');
              const dataFrames = [];
              const dfDataStart = output.indexOf('DF_DATA_START');
              const dfDataEnd = output.indexOf('DF_DATA_END');

              console.log(`DF_DATA_START position: ${dfDataStart}`);
              console.log(`DF_DATA_END position: ${dfDataEnd}`);

              if (dfDataStart !== -1 && dfDataEnd !== -1) {
                const dfDataSection = output.substring(dfDataStart, dfDataEnd);
                console.log(`DataFrame section length: ${dfDataSection.length}`);
                console.log(`DataFrame section preview: ${dfDataSection.substring(0, 500)}...`);
                console.log(`Full DataFrame section:`, dfDataSection);

                // Try different regex patterns
                const dfMatches1 = dfDataSection.match(/DF_START (\d+)\n(.*?)\nDF_END \1/gs);
                const dfMatches2 = dfDataSection.match(/DF_START (\d+)\n(.*?)\nDF_END \1/g);
                const dfMatches3 = dfDataSection.match(/DF_START (\d+)\n(.*?)\nDF_END \1/s);

                console.log(`Regex 1 (with 's' flag): ${dfMatches1 ? dfMatches1.length : 0} matches`);
                console.log(`Regex 2 (without 's' flag): ${dfMatches2 ? dfMatches2.length : 0} matches`);
                console.log(`Regex 3 (with 's' flag, no 'g'): ${dfMatches3 ? dfMatches3.length : 0} matches`);

                const dfMatches = dfMatches1 || dfMatches2 || dfMatches3;
                console.log(`Using matches: ${dfMatches ? dfMatches.length : 0} DataFrame matches`);

                if (dfMatches) {
                  for (const match of dfMatches) {
                    const lines = match.split('\n');
                    const dfIndex = parseInt(lines[0].split(' ')[1]);
                    const jsonData = lines.slice(1, -1).join('\n');

                    console.log(`\n--- Parsing DataFrame ${dfIndex} ---`);
                    console.log(`JSON data length: ${jsonData.length}`);
                    console.log(`JSON data preview: ${jsonData.substring(0, 200)}...`);

                    try {
                      const dfData = JSON.parse(jsonData);
                      dataFrames[dfIndex] = dfData;
                      console.log(`✓ Successfully parsed DataFrame ${dfIndex} with ${dfData.length} rows`);
                      console.log(`Sample row:`, dfData[0]);
                    } catch (parseErr) {
                      console.error(`✗ Error parsing DataFrame ${dfIndex}:`, parseErr.message);
                      console.error(`JSON data that failed:`, jsonData.substring(0, 500));
                    }
                  }
                } else {
                  console.error('No DataFrame matches found in output');

                  // Fallback: try to parse manually by splitting on DF_START/DF_END
                  console.log('Trying fallback parsing method...');
                  const parts = dfDataSection.split('DF_START');
                  console.log(`Found ${parts.length - 1} DF_START markers`);

                  for (let i = 1; i < parts.length; i++) {
                    const part = parts[i];
                    const endIndex = part.indexOf('DF_END');
                    if (endIndex !== -1) {
                      const dfIndex = parseInt(part.split('\n')[0].trim());
                      const jsonData = part.substring(part.indexOf('\n') + 1, endIndex).trim();

                      console.log(`\n--- Fallback parsing DataFrame ${dfIndex} ---`);
                      console.log(`JSON data length: ${jsonData.length}`);
                      console.log(`JSON data preview: ${jsonData.substring(0, 200)}...`);

                      try {
                        const dfData = JSON.parse(jsonData);
                        dataFrames[dfIndex] = dfData;
                        console.log(`✓ Successfully parsed DataFrame ${dfIndex} with ${dfData.length} rows`);
                        console.log(`Sample row:`, dfData[0]);
                      } catch (parseErr) {
                        console.error(`✗ Error parsing DataFrame ${dfIndex}:`, parseErr.message);
                        console.error(`JSON data that failed:`, jsonData.substring(0, 500));
                      }
                    }
                  }
                }

                // Insert DataFrame data into database
                if (dataFrames.length > 0) {
                  console.log(`\n=== STARTING DATABASE INSERTION ===`);
                  console.log(`DataFrames to insert: ${dataFrames.length}`);
                  const KeyReview = require('../models/KeyReview');
                  const insertResult = await KeyReview.insertDataFrameData(project.project_id, dataFrames, branchModelsDict);

                  if (insertResult.success) {
                    console.log(`✓ Successfully inserted ${insertResult.inserted} key review records`);
                  } else {
                    console.error('✗ Failed to insert DataFrame data:', insertResult.error);
                    try {
                      await Project.update(project.project_id, {
                        title: completeProject.title,
                        description: completeProject.description,
                        refresh_schedule: completeProject.refresh_schedule,
                        status: 'sync error'
                      });
                    } catch (statusErr) {
                      console.error('Failed to set project status to sync error after insert failure:', statusErr.message);
                    }
                  }
                } else {
                  console.error('No DataFrames to insert');
                }
              } else {
                console.error('DF_DATA_START or DF_DATA_END markers not found in output');
                console.log('Full output:', output);
                try {
                  await Project.update(project.project_id, {
                    title: completeProject.title,
                    description: completeProject.description,
                    refresh_schedule: completeProject.refresh_schedule,
                    status: 'sync error'
                  });
                } catch (statusErr) {
                  console.error('Failed to set project status to sync error after parsing failure:', statusErr.message);
                }
              }
            } catch (dataErr) {
              console.error('Error processing DataFrame data:', dataErr.message);
              console.error('Stack trace:', dataErr.stack);
              try {
                await Project.update(project.project_id, {
                  title: completeProject.title,
                  description: completeProject.description,
                  refresh_schedule: completeProject.refresh_schedule,
                  status: 'sync error'
                });
              } catch (statusErr) {
                console.error('Failed to set project status to sync error after exception:', statusErr.message);
              }
            }
          } else {
            console.log(`Skipping DataFrame processing - code: ${code}, dfCount: ${dfCount}`);
          }

          try {
            // If code is 0 and we didn't hit earlier errors, set active; otherwise sync error
            const newStatus = code === 0 ? 'active' : 'sync error';
            await Project.update(project.project_id, {
              title: completeProject.title,
              description: completeProject.description,
              refresh_schedule: completeProject.refresh_schedule,
              status: newStatus
            });
            console.log(`Project ${project.project_id} sync finished with code ${code}. Status set to ${newStatus}.`);
          } catch (statusErr) {
            console.error('Failed to set project status:', statusErr.message);
          }
        });
      } catch (pyErr) {
        console.error('Failed to spawn P4 Python process:', pyErr.message);
      }
    } catch (buildErr) {
      console.error('Failed to build/send branch_models_dict:', buildErr.message);
    }

    res.status(201).json({
      success: true,
      message: 'Project created successfully',
      data: completeProject,
      branchModelsDict
    });
  } catch (error) {
    console.error('Create project error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to create project'
    });
  }
});


// PUT /api/projects/:id - Update project
router.put('/:id', async (req, res) => {
  try {
    const projectId = req.params.id;
    const { title, description, refreshSchedule, groups } = req.body;

    // Check if user is admin of this project
    const project = await Project.findById(projectId);
    if (!project || project.admin_username !== req.user.username) {
      return res.status(403).json({
        success: false,
        message: 'Only project admin can update project'
      });
    }

    // Update basic project information
    const updateData = {
      title: title ? title.substring(0, 100) : project.title,
      description: description !== undefined ? description.substring(0, 500) : project.description,
      refresh_schedule: refreshSchedule || project.refresh_schedule || 'Weekly' // Default to 'Weekly' if both are undefined
    };

    console.log('Update data being passed to Project.update:', updateData);
    console.log('Project ID:', projectId);

    const updatedProject = await Project.update(projectId, updateData);

    // Update groups and their configurations if provided
    if (groups && Array.isArray(groups)) {
      // Delete existing groups and their mappings
      await executeQuery('DELETE FROM `Group_Model_Mapping` WHERE group_id IN (SELECT group_id FROM `grps` WHERE project_id = ?)', [projectId]);
      await executeQuery('DELETE FROM `grps` WHERE project_id = ?', [projectId]);

      // Create new groups
      for (const groupData of groups) {
        const { name, comparisonType, branches, models } = groupData;

        // Ensure required fields are not undefined
        if (!name || !comparisonType) {
          console.error('Group data missing required fields:', { name, comparisonType });
          throw new Error('Group name and comparison type are required');
        }

        // Get branch IDs from branch names
        const branchIds = {};
        if (branches && typeof branches === 'object') {
          for (const [role, branchName] of Object.entries(branches)) {
            const branchQuery = `SELECT branch_id FROM \`Branches\` WHERE branch_name = ?`;
            const branchResults = await executeQuery(branchQuery, [branchName]);
            if (branchResults.length > 0) {
              branchIds[role] = branchResults[0].branch_id;
            }
          }
        }

        // Create the group with branch IDs
        const groupQuery = `
          INSERT INTO \`grps\` (project_id, name, comparison_type, target_branch_id, ref1_branch_id, ref2_branch_id, ref3_branch_id)
          VALUES (?, ?, ?, ?, ?, ?, ?)
        `;

        const groupResult = await executeQuery(groupQuery, [
          projectId,
          name,
          comparisonType,
          branchIds.target || null,
          branchIds.ref1 || branchIds.reference || null,
          branchIds.ref2 || null,
          branchIds.ref3 || null
        ]);

        const groupId = groupResult.insertId;

        // Add models to the group if provided
        if (models && Array.isArray(models) && models.length > 0) {
          for (const modelData of models) {
            // Get model IDs
            const modelIds = {};
            for (const [role, modelName] of Object.entries(modelData)) {
              if (modelName) {
                const modelQuery = `SELECT model_id FROM \`Models\` WHERE model_name = ?`;
                const modelResults = await executeQuery(modelQuery, [modelName]);
                if (modelResults.length > 0) {
                  modelIds[role] = modelResults[0].model_id;
                }
              }
            }

            // Create model mapping
            const modelMappingQuery = `
              INSERT INTO \`Group_Model_Mapping\` (group_id, target_model_id, ref1_model_id, ref2_model_id, ref3_model_id)
              VALUES (?, ?, ?, ?, ?)
            `;

            await executeQuery(modelMappingQuery, [
              groupId,
              modelIds.target || null,
              modelIds.ref1 || modelIds.reference || null,
              modelIds.ref2 || null,
              modelIds.ref3 || null
            ]);
          }
        }
      }
    }

    // Get the complete updated project with all details
    const completeProject = await Project.getFullDetails(projectId);

    // Start syncing process if groups were updated
    if (groups && Array.isArray(groups)) {
      console.log(`Starting sync process for updated project ${projectId}`);

      // Set project status to syncing
      await Project.update(projectId, {
        title: completeProject.title,
        description: completeProject.description,
        refresh_schedule: completeProject.refresh_schedule,
        status: 'syncing'
      });

      // Build branch_models_dict for P4 script
      let branchModelsDict = null;
      try {
        const branchList2D = [];
        const modelList3D = [];

        for (const group of completeProject.groups) {
          const comparisonType = group.comparison_type || group.comparisonType;
          const branches = [];

          // Always add target branch
          if (group.target_branch_name || group.branches?.target) {
            branches.push(group.target_branch_name || group.branches?.target);
          }

          // Add reference branches based on comparison type
          if (comparisonType === '2-way' || comparisonType === '3-way' || comparisonType === '4-way' || comparisonType === '2-way-vs-2-way') {
            // For 2-way, check both reference1 and reference fields
            const ref1Branch = group.ref1_branch_name || group.branches?.reference1 || group.branches?.reference;
            if (ref1Branch) {
              branches.push(ref1Branch);
            }
          }

          if (comparisonType === '3-way' || comparisonType === '4-way') {
            if (group.ref2_branch_name || group.branches?.reference2) {
              branches.push(group.ref2_branch_name || group.branches?.reference2);
            }
          }

          if (comparisonType === '4-way') {
            if (group.ref3_branch_name || group.branches?.reference3) {
              branches.push(group.ref3_branch_name || group.branches?.reference3);
            }
          }

          branchList2D.push(branches);

          // Fetch model combinations for the group
          const modelCombinations = await Project.getGroupModelCombinations(group.group_id);
          const modelRows = modelCombinations.map((row) => {
            const models = [];
            if (row.target) models.push(row.target);
            if (branches.length >= 2) models.push(row.reference || row.reference1 || row.target);
            if (branches.length >= 3) models.push(row.reference2 || row.target);
            if (branches.length >= 4) models.push(row.reference3 || row.target);
            return models;
          });
          modelList3D.push(modelRows);
        }

        branchModelsDict = { branch: branchList2D, model: modelList3D };
        console.log('Branch models dict for update:', JSON.stringify(branchModelsDict, null, 2));

        // Execute Python script
        try {
          const pythonPath = 'python';
          const scriptPath = path.join(__dirname, '..', '..', 'sample key review data', 'new_p4_diff_code.py');
          const jsonArg = JSON.stringify(branchModelsDict);

          // Python shim code (same as in project creation)
          const shimCode = `import sys,json;\nfrom pathlib import Path;\nfp = ${JSON.stringify(scriptPath) !== undefined ? `r'''${scriptPath.replace(/\\/g, '\\\\')}'''` : `''`};\nimport importlib.util;\nspec = importlib.util.spec_from_file_location('p4mod', fp);\nmod = importlib.util.module_from_spec(spec);\nspec.loader.exec_module(mod);\narg=json.loads(sys.argv[1]);\nprint('P4 shim start');\nres = mod.get_dif_from_p4(arg, mod.model_data, mod.branch_data);\nprint('P4 shim done', len(res) if res else 0);\nprint('DF_COUNT:', len(res) if res else 0);\nimport pandas as pd;\nprint('DF_DATA_START');\nfor i, df in enumerate(res or []):\n    # Transform column names to match expected format safely (4-way -> 3-way -> 2-way)\n    df_processed = df.copy()\n    ncols = len(df_processed.columns)\n    try:\n        if ncols >= 5:\n            df_processed = df_processed.iloc[:, :5]\n            df_processed.columns = ['key name', 'target_model data', 'ref1 model data', 'ref2 model data', 'ref3 model data']\n        elif ncols == 4:\n            df_processed = df_processed.iloc[:, :4]\n            df_processed.columns = ['key name', 'target_model data', 'ref1 model data', 'ref2 model data']\n        elif ncols == 3:\n            df_processed = df_processed.iloc[:, :3]\n            df_processed.columns = ['key name', 'target_model data', 'ref1 model data']\n        else:\n            print('Skipping DF index', i, 'unsupported column count', ncols)\n            continue\n    except Exception as e:\n        print('Column rename error for DF', i, 'with ncols', ncols, ':', e)\n        continue\n    print('DF_START', i);\n    print(df_processed.to_json(orient='records'));\n    print('DF_END', i);\nprint('DF_DATA_END')`;

          const child = spawn(pythonPath, ['-c', shimCode, jsonArg], {
            stdio: ['ignore', 'pipe', 'pipe'],
            detached: false
          });

          let output = '';
          let errorOutput = '';

          child.stdout.on('data', (data) => {
            output += data.toString();
          });

          child.stderr.on('data', (data) => {
            errorOutput += data.toString();
          });

          // Set 10 minute timeout
          const timeout = setTimeout(async () => {
            child.kill('SIGTERM');
            try {
              await Project.update(projectId, {
                title: completeProject.title,
                description: completeProject.description,
                refresh_schedule: completeProject.refresh_schedule,
                status: 'sync error'
              });
              console.log(`Project ${projectId} sync timed out after 10 minutes. Status set to 'sync error'.`);
            } catch (statusErr) {
              console.error('Failed to set project status to error syncing:', statusErr.message);
            }
          }, 10 * 60 * 1000); // 10 minutes

          child.on('exit', async (code) => {
            clearTimeout(timeout);

            // Extract DataFrame count from output
            const dfCountMatch = output.match(/DF_COUNT:\s*(\d+)/);
            const dfCount = dfCountMatch ? parseInt(dfCountMatch[1]) : 0;

            console.log(`Project ${projectId} Python output:`, output.trim());
            if (errorOutput) {
              console.error(`Project ${projectId} Python error:`, errorOutput.trim());
            }
            console.log(`Project ${projectId} returned ${dfCount} DataFrames`);

            // Parse DataFrame data if available
            if (code === 0 && dfCount > 0) {
              try {
                console.log('\n=== PARSING DATAFRAME DATA ===');
                const dataFrames = [];
                const dfDataStart = output.indexOf('DF_DATA_START');
                const dfDataEnd = output.indexOf('DF_DATA_END');

                console.log(`DF_DATA_START position: ${dfDataStart}`);
                console.log(`DF_DATA_END position: ${dfDataEnd}`);

                if (dfDataStart !== -1 && dfDataEnd !== -1) {
                  const dfDataSection = output.substring(dfDataStart, dfDataEnd);
                  console.log(`DataFrame section length: ${dfDataSection.length}`);

                  // Try different regex patterns
                  const dfMatches1 = dfDataSection.match(/DF_START (\d+)\n(.*?)\nDF_END \1/gs);
                  const dfMatches2 = dfDataSection.match(/DF_START (\d+)\n(.*?)\nDF_END \1/g);
                  const dfMatches3 = dfDataSection.match(/DF_START (\d+)\n(.*?)\nDF_END \1/s);

                  const dfMatches = dfMatches1 || dfMatches2 || dfMatches3;
                  console.log(`Using matches: ${dfMatches ? dfMatches.length : 0} DataFrame matches`);

                  if (dfMatches) {
                    for (const match of dfMatches) {
                      const lines = match.split('\n');
                      const dfIndex = parseInt(lines[0].split(' ')[1]);
                      const jsonData = lines.slice(1, -1).join('\n');

                      console.log(`\n--- Parsing DataFrame ${dfIndex} ---`);
                      try {
                        const dfData = JSON.parse(jsonData);
                        dataFrames[dfIndex] = dfData;
                        console.log(`✓ Successfully parsed DataFrame ${dfIndex} with ${dfData.length} rows`);
                      } catch (parseErr) {
                        console.error(`✗ Error parsing DataFrame ${dfIndex}:`, parseErr.message);
                      }
                    }
                  } else {
                    console.error('No DataFrame matches found in output');
                  }

                  // Insert DataFrame data into database
                  if (dataFrames.length > 0) {
                    console.log(`\n=== STARTING DATABASE INSERTION ===`);
                    console.log(`DataFrames to insert: ${dataFrames.length}`);
                    const KeyReview = require('../models/KeyReview');
                    const insertResult = await KeyReview.insertDataFrameData(projectId, dataFrames, branchModelsDict);

                    if (insertResult.success) {
                      console.log(`✓ Successfully inserted ${insertResult.inserted} key review records`);
                    } else {
                      console.error('✗ Failed to insert DataFrame data:', insertResult.error);
                      try {
                        await Project.update(projectId, {
                          title: completeProject.title,
                          description: completeProject.description,
                          refresh_schedule: completeProject.refresh_schedule,
                          status: 'sync error'
                        });
                      } catch (statusErr) {
                        console.error('Failed to set project status to sync error after insert failure:', statusErr.message);
                      }
                    }
                  } else {
                    console.error('No DataFrames to insert');
                  }
                } else {
                  console.error('DF_DATA_START or DF_DATA_END markers not found in output');
                  try {
                    await Project.update(projectId, {
                      title: completeProject.title,
                      description: completeProject.description,
                      refresh_schedule: completeProject.refresh_schedule,
                      status: 'sync error'
                    });
                  } catch (statusErr) {
                    console.error('Failed to set project status to sync error after parsing failure:', statusErr.message);
                  }
                }
              } catch (dataErr) {
                console.error('Error processing DataFrame data:', dataErr.message);
                try {
                  await Project.update(projectId, {
                    title: completeProject.title,
                    description: completeProject.description,
                    refresh_schedule: completeProject.refresh_schedule,
                    status: 'sync error'
                  });
                } catch (statusErr) {
                  console.error('Failed to set project status to sync error after exception:', statusErr.message);
                }
              }
            } else {
              console.log(`Skipping DataFrame processing - code: ${code}, dfCount: ${dfCount}`);
            }

            try {
              // If code is 0 and we didn't hit earlier errors, set active; otherwise sync error
              const newStatus = code === 0 ? 'active' : 'sync error';
              await Project.update(projectId, {
                title: completeProject.title,
                description: completeProject.description,
                refresh_schedule: completeProject.refresh_schedule,
                status: newStatus
              });
              console.log(`Project ${projectId} sync finished with code ${code}. Status set to ${newStatus}.`);
            } catch (statusErr) {
              console.error('Failed to set project status:', statusErr.message);
            }
          });
        } catch (pyErr) {
          console.error('Failed to spawn P4 Python process:', pyErr.message);
          try {
            await Project.update(projectId, {
              title: completeProject.title,
              description: completeProject.description,
              refresh_schedule: completeProject.refresh_schedule,
              status: 'sync error'
            });
          } catch (statusErr) {
            console.error('Failed to set project status to sync error after Python spawn failure:', statusErr.message);
          }
        }
      } catch (buildErr) {
        console.error('Failed to build/send branch_models_dict:', buildErr.message);
        try {
          await Project.update(projectId, {
            title: completeProject.title,
            description: completeProject.description,
            refresh_schedule: completeProject.refresh_schedule,
            status: 'sync error'
          });
        } catch (statusErr) {
          console.error('Failed to set project status to sync error after build failure:', statusErr.message);
        }
      }
    }

    res.json({
      success: true,
      message: 'Project updated successfully',
      data: completeProject
    });
  } catch (error) {
    console.error('Update project error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to update project'
    });
  }
});

// DELETE /api/projects/:id - Delete project
router.delete('/:id', async (req, res) => {
  try {
    const projectId = req.params.id;

    // Check if user is admin of this project
    const project = await Project.findById(projectId);
    if (!project || project.admin_username !== req.user.username) {
      return res.status(403).json({
        success: false,
        message: 'Only project admin can delete project'
      });
    }

    await Project.delete(projectId);

    res.json({
      success: true,
      message: 'Project deleted successfully'
    });
  } catch (error) {
    console.error('Delete project error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to delete project'
    });
  }
});

// POST /api/projects/:id/participants - Add participant to project
router.post('/:id/participants', async (req, res) => {
  try {
    const projectId = req.params.id;
    const { username, role } = req.body;

    // Check if user is admin of this project
    const project = await Project.findById(projectId);
    if (!project || project.admin_username !== req.user.username) {
      return res.status(403).json({
        success: false,
        message: 'Only project admin can add participants'
      });
    }

    await Project.addParticipant(projectId, username, req.user.username, role || 'reviewer');

    res.json({
      success: true,
      message: 'Participant added successfully'
    });
  } catch (error) {
    console.error('Add participant error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to add participant'
    });
  }
});

// DELETE /api/projects/:id/participants/:username - Remove participant
router.delete('/:id/participants/:username', async (req, res) => {
  try {
    const projectId = req.params.id;
    const username = req.params.username;

    // Check if user is admin of this project
    const project = await Project.findById(projectId);
    if (!project || project.admin_username !== req.user.username) {
      return res.status(403).json({
        success: false,
        message: 'Only project admin can remove participants'
      });
    }

    await Project.removeParticipant(projectId, username);

    res.json({
      success: true,
      message: 'Participant removed successfully'
    });
  } catch (error) {
    console.error('Remove participant error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to remove participant'
    });
  }
});

// GET /api/projects/:id/groups - Get project groups
router.get('/:id/groups', async (req, res) => {
  try {
    const projectId = req.params.id;

    // Check access
    const hasAccess = await Project.hasAccess(projectId, req.user.username);
    if (!hasAccess) {
      return res.status(403).json({
        success: false,
        message: 'Access denied to this project'
      });
    }

    const groups = await Group.getByProject(projectId);

    res.json({
      success: true,
      groups
    });
  } catch (error) {
    console.error('Get project groups error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch project groups'
    });
  }
});

// POST /api/projects/:id/groups - Create group in project
router.post('/:id/groups', async (req, res) => {
  try {
    const projectId = req.params.id;
    const { name, comparison_type, branchConfig } = req.body;

    // Check if user is admin of this project
    const project = await Project.findById(projectId);
    if (!project || project.admin_username !== req.user.username) {
      return res.status(403).json({
        success: false,
        message: 'Only project admin can create groups'
      });
    }

    // Validate input
    if (!name || !comparison_type) {
      return res.status(400).json({
        success: false,
        message: 'Group name and comparison type are required'
      });
    }

    const groupData = {
      project_id: projectId,
      name,
      comparison_type
    };

    const group = await Group.create(groupData);

    // Set branch configuration if provided
    if (branchConfig) {
      await Group.setBranchConfig(group.group_id, branchConfig);
    }

    res.status(201).json({
      success: true,
      message: 'Group created successfully',
      group
    });
  } catch (error) {
    console.error('Create group error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to create group'
    });
  }
});

// GET /api/projects/:id/reviews - Get key reviews for project
router.get('/:id/reviews', async (req, res) => {
  try {
    const projectId = req.params.id;

    // Check access
    const hasAccess = await Project.hasAccess(projectId, req.user.username);
    if (!hasAccess) {
      return res.status(403).json({
        success: false,
        message: 'Access denied to this project'
      });
    }

    const reviews = await KeyReview.getHierarchicalData(projectId);

    res.json({
      success: true,
      reviews
    });
  } catch (error) {
    console.error('Get project reviews error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch project reviews'
    });
  }
});

// GET /api/projects/:id/stats - Get project statistics
router.get('/:id/stats', async (req, res) => {
  try {
    const projectId = req.params.id;

    // Check access
    const hasAccess = await Project.hasAccess(projectId, req.user.username);
    if (!hasAccess) {
      return res.status(403).json({
        success: false,
        message: 'Access denied to this project'
      });
    }

    const stats = await KeyReview.getProjectStats(projectId);

    res.json({
      success: true,
      stats
    });
  } catch (error) {
    console.error('Get project stats error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch project statistics'
    });
  }
});

module.exports = router;