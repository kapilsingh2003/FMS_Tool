const express = require('express');
const router = express.Router();
const Comment = require('../models/Comment');
const { authenticateToken } = require('./auth');

// Apply authentication middleware to all routes
router.use(authenticateToken);

// GET /api/comments/:keyReviewId - Get all comments for a key review
router.get('/:keyReviewId', async (req, res) => {
    try {
        const { keyReviewId } = req.params;

        const comments = await Comment.getByKeyReview(keyReviewId);

        res.json({
            success: true,
            comments: comments
        });
    } catch (error) {
        console.error('Get comments error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to fetch comments',
            error: error.message
        });
    }
});

// POST /api/comments - Create a new comment
router.post('/', async (req, res) => {
    try {
        const { key_review_id, comment_text } = req.body;
        const commented_by_username = req.user.username;

        // Validate input
        if (!key_review_id || !comment_text || !comment_text.trim()) {
            return res.status(400).json({
                success: false,
                message: 'Key review ID and comment text are required'
            });
        }

        const commentData = {
            key_review_id,
            comment_text: comment_text.trim(),
            commented_by_username
        };

        const newComment = await Comment.create(commentData);

        // Get the full comment with user details
        const fullComment = await Comment.getById(newComment.comment_id);

        res.status(201).json({
            success: true,
            message: 'Comment created successfully',
            comment: fullComment
        });
    } catch (error) {
        console.error('Create comment error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to create comment',
            error: error.message
        });
    }
});

// PUT /api/comments/:commentId - Update a comment
router.put('/:commentId', async (req, res) => {
    try {
        const { commentId } = req.params;
        const { comment_text } = req.body;
        const username = req.user.username;

        // Validate input
        if (!comment_text || !comment_text.trim()) {
            return res.status(400).json({
                success: false,
                message: 'Comment text is required'
            });
        }

        // Check if user can modify this comment
        const canModify = await Comment.canUserModify(commentId, username);
        if (!canModify) {
            return res.status(403).json({
                success: false,
                message: 'You can only edit your own comments'
            });
        }

        const updateData = {
            comment_text: comment_text.trim()
        };

        const updated = await Comment.update(commentId, updateData);

        if (!updated) {
            return res.status(404).json({
                success: false,
                message: 'Comment not found'
            });
        }

        // Get the updated comment
        const updatedComment = await Comment.getById(commentId);

        res.json({
            success: true,
            message: 'Comment updated successfully',
            comment: updatedComment
        });
    } catch (error) {
        console.error('Update comment error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to update comment',
            error: error.message
        });
    }
});

// DELETE /api/comments/:commentId - Delete a comment
router.delete('/:commentId', async (req, res) => {
    try {
        const { commentId } = req.params;
        const username = req.user.username;

        // Check if user can modify this comment
        const canModify = await Comment.canUserModify(commentId, username);
        if (!canModify) {
            return res.status(403).json({
                success: false,
                message: 'You can only delete your own comments'
            });
        }

        const deleted = await Comment.delete(commentId);

        if (!deleted) {
            return res.status(404).json({
                success: false,
                message: 'Comment not found'
            });
        }

        res.json({
            success: true,
            message: 'Comment deleted successfully'
        });
    } catch (error) {
        console.error('Delete comment error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to delete comment',
            error: error.message
        });
    }
});

// GET /api/comments/:keyReviewId/latest - Get latest comment for a key review
router.get('/:keyReviewId/latest', async (req, res) => {
    try {
        const { keyReviewId } = req.params;

        const latestComment = await Comment.getLatestByKeyReview(keyReviewId);

        res.json({
            success: true,
            comment: latestComment
        });
    } catch (error) {
        console.error('Get latest comment error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to fetch latest comment',
            error: error.message
        });
    }
});

// GET /api/comments/:keyReviewId/count - Get comment count for a key review
router.get('/:keyReviewId/count', async (req, res) => {
    try {
        const { keyReviewId } = req.params;

        const count = await Comment.getCountByKeyReview(keyReviewId);

        res.json({
            success: true,
            count: count
        });
    } catch (error) {
        console.error('Get comment count error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to fetch comment count',
            error: error.message
        });
    }
});

module.exports = router;
