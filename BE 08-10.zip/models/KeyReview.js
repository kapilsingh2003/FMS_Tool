// Key Review Model - Samsung FMS Portal
const { executeQuery } = require('../config/database');

class KeyReview {
  // Get all key reviews for a project
  static async getByProject(projectId) {
    const query = `
      SELECT 
        kr.*,
        fk.key_name,
        fk.work_assignment,
        fk.work_assignment_owner,
        fk.description,
        g.group_id,
        g.name as group_name,
        g.comparison_type,
        -- Group models
        target_m.model_name as target_model_name,
        target_m.product_category as target_product_category,
        ref1_m.model_name as ref1_model_name,
        ref1_m.product_category as ref1_product_category,
        ref2_m.model_name as ref2_model_name,
        ref2_m.product_category as ref2_product_category,
        ref3_m.model_name as ref3_model_name,
        ref3_m.product_category as ref3_product_category,
        -- Branch names from grps table
        target_b.branch_name as target_branch_name,
        ref1_b.branch_name as ref1_branch_name,
        ref2_b.branch_name as ref2_branch_name,
        ref3_b.branch_name as ref3_branch_name
      FROM \`Key_Reviews\` kr
      JOIN \`FMS_Keys\` fk ON kr.fms_key_id = fk.fms_key_id
      JOIN \`grps\` g ON kr.group_id = g.group_id
      JOIN \`Group_Model_Mapping\` gmm ON kr.gm_id = gmm.gm_id
      LEFT JOIN \`Models\` target_m ON gmm.target_model_id = target_m.model_id
      LEFT JOIN \`Models\` ref1_m ON gmm.ref1_model_id = ref1_m.model_id
      LEFT JOIN \`Models\` ref2_m ON gmm.ref2_model_id = ref2_m.model_id
      LEFT JOIN \`Models\` ref3_m ON gmm.ref3_model_id = ref3_m.model_id
      LEFT JOIN \`Branches\` target_b ON g.target_branch_id = target_b.branch_id
      LEFT JOIN \`Branches\` ref1_b ON g.ref1_branch_id = ref1_b.branch_id
      LEFT JOIN \`Branches\` ref2_b ON g.ref2_branch_id = ref2_b.branch_id
      LEFT JOIN \`Branches\` ref3_b ON g.ref3_branch_id = ref3_b.branch_id
      WHERE g.project_id = ?
      ORDER BY fk.work_assignment, fk.key_name, g.group_id, g.name
    `;

    return await executeQuery(query, [projectId]);
  }

  // Get all key reviews for a project with latest comments
  static async getByProjectWithComments(projectId) {
    const query = `
      SELECT 
        kr.*,
        fk.key_name,
        fk.work_assignment,
        fk.work_assignment_owner,
        fk.description,
        g.group_id,
        g.name as group_name,
        g.comparison_type,
        -- Group models
        target_m.model_name as target_model_name,
        target_m.product_category as target_product_category,
        ref1_m.model_name as ref1_model_name,
        ref1_m.product_category as ref1_product_category,
        ref2_m.model_name as ref2_model_name,
        ref2_m.product_category as ref2_product_category,
        ref3_m.model_name as ref3_model_name,
        ref3_m.product_category as ref3_product_category,
        -- Branch names from grps table
        target_b.branch_name as target_branch_name,
        ref1_b.branch_name as ref1_branch_name,
        ref2_b.branch_name as ref2_branch_name,
        ref3_b.branch_name as ref3_branch_name,
        -- Latest comment info
        latest_comment.comment_text as latest_comment_text,
        latest_comment.commented_by_username as latest_comment_author,
        latest_comment.created_at as latest_comment_date,
        comment_count.total_comments
      FROM \`Key_Reviews\` kr
      JOIN \`FMS_Keys\` fk ON kr.fms_key_id = fk.fms_key_id
      JOIN \`grps\` g ON kr.group_id = g.group_id
      JOIN \`Group_Model_Mapping\` gmm ON kr.gm_id = gmm.gm_id
      LEFT JOIN \`Models\` target_m ON gmm.target_model_id = target_m.model_id
      LEFT JOIN \`Models\` ref1_m ON gmm.ref1_model_id = ref1_m.model_id
      LEFT JOIN \`Models\` ref2_m ON gmm.ref2_model_id = ref2_m.model_id
      LEFT JOIN \`Models\` ref3_m ON gmm.ref3_model_id = ref3_m.model_id
      LEFT JOIN \`Branches\` target_b ON g.target_branch_id = target_b.branch_id
      LEFT JOIN \`Branches\` ref1_b ON g.ref1_branch_id = ref1_b.branch_id
      LEFT JOIN \`Branches\` ref2_b ON g.ref2_branch_id = ref2_b.branch_id
      LEFT JOIN \`Branches\` ref3_b ON g.ref3_branch_id = ref3_b.branch_id
      LEFT JOIN (
        SELECT 
          key_review_id,
          comment_text,
          commented_by_username,
          created_at,
          ROW_NUMBER() OVER (PARTITION BY key_review_id ORDER BY created_at DESC) as rn
        FROM \`Comments\`
      ) latest_comment ON kr.key_review_id = latest_comment.key_review_id AND latest_comment.rn = 1
      LEFT JOIN (
        SELECT key_review_id, COUNT(*) as total_comments
        FROM \`Comments\`
        GROUP BY key_review_id
      ) comment_count ON kr.key_review_id = comment_count.key_review_id
      WHERE g.project_id = ?
      ORDER BY fk.work_assignment, fk.key_name, g.group_id, g.name
    `;

    return await executeQuery(query, [projectId]);
  }

  // Get hierarchical data with comments
  static async getHierarchicalDataWithComments(projectId) {
    const reviews = await this.getByProjectWithComments(projectId);

    // Organize data hierarchically: keys -> groups -> models with branch values
    const keyMap = new Map();

    reviews.forEach(review => {
      const keyId = review.fms_key_id;
      const groupId = review.group_id;

      // Initialize key if not exists
      if (!keyMap.has(keyId)) {
        keyMap.set(keyId, {
          fms_key_id: keyId,
          key_name: review.key_name,
          work_assignment: review.work_assignment,
          work_assignment_owner: review.work_assignment_owner,
          description: review.description,
          groups: new Map()
        });
      }

      const key = keyMap.get(keyId);

      // Initialize group if not exists
      if (!key.groups.has(groupId)) {
        key.groups.set(groupId, {
          group_id: groupId,
          group_name: review.group_name,
          comparison_type: review.comparison_type,
          models: new Map()
        });
      }

      const group = key.groups.get(groupId);

      // Create model display based on comparison type using the specific model combination for this review
      let modelDisplay = '';

      if (review.comparison_type === '2-way') {
        // For 2-way, only show target and ref1, ignore ref2 and ref3
        modelDisplay = `${review.target_model_name} | ${review.ref1_model_name}`;
      } else if (review.comparison_type === '3-way') {
        // For 3-way, show target, ref1, and ref2, ignore ref3
        modelDisplay = `${review.target_model_name} | ${review.ref1_model_name} | ${review.ref2_model_name}`;
      } else if (review.comparison_type === '4-way') {
        // For 4-way, show all models
        modelDisplay = `${review.target_model_name} | ${review.ref1_model_name} | ${review.ref2_model_name} | ${review.ref3_model_name}`;
      }

      // Use key_review_id as the unique key to ensure each review record is separate
      const uniqueKey = `${review.key_review_id}`;

      // Always add the model combination (don't check if it exists)
      // Create values object based on comparison type
      let values = {
        target: review.target_val,
        ref1: review.ref1_val
      };

      if (review.comparison_type === '3-way' || review.comparison_type === '4-way') {
        values.ref2 = review.ref2_val;
      }

      if (review.comparison_type === '4-way') {
        values.ref3 = review.ref3_val;
      }

      group.models.set(uniqueKey, {
        model: modelDisplay,
        model_name: modelDisplay,
        ...values,
        comment: review.comment,
        status: review.status,
        kona_ids: review.kona_ids,
        cl_numbers: review.cl_numbers,
        reviewed_by_username: review.reviewed_by_username,
        last_modified: review.reviewed_at,
        key_review_id: review.key_review_id,
        // Store identifiers for updates
        gm_id: review.gm_id,
        group_id: review.group_id,
        // Comment information
        latest_comment_text: review.latest_comment_text,
        latest_comment_author: review.latest_comment_author,
        latest_comment_date: review.latest_comment_date,
        total_comments: review.total_comments || 0
      });
    });

    // Convert Maps to Arrays for JSON serialization
    const result = Array.from(keyMap.values()).map(key => ({
      ...key,
      groups: Array.from(key.groups.values()).map(group => ({
        ...group,
        models: Array.from(group.models.values())
      }))
    }));

    return result;
  }

  // Get key reviews by group
  static async getByGroup(groupId) {
    const query = `
      SELECT 
        kr.*,
        fk.key_name,
        fk.work_assignment,
        fk.work_assignment_owner,
        fk.description,
        g.comparison_type,
        target_m.model_name as target_model_name,
        target_m.product_category as target_product_category,
        ref1_m.model_name as ref1_model_name,
        ref1_m.product_category as ref1_product_category,
        ref2_m.model_name as ref2_model_name,
        ref2_m.product_category as ref2_product_category,
        ref3_m.model_name as ref3_model_name,
        ref3_m.product_category as ref3_product_category
      FROM \`Key_Reviews\` kr
      JOIN \`FMS_Keys\` fk ON kr.fms_key_id = fk.fms_key_id
      JOIN \`grps\` g ON kr.group_id = g.group_id
      JOIN \`Group_Model_Mapping\` gmm ON kr.gm_id = gmm.gm_id
      LEFT JOIN \`Models\` target_m ON gmm.target_model_id = target_m.model_id
      LEFT JOIN \`Models\` ref1_m ON gmm.ref1_model_id = ref1_m.model_id
      LEFT JOIN \`Models\` ref2_m ON gmm.ref2_model_id = ref2_m.model_id
      LEFT JOIN \`Models\` ref3_m ON gmm.ref3_model_id = ref3_m.model_id
      WHERE g.group_id = ?
      ORDER BY fk.work_assignment, fk.key_name, target_m.model_name
    `;

    return await executeQuery(query, [groupId]);
  }

  // Get hierarchical key review data for project (organized by keys -> groups -> models)
  static async getHierarchicalData(projectId) {
    const reviews = await this.getByProject(projectId);

    // Organize data hierarchically: keys -> groups -> models with branch values
    const keyMap = new Map();

    reviews.forEach(review => {
      const keyId = review.fms_key_id;
      const groupId = review.group_id;

      // Initialize key if not exists
      if (!keyMap.has(keyId)) {
        keyMap.set(keyId, {
          fms_key_id: keyId,
          key_name: review.key_name,
          work_assignment: review.work_assignment,
          work_assignment_owner: review.work_assignment_owner,
          description: review.description,
          groups: new Map()
        });
      }

      const key = keyMap.get(keyId);

      // Initialize group if not exists
      if (!key.groups.has(groupId)) {
        key.groups.set(groupId, {
          group_id: groupId,
          group_name: review.group_name,
          comparison_type: review.comparison_type,
          models: new Map()
        });
      }

      const group = key.groups.get(groupId);

      // Create model display based on comparison type using the specific model combination for this review
      let modelDisplay = '';

      if (review.comparison_type === '2-way') {
        // For 2-way, only show target and ref1, ignore ref2 and ref3
        modelDisplay = `${review.target_model_name} | ${review.ref1_model_name}`;
      } else if (review.comparison_type === '3-way') {
        // For 3-way, show target, ref1, and ref2, ignore ref3
        modelDisplay = `${review.target_model_name} | ${review.ref1_model_name} | ${review.ref2_model_name}`;
      } else if (review.comparison_type === '4-way') {
        // For 4-way, show all models
        modelDisplay = `${review.target_model_name} | ${review.ref1_model_name} | ${review.ref2_model_name} | ${review.ref3_model_name}`;
      }

      // Use key_review_id as the unique key to ensure each review record is separate
      const uniqueKey = `${review.key_review_id}`;

      // Always add the model combination (don't check if it exists)
      // Create values object based on comparison type
      let values = {
        target: review.target_val,
        ref1: review.ref1_val
      };

      if (review.comparison_type === '3-way' || review.comparison_type === '4-way') {
        values.ref2 = review.ref2_val;
      }

      if (review.comparison_type === '4-way') {
        values.ref3 = review.ref3_val;
      }

      group.models.set(uniqueKey, {
        model: modelDisplay,
        model_name: modelDisplay,
        ...values,
        comment: review.comment,
        status: review.status,
        kona_ids: review.kona_ids,
        cl_numbers: review.cl_numbers,
        reviewed_by_username: review.reviewed_by_username,
        last_modified: review.reviewed_at,
        key_review_id: review.key_review_id,
        // Store identifiers for updates
        gm_id: review.gm_id,
        group_id: review.group_id
      });
    });

    // Convert Maps to Arrays for JSON serialization
    const result = Array.from(keyMap.values()).map(key => ({
      ...key,
      groups: Array.from(key.groups.values()).map(group => ({
        ...group,
        models: Array.from(group.models.values())
      }))
    }));

    return result;
  }

  // Create or update a key review
  static async upsert(reviewData) {
    const {
      fms_key_id,
      gm_id,
      group_id,
      target_val,
      ref1_val,
      ref2_val,
      ref3_val,
      comment,
      status,
      kona_ids,
      cl_numbers,
      reviewed_by_username
    } = reviewData;

    const query = `
      INSERT INTO \`Key_Reviews\` (
        fms_key_id, gm_id, group_id,
        target_val, ref1_val, ref2_val, ref3_val,
        comment, status, kona_ids, cl_numbers, reviewed_by_username
      )
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      ON DUPLICATE KEY UPDATE
        target_val = VALUES(target_val),
        ref1_val = VALUES(ref1_val),
        ref2_val = VALUES(ref2_val),
        ref3_val = VALUES(ref3_val),
        comment = VALUES(comment),
        status = VALUES(status),
        kona_ids = VALUES(kona_ids),
        cl_numbers = VALUES(cl_numbers),
        reviewed_by_username = VALUES(reviewed_by_username),
        reviewed_at = CURRENT_TIMESTAMP
    `;

    await executeQuery(query, [
      fms_key_id, gm_id, group_id,
      target_val, ref1_val, ref2_val, ref3_val,
      comment, status, kona_ids, cl_numbers, reviewed_by_username
    ]);

    return this.findByKeyAndGMGroup(fms_key_id, gm_id, group_id);
  }

  // Find specific key review by gm_id and group_id
  static async findByKeyAndGMGroup(fmsKeyId, gmId, groupId) {
    const query = `
      SELECT kr.*, fk.key_name
      FROM \`Key_Reviews\` kr
      JOIN \`FMS_Keys\` fk ON kr.fms_key_id = fk.fms_key_id
      WHERE kr.fms_key_id = ? AND kr.gm_id = ? AND kr.group_id = ?
    `;

    const reviews = await executeQuery(query, [fmsKeyId, gmId, groupId]);
    return reviews[0] || null;
  }

  // Update review status
  static async updateStatus(keyReviewId, status, reviewedBy) {
    const query = `
      UPDATE \`Key_Reviews\`
      SET status = ?, reviewed_by_username = ?, reviewed_at = CURRENT_TIMESTAMP
      WHERE key_review_id = ?
    `;

    await executeQuery(query, [status, reviewedBy, keyReviewId]);
  }

  // Update review values
  static async updateValues(keyReviewId, values) {
    const { target_val, ref1_val, ref2_val, ref3_val } = values;

    const query = `
      UPDATE \`Key_Reviews\`
      SET target_val = ?, ref1_val = ?, ref2_val = ?, ref3_val = ?, reviewed_at = CURRENT_TIMESTAMP
      WHERE key_review_id = ?
    `;

    await executeQuery(query, [target_val, ref1_val, ref2_val, ref3_val, keyReviewId]);
  }

  // Add or update comment
  static async updateComment(keyReviewId, comment, reviewedBy) {
    const query = `
      UPDATE \`Key_Reviews\`
      SET comment = ?, reviewed_by_username = ?, reviewed_at = CURRENT_TIMESTAMP
      WHERE key_review_id = ?
    `;

    await executeQuery(query, [comment, reviewedBy, keyReviewId]);
  }

  // Update KONA IDs
  static async updateKonaIds(keyReviewId, konaIds, reviewedBy) {
    const query = `
      UPDATE \`Key_Reviews\`
      SET kona_ids = ?, reviewed_by_username = ?, reviewed_at = CURRENT_TIMESTAMP
      WHERE key_review_id = ?
    `;

    await executeQuery(query, [konaIds, reviewedBy, keyReviewId]);
  }

  // Update CL numbers
  static async updateClNumbers(keyReviewId, clNumbers, reviewedBy) {
    const query = `
      UPDATE \`Key_Reviews\`
      SET cl_numbers = ?, reviewed_by_username = ?, reviewed_at = CURRENT_TIMESTAMP
      WHERE key_review_id = ?
    `;

    await executeQuery(query, [clNumbers, reviewedBy, keyReviewId]);
  }

  // Get review statistics for a project
  static async getProjectStats(projectId) {
    const query = `
      SELECT 
        COUNT(DISTINCT kr.fms_key_id) as total_keys,
        COUNT(DISTINCT CASE WHEN kr.status = 'changes_made' THEN kr.fms_key_id END) as reviewed_keys,
        COUNT(DISTINCT CASE WHEN kr.status = 'pending_response' THEN kr.fms_key_id END) as pending_keys,
        COUNT(DISTINCT CASE WHEN kr.status = 'internal_discussion' THEN kr.fms_key_id END) as discussion_keys,
        COUNT(DISTINCT CASE WHEN kr.status = 'no_change_req' THEN kr.fms_key_id END) as no_change_keys
      FROM \`Key_Reviews\` kr
      JOIN \`Group_Branch_Model_Map\` target_gbmm ON kr.target_gbm_id = target_gbmm.gbm_id
      JOIN \`Group_Branch_Mapping\` target_gbm ON target_gbmm.gb_id = target_gbm.gb_id
      JOIN \`grps\` g ON target_gbm.group_id = g.group_id
      WHERE g.project_id = ?
    `;

    const stats = await executeQuery(query, [projectId]);
    return stats[0];
  }

  // Delete key review
  static async delete(keyReviewId) {
    const query = `DELETE FROM \`Key_Reviews\` WHERE key_review_id = ?`;
    await executeQuery(query, [keyReviewId]);
  }

  // Get recent review activity
  static async getRecentActivity(projectId, limit = 10) {
    const query = `
      SELECT 
        kr.reviewed_at as last_modified,
        kr.status,
        kr.comment,
        fk.key_name,
        target_m.model_name,
        g.name as group_name,
        u.name as reviewer_name
      FROM \`Key_Reviews\` kr
      JOIN \`FMS_Keys\` fk ON kr.fms_key_id = fk.fms_key_id
      JOIN \`Group_Branch_Model_Map\` target_gbmm ON kr.target_gbm_id = target_gbmm.gbm_id
      JOIN \`Models\` target_m ON target_gbmm.model_id = target_m.model_id
      JOIN \`Group_Branch_Mapping\` target_gbm ON target_gbmm.gb_id = target_gbm.gb_id
      JOIN \`grps\` g ON target_gbm.group_id = g.group_id
      LEFT JOIN \`Users\` u ON kr.reviewed_by_username = u.username
      WHERE g.project_id = ?
      ORDER BY kr.reviewed_at DESC
      LIMIT ?
    `;

    return await executeQuery(query, [projectId, limit]);
  }

  // Insert DataFrame data into Key_Reviews table
  static async insertDataFrameData(projectId, dataFrames, branchModelsDict) {
    try {
      console.log(`\n=== STARTING DATAFRAME INSERTION ===`);
      console.log(`Project ID: ${projectId}`);
      console.log(`DataFrames count: ${dataFrames.length}`);
      console.log(`Branch models dict:`, JSON.stringify(branchModelsDict, null, 2));

      let totalInserted = 0;

      // CRITICAL FIX: The issue is that when a group has multiple model combinations,
      // the Python function should return separate DataFrames for each model combination,
      // not just one DataFrame per group. We need to handle this properly.

      // First, let's understand the structure:
      // - dataFrames: Array of DataFrames returned by Python function
      // - branchModelsDict.model: 3D array where each group can have multiple model combinations
      // - branchModelsDict.branch: 2D array where each group has its branches

      // We need to map DataFrames to model combinations, not just groups
      let dfIndex = 0; // Track which DataFrame we're currently processing

      for (let groupIndex = 0; groupIndex < branchModelsDict.branch.length; groupIndex++) {
        const groupBranches = branchModelsDict.branch[groupIndex];
        const groupModels = branchModelsDict.model[groupIndex];

        console.log(`\n--- Processing Group ${groupIndex + 1} ---`);
        console.log(`Branches:`, groupBranches);
        console.log(`Models:`, groupModels);
        console.log(`Number of model combinations in this group: ${groupModels.length}`);

        // Get group info from database
        // Use LIMIT ?, 1 because some MySQL drivers do not allow binding OFFSET directly
        const safeGroupOffset = Math.max(0, parseInt(groupIndex));
        const groupQuery = `
          SELECT g.group_id, g.comparison_type
          FROM \`grps\` g
          WHERE g.project_id = ?
          ORDER BY g.created_at
          LIMIT ${safeGroupOffset}, 1
        `;
        console.log(`Group query: ${groupQuery} with params: [${projectId}]`);
        console.log(`ProjectId type: ${typeof projectId}, value: ${projectId}`);
        console.log(`GroupIndex (embedded) value: ${safeGroupOffset}`);

        const groups = await executeQuery(groupQuery, [parseInt(projectId)]);
        console.log(`Group query result:`, groups);

        if (groups.length === 0) {
          console.error(`No group found for project ${projectId} at index ${groupIndex}`);
          continue;
        }

        const group = groups[0];
        console.log(`Found group:`, group);

        // FIXED LOGIC: Process each model combination in the group
        // Each model combination should have its own DataFrame from the Python function
        for (let modelIndex = 0; modelIndex < groupModels.length; modelIndex++) {
          const modelCombination = groupModels[modelIndex];
          console.log(`\n  Processing model combination ${modelIndex + 1}:`, modelCombination);

          // Check if we have a DataFrame for this model combination
          if (dfIndex >= dataFrames.length) {
            console.error(`No DataFrame available for model combination ${modelIndex + 1} (dfIndex: ${dfIndex}, total DataFrames: ${dataFrames.length})`);
            continue;
          }

          const df = dataFrames[dfIndex];
          console.log(`  Using DataFrame ${dfIndex + 1} for model combination: ${modelCombination}`);
          console.log(`  DataFrame rows: ${df.length}`);
          console.log(`  DataFrame sample:`, df[0]);

          // Get the corresponding gm_id for this model combination
          const safeModelOffset = Math.max(0, parseInt(modelIndex));
          const gmQuery = `
            SELECT gmm.gm_id
            FROM \`Group_Model_Mapping\` gmm
            WHERE gmm.group_id = ?
            ORDER BY gmm.gm_id
            LIMIT ${safeModelOffset}, 1
          `;
          console.log(`GM query: ${gmQuery} with params: [${group.group_id}]`);
          const gmResults = await executeQuery(gmQuery, [group.group_id]);
          console.log(`GM query result:`, gmResults);

          if (gmResults.length === 0) {
            console.error(`No gm_id found for group ${group.group_id} at model index ${modelIndex}`);
            dfIndex++; // Move to next DataFrame even if this model combination fails
            continue;
          }

          const gmId = gmResults[0].gm_id;
          console.log(`Using gm_id: ${gmId}`);

          // Process each row in the DataFrame for this model combination
          for (let rowIndex = 0; rowIndex < df.length; rowIndex++) {
            const row = df[rowIndex];
            console.log(`\n    Processing row ${rowIndex + 1}:`, row);

            // Normalize key name from dataframe
            const rawKeyName = row['key name'] || row['key_name'];
            const keyName = typeof rawKeyName === 'string' ? rawKeyName.trim() : rawKeyName;
            if (!keyName) {
              console.warn(`    Skipping row with no key name:`, row);
              continue;
            }

            console.log(`    Key name: "${keyName}"`);

            // Get or create FMS key
            let fmsKeyId;
            // Try exact match first
            const keyQueryExact = 'SELECT fms_key_id FROM `FMS_Keys` WHERE key_name = ?';
            console.log(`    Key lookup (exact) query: ${keyQueryExact} with param: "${keyName}"`);
            let existingKey = await executeQuery(keyQueryExact, [keyName]);
            // If not found, try case-insensitive match
            if (existingKey.length === 0 && typeof keyName === 'string') {
              const keyQueryCI = 'SELECT fms_key_id FROM `FMS_Keys` WHERE LOWER(key_name) = LOWER(?)';
              console.log(`    Key lookup (case-insensitive) query: ${keyQueryCI} with param: "${keyName}"`);
              existingKey = await executeQuery(keyQueryCI, [keyName]);
            }
            // If still not found, try replacing spaces with underscores (common normalization)
            if (existingKey.length === 0 && typeof keyName === 'string') {
              const normalized = keyName.replace(/\s+/g, '_');
              if (normalized !== keyName) {
                const keyQueryNormalized = 'SELECT fms_key_id FROM `FMS_Keys` WHERE key_name = ?';
                console.log(`    Key lookup (normalized) query: ${keyQueryNormalized} with param: "${normalized}"`);
                existingKey = await executeQuery(keyQueryNormalized, [normalized]);
              }
            }
            console.log(`    Key lookup result count: ${existingKey.length}`);

            if (existingKey.length > 0) {
              fmsKeyId = existingKey[0].fms_key_id;
              console.log(`    Using existing FMS key ID: ${fmsKeyId}`);
            } else {
              // Create new FMS key
              const insertKeyQuery = `
                INSERT INTO \`FMS_Keys\` (key_name, has_differences)
                VALUES (?, TRUE)
              `;
              console.log(`    Creating new FMS key: ${insertKeyQuery} with params: ["${keyName}", TRUE]`);
              const keyResult = await executeQuery(insertKeyQuery, [keyName]);
              fmsKeyId = keyResult.insertId;
              console.log(`    Created new FMS key: ${keyName} (ID: ${fmsKeyId})`);
            }

            // Extract values based on comparison type
            const targetVal = row['target_model data'] || row['target_model_data'] || '';
            const ref1Val = row['ref1 model data'] || row['ref1_model_data'] || '';
            const ref2Val = row['ref2 model data'] || row['ref2_model_data'] || '';
            const ref3Val = row['ref3 model data'] || row['ref3_model_data'] || '';

            console.log(`    Values - target: "${targetVal}", ref1: "${ref1Val}", ref2: "${ref2Val}", ref3: "${ref3Val}"`);

            // Insert or update key review
            const upsertQuery = `
              INSERT INTO \`Key_Reviews\` 
              (fms_key_id, gm_id, group_id, target_val, ref1_val, ref2_val, ref3_val, status)
              VALUES (?, ?, ?, ?, ?, ?, ?, 'unreviewed')
              ON DUPLICATE KEY UPDATE
                target_val = VALUES(target_val),
                ref1_val = VALUES(ref1_val),
                ref2_val = VALUES(ref2_val),
                ref3_val = VALUES(ref3_val),
                reviewed_at = CURRENT_TIMESTAMP
            `;

            const insertParams = [
              fmsKeyId,
              gmId,
              group.group_id,
              targetVal,
              ref1Val,
              ref2Val,
              ref3Val
            ];

            console.log(`    Insert query: ${upsertQuery}`);
            console.log(`    Insert params:`, insertParams);

            const insertResult = await executeQuery(upsertQuery, insertParams);
            console.log(`    Insert result:`, insertResult);

            totalInserted++;
            console.log(`    ✓ Inserted record ${totalInserted}`);
          }

          // Move to next DataFrame for the next model combination
          dfIndex++;
          console.log(`  Completed processing model combination ${modelIndex + 1}. Moving to DataFrame ${dfIndex + 1}.`);
        }
      }

      console.log(`\n=== DATAFRAME INSERTION COMPLETE ===`);
      console.log(`Successfully inserted ${totalInserted} key review records for project ${projectId}`);
      return { success: true, inserted: totalInserted };

    } catch (error) {
      console.error('\n=== DATAFRAME INSERTION ERROR ===');
      console.error('Error inserting DataFrame data:', error);
      console.error('Stack trace:', error.stack);
      return { success: false, error: error.message };
    }
  }
}

module.exports = KeyReview;
