import React, { useState, useEffect } from 'react';
import {
    Dialog,
    DialogTitle,
    DialogContent,
    DialogActions,
    Button,
    TextField,
    Box,
    Typography,
    Avatar,
    Divider,
    IconButton,
    Menu,
    MenuItem,
    ListItemIcon,
    ListItemText,
    Chip,
    CircularProgress,
    Alert
} from '@mui/material';
import {
    Send,
    MoreVert,
    Edit,
    Delete,
    Person,
    AccessTime,
    GroupWork
} from '@mui/icons-material';
import { commentAPI } from '../../services/api';
import { useAuth } from '../../contexts/AuthContext';
import { toast } from 'react-toastify';

const CommentDialog = ({ open, onClose, keyReviewId, keyName, groupName, groupKeyReviewIds, onCommentAdded }) => {
    const { user } = useAuth();
    const [comments, setComments] = useState([]);
    const [newComment, setNewComment] = useState('');
    const [loading, setLoading] = useState(false);
    const [submitting, setSubmitting] = useState(false);
    const [editingComment, setEditingComment] = useState(null);
    const [editText, setEditText] = useState('');
    const [anchorEl, setAnchorEl] = useState(null);
    const [selectedComment, setSelectedComment] = useState(null);

    useEffect(() => {
        if (open && keyReviewId) {
            loadComments();
        }
    }, [open, keyReviewId]);

    const loadComments = async () => {
        setLoading(true);
        try {
            const result = await commentAPI.getComments(keyReviewId);
            if (result.success) {
                setComments(result.data.comments || []);
            } else {
                toast.error('Failed to load comments');
            }
        } catch (error) {
            toast.error('Error loading comments');
        } finally {
            setLoading(false);
        }
    };

    const handleSubmitComment = async () => {
        if (!newComment.trim()) return;

        setSubmitting(true);
        try {
            const result = await commentAPI.createComment(keyReviewId, newComment.trim());
            if (result.success) {
                setNewComment('');
                await loadComments(); // Reload comments
                toast.success('Comment added successfully');
                if (onCommentAdded) onCommentAdded();
            } else {
                toast.error(result.error || 'Failed to add comment');
            }
        } catch (error) {
            toast.error('Error adding comment');
        } finally {
            setSubmitting(false);
        }
    };

    const handleApplyToGroup = async () => {
        if (!newComment.trim()) {
            toast.error('Please enter a comment first');
            return;
        }

        if (!groupKeyReviewIds || groupKeyReviewIds.length === 0) {
            toast.error('No group key reviews found');
            return;
        }

        const confirmMessage = `Apply this comment to all ${groupKeyReviewIds.length} models in group "${groupName}" for this key?`;
        if (!window.confirm(confirmMessage)) {
            return;
        }

        setSubmitting(true);
        try {
            const result = await commentAPI.createBulkComment(groupKeyReviewIds, newComment.trim());
            if (result.success) {
                setNewComment('');
                await loadComments(); // Reload comments for current key review
                toast.success(result.data.message || `Comment added to ${result.data.successCount} key reviews`);
                if (onCommentAdded) onCommentAdded();
            } else {
                toast.error(result.error || 'Failed to apply comment to group');
            }
        } catch (error) {
            toast.error('Error applying comment to group');
        } finally {
            setSubmitting(false);
        }
    };

    const handleEditComment = (comment) => {
        setEditingComment(comment.comment_id);
        setEditText(comment.comment_text);
        setAnchorEl(null);
    };

    const handleSaveEdit = async () => {
        if (!editText.trim()) return;

        try {
            const result = await commentAPI.updateComment(editingComment, editText.trim());
            if (result.success) {
                setEditingComment(null);
                setEditText('');
                await loadComments();
                toast.success('Comment updated successfully');
            } else {
                toast.error(result.error || 'Failed to update comment');
            }
        } catch (error) {
            toast.error('Error updating comment');
        }
    };

    const handleDeleteComment = async (commentId) => {
        if (!window.confirm('Are you sure you want to delete this comment?')) return;

        try {
            const result = await commentAPI.deleteComment(commentId);
            if (result.success) {
                await loadComments();
                toast.success('Comment deleted successfully');
            } else {
                toast.error(result.error || 'Failed to delete comment');
            }
        } catch (error) {
            toast.error('Error deleting comment');
        } finally {
            setAnchorEl(null);
        }
    };

    const handleMenuOpen = (event, comment) => {
        setAnchorEl(event.currentTarget);
        setSelectedComment(comment);
    };

    const handleMenuClose = () => {
        setAnchorEl(null);
        setSelectedComment(null);
    };

    const formatDate = (dateString) => {
        const date = new Date(dateString);
        return date.toLocaleString();
    };

    const canEditComment = (comment) => {
        return comment.commented_by_username === user.username;
    };

    return (
        <Dialog open={open} onClose={onClose} maxWidth="md" fullWidth>
            <DialogTitle>
                <Box display="flex" alignItems="center" gap={1}>
                    <Person />
                    <Typography variant="h6">Comments for {keyName}</Typography>
                </Box>
            </DialogTitle>

            <DialogContent>
                {loading ? (
                    <Box display="flex" justifyContent="center" p={3}>
                        <CircularProgress />
                    </Box>
                ) : (
                    <Box>
                        {/* Comments List */}
                        {comments.length === 0 ? (
                            <Alert severity="info">No comments yet. Be the first to comment!</Alert>
                        ) : (
                            <Box>
                                {comments.map((comment, index) => (
                                    <Box key={comment.comment_id}>
                                        <Box display="flex" alignItems="flex-start" gap={2} p={2}>
                                            <Avatar sx={{ bgcolor: 'primary.main' }}>
                                                {comment.commented_by_name?.charAt(0) || 'U'}
                                            </Avatar>

                                            <Box flex={1}>
                                                <Box display="flex" alignItems="center" gap={1} mb={1}>
                                                    <Typography variant="subtitle2" fontWeight="bold">
                                                        {comment.commented_by_name}
                                                    </Typography>
                                                    <Chip
                                                        label={comment.commented_by_team}
                                                        size="small"
                                                        color="secondary"
                                                        variant="outlined"
                                                    />
                                                    <Typography variant="caption" color="text.secondary">
                                                        <AccessTime sx={{ fontSize: 14, mr: 0.5 }} />
                                                        {formatDate(comment.created_at)}
                                                    </Typography>

                                                    {canEditComment(comment) && (
                                                        <IconButton
                                                            size="small"
                                                            onClick={(e) => handleMenuOpen(e, comment)}
                                                        >
                                                            <MoreVert fontSize="small" />
                                                        </IconButton>
                                                    )}
                                                </Box>

                                                {editingComment === comment.comment_id ? (
                                                    <Box>
                                                        <TextField
                                                            fullWidth
                                                            multiline
                                                            rows={3}
                                                            value={editText}
                                                            onChange={(e) => setEditText(e.target.value)}
                                                            variant="outlined"
                                                            size="small"
                                                        />
                                                        <Box mt={1} display="flex" gap={1}>
                                                            <Button
                                                                size="small"
                                                                variant="contained"
                                                                onClick={handleSaveEdit}
                                                            >
                                                                Save
                                                            </Button>
                                                            <Button
                                                                size="small"
                                                                onClick={() => {
                                                                    setEditingComment(null);
                                                                    setEditText('');
                                                                }}
                                                            >
                                                                Cancel
                                                            </Button>
                                                        </Box>
                                                    </Box>
                                                ) : (
                                                    <Typography variant="body2" sx={{ whiteSpace: 'pre-wrap' }}>
                                                        {comment.comment_text}
                                                    </Typography>
                                                )}
                                            </Box>
                                        </Box>

                                        {index < comments.length - 1 && <Divider />}
                                    </Box>
                                ))}
                            </Box>
                        )}

                        {/* Add Comment Section */}
                        <Box mt={3}>
                            <Typography variant="subtitle2" gutterBottom>
                                Add a comment
                            </Typography>
                            <TextField
                                fullWidth
                                multiline
                                rows={3}
                                value={newComment}
                                onChange={(e) => setNewComment(e.target.value)}
                                placeholder="Write your comment here..."
                                variant="outlined"
                                disabled={submitting}
                            />
                        </Box>
                    </Box>
                )}
            </DialogContent>

            <DialogActions sx={{ justifyContent: 'space-between', px: 3, py: 2 }}>
                {/* Left side - Apply to Group button */}
                {groupKeyReviewIds && groupKeyReviewIds.length > 1 && (
                    <Button
                        onClick={handleApplyToGroup}
                        startIcon={<GroupWork />}
                        size="small"
                        variant="outlined"
                        color="secondary"
                        disabled={!newComment.trim() || submitting}
                    >
                        Apply to Group ({groupKeyReviewIds.length})
                    </Button>
                )}
                {(!groupKeyReviewIds || groupKeyReviewIds.length <= 1) && <Box />}

                {/* Right side - Close and Add Comment buttons */}
                <Box sx={{ display: 'flex', gap: 1 }}>
                    <Button onClick={onClose}>Close</Button>
                    <Button
                        variant="contained"
                        onClick={handleSubmitComment}
                        disabled={!newComment.trim() || submitting}
                        startIcon={submitting ? <CircularProgress size={16} /> : <Send />}
                    >
                        {submitting ? 'Adding...' : 'Add Comment'}
                    </Button>
                </Box>
            </DialogActions>

            {/* Comment Menu */}
            <Menu
                anchorEl={anchorEl}
                open={Boolean(anchorEl)}
                onClose={handleMenuClose}
            >
                <MenuItem onClick={() => handleEditComment(selectedComment)}>
                    <ListItemIcon>
                        <Edit fontSize="small" />
                    </ListItemIcon>
                    <ListItemText>Edit</ListItemText>
                </MenuItem>
                <MenuItem
                    onClick={() => handleDeleteComment(selectedComment?.comment_id)}
                    sx={{ color: 'error.main' }}
                >
                    <ListItemIcon>
                        <Delete fontSize="small" color="error" />
                    </ListItemIcon>
                    <ListItemText>Delete</ListItemText>
                </MenuItem>
            </Menu>
        </Dialog>
    );
};

export default CommentDialog;

