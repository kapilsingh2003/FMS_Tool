import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
    Container,
    Paper,
    Box,
    Typography,
    Grid,
    Card,
    CardContent,
    Button,
    Chip,
    Avatar,
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TableRow,
    CircularProgress,
    Alert,
    Tabs,
    Tab,
    IconButton,
    Tooltip,
    LinearProgress,
    Divider
} from '@mui/material';
import {
    ExitToApp,
    People,
    Assessment,
    TrendingUp,
    Comment,
    Folder,
    Refresh,
    Schedule,
    CheckCircle,
    Warning,
    Error as ErrorIcon,
    Person,
    Group,
    Timeline,
    BarChart as BarChartIcon,
    PieChart as PieChartIcon,
    Dashboard as DashboardIcon,
    ArrowBack
} from '@mui/icons-material';
import {
    BarChart,
    Bar,
    XAxis,
    YAxis,
    CartesianGrid,
    Tooltip as RechartsTooltip,
    ResponsiveContainer,
    PieChart,
    Pie,
    Cell,
    Legend,
    LineChart,
    Line,
    Area,
    AreaChart
} from 'recharts';
import { useAuth } from '../../contexts/AuthContext';
import { kpiAPI } from '../../services/api';
import { toast } from 'react-toastify';

// Color palette for charts
const COLORS = ['#1976d2', '#2e7d32', '#ed6c02', '#9c27b0', '#d32f2f', '#0288d1', '#388e3c', '#f57c00'];
const STATUS_COLORS = {
    unreviewed: '#757575',
    changes_made: '#2e7d32',
    pending_response: '#ed6c02',
    no_change_req: '#1976d2',
    internal_discussion: '#9c27b0',
    changes_in_progress: '#0288d1',
    value_changed: '#d32f2f'
};

// Stat Card Component
const StatCard = ({ title, value, subtitle, icon, color = 'primary', trend }) => (
    <Card sx={{
        height: '100%',
        background: `linear-gradient(135deg, ${color === 'primary' ? '#1976d2' : color === 'success' ? '#2e7d32' : color === 'warning' ? '#ed6c02' : color === 'error' ? '#d32f2f' : '#9c27b0'} 0%, ${color === 'primary' ? '#42a5f5' : color === 'success' ? '#66bb6a' : color === 'warning' ? '#ffa726' : color === 'error' ? '#ef5350' : '#ba68c8'} 100%)`,
        color: 'white'
    }}>
        <CardContent>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                <Box>
                    <Typography variant="h3" sx={{ fontWeight: 700, mb: 1 }}>
                        {value}
                    </Typography>
                    <Typography variant="h6" sx={{ fontWeight: 500, opacity: 0.9 }}>
                        {title}
                    </Typography>
                    {subtitle && (
                        <Typography variant="body2" sx={{ opacity: 0.8, mt: 0.5 }}>
                            {subtitle}
                        </Typography>
                    )}
                </Box>
                <Avatar sx={{ bgcolor: 'rgba(255,255,255,0.2)', width: 56, height: 56 }}>
                    {icon}
                </Avatar>
            </Box>
            {trend && (
                <Box sx={{ display: 'flex', alignItems: 'center', mt: 2 }}>
                    <TrendingUp sx={{ mr: 0.5, fontSize: 16 }} />
                    <Typography variant="body2">{trend}</Typography>
                </Box>
            )}
        </CardContent>
    </Card>
);

// Tab Panel Component
const TabPanel = ({ children, value, index }) => (
    <div hidden={value !== index} style={{ paddingTop: 24 }}>
        {value === index && children}
    </div>
);

const KPIDashboard = () => {
    const { user, logout } = useAuth();
    const navigate = useNavigate();
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [stats, setStats] = useState(null);
    const [activity, setActivity] = useState([]);
    const [users, setUsers] = useState([]);
    const [projects, setProjects] = useState([]);
    const [tabValue, setTabValue] = useState(0);
    const [refreshing, setRefreshing] = useState(false);

    useEffect(() => {
        // Check if user is system
        if (user?.username !== 'system') {
            toast.error('Access denied. Only system user can access KPI dashboard.');
            navigate('/');
            return;
        }
        fetchAllData();
    }, [user, navigate]);

    const fetchAllData = async () => {
        setLoading(true);
        setError(null);
        try {
            const [statsResult, activityResult, usersResult, projectsResult] = await Promise.all([
                kpiAPI.getStats(),
                kpiAPI.getActivity(50, 0),
                kpiAPI.getUsers(),
                kpiAPI.getProjects()
            ]);

            if (statsResult.success) setStats(statsResult.data);
            if (activityResult.success) setActivity(activityResult.data.activity || []);
            if (usersResult.success) setUsers(usersResult.data || []);
            if (projectsResult.success) setProjects(projectsResult.data || []);

            if (!statsResult.success) {
                setError(statsResult.error);
            }
        } catch (err) {
            setError('Failed to fetch KPI data');
            console.error('KPI fetch error:', err);
        } finally {
            setLoading(false);
        }
    };

    const handleRefresh = async () => {
        setRefreshing(true);
        await fetchAllData();
        setRefreshing(false);
        toast.success('Data refreshed');
    };

    const handleLogout = () => {
        logout();
        navigate('/login');
    };

    const handleTabChange = (event, newValue) => {
        setTabValue(newValue);
    };

    const formatDate = (dateString) => {
        if (!dateString) return 'Never';
        return new Date(dateString).toLocaleString();
    };

    const getActivityStatusColor = (status) => {
        switch (status) {
            case 'active': return 'success';
            case 'moderate': return 'warning';
            default: return 'default';
        }
    };

    if (loading) {
        return (
            <Container maxWidth="xl">
                <Box sx={{ mt: 4, display: 'flex', justifyContent: 'center', alignItems: 'center', height: '50vh' }}>
                    <CircularProgress size={60} />
                </Box>
            </Container>
        );
    }

    if (error) {
        return (
            <Container maxWidth="xl">
                <Box sx={{ mt: 4 }}>
                    <Alert severity="error" sx={{ mb: 3 }}>{error}</Alert>
                    <Button variant="contained" onClick={fetchAllData}>Retry</Button>
                </Box>
            </Container>
        );
    }

    // Prepare chart data
    const statusChartData = stats?.statusDistribution?.map(item => ({
        name: item.status.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase()),
        value: item.count,
        color: STATUS_COLORS[item.status] || '#757575'
    })) || [];

    const teamChartData = stats?.teamDistribution?.map((item, index) => ({
        name: item.team,
        value: item.count,
        color: COLORS[index % COLORS.length]
    })) || [];

    const projectsPerMonthData = stats?.projectsPerMonth || [];
    const reviewsPerMonthData = stats?.reviewsPerMonth || [];

    return (
        <Container maxWidth="xl">
            <Box sx={{ mt: 3, mb: 4 }}>
                {/* Header */}
                <Paper sx={{ p: 3, mb: 3, background: 'linear-gradient(45deg, #1976d2 30%, #42a5f5 90%)', color: 'white' }}>
                    <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                            <IconButton onClick={() => navigate('/')} sx={{ color: 'white' }}>
                                <ArrowBack />
                            </IconButton>
                            <DashboardIcon sx={{ fontSize: 40 }} />
                            <Box>
                                <Typography variant="h4" sx={{ fontWeight: 700 }}>
                                    KPI Dashboard
                                </Typography>
                                <Typography variant="body2" sx={{ opacity: 0.8 }}>
                                    FMS Review Manager Analytics & Monitoring
                                </Typography>
                            </Box>
                        </Box>
                        <Box sx={{ display: 'flex', gap: 1 }}>
                            <Tooltip title="Refresh Data">
                                <IconButton onClick={handleRefresh} disabled={refreshing} sx={{ color: 'white' }}>
                                    {refreshing ? <CircularProgress size={24} color="inherit" /> : <Refresh />}
                                </IconButton>
                            </Tooltip>
                            <Button
                                variant="outlined"
                                startIcon={<ExitToApp />}
                                onClick={handleLogout}
                                sx={{ color: 'white', borderColor: 'rgba(255,255,255,0.5)', '&:hover': { borderColor: 'white', bgcolor: 'rgba(255,255,255,0.1)' } }}
                            >
                                Logout
                            </Button>
                        </Box>
                    </Box>
                </Paper>

                {/* Key Metrics */}
                <Grid container spacing={3} sx={{ mb: 3 }}>
                    <Grid item xs={12} sm={6} md={3}>
                        <StatCard
                            title="Active Users"
                            value={stats?.activeUsers || 0}
                            subtitle={`of ${stats?.totalUsers || 0} total users`}
                            icon={<People sx={{ fontSize: 32 }} />}
                            color="primary"
                            trend="Last 7 days"
                        />
                    </Grid>
                    <Grid item xs={12} sm={6} md={3}>
                        <StatCard
                            title="Total Projects"
                            value={stats?.totalProjects || 0}
                            subtitle={`${stats?.activeProjects || 0} active`}
                            icon={<Folder sx={{ fontSize: 32 }} />}
                            color="success"
                        />
                    </Grid>
                    <Grid item xs={12} sm={6} md={3}>
                        <StatCard
                            title="Reviews Modified"
                            value={stats?.modifiedKeyReviews || 0}
                            subtitle={`${stats?.modifiedKeyReviewsThisWeek || 0} this week`}
                            icon={<Assessment sx={{ fontSize: 32 }} />}
                            color="warning"
                            trend="All time by users"
                        />
                    </Grid>
                    <Grid item xs={12} sm={6} md={3}>
                        <StatCard
                            title="User Comments"
                            value={stats?.userComments || 0}
                            subtitle={`${stats?.userCommentsThisWeek || 0} this week`}
                            icon={<Comment sx={{ fontSize: 32 }} />}
                            color="secondary"
                            trend="All time by users"
                        />
                    </Grid>
                </Grid>

                {/* Tabs */}
                <Paper sx={{ mb: 3 }}>
                    <Tabs value={tabValue} onChange={handleTabChange} variant="fullWidth">
                        <Tab icon={<BarChartIcon />} label="Overview" />
                        <Tab icon={<Timeline />} label="Activity" />
                        <Tab icon={<Group />} label="Users" />
                        <Tab icon={<Folder />} label="Projects" />
                    </Tabs>
                </Paper>

                {/* Tab Content */}
                <TabPanel value={tabValue} index={0}>
                    {/* Overview Tab */}
                    <Grid container spacing={3}>
                        {/* Projects Created Per Month */}
                        <Grid item xs={12} md={6}>
                            <Paper sx={{ p: 3, height: 400 }}>
                                <Typography variant="h6" gutterBottom sx={{ fontWeight: 600 }}>
                                    Projects Created Per Month
                                </Typography>
                                <ResponsiveContainer width="100%" height={320}>
                                    <AreaChart data={projectsPerMonthData}>
                                        <CartesianGrid strokeDasharray="3 3" />
                                        <XAxis dataKey="month_label" tick={{ fontSize: 12 }} />
                                        <YAxis />
                                        <RechartsTooltip />
                                        <Area type="monotone" dataKey="count" stroke="#1976d2" fill="#42a5f5" fillOpacity={0.6} name="Projects" />
                                    </AreaChart>
                                </ResponsiveContainer>
                            </Paper>
                        </Grid>

                        {/* Key Review Status Distribution */}
                        <Grid item xs={12} md={6}>
                            <Paper sx={{ p: 3, height: 400 }}>
                                <Typography variant="h6" gutterBottom sx={{ fontWeight: 600 }}>
                                    Key Review Status Distribution
                                </Typography>
                                <ResponsiveContainer width="100%" height={320}>
                                    <PieChart>
                                        <Pie
                                            data={statusChartData}
                                            cx="35%"
                                            cy="50%"
                                            innerRadius={50}
                                            outerRadius={90}
                                            paddingAngle={2}
                                            dataKey="value"
                                            label={false}
                                        >
                                            {statusChartData.map((entry, index) => (
                                                <Cell key={`cell-${index}`} fill={entry.color} />
                                            ))}
                                        </Pie>
                                        <RechartsTooltip
                                            formatter={(value, name) => [`${value} keys`, name]}
                                        />
                                        <Legend
                                            layout="vertical"
                                            align="right"
                                            verticalAlign="middle"
                                            wrapperStyle={{ paddingLeft: 20 }}
                                            formatter={(value, entry) => {
                                                const item = statusChartData.find(d => d.name === value);
                                                const total = statusChartData.reduce((sum, d) => sum + d.value, 0);
                                                const percent = total > 0 ? ((item?.value || 0) / total * 100).toFixed(1) : 0;
                                                return `${value} (${percent}%)`;
                                            }}
                                        />
                                    </PieChart>
                                </ResponsiveContainer>
                            </Paper>
                        </Grid>

                        {/* Reviews Modified Per Month */}
                        <Grid item xs={12} md={6}>
                            <Paper sx={{ p: 3, height: 400 }}>
                                <Typography variant="h6" gutterBottom sx={{ fontWeight: 600 }}>
                                    Key Reviews Modified Per Month
                                </Typography>
                                <ResponsiveContainer width="100%" height={320}>
                                    <BarChart data={reviewsPerMonthData}>
                                        <CartesianGrid strokeDasharray="3 3" />
                                        <XAxis dataKey="month_label" tick={{ fontSize: 12 }} />
                                        <YAxis />
                                        <RechartsTooltip />
                                        <Bar dataKey="count" fill="#2e7d32" name="Reviews Modified" radius={[4, 4, 0, 0]} />
                                    </BarChart>
                                </ResponsiveContainer>
                            </Paper>
                        </Grid>

                        {/* Team Distribution */}
                        <Grid item xs={12} md={6}>
                            <Paper sx={{ p: 3, height: 400 }}>
                                <Typography variant="h6" gutterBottom sx={{ fontWeight: 600 }}>
                                    Users by Team
                                </Typography>
                                <ResponsiveContainer width="100%" height={320}>
                                    <PieChart>
                                        <Pie
                                            data={teamChartData}
                                            cx="50%"
                                            cy="50%"
                                            outerRadius={100}
                                            dataKey="value"
                                            label={({ name, value }) => `${name}: ${value}`}
                                        >
                                            {teamChartData.map((entry, index) => (
                                                <Cell key={`cell-${index}`} fill={entry.color} />
                                            ))}
                                        </Pie>
                                        <RechartsTooltip />
                                        <Legend />
                                    </PieChart>
                                </ResponsiveContainer>
                            </Paper>
                        </Grid>

                        {/* Top Active Users */}
                        <Grid item xs={12} md={6}>
                            <Paper sx={{ p: 3 }}>
                                <Typography variant="h6" gutterBottom sx={{ fontWeight: 600 }}>
                                    Top Active Users
                                </Typography>
                                <TableContainer>
                                    <Table size="small">
                                        <TableHead>
                                            <TableRow>
                                                <TableCell>User</TableCell>
                                                <TableCell>Team</TableCell>
                                                <TableCell align="right">Reviews</TableCell>
                                                <TableCell align="right">Comments</TableCell>
                                            </TableRow>
                                        </TableHead>
                                        <TableBody>
                                            {stats?.topUsers?.slice(0, 5).map((user, index) => (
                                                <TableRow key={user.username}>
                                                    <TableCell>
                                                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                                                            <Avatar sx={{ width: 24, height: 24, fontSize: 12, bgcolor: COLORS[index % COLORS.length] }}>
                                                                {user.name?.charAt(0)}
                                                            </Avatar>
                                                            {user.name}
                                                        </Box>
                                                    </TableCell>
                                                    <TableCell>{user.team}</TableCell>
                                                    <TableCell align="right">{user.reviews_modified}</TableCell>
                                                    <TableCell align="right">{user.comments_added}</TableCell>
                                                </TableRow>
                                            ))}
                                        </TableBody>
                                    </Table>
                                </TableContainer>
                            </Paper>
                        </Grid>

                        {/* Recent Syncs */}
                        <Grid item xs={12} md={6}>
                            <Paper sx={{ p: 3 }}>
                                <Typography variant="h6" gutterBottom sx={{ fontWeight: 600 }}>
                                    Recent Project Syncs
                                </Typography>
                                <TableContainer>
                                    <Table size="small">
                                        <TableHead>
                                            <TableRow>
                                                <TableCell>Project</TableCell>
                                                <TableCell>Admin</TableCell>
                                                <TableCell>Status</TableCell>
                                                <TableCell>Last Refreshed</TableCell>
                                            </TableRow>
                                        </TableHead>
                                        <TableBody>
                                            {stats?.recentSyncs?.slice(0, 5).map((project) => (
                                                <TableRow key={project.project_id}>
                                                    <TableCell>{project.title}</TableCell>
                                                    <TableCell>{project.admin_name}</TableCell>
                                                    <TableCell>
                                                        <Chip
                                                            label={project.status}
                                                            size="small"
                                                            color={project.status === 'active' ? 'success' : project.status === 'syncing' ? 'info' : 'error'}
                                                        />
                                                    </TableCell>
                                                    <TableCell>{formatDate(project.last_refreshed_at)}</TableCell>
                                                </TableRow>
                                            ))}
                                        </TableBody>
                                    </Table>
                                </TableContainer>
                            </Paper>
                        </Grid>
                    </Grid>
                </TabPanel>

                <TabPanel value={tabValue} index={1}>
                    {/* Activity Tab */}
                    <Paper sx={{ p: 3 }}>
                        <Typography variant="h6" gutterBottom sx={{ fontWeight: 600 }}>
                            Recent User Activity
                        </Typography>
                        <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
                            Showing recent comments and key review modifications (excluding system changes)
                        </Typography>
                        {activity.length === 0 ? (
                            <Alert severity="info" sx={{ mt: 2 }}>
                                <Typography variant="body2">
                                    No user activity found. Activity is tracked when users:
                                </Typography>
                                <ul style={{ margin: '8px 0', paddingLeft: 20 }}>
                                    <li>Add comments to key reviews</li>
                                    <li>Update key review status (e.g., "Changes Made", "Pending Response")</li>
                                    <li>Add KONA IDs or CL numbers</li>
                                </ul>
                                <Typography variant="body2" color="text.secondary">
                                    Note: System-generated changes (during sync) are excluded.
                                </Typography>
                            </Alert>
                        ) : (
                            <TableContainer>
                                <Table>
                                    <TableHead>
                                        <TableRow>
                                            <TableCell>User</TableCell>
                                            <TableCell>Action</TableCell>
                                            <TableCell>Key</TableCell>
                                            <TableCell>Project</TableCell>
                                            <TableCell>Details</TableCell>
                                            <TableCell>Time</TableCell>
                                        </TableRow>
                                    </TableHead>
                                    <TableBody>
                                        {activity.map((item, index) => (
                                            <TableRow key={index}>
                                                <TableCell>
                                                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                                                        <Avatar sx={{ width: 28, height: 28, fontSize: 12 }}>
                                                            {item.user_name?.charAt(0)}
                                                        </Avatar>
                                                        <Box>
                                                            <Typography variant="body2">{item.user_name}</Typography>
                                                            <Typography variant="caption" color="text.secondary">{item.team}</Typography>
                                                        </Box>
                                                    </Box>
                                                </TableCell>
                                                <TableCell>
                                                    <Chip
                                                        label={item.action_type === 'comment_add' ? 'Comment' : 'Review Update'}
                                                        size="small"
                                                        color={item.action_type === 'comment_add' ? 'primary' : 'success'}
                                                    />
                                                </TableCell>
                                                <TableCell>
                                                    <Typography variant="body2" sx={{ maxWidth: 200, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                                                        {item.key_name}
                                                    </Typography>
                                                </TableCell>
                                                <TableCell>{item.project_title}</TableCell>
                                                <TableCell>
                                                    {item.action_type === 'comment_add' ? (
                                                        <Typography variant="body2" sx={{ maxWidth: 150, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                                                            "{item.details?.comment}"
                                                        </Typography>
                                                    ) : (
                                                        <Box>
                                                            {item.details?.status && <Chip label={item.details.status} size="small" sx={{ mr: 0.5 }} />}
                                                            {item.details?.kona && <Typography variant="caption">KONA: {item.details.kona}</Typography>}
                                                        </Box>
                                                    )}
                                                </TableCell>
                                                <TableCell>
                                                    <Typography variant="body2">{formatDate(item.timestamp)}</Typography>
                                                </TableCell>
                                            </TableRow>
                                        ))}
                                    </TableBody>
                                </Table>
                            </TableContainer>
                        )}
                    </Paper>
                </TabPanel>

                <TabPanel value={tabValue} index={2}>
                    {/* Users Tab */}
                    <Paper sx={{ p: 3 }}>
                        <Typography variant="h6" gutterBottom sx={{ fontWeight: 600 }}>
                            User Statistics
                        </Typography>
                        <TableContainer>
                            <Table>
                                <TableHead>
                                    <TableRow>
                                        <TableCell>User</TableCell>
                                        <TableCell>Team</TableCell>
                                        <TableCell>Activity</TableCell>
                                        <TableCell align="right">Projects Owned</TableCell>
                                        <TableCell align="right">Participating</TableCell>
                                        <TableCell align="right">Reviews</TableCell>
                                        <TableCell align="right">Comments</TableCell>
                                        <TableCell>Last Login</TableCell>
                                    </TableRow>
                                </TableHead>
                                <TableBody>
                                    {users.map((user) => (
                                        <TableRow key={user.username}>
                                            <TableCell>
                                                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                                                    <Avatar sx={{ width: 28, height: 28, fontSize: 12 }}>
                                                        {user.name?.charAt(0)}
                                                    </Avatar>
                                                    <Box>
                                                        <Typography variant="body2">{user.name}</Typography>
                                                        <Typography variant="caption" color="text.secondary">{user.username}</Typography>
                                                    </Box>
                                                </Box>
                                            </TableCell>
                                            <TableCell>{user.team}</TableCell>
                                            <TableCell>
                                                <Chip
                                                    label={user.activityStatus}
                                                    size="small"
                                                    color={getActivityStatusColor(user.activityStatus)}
                                                />
                                            </TableCell>
                                            <TableCell align="right">{user.projects_owned}</TableCell>
                                            <TableCell align="right">{user.projects_participating}</TableCell>
                                            <TableCell align="right">{user.reviews_modified}</TableCell>
                                            <TableCell align="right">{user.comments_added}</TableCell>
                                            <TableCell>{formatDate(user.last_login)}</TableCell>
                                        </TableRow>
                                    ))}
                                </TableBody>
                            </Table>
                        </TableContainer>
                    </Paper>
                </TabPanel>

                <TabPanel value={tabValue} index={3}>
                    {/* Projects Tab */}
                    <Paper sx={{ p: 3 }}>
                        <Typography variant="h6" gutterBottom sx={{ fontWeight: 600 }}>
                            Project Statistics
                        </Typography>
                        <TableContainer>
                            <Table>
                                <TableHead>
                                    <TableRow>
                                        <TableCell>Project</TableCell>
                                        <TableCell>Admin</TableCell>
                                        <TableCell>Status</TableCell>
                                        <TableCell align="right">Groups</TableCell>
                                        <TableCell align="right">Keys</TableCell>
                                        <TableCell>Review Progress</TableCell>
                                        <TableCell align="right">Participants</TableCell>
                                        <TableCell>Last Refreshed</TableCell>
                                    </TableRow>
                                </TableHead>
                                <TableBody>
                                    {projects.map((project) => (
                                        <TableRow key={project.project_id}>
                                            <TableCell>
                                                <Typography variant="body2" sx={{ fontWeight: 500 }}>{project.title}</Typography>
                                                <Typography variant="caption" color="text.secondary">
                                                    {project.description?.substring(0, 50)}...
                                                </Typography>
                                            </TableCell>
                                            <TableCell>{project.admin_name}</TableCell>
                                            <TableCell>
                                                <Chip
                                                    label={project.status}
                                                    size="small"
                                                    color={project.status === 'active' ? 'success' : project.status === 'syncing' ? 'info' : 'error'}
                                                />
                                            </TableCell>
                                            <TableCell align="right">{project.group_count}</TableCell>
                                            <TableCell align="right">{project.total_keys}</TableCell>
                                            <TableCell>
                                                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                                                    <LinearProgress
                                                        variant="determinate"
                                                        value={project.reviewProgress}
                                                        sx={{ width: 100, height: 8, borderRadius: 4 }}
                                                    />
                                                    <Typography variant="body2">{project.reviewProgress}%</Typography>
                                                </Box>
                                            </TableCell>
                                            <TableCell align="right">{project.participant_count}</TableCell>
                                            <TableCell>{formatDate(project.last_refreshed_at)}</TableCell>
                                        </TableRow>
                                    ))}
                                </TableBody>
                            </Table>
                        </TableContainer>
                    </Paper>
                </TabPanel>
            </Box>
        </Container>
    );
};

export default KPIDashboard;

