import mysql.connector
import pandas as pd
import json

# Database connection details
db_config = {
    'host':'localhost',
    'database':'samsung_fms_portal',
    'user':'root',
    'password':'root'
}

df = pd.read_csv(r'C:\Users\kapil\Downloads\sample key review data\sample key review data\keys_data.csv')
keyName = list(df['key_name'])
# json_data = df['chipset'].apply(lambda x: json.dumps({'chipset': x}))
# specifications = json_data.tolist()

# Default values for other attributes
models_default_values = {
    'work_assignment': 'TP_Platform',
    'work_assignment_owner': 'heong.ng',
    'description': None, 
    'has_differences': 1
}

# Connect to the database
conn = mysql.connector.connect(**db_config)
cursor = conn.cursor()

# Insert data into the Models table
for name in (keyName):
    query = """
    INSERT INTO fms_keys (key_name, work_assignment, work_assignment_owner, description, has_differences)
    VALUES (%s, %s, %s, %s, %s)
    """
    values = (name, models_default_values['work_assignment'], models_default_values['work_assignment_owner'], models_default_values['description'], models_default_values['has_differences'])
    cursor.execute(query, values)

# Commit the transaction and close the connection
conn.commit()
cursor.close()
conn.close()