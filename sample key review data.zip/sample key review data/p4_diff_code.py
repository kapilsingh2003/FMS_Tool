import json
import pandas as pd
import requests
import time

# Base URL of the API
BASE_URL = "http://107.108.161.134:8000/"

# Change the file path accordingly (will fetch from DB)
model_data = pd.read_csv(r"C:\Users\karan.ch\Desktop\FMS Portal\py github\FMS_Tool-master_py\backend_python\temp_code\FMS_Model.csv")
branch_data = pd.read_csv(r"C:\Users\karan.ch\Desktop\FMS Portal\py github\FMS_Tool-master_py\backend_python\temp_code\FMS_Branch.csv")


# Function to get difference sheet data of a group with multiple models via P4 (currently code works for only "TV" models)
def get_dif_from_p4(branch_list, model_list_2d, model_data, branch_data):
    file_paths = []
    fms_tables = []
    for model_list in model_list_2d:
        master_data = {
            "arr": [],
            "has_reference": "false"
        }
        for ind in range(0, len(branch_list)):
            branch_name = branch_list[ind]
            branch_path = branch_data.loc[branch_data['name'] == branch_name, 'path'].values[0]

            model_name = model_list[ind]
            chipset = model_data.loc[model_data['name'] == model_name, 'chipset'].values[0]

            new_entry = {
                "delta_path": f"{branch_path}FEATURECONFIG/Feature-config/feature-config-data/csv/delta/TV/{chipset}",  # (currently code works for only "TV" models)
                "model": model_name,
                "changelist": 0
            }
            master_data["arr"].append(new_entry)

        print(master_data)
        api_result = requests.post(f"{BASE_URL}multi_model/process", json=master_data)
        file_path = api_result.json()['data']['file_path']
        fms_table = api_result.json()['data']['fms_table']
        file_paths.append(file_path)
        fms_tables.append(fms_table)

    # Converting data to df
    data_frame_list = []
    for fms_table in fms_tables:
        df = pd.DataFrame(fms_table)
        data_frame_list.append(df)

    return data_frame_list


# Start time
start_time = time.time()

# b = ["[TIZENPROD_Prj]", "[Trunk_2025_MP_Prj]"]
# m = [
#     ["M80D", "M80D"],
#     ["G70D", "G70D"]
# ]
# b = ["[TIZENPROD_Prj]", "[Trunk_2025_MP_Prj]", "[SmartMonitor_2025_MP_Prj]"]
# m = [
#     ["M80D", "M80D", "M80F"],
#     ["G70D", "G70D", "M80F"],
#     ["G80SD", "G80SD", "M80F"],
#     ["G85SD", "G85SD", "M80F"],
#     ["M70D", "M70D", "M80F"]
# ]



b = ["[Trunk_2025_MP_Prj]", "[TIZENPROD_Prj]", "[Trunk_2024_MonitorRC_MP_Prj]", "[BizTV_2025_MP_Prj]"]
m = [
    ["BED_H", "BED_H", "BED_H", "BEFX_H2"],
    ["BED_HA", "BED_HA", "BED_HA", "BEFX_H2"],
    ["BED_HB", "BED_HB", "BED_HB", "BEFX_H2"]
]



df_list = get_dif_from_p4(branch_list=b, model_list_2d=m, branch_data=branch_data, model_data=model_data)


print(len(df_list))
print(len(df_list[0]))
print(len(df_list[1]))

i = -1
for df in df_list:
    i = i+1
    df.to_csv(f"model_comp_group_3_{m[i][0]}.csv")



# End time
end_time = time.time()

# Calculate and print execution time
execution_time = end_time - start_time
print(f"Execution Time: {execution_time:.2f} seconds")










# import json
# import pandas as pd
# import requests


# # Base URL of the API
# BASE_URL = "http://107.108.161.134:8000/"

# # change the file path accordingly (will fetch from DB)
# model_data = pd.read_csv(r"C:\Users\karan.ch\Desktop\FMS Portal\py github\FMS_Tool-master_py\backend_python\temp_code\FMS_Model.csv")
# branch_data = pd.read_csv(r"C:\Users\karan.ch\Desktop\FMS Portal\py github\FMS_Tool-master_py\backend_python\temp_code\FMS_Branch.csv")


# # Function to get difference sheet data of a group with multiple models via P4 (currently code works for only "TV" models)
# def get_dif_from_p4(branch_list , model_list_2d, model_data, branch_data):
#     file_paths = []
#     fms_tables = []
#     for model_list in model_list_2d:
#         master_data = {
#         "arr": [],
#         "has_reference": "false"
#         }
#         for ind in range(0,len(branch_list)):
#             branch_name = branch_list[ind]
#             branch_path = branch_data.loc[branch_data['name'] == branch_name, 'path'].values[0]

#             model_name = model_list[ind]
#             chipset = model_data.loc[model_data['name'] == model_name, 'chipset'].values[0]
        
#             new_entry = {
#                 "delta_path": f"{branch_path}FEATURECONFIG/Feature-config/feature-config-data/csv/delta/TV/{chipset}",  # (currently code works for only "TV" models)
#                 "model": model_name,
#                 "changelist": 0
#             }
#             master_data["arr"].append(new_entry)

#         print(master_data)        
#         api_result = requests.post(f"{BASE_URL}multi_model/process", json=master_data)
#         file_path = api_result.json()['data']['file_path']
#         fms_table = api_result.json()['data']['fms_table']
#         file_paths.append(file_path)
#         fms_tables.append(fms_table)


#     # coverting data to df
#     data_frame_list = []
#     for fms_table in fms_tables:
#         df = pd.DataFrame(fms_table)
#         data_frame_list.append(df)

#     return data_frame_list





# b = ["[TIZENPROD_Prj]" , "[Trunk_2025_MP_Prj]" , "[SmartMonitor_2025_MP_Prj]" ]


# m = [
# ["M80D" , "M80D" , "M80F" ],
# ["G70D" , "G70D" , "M80F" ],
# ["G80SD" , "G80SD" , "M80F" ],
# ["G85SD" , "G85SD" , "M80F" ],
# ["M70D" , "M70D" , "M80F" ]
# ]

# df_list = get_dif_from_p4(branch_list= b, model_list_2d=m, branch_data=branch_data , model_data=model_data)

# print(len(df_list))
# print(len(df_list[0]))
# print(len(df_list[1]))