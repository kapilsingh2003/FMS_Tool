-- Samsung FMS Portal - Current Database Schema
-- This matches the ACTUAL database structure currently in use
-- Database: samsung_fms_portal
-- Last Updated: January 2026 (includes comment verification and official projects)

DROP DATABASE IF EXISTS samsung_fms_portal;
CREATE DATABASE samsung_fms_portal;
USE samsung_fms_portal;

-- 1. Users table (authentication and basic user info)
CREATE TABLE `Users` (
    username VARCHAR(50) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    password VARCHAR(255) NOT NULL,
    user_type ENUM('admin', 'user') NOT NULL DEFAULT 'user',
    email VARCHAR(255) UNIQUE NOT NULL,
    team ENUM('ENT_SM', 'CTV', 'ENT_TV') NOT NULL,
    is_verified BOOLEAN DEFAULT FALSE,
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_login TIMESTAMP NULL,
    INDEX idx_user_type (user_type),
    INDEX idx_team (team),
    INDEX idx_verified (is_verified)
);

-- 2. Projects table (FMS comparison projects - includes official project support)
CREATE TABLE `Projects` (
    project_id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    admin_username VARCHAR(50) NOT NULL,
    refresh_schedule ENUM('Daily', 'Weekly', 'Monthly') DEFAULT 'Weekly',
    status ENUM('active', 'syncing', 'sync error') DEFAULT 'syncing',
    -- Official project fields
    is_official BOOLEAN DEFAULT FALSE,
    swplm_project_name VARCHAR(255) NULL,
    project_lead_username VARCHAR(50) NULL,
    project_manager_username VARCHAR(50) NULL,
    target_completion_date DATE NULL,
    pm_approval_status ENUM('not_submitted', 'pending', 'approved', 'rejected') DEFAULT 'not_submitted',
    pm_submitted_at TIMESTAMP NULL,
    pm_approved_at TIMESTAMP NULL,
    pm_rejection_reason TEXT NULL,
    -- Creation approval fields (PM must approve official project creation before it can be accessed)
    creation_approval_status ENUM('not_required', 'pending', 'approved', 'rejected') DEFAULT 'not_required',
    creation_approved_at TIMESTAMP NULL,
    creation_rejection_reason TEXT NULL,
    -- Timestamps
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (admin_username) REFERENCES `Users`(username) ON DELETE CASCADE,
    INDEX idx_status (status),
    INDEX idx_admin (admin_username),
    INDEX idx_is_official (is_official),
    INDEX idx_pm_approval_status (pm_approval_status),
    INDEX idx_project_lead (project_lead_username),
    INDEX idx_project_manager (project_manager_username),
    INDEX idx_target_completion_date (target_completion_date),
    INDEX idx_creation_approval_status (creation_approval_status)
);

-- 3. Project_Participants table (users in projects with project-specific roles)
-- Includes 'pl' (Project Lead) and 'pm' (Project Manager) roles for official projects
CREATE TABLE `Project_Participants` (
    participant_id INT AUTO_INCREMENT PRIMARY KEY,
    project_id INT NOT NULL,
    user_username VARCHAR(50) NOT NULL,
    added_by VARCHAR(50) NOT NULL,
    participant_role ENUM('admin', 'reviewer', 'viewer', 'pl', 'pm') NOT NULL DEFAULT 'viewer',
    joined_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (project_id) REFERENCES `Projects`(project_id) ON DELETE CASCADE,
    FOREIGN KEY (user_username) REFERENCES `Users`(username) ON DELETE CASCADE,
    FOREIGN KEY (added_by) REFERENCES `Users`(username) ON DELETE CASCADE,
    UNIQUE KEY unique_project_user (project_id, user_username),
    INDEX idx_project (project_id),
    INDEX idx_user (user_username),
    INDEX idx_role (participant_role)
);

-- 4. Branches table (available branches for comparison)
CREATE TABLE `Branches` (
    branch_id INT AUTO_INCREMENT PRIMARY KEY,
    branch_name VARCHAR(255) UNIQUE NOT NULL,
    branch_type VARCHAR(50),
    branch_path VARCHAR(500),
    is_active BOOLEAN DEFAULT TRUE,
    INDEX idx_active (is_active),
    INDEX idx_type (branch_type)
);

-- 5. Models table (monitor/TV models)
CREATE TABLE `Models` (
    model_id INT AUTO_INCREMENT PRIMARY KEY,
    model_name VARCHAR(50) UNIQUE NOT NULL,
    product_category VARCHAR(255),
    chipset VARCHAR(100),
    is_active BOOLEAN DEFAULT TRUE,
    INDEX idx_category (product_category),
    INDEX idx_active (is_active)
);

-- 6. Groups table (comparison groups within projects) - renamed to grps to avoid reserved word
CREATE TABLE `grps` (
    group_id INT AUTO_INCREMENT PRIMARY KEY,
    project_id INT NOT NULL,
    name VARCHAR(255) NOT NULL,
    comparison_type ENUM('2-way', '3-way', '4-way', '2-way-vs-2-way') NOT NULL,
    target_branch_id INT,
    ref1_branch_id INT,
    ref2_branch_id INT,
    ref3_branch_id INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (project_id) REFERENCES `Projects`(project_id) ON DELETE CASCADE,
    FOREIGN KEY (target_branch_id) REFERENCES `Branches`(branch_id) ON DELETE CASCADE,
    FOREIGN KEY (ref1_branch_id) REFERENCES `Branches`(branch_id) ON DELETE CASCADE,
    FOREIGN KEY (ref2_branch_id) REFERENCES `Branches`(branch_id) ON DELETE CASCADE,
    FOREIGN KEY (ref3_branch_id) REFERENCES `Branches`(branch_id) ON DELETE CASCADE,
    INDEX idx_project (project_id),
    INDEX idx_comparison_type (comparison_type),
    INDEX idx_target_branch (target_branch_id),
    INDEX idx_ref1_branch (ref1_branch_id),
    INDEX idx_ref2_branch (ref2_branch_id),
    INDEX idx_ref3_branch (ref3_branch_id)
);

-- 7. Branch_Model_Mapping table (which models exist in which branches)
CREATE TABLE `Branch_Model_Mapping` (
    bmm_id INT AUTO_INCREMENT PRIMARY KEY,
    branch_id INT NOT NULL,
    model_id INT NOT NULL,
    is_available BOOLEAN DEFAULT TRUE,
    FOREIGN KEY (branch_id) REFERENCES `Branches`(branch_id) ON DELETE CASCADE,
    FOREIGN KEY (model_id) REFERENCES `Models`(model_id) ON DELETE CASCADE,
    UNIQUE KEY unique_branch_model (branch_id, model_id),
    INDEX idx_branch (branch_id),
    INDEX idx_model (model_id)
);

-- 8. Group_Model_Mapping table (specific models used in group-branch combinations)
CREATE TABLE `Group_Model_Mapping` (
    gm_id INT AUTO_INCREMENT PRIMARY KEY,
    group_id INT NOT NULL,
    target_model_id INT NOT NULL,
    ref1_model_id INT,
    ref2_model_id INT,
    ref3_model_id INT,
    FOREIGN KEY (group_id) REFERENCES `grps`(group_id) ON DELETE CASCADE,
    FOREIGN KEY (target_model_id) REFERENCES `Models`(model_id) ON DELETE CASCADE,
    FOREIGN KEY (ref1_model_id) REFERENCES `Models`(model_id) ON DELETE CASCADE,
    FOREIGN KEY (ref2_model_id) REFERENCES `Models`(model_id) ON DELETE CASCADE,
    FOREIGN KEY (ref3_model_id) REFERENCES `Models`(model_id) ON DELETE CASCADE,
    UNIQUE KEY unique_gb_model (group_id, target_model_id, ref1_model_id, ref2_model_id, ref3_model_id),
    INDEX idx_gb (group_id),
    INDEX idx_target_model (target_model_id),
    INDEX idx_ref1_model (ref1_model_id),
    INDEX idx_ref2_model (ref2_model_id),
    INDEX idx_ref3_model (ref3_model_id)
);

-- 9. FMS_Keys table (feature management system keys)
CREATE TABLE `FMS_Keys` (
    fms_key_id INT AUTO_INCREMENT PRIMARY KEY,
    key_name VARCHAR(255) UNIQUE NOT NULL,
    work_assignment VARCHAR(100),
    work_assignment_owner VARCHAR(100),
    description TEXT,
    has_differences BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_work_assignment (work_assignment),
    INDEX idx_owner (work_assignment_owner),
    INDEX idx_differences (has_differences)
);

-- 10. Key_Reviews table (review data for FMS keys)
CREATE TABLE `Key_Reviews` (
    key_review_id INT AUTO_INCREMENT PRIMARY KEY,
    fms_key_id INT NOT NULL,
    gm_id INT NOT NULL,
    group_id INT NOT NULL,
    target_val TEXT,
    ref1_val TEXT,
    ref2_val TEXT,
    ref3_val TEXT,
    comment TEXT,
    status ENUM('unreviewed', 'changes_made', 'pending_response', 'no_change_req', 'internal_discussion', 'changes_in_progress', 'value_changed') DEFAULT 'unreviewed',
    kona_ids TEXT,
    cl_numbers TEXT,
    reviewed_by_username VARCHAR(50),
    reviewed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (fms_key_id) REFERENCES `FMS_Keys`(fms_key_id) ON DELETE CASCADE,
    FOREIGN KEY (gm_id) REFERENCES `Group_Model_Mapping`(gm_id) ON DELETE CASCADE,
    FOREIGN KEY (group_id) REFERENCES `grps`(group_id) ON DELETE CASCADE,
    FOREIGN KEY (reviewed_by_username) REFERENCES `Users`(username) ON DELETE SET NULL,
    UNIQUE KEY unique_key_gm_group (fms_key_id, gm_id, group_id),
    INDEX idx_fms_key (fms_key_id),
    INDEX idx_gm (gm_id),
    INDEX idx_group (group_id),
    INDEX idx_status (status),
    INDEX idx_reviewer (reviewed_by_username)
);

-- 11. Comments table (multiple comments for each key review - includes verification)
CREATE TABLE `Comments` (
    comment_id INT AUTO_INCREMENT PRIMARY KEY,
    key_review_id INT NOT NULL,
    comment_text TEXT NOT NULL,
    -- Verification fields: comments by admins are auto-verified, others need admin approval
    verification_status ENUM('pending', 'verified') NOT NULL DEFAULT 'pending',
    verified_by_username VARCHAR(50) NULL,
    verified_at TIMESTAMP NULL,
    -- Comment metadata
    commented_by_username VARCHAR(50) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (key_review_id) REFERENCES `Key_Reviews`(key_review_id) ON DELETE CASCADE,
    FOREIGN KEY (commented_by_username) REFERENCES `Users`(username) ON DELETE CASCADE,
    INDEX idx_key_review (key_review_id),
    INDEX idx_commented_by (commented_by_username),
    INDEX idx_created_at (created_at),
    INDEX idx_verification_status (verification_status)
);

-- 12. Activity_Log table (tracks user activities for KPIs)
CREATE TABLE `Activity_Log` (
    log_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL,
    action_type ENUM(
        'key_review_update',
        'comment_add',
        'comment_edit',
        'project_create',
        'project_edit',
        'project_delete',
        'project_refresh',
        'user_login',
        'user_signup',
        'participant_add',
        'participant_remove',
        'pm_approval_submit',
        'pm_approval_approve',
        'pm_approval_reject'
    ) NOT NULL,
    entity_type ENUM('project', 'key_review', 'comment', 'user') NOT NULL,
    entity_id INT,
    project_id INT,
    details JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (username) REFERENCES `Users`(username) ON DELETE CASCADE,
    INDEX idx_username (username),
    INDEX idx_action_type (action_type),
    INDEX idx_entity_type (entity_type),
    INDEX idx_project_id (project_id),
    INDEX idx_created_at (created_at)
);

-- System user for automated comments and KPI access
INSERT INTO `Users` (username, name, password, user_type, email, team, is_verified)
VALUES ('system', 'System', '$2a$10$systempasswordhashnotusedforlogin', 'admin', 'system@samsung.com', 'ENT_SM', true)
ON DUPLICATE KEY UPDATE name = 'System';
