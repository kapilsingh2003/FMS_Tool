import React, { createContext, useState, useContext, useEffect } from 'react';
import Cookies from 'js-cookie';
import { authAPI } from '../services/api';

const AuthContext = createContext();

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  // User roles - for backwards compatibility and project-specific roles
  const USER_ROLES = {
    ADMIN: 'admin',
    REVIEWER: 'reviewer',
    VIEWER: 'viewer'
  };

  // User types - global user classification
  const USER_TYPES = {
    ADMIN: 'admin',
    USER: 'user'
  };

  // Check for existing authentication on app load
  useEffect(() => {
    const validateStoredAuth = async () => {
      const storedUser = Cookies.get('user');
      const token = localStorage.getItem('token');

      if (storedUser && token) {
        try {
          // Validate token by making a test API call
          const result = await authAPI.getCurrentUser();

          if (result.success) {
            // Token is valid, set user
            setUser(JSON.parse(storedUser));
            console.log('Restored valid session for:', JSON.parse(storedUser).username);
          } else {
            // Token is invalid, clear stored data
            console.log('Stored token is invalid, clearing session');
            Cookies.remove('user');
            localStorage.removeItem('token');
          }
        } catch (error) {
          console.error('Error parsing stored user:', error);
          Cookies.remove('user');
          localStorage.removeItem('token');
        }
      }
      setLoading(false);
    };

    validateStoredAuth();
  }, []);

  const login = async (username, password) => {
    try {
      const result = await authAPI.login(username, password);

      if (result.success) {
        const userData = result.data.user;
        const token = result.data.token;

        // Store token first
        localStorage.setItem('token', token);
        // Then store user data
        Cookies.set('user', JSON.stringify(userData), { expires: 7 });
        // Signal that this is a fresh login so the announcement banner shows
        sessionStorage.setItem('showAnnouncement', 'true');
        // Finally update state
        setUser(userData);

        console.log('Login successful:', { username: userData.username, hasToken: !!token });

        return { success: true, user: userData };
      } else {
        console.error('Login failed:', result.error);
        return { success: false, error: result.error };
      }
    } catch (error) {
      return { success: false, error: error.message };
    }
  };

  const signup = async (userData) => {
    try {
      const result = await authAPI.signup(userData);

        if (result.success) {
        const newUser = result.data.user;
        const token = result.data.token;

        // Auto-login after signup
        setUser(newUser);
        Cookies.set('user', JSON.stringify(newUser), { expires: 7 });
        localStorage.setItem('token', token);
        // Signal that this is a fresh sign-in so the announcement banner shows
        sessionStorage.setItem('showAnnouncement', 'true');

        return { success: true, user: newUser };
      } else {
        return { success: false, error: result.error };
      }
    } catch (error) {
      return { success: false, error: error.message };
    }
  };

  const logout = () => {
    setUser(null);
    Cookies.remove('user');
    localStorage.removeItem('token');
  };

  // OTP functions for signup
  const sendOtp = async (knoxId) => {
    try {
      const result = await authAPI.sendOtp(knoxId);
      return result;
    } catch (error) {
      return { success: false, error: error.message };
    }
  };

  const verifyOtp = async (knoxId, otp) => {
    try {
      const result = await authAPI.verifyOtp(knoxId, otp);
      return result;
    } catch (error) {
      return { success: false, error: error.message };
    }
  };

  const hasRole = (requiredRole) => {
    if (!user) return false;

    const roleHierarchy = {
      [USER_ROLES.VIEWER]: 1,
      [USER_ROLES.REVIEWER]: 2,
      [USER_ROLES.ADMIN]: 3
    };

    // For backwards compatibility, use user.role if it exists, otherwise use user_type
    const userRole = user.role || (user.user_type === 'admin' ? USER_ROLES.ADMIN : USER_ROLES.VIEWER);
    return roleHierarchy[userRole] >= roleHierarchy[requiredRole];
  };

  // Helper function to check if user is global admin
  const isGlobalAdmin = () => {
    return user && user.user_type === 'admin';
  };

  // Helper function to check project-specific role
  const hasProjectRole = (projectId, requiredRole) => {
    // This would need to be implemented with project-specific role data
    // For now, return true for global admins
    return isGlobalAdmin();
  };

  const value = {
    user,
    login,
    signup,
    logout,
    sendOtp,
    verifyOtp,
    hasRole,
    isGlobalAdmin,
    hasProjectRole,
    loading,
    USER_ROLES,
    USER_TYPES
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
}; 