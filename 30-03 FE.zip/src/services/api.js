import axios from 'axios';

// Create axios instance with base configuration
const api = axios.create({
    baseURL: 'http://localhost:5000',
    timeout: 0, // No timeout for refresh operations
    headers: {
        'Content-Type': 'application/json',
    },
});

// Request interceptor for adding auth headers
api.interceptors.request.use(
    (config) => {
        // Add auth token from localStorage if available
        const token = localStorage.getItem('token');
        if (token) {
            config.headers.Authorization = `Bearer ${token}`;
        }
        return config;
    },
    (error) => {
        return Promise.reject(error);
    }
);

// Response interceptor for error handling
api.interceptors.response.use(
    (response) => {
        return response;
    },
    (error) => {
        console.error('API Error:', error.response?.data || error.message);

        // Handle authentication errors
        if (error.response?.status === 401) {
            console.warn('Authentication failed on:', error.config?.url);

            // Clear stored token and user data
            localStorage.removeItem('token');
            // Clear cookies too  
            document.cookie = 'user=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;';

            // Only redirect if we're not already on auth pages
            if (window.location.pathname !== '/login' && window.location.pathname !== '/signup') {
                console.warn('Redirecting to login due to authentication failure');
                window.location.href = '/login';
            }
        }

        return Promise.reject(error);
    }
);

// Auth API
export const authAPI = {
    login: async (username, password) => {
        try {
            const response = await api.post('/api/auth/login', { username, password });
            return { success: true, data: response.data };
        } catch (error) {
            return {
                success: false,
                error: error.response?.data?.message || 'Login failed'
            };
        }
    },

    signup: async (userData) => {
        try {
            const response = await api.post('/api/auth/signup', userData);
            return { success: true, data: response.data };
        } catch (error) {
            return {
                success: false,
                error: error.response?.data?.message || 'Signup failed'
            };
        }
    },

    sendOtp: async (knoxId) => {
        try {
            const response = await api.post('/api/auth/send-otp', { knoxId });
            return { success: true, data: response.data };
        } catch (error) {
            return {
                success: false,
                error: error.response?.data?.message || 'Failed to send OTP'
            };
        }
    },

    verifyOtp: async (knoxId, otp) => {
        try {
            const response = await api.post('/api/auth/verify-otp', { knoxId, otp });
            return { success: true, data: response.data };
        } catch (error) {
            return {
                success: false,
                error: error.response?.data?.message || 'OTP verification failed'
            };
        }
    },

    getCurrentUser: async () => {
        try {
            const response = await api.get('/api/auth/me');
            return { success: true, data: response.data };
        } catch (error) {
            return {
                success: false,
                error: error.response?.data?.message || 'Failed to get user info'
            };
        }
    },

    changePassword: async (currentPassword, newPassword) => {
        try {
            const response = await api.post('/api/auth/change-password', {
                currentPassword,
                newPassword
            });
            return { success: true, data: response.data };
        } catch (error) {
            return {
                success: false,
                error: error.response?.data?.message || 'Failed to change password'
            };
        }
    }
};

// Projects API
export const projectsAPI = {
    getAllProjects: async () => {
        try {
            const response = await api.get('/api/projects');
            return { success: true, data: response.data };
        } catch (error) {
            return { success: false, error: error.response?.data?.message || error.message };
        }
    },

    getProject: async (projectId) => {
        try {
            const response = await api.get(`/api/projects/${projectId}`);
            return { success: true, data: response.data.project };
        } catch (error) {
            return { success: false, error: error.response?.data?.message || error.message };
        }
    },

    createProject: async (projectData) => {
        try {
            const response = await api.post('/api/projects', projectData);
            return { success: true, data: response.data };
        } catch (error) {
            return { success: false, error: error.response?.data?.message || error.message };
        }
    },

    updateProject: async (projectId, projectData) => {
        try {
            const response = await api.put(`/api/projects/${projectId}`, projectData);
            return { success: true, data: response.data };
        } catch (error) {
            return { success: false, error: error.response?.data?.message || error.message };
        }
    },

    deleteProject: async (projectId) => {
        try {
            const response = await api.delete(`/api/projects/${projectId}`);
            return { success: true, data: response.data };
        } catch (error) {
            return { success: false, error: error.response?.data?.message || error.message };
        }
    },

    getProjectGroups: async (projectId) => {
        try {
            const response = await api.get(`/api/projects/${projectId}/groups`);
            return { success: true, data: response.data };
        } catch (error) {
            return { success: false, error: error.response?.data?.message || error.message };
        }
    },

    createGroup: async (projectId, groupData) => {
        try {
            const response = await api.post(`/api/projects/${projectId}/groups`, groupData);
            return { success: true, data: response.data };
        } catch (error) {
            return { success: false, error: error.response?.data?.message || error.message };
        }
    },

    getProjectReviews: async (projectId) => {
        try {
            const response = await api.get(`/api/projects/${projectId}/reviews`);
            return { success: true, data: response.data };
        } catch (error) {
            return { success: false, error: error.response?.data?.message || error.message };
        }
    },

    getProjectStats: async (projectId) => {
        try {
            const response = await api.get(`/api/projects/${projectId}/stats`);
            return { success: true, data: response.data };
        } catch (error) {
            return { success: false, error: error.response?.data?.message || error.message };
        }
    },

    addParticipant: async (projectId, username, role) => {
        try {
            const response = await api.post(`/api/projects/${projectId}/participants`, { username, role });
            return { success: true, data: response.data };
        } catch (error) {
            return { success: false, error: error.response?.data?.message || error.message };
        }
    },

    removeParticipant: async (projectId, username) => {
        try {
            const response = await api.delete(`/api/projects/${projectId}/participants/${username}`);
            return { success: true, data: response.data };
        } catch (error) {
            return { success: false, error: error.response?.data?.message || error.message };
        }
    },

    refreshProject: async (projectId) => {
        try {
            const response = await api.post(`/api/projects/${projectId}/refresh`);
            return { success: true, data: response.data };
        } catch (error) {
            return { success: false, error: error.response?.data?.message || error.message };
        }
    },

    // Official Project API methods
    getOfficialProjects: async () => {
        try {
            const response = await api.get('/api/projects/official/list');
            return { success: true, data: response.data.projects };
        } catch (error) {
            return { success: false, error: error.response?.data?.message || error.message };
        }
    },

    submitForPMApproval: async (projectId) => {
        try {
            const response = await api.post(`/api/projects/${projectId}/submit-for-approval`);
            return { success: true, data: response.data };
        } catch (error) {
            return { success: false, error: error.response?.data?.message || error.message };
        }
    },

    approveProject: async (projectId) => {
        try {
            const response = await api.post(`/api/projects/${projectId}/approve`);
            return { success: true, data: response.data };
        } catch (error) {
            return { success: false, error: error.response?.data?.message || error.message };
        }
    },

    rejectProject: async (projectId, reason) => {
        try {
            const response = await api.post(`/api/projects/${projectId}/reject`, { reason });
            return { success: true, data: response.data };
        } catch (error) {
            return { success: false, error: error.response?.data?.message || error.message };
        }
    },

    // Creation Approval - PM approves/rejects project creation
    approveCreation: async (projectId) => {
        try {
            const response = await api.post(`/api/projects/${projectId}/approve-creation`);
            return { success: true, data: response.data };
        } catch (error) {
            return { success: false, error: error.response?.data?.message || error.message };
        }
    },

    rejectCreation: async (projectId, reason) => {
        try {
            const response = await api.post(`/api/projects/${projectId}/reject-creation`, { reason });
            return { success: true, data: response.data };
        } catch (error) {
            return { success: false, error: error.response?.data?.message || error.message };
        }
    },

    getPendingCreationApproval: async () => {
        try {
            const response = await api.get('/api/projects/pending-creation-approval');
            return { success: true, data: response.data.projects };
        } catch (error) {
            return { success: false, error: error.response?.data?.message || error.message };
        }
    }
};

// Reference API
export const referenceAPI = {
    getModels: async () => {
        try {
            const response = await api.get('/api/reference/models');
            return { success: true, data: response.data.data };
        } catch (error) {
            return {
                success: false,
                error: error.response?.data?.message || 'Failed to fetch models'
            };
        }
    },

    getBranches: async () => {
        try {
            const response = await api.get('/api/reference/branches');
            return { success: true, data: response.data.data };
        } catch (error) {
            return {
                success: false,
                error: error.response?.data?.message || 'Failed to fetch branches'
            };
        }
    },

    searchBranches: async (searchTerm) => {
        try {
            const response = await api.get(`/api/reference/branches/search?q=${encodeURIComponent(searchTerm)}`);
            return { success: true, data: response.data.data };
        } catch (error) {
            return {
                success: false,
                error: error.response?.data?.message || 'Failed to search branches'
            };
        }
    },

    searchModels: async (searchTerm) => {
        try {
            const response = await api.get(`/api/reference/models/search?q=${encodeURIComponent(searchTerm)}`);
            return { success: true, data: response.data.data };
        } catch (error) {
            return {
                success: false,
                error: error.response?.data?.message || 'Failed to search models'
            };
        }
    },

    getModelsInBranch: async (branchId) => {
        try {
            const response = await api.get(`/api/reference/models/branch/${branchId}`);
            return { success: true, data: response.data.data };
        } catch (error) {
            return {
                success: false,
                error: error.response?.data?.message || 'Failed to fetch models for branch'
            };
        }
    },

    getModelsByBranchName: async (branchName) => {
        try {
            const response = await api.get(`/api/reference/models/branch/${encodeURIComponent(branchName)}/by-name`);
            return { success: true, data: response.data.data };
        } catch (error) {
            return {
                success: false,
                error: error.response?.data?.message || 'Failed to fetch models for branch'
            };
        }
    },

    validateBranchModel: async (branchId, modelId) => {
        try {
            const response = await api.post('/api/reference/validate-branch-model', { branchId, modelId });
            return { success: true, data: response.data };
        } catch (error) {
            return {
                success: false,
                error: error.response?.data?.message || 'Failed to validate branch-model compatibility'
            };
        }
    },

    getFMSKeys: async (withDifferences = false) => {
        try {
            const url = withDifferences ? '/api/reference/fms-keys?with_differences=true' : '/api/reference/fms-keys';
            const response = await api.get(url);
            return { success: true, data: response.data };
        } catch (error) {
            return {
                success: false,
                error: error.response?.data?.message || 'Failed to fetch FMS keys'
            };
        }
    },

    getWorkAssignments: async () => {
        try {
            const response = await api.get('/api/reference/work-assignments');
            return { success: true, data: response.data };
        } catch (error) {
            return {
                success: false,
                error: error.response?.data?.message || 'Failed to fetch work assignments'
            };
        }
    },

    getAvailableModelsForGroup: async (groupId) => {
        try {
            const response = await api.get(`/api/reference/group/${groupId}/available-models`);
            return { success: true, data: response.data };
        } catch (error) {
            return {
                success: false,
                error: error.response?.data?.message || 'Failed to fetch available models for group'
            };
        }
    }
};

// Users API (Admin only)
export const usersAPI = {
    getAllUsers: async () => {
        try {
            const response = await api.get('/api/users');
            return { success: true, data: response.data };
        } catch (error) {
            return { success: false, error: error.response?.data?.message || error.message };
        }
    },

    getUser: async (username) => {
        try {
            const response = await api.get(`/api/users/${username}`);
            return { success: true, data: response.data };
        } catch (error) {
            return { success: false, error: error.response?.data?.message || error.message };
        }
    },

    updateUser: async (username, userData) => {
        try {
            const response = await api.put(`/api/users/${username}`, userData);
            return { success: true, data: response.data };
        } catch (error) {
            return { success: false, error: error.response?.data?.message || error.message };
        }
    },

    deleteUser: async (username) => {
        try {
            const response = await api.delete(`/api/users/${username}`);
            return { success: true, data: response.data };
        } catch (error) {
            return { success: false, error: error.response?.data?.message || error.message };
        }
    },

    addUserToProject: async (username, projectId, role = 'viewer') => {
        try {
            const response = await api.post(`/api/users/${username}/projects/${projectId}`, { role });
            return { success: true, data: response.data };
        } catch (error) {
            return { success: false, error: error.response?.data?.message || error.message };
        }
    },

    updateUserProjectRole: async (username, projectId, role) => {
        try {
            const response = await api.put(`/api/users/${username}/projects/${projectId}/role`, { role });
            return { success: true, data: response.data };
        } catch (error) {
            return { success: false, error: error.response?.data?.message || error.message };
        }
    },

    removeUserFromProject: async (username, projectId) => {
        try {
            const response = await api.delete(`/api/users/${username}/projects/${projectId}`);
            return { success: true, data: response.data };
        } catch (error) {
            return { success: false, error: error.response?.data?.message || error.message };
        }
    },

    getUserProjects: async (username) => {
        try {
            const response = await api.get(`/api/users/${username}/projects`);
            return { success: true, data: response.data };
        } catch (error) {
            return { success: false, error: error.response?.data?.message || error.message };
        }
    }
};

// Key Review API
export const keyReviewAPI = {
    getProjectReviews: async (projectId) => {
        try {
            const response = await api.get(`/api/keyreviews/project/${projectId}`);
            return { success: true, data: response.data };
        } catch (error) {
            return { success: false, error: error.response?.data?.message || error.message };
        }
    },

    getGroupReviews: async (groupId) => {
        try {
            const response = await api.get(`/api/keyreviews/group/${groupId}`);
            return { success: true, data: response.data };
        } catch (error) {
            return { success: false, error: error.response?.data?.message || error.message };
        }
    },

    createOrUpdateReview: async (reviewData) => {
        try {
            const response = await api.post('/api/keyreviews', reviewData);
            return { success: true, data: response.data };
        } catch (error) {
            return { success: false, error: error.response?.data?.message || error.message };
        }
    },

    updateReviewStatus: async (reviewId, status) => {
        try {
            const response = await api.put(`/api/keyreviews/${reviewId}/status`, { status });
            return { success: true, data: response.data };
        } catch (error) {
            return { success: false, error: error.response?.data?.message || error.message };
        }
    },

    updateReviewValues: async (reviewId, values) => {
        try {
            const response = await api.put(`/api/keyreviews/${reviewId}/values`, values);
            return { success: true, data: response.data };
        } catch (error) {
            return { success: false, error: error.response?.data?.message || error.message };
        }
    },

    updateReviewComment: async (reviewId, comment) => {
        try {
            const response = await api.put(`/api/keyreviews/${reviewId}/comment`, { comment });
            return { success: true, data: response.data };
        } catch (error) {
            return { success: false, error: error.response?.data?.message || error.message };
        }
    },

    updateKonaIds: async (reviewId, kona_ids) => {
        try {
            const response = await api.put(`/api/keyreviews/${reviewId}/kona`, { kona_ids });
            return { success: true, data: response.data };
        } catch (error) {
            return { success: false, error: error.response?.data?.message || error.message };
        }
    },

    updateClNumbers: async (reviewId, cl_numbers) => {
        try {
            const response = await api.put(`/api/keyreviews/${reviewId}/cl`, { cl_numbers });
            return { success: true, data: response.data };
        } catch (error) {
            return { success: false, error: error.response?.data?.message || error.message };
        }
    },

    getProjectStats: async (projectId) => {
        try {
            const response = await api.get(`/api/keyreviews/project/${projectId}/stats`);
            return { success: true, data: response.data };
        } catch (error) {
            return { success: false, error: error.response?.data?.message || error.message };
        }
    },

    getRecentActivity: async (projectId, limit = 10) => {
        try {
            const response = await api.get(`/api/keyreviews/project/${projectId}/activity?limit=${limit}`);
            return { success: true, data: response.data };
        } catch (error) {
            return { success: false, error: error.response?.data?.message || error.message };
        }
    },

    deleteReview: async (reviewId) => {
        try {
            const response = await api.delete(`/api/keyreviews/${reviewId}`);
            return { success: true, data: response.data };
        } catch (error) {
            return { success: false, error: error.response?.data?.message || error.message };
        }
    },

    // Get all keys with comments across all projects (read-only)
    getAllComments: async () => {
        try {
            const response = await api.get('/api/keyreviews/all-comments');
            return { success: true, data: response.data };
        } catch (error) {
            return { success: false, error: error.response?.data?.message || error.message };
        }
    },

    generateAISummary: async (fmsKey, fmsKeyDescription, jsonData) => {
        try {
            const response = await api.post('/api/keyreviews/ai-summary', {
                fmsKey,
                fmsKeyDescription,
                jsonData
            }, { timeout: 125000 }); // 125s client timeout (server has 120s)
            return { success: true, data: response.data };
        } catch (error) {
            if (error.code === 'ECONNABORTED') {
                return { success: false, error: 'Request timed out after 2 minutes' };
            }
            return { success: false, error: error.response?.data?.error || error.message };
        }
    }
};

// KPI API (System admin only)
export const kpiAPI = {
    getStats: async () => {
        try {
            const response = await api.get('/api/kpi/stats');
            return { success: true, data: response.data.data };
        } catch (error) {
            return { success: false, error: error.response?.data?.message || error.message };
        }
    },

    getActivity: async (limit = 50, offset = 0) => {
        try {
            const response = await api.get(`/api/kpi/activity?limit=${limit}&offset=${offset}`);
            return { success: true, data: response.data.data };
        } catch (error) {
            return { success: false, error: error.response?.data?.message || error.message };
        }
    },

    getUsers: async () => {
        try {
            const response = await api.get('/api/kpi/users');
            return { success: true, data: response.data.data };
        } catch (error) {
            return { success: false, error: error.response?.data?.message || error.message };
        }
    },

    getProjects: async () => {
        try {
            const response = await api.get('/api/kpi/projects');
            return { success: true, data: response.data.data };
        } catch (error) {
            return { success: false, error: error.response?.data?.message || error.message };
        }
    }
};

// Comment API functions
export const commentAPI = {
    // Get all comments for a key review
    getComments: async (keyReviewId) => {
        try {
            const response = await api.get(`/api/comments/${keyReviewId}`);
            return { success: true, data: response.data };
        } catch (error) {
            return { success: false, error: error.response?.data?.message || error.message };
        }
    },

    // Create a new comment
    createComment: async (keyReviewId, commentText) => {
        try {
            const response = await api.post('/api/comments', {
                key_review_id: keyReviewId,
                comment_text: commentText
            });
            return { success: true, data: response.data };
        } catch (error) {
            return { success: false, error: error.response?.data?.message || error.message };
        }
    },

    // Update a comment
    updateComment: async (commentId, commentText) => {
        try {
            const response = await api.put(`/api/comments/${commentId}`, {
                comment_text: commentText
            });
            return { success: true, data: response.data };
        } catch (error) {
            return { success: false, error: error.response?.data?.message || error.message };
        }
    },

    // Delete a comment
    deleteComment: async (commentId) => {
        try {
            const response = await api.delete(`/api/comments/${commentId}`);
            return { success: true, data: response.data };
        } catch (error) {
            return { success: false, error: error.response?.data?.message || error.message };
        }
    },

    // Get latest comment for a key review
    getLatestComment: async (keyReviewId) => {
        try {
            const response = await api.get(`/api/comments/${keyReviewId}/latest`);
            return { success: true, data: response.data };
        } catch (error) {
            return { success: false, error: error.response?.data?.message || error.message };
        }
    },

    // Get comment count for a key review
    getCommentCount: async (keyReviewId) => {
        try {
            const response = await api.get(`/api/comments/${keyReviewId}/count`);
            return { success: true, data: response.data };
        } catch (error) {
            return { success: false, error: error.response?.data?.message || error.message };
        }
    },

    // Create a comment for multiple key reviews (Apply to Group)
    createBulkComment: async (keyReviewIds, commentText) => {
        try {
            const response = await api.post('/api/comments/bulk', {
                key_review_ids: keyReviewIds,
                comment_text: commentText
            });
            return { success: true, data: response.data };
        } catch (error) {
            return { success: false, error: error.response?.data?.message || error.message };
        }
    },

    // Verify a single comment (admin only)
    verifyComment: async (commentId) => {
        try {
            const response = await api.post(`/api/comments/${commentId}/verify`);
            return { success: true, data: response.data };
        } catch (error) {
            return { success: false, error: error.response?.data?.message || error.message };
        }
    },

    // Verify all comments for a key review (admin only)
    verifyAllComments: async (keyReviewId) => {
        try {
            const response = await api.post(`/api/comments/verify-all/${keyReviewId}`);
            return { success: true, data: response.data };
        } catch (error) {
            return { success: false, error: error.response?.data?.message || error.message };
        }
    },

    // Bulk verify comments for multiple key reviews (admin only)
    verifyBulkComments: async (keyReviewIds) => {
        try {
            const response = await api.post('/api/comments/verify-bulk', {
                key_review_ids: keyReviewIds
            });
            return { success: true, data: response.data };
        } catch (error) {
            return { success: false, error: error.response?.data?.message || error.message };
        }
    },

    // Get pending comments count for a project (admin only)
    getPendingCount: async (projectId) => {
        try {
            const response = await api.get(`/api/comments/pending-count/${projectId}`);
            return { success: true, data: response.data };
        } catch (error) {
            return { success: false, error: error.response?.data?.message || error.message };
        }
    }
};

// Sync API (System admin only)
export const syncAPI = {
    getKeys: async () => {
        try {
            const response = await api.get('/api/sync/keys');
            return { success: true, data: response.data.data, count: response.data.count };
        } catch (error) {
            return { success: false, error: error.response?.data?.message || error.message };
        }
    },

    getModels: async () => {
        try {
            const response = await api.get('/api/sync/models');
            return { success: true, data: response.data.data, count: response.data.count };
        } catch (error) {
            return { success: false, error: error.response?.data?.message || error.message };
        }
    },

    getBranches: async () => {
        try {
            const response = await api.get('/api/sync/branches');
            return { success: true, data: response.data.data, count: response.data.count };
        } catch (error) {
            return { success: false, error: error.response?.data?.message || error.message };
        }
    },

    getStats: async () => {
        try {
            const response = await api.get('/api/sync/stats');
            return { success: true, data: response.data.data };
        } catch (error) {
            return { success: false, error: error.response?.data?.message || error.message };
        }
    },

    runKeysSync: async () => {
        try {
            const response = await api.post('/api/sync/keys/run', {}, { timeout: 140000 });
            return { success: true, data: response.data };
        } catch (error) {
            return {
                success: false,
                error: error.response?.data?.message || error.message,
                timedOut: error.response?.data?.timedOut || error.code === 'ECONNABORTED'
            };
        }
    },

    runModelsSync: async () => {
        try {
            const response = await api.post('/api/sync/models/run', {}, { timeout: 140000 });
            return { success: true, data: response.data };
        } catch (error) {
            return {
                success: false,
                error: error.response?.data?.message || error.message,
                timedOut: error.response?.data?.timedOut || error.code === 'ECONNABORTED'
            };
        }
    },

    runBranchesSync: async () => {
        try {
            const response = await api.post('/api/sync/branches/run', {}, { timeout: 140000 });
            return { success: true, data: response.data };
        } catch (error) {
            return {
                success: false,
                error: error.response?.data?.message || error.message,
                timedOut: error.response?.data?.timedOut || error.code === 'ECONNABORTED'
            };
        }
    }
};

export default api; 