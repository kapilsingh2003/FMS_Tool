import React, { useState, useEffect } from 'react';
import {
    Dialog,
    DialogContent,
    DialogActions,
    Button,
    Typography,
    Box,
    Chip,
    LinearProgress,
} from '@mui/material';
import NewReleasesIcon from '@mui/icons-material/NewReleases';
import StarIcon from '@mui/icons-material/Star';
import BookmarkAddedIcon from '@mui/icons-material/BookmarkAdded';
import ContentPasteGoIcon from '@mui/icons-material/ContentPasteGo';
import InfoOutlinedIcon from '@mui/icons-material/InfoOutlined';
import AssessmentOutlinedIcon from '@mui/icons-material/AssessmentOutlined';
import AutoAwesomeIcon from '@mui/icons-material/AutoAwesome';

const MANDATORY_SECONDS = 5;

const FEATURES = [
    {
        icon: <BookmarkAddedIcon />,
        title: 'Save Filter',
        description:
            'Applied the perfect set of filters? Save them. Click "Save Filter", give it a name, and it will appear in your Filters menu for one-click reuse — no rebuilding from scratch each time.',
        isHighlighted: false,
    },
    {
        icon: <ContentPasteGoIcon />,
        title: 'Paste from Excel',
        description:
            'Copy a column of values directly from any Excel sheet and paste it into the filter search bar. All entries are automatically detected and selected — bulk filtering without the manual effort.',
        isHighlighted: false,
    },
    {
        icon: <InfoOutlinedIcon />,
        title: 'Key Description Button',
        description:
            'Each key now has a dedicated Description button. Click it to instantly view the full description of that key — right where you are, without navigating away.',
        isHighlighted: false,
    },
    {
        icon: <AssessmentOutlinedIcon />,
        title: 'Project Summary on Project Card',
        description:
            'Project summaries are now visible directly on the project card. Managers can check progress at a glance — no need to open the project just to see where things stand.',
        isHighlighted: false,
    },
    {
        icon: <AutoAwesomeIcon />,
        title: 'AI-Difference Summarizer',
        description:
            "When a key has values that differ across many regions, spotting exactly what's different manually can be slow and error-prone. The AI-Difference Summarizer analyzes the values instantly and gives you a clear, readable summary of the differences — so you can focus on reviewing, not decoding.",
        isHighlighted: true,
    },
];

const AnnouncementBanner = ({ open, onClose }) => {
    const [countdown, setCountdown] = useState(MANDATORY_SECONDS);
    const [canClose, setCanClose] = useState(false);

    useEffect(() => {
        if (!open) return;
        setCountdown(MANDATORY_SECONDS);
        setCanClose(false);

        const timer = setInterval(() => {
            setCountdown((prev) => {
                if (prev <= 1) {
                    clearInterval(timer);
                    setCanClose(true);
                    return 0;
                }
                return prev - 1;
            });
        }, 1000);

        return () => clearInterval(timer);
    }, [open]);

    const progress = ((MANDATORY_SECONDS - countdown) / MANDATORY_SECONDS) * 100;

    return (
        <Dialog
            open={open}
            onClose={canClose ? onClose : undefined}
            maxWidth="sm"
            fullWidth
            disableEscapeKeyDown={!canClose}
            PaperProps={{
                sx: {
                    borderRadius: 3,
                    overflow: 'hidden',
                    boxShadow: '0 24px 64px rgba(0,0,0,0.18)',
                },
            }}
        >
            {/* Header */}
            <Box
                sx={{
                    background: 'linear-gradient(135deg, #0d47a1 0%, #1261b0 60%, #1976d2 100%)',
                    px: 3,
                    pt: 3,
                    pb: 2.5,
                    color: 'white',
                }}
            >
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5, mb: 1 }}>
                    <Box
                        sx={{
                            width: 40,
                            height: 40,
                            borderRadius: '50%',
                            bgcolor: 'rgba(255,255,255,0.15)',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                        }}
                    >
                        <NewReleasesIcon sx={{ fontSize: 22 }} />
                    </Box>
                    <Box>
                        <Typography variant="h6" fontWeight={700} lineHeight={1.2}>
                            What's New
                        </Typography>
                        <Typography variant="caption" sx={{ opacity: 0.75, fontWeight: 400 }}>
                            Latest updates &amp; improvements
                        </Typography>
                    </Box>
                    <Chip
                        label="NEW"
                        size="small"
                        sx={{
                            ml: 'auto',
                            bgcolor: 'rgba(255,255,255,0.18)',
                            color: 'white',
                            fontWeight: 700,
                            fontSize: 10,
                            letterSpacing: 1,
                            height: 22,
                            border: '1px solid rgba(255,255,255,0.3)',
                        }}
                    />
                </Box>
                <Typography variant="body2" sx={{ opacity: 0.8, lineHeight: 1.5, mt: 0.5 }}>
                    We've shipped some powerful new features. Take a moment to see what's changed.
                </Typography>
            </Box>

            {/* Mandatory read progress bar */}
            <Box sx={{ position: 'relative', height: 4, bgcolor: '#e3f0ff' }}>
                <Box
                    sx={{
                        position: 'absolute',
                        inset: 0,
                        width: `${progress}%`,
                        bgcolor: '#ff6f00',
                        transition: 'width 1s linear',
                        borderRadius: '0 2px 2px 0',
                    }}
                />
            </Box>

            <DialogContent sx={{ p: 0, overflowY: 'auto', maxHeight: '60vh' }}>
                <Box sx={{ p: 2.5, display: 'flex', flexDirection: 'column', gap: 1.5 }}>
                    {FEATURES.map((feature, index) => (
                        <Box
                            key={index}
                            sx={{
                                display: 'flex',
                                gap: 2,
                                p: 2,
                                borderRadius: 2.5,
                                border: feature.isHighlighted
                                    ? '1.5px solid #ff6f00'
                                    : '1px solid #e8edf2',
                                bgcolor: feature.isHighlighted ? '#fff8f0' : '#fafbfc',
                                position: 'relative',
                                transition: 'box-shadow 0.2s',
                                '&:hover': {
                                    boxShadow: feature.isHighlighted
                                        ? '0 4px 16px rgba(255,111,0,0.15)'
                                        : '0 4px 12px rgba(18,97,176,0.08)',
                                },
                            }}
                        >
                            {feature.isHighlighted && (
                                <Chip
                                    icon={<StarIcon sx={{ fontSize: '12px !important', color: 'white !important' }} />}
                                    label="Featured"
                                    size="small"
                                    sx={{
                                        position: 'absolute',
                                        top: -11,
                                        right: 14,
                                        bgcolor: '#ff6f00',
                                        color: 'white',
                                        fontWeight: 700,
                                        fontSize: 10,
                                        letterSpacing: 0.5,
                                        height: 20,
                                        px: 0.5,
                                    }}
                                />
                            )}

                            {/* Icon badge */}
                            <Box
                                sx={{
                                    width: 38,
                                    height: 38,
                                    borderRadius: 2,
                                    bgcolor: feature.isHighlighted ? '#ff6f00' : '#1261b0',
                                    display: 'flex',
                                    alignItems: 'center',
                                    justifyContent: 'center',
                                    color: 'white',
                                    flexShrink: 0,
                                    '& .MuiSvgIcon-root': { fontSize: 20 },
                                }}
                            >
                                {feature.icon}
                            </Box>

                            <Box sx={{ flex: 1, minWidth: 0 }}>
                                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 0.4 }}>
                                    <Typography
                                        variant="subtitle2"
                                        fontWeight={700}
                                        sx={{
                                            color: feature.isHighlighted ? '#bf4500' : '#1261b0',
                                            lineHeight: 1.3,
                                        }}
                                    >
                                        {feature.title}
                                    </Typography>
                                    <Typography
                                        variant="caption"
                                        sx={{
                                            bgcolor: feature.isHighlighted ? '#ffe0c0' : '#e8f0fe',
                                            color: feature.isHighlighted ? '#bf4500' : '#1261b0',
                                            fontWeight: 600,
                                            px: 0.8,
                                            py: 0.1,
                                            borderRadius: 1,
                                            fontSize: 10,
                                        }}
                                    >
                                        #{index + 1}
                                    </Typography>
                                </Box>
                                <Typography
                                    variant="body2"
                                    color="text.secondary"
                                    sx={{ lineHeight: 1.65, fontSize: '0.8rem' }}
                                >
                                    {feature.description}
                                </Typography>
                            </Box>
                        </Box>
                    ))}
                </Box>
            </DialogContent>

            {/* Footer */}
            <DialogActions
                sx={{
                    px: 2.5,
                    py: 2,
                    borderTop: '1px solid #f0f2f5',
                    bgcolor: '#fafbfc',
                    display: 'flex',
                    alignItems: 'center',
                    gap: 1,
                }}
            >
                <Box sx={{ flex: 1 }}>
                    {canClose ? (
                        <Typography variant="caption" color="text.secondary">
                            You're all caught up. Welcome back! <br />(For any queries, please contact kapil.sk or karan.ch)
                        </Typography>
                    ) : (
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                            <Box
                                sx={{
                                    width: 20,
                                    height: 20,
                                    borderRadius: '50%',
                                    bgcolor: '#ff6f00',
                                    color: 'white',
                                    display: 'flex',
                                    alignItems: 'center',
                                    justifyContent: 'center',
                                    fontSize: 11,
                                    fontWeight: 700,
                                    flexShrink: 0,
                                }}
                            >
                                {countdown}
                            </Box>
                            <Typography variant="caption" color="text.secondary">
                                Please review before dismissing
                            </Typography>
                        </Box>
                    )}
                </Box>

                <Button
                    variant="contained"
                    onClick={onClose}
                    disabled={!canClose}
                    disableElevation
                    sx={{
                        minWidth: 110,
                        fontWeight: 600,
                        borderRadius: 2,
                        bgcolor: canClose ? '#1261b0' : undefined,
                        '&:hover': {
                            bgcolor: canClose ? '#0d47a1' : undefined,
                        },
                    }}
                >
                    {canClose ? 'Got it!' : `Wait (${countdown}s)`}
                </Button>
            </DialogActions>
        </Dialog>
    );
};

export default AnnouncementBanner;
