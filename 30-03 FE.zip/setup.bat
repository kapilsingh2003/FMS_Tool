@echo off
echo ===============================================
echo Samsung FMS Portal - Windows Setup Script
echo ===============================================
echo.

echo [1/5] Checking Node.js installation...
node --version >nul 2>&1
if %errorlevel% neq 0 (
    echo ERROR: Node.js is not installed or not in PATH
    echo Please install Node.js from https://nodejs.org/
    pause
    exit /b 1
)
echo ✓ Node.js found

echo.
echo [2/5] Checking MySQL installation...
mysql --version >nul 2>&1
if %errorlevel% neq 0 (
    echo WARNING: MySQL not found in PATH
    echo Please ensure MySQL is installed and running
    echo You can continue and configure MySQL manually
)
echo ✓ MySQL check completed

echo.
echo [3/5] Installing frontend dependencies...
npm install
if %errorlevel% neq 0 (
    echo ERROR: Failed to install frontend dependencies
    pause
    exit /b 1
)
echo ✓ Frontend dependencies installed

echo.
echo [4/5] Installing backend dependencies...
cd backend
npm install
if %errorlevel% neq 0 (
    echo ERROR: Failed to install backend dependencies
    pause
    exit /b 1
)
echo ✓ Backend dependencies installed

echo.
echo [5/5] Setting up environment file...
if not exist .env (
    copy env.example .env
    echo ✓ Environment file created
    echo.
    echo IMPORTANT: Please edit backend\.env with your MySQL credentials:
    echo - DB_PASSWORD=your_mysql_password
    echo - Update other settings if needed
) else (
    echo ✓ Environment file already exists
)

cd ..

echo.
echo ===============================================
echo Setup completed successfully!
echo ===============================================
echo.
echo Next steps:
echo 1. Configure database:
echo    mysql -u root -p ^< revised_schema.sql
echo.
echo 2. Start the application:
echo    - Terminal 1: cd backend ^&^& npm start
echo    - Terminal 2: npm start
echo.
echo 3. Open browser: http://localhost:3000
echo    Login: admin.john / password123
echo.
echo See WORK_MACHINE_SETUP.md for detailed instructions
echo.
pause