-- Samsung FMS Portal Database Creation Script
-- MySQL Database with all tables, constraints, and sample data

-- Create the database
CREATE DATABASE IF NOT EXISTS samsung_fms_portal;
USE samsung_fms_portal;

-- Drop tables if they exist (for clean setup)
DROP TABLE IF EXISTS `Key_Reviews`;
DROP TABLE IF EXISTS `Group_Branch_Model_Map`;
DROP TABLE IF EXISTS `Group_Branch_Mapping`;
DROP TABLE IF EXISTS `Branch_Model_Mapping`;
DROP TABLE IF EXISTS `Project_Participants`;
DROP TABLE IF EXISTS `Groups`;
DROP TABLE IF EXISTS `Projects`;
DROP TABLE IF EXISTS `FMS_Keys`;
DROP TABLE IF EXISTS `Models`;
DROP TABLE IF EXISTS `Branches`;
DROP TABLE IF EXISTS `Users`;

-- 1. Users table (Knox ID based authentication)
CREATE TABLE `Users` (
    username VARCHAR(50) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    password VARCHAR(255) NOT NULL,
    role ENUM('admin', 'reviewer', 'viewer') NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    team ENUM('ENT_SM', 'CTV', 'ENT_TV') NOT NULL,
    created_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    last_login DATETIME,
    is_verified BOOLEAN DEFAULT FALSE,
    INDEX idx_role (role),
    INDEX idx_team (team)
);

-- 2. Projects table (project-level configuration)
CREATE TABLE `Projects` (
    project_id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(100) NOT NULL,
    description VARCHAR(500),
    admin_username VARCHAR(50) NOT NULL,
    refresh_schedule ENUM('Daily', 'Weekly', 'Monthly') DEFAULT 'Weekly',
    status ENUM('active', 'inactive', 'completed') DEFAULT 'active',
    created_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    is_active BOOLEAN DEFAULT TRUE,
    FOREIGN KEY (admin_username) REFERENCES `Users`(username) ON DELETE RESTRICT,
    INDEX idx_admin (admin_username),
    INDEX idx_status (status)
);

-- 3. Project_Participants table (many-to-many: users and projects)
CREATE TABLE `Project_Participants` (
    project_id INT,
    user_username VARCHAR(50),
    added_by VARCHAR(50) NOT NULL,
    participant_role ENUM('admin', 'reviewer', 'viewer') DEFAULT 'reviewer',
    joined_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (project_id, user_username),
    FOREIGN KEY (project_id) REFERENCES `Projects`(project_id) ON DELETE CASCADE,
    FOREIGN KEY (user_username) REFERENCES `Users`(username) ON DELETE CASCADE,
    FOREIGN KEY (added_by) REFERENCES `Users`(username) ON DELETE RESTRICT,
    INDEX idx_user (user_username)
);

-- 4. Groups table (group-level comparison configuration)
CREATE TABLE `Groups` (
    group_id INT AUTO_INCREMENT PRIMARY KEY,
    project_id INT NOT NULL,
    name VARCHAR(100) NOT NULL,
    comparison_type ENUM('2-way', '3-way', '4-way', '2-way vs 2-way') NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (project_id) REFERENCES `Projects`(project_id) ON DELETE CASCADE,
    UNIQUE KEY unique_group_per_project (project_id, name),
    INDEX idx_project (project_id)
);

-- 5. Branches table (available branches for comparison)
CREATE TABLE `Branches` (
    branch_id INT AUTO_INCREMENT PRIMARY KEY,
    branch_name VARCHAR(255) UNIQUE NOT NULL,
    branch_type VARCHAR(50),
    description TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    INDEX idx_active (is_active),
    INDEX idx_type (branch_type)
);

-- 6. Models table (monitor/TV models)
CREATE TABLE `Models` (
    model_id INT AUTO_INCREMENT PRIMARY KEY,
    model_name VARCHAR(50) UNIQUE NOT NULL,
    product_category ENUM('Smart Monitors', 'CTV', 'ENT_TV'),
    specifications JSON,
    is_active BOOLEAN DEFAULT TRUE,
    INDEX idx_category (product_category),
    INDEX idx_active (is_active)
);

-- 7. Branch_Model_Mapping table (CRITICAL: which models exist in which branches)
CREATE TABLE `Branch_Model_Mapping` (
    bm_id INT AUTO_INCREMENT PRIMARY KEY,
    branch_id INT NOT NULL,
    model_id INT NOT NULL,
    is_available BOOLEAN DEFAULT TRUE,
    date_added DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (branch_id) REFERENCES `Branches`(branch_id) ON DELETE CASCADE,
    FOREIGN KEY (model_id) REFERENCES `Models`(model_id) ON DELETE CASCADE,
    UNIQUE KEY unique_branch_model (branch_id, model_id),
    INDEX idx_branch (branch_id),
    INDEX idx_model (model_id),
    INDEX idx_available (is_available),
    INDEX idx_branch_available (branch_id, is_available)
);

-- 8. Group_Branch_Mapping table (which branches are assigned to which groups)
CREATE TABLE `Group_Branch_Mapping` (
    gb_id INT AUTO_INCREMENT PRIMARY KEY,
    group_id INT NOT NULL,
    branch_role ENUM('target', 'reference1', 'reference2', 'reference3') NOT NULL,
    branch_id INT NOT NULL,
    sort_order INT DEFAULT 0,
    FOREIGN KEY (group_id) REFERENCES `Groups`(group_id) ON DELETE CASCADE,
    FOREIGN KEY (branch_id) REFERENCES `Branches`(branch_id) ON DELETE RESTRICT,
    UNIQUE KEY unique_group_branch_role (group_id, branch_role),
    INDEX idx_group (group_id),
    INDEX idx_branch (branch_id)
);

-- 9. Group_Branch_Model_Map table (specific models used in group-branch combinations)
CREATE TABLE `Group_Branch_Model_Map` (
    gbm_id INT AUTO_INCREMENT PRIMARY KEY,
    gb_id INT NOT NULL,
    model_id INT NOT NULL,
    added_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (gb_id) REFERENCES `Group_Branch_Mapping`(gb_id) ON DELETE CASCADE,
    FOREIGN KEY (model_id) REFERENCES `Models`(model_id) ON DELETE CASCADE,
    UNIQUE KEY unique_gb_model (gb_id, model_id),
    INDEX idx_gb (gb_id),
    INDEX idx_model (model_id),
    INDEX idx_gb_model (gb_id, model_id)
);

-- 10. FMS_Keys table (feature management system keys)
CREATE TABLE `FMS_Keys` (
    fms_key_id INT AUTO_INCREMENT PRIMARY KEY,
    key_name VARCHAR(255) UNIQUE NOT NULL,
    work_assignment VARCHAR(100),
    work_assignment_owner VARCHAR(100),
    key_category VARCHAR(100),
    data_type ENUM('boolean', 'integer', 'string', 'float') DEFAULT 'string',
    description TEXT,
    has_differences BOOLEAN DEFAULT FALSE,
    INDEX idx_work_assignment (work_assignment),
    INDEX idx_owner (work_assignment_owner),
    INDEX idx_differences (has_differences),
    INDEX idx_key_name (key_name)
);

-- 11. Key_Reviews table (the core review data)
CREATE TABLE `Key_Reviews` (
    key_review_id INT AUTO_INCREMENT PRIMARY KEY,
    fms_key_id INT NOT NULL,
    gbm_id INT NOT NULL,
    target_val TEXT,
    ref1_val TEXT,
    ref2_val TEXT,
    ref3_val TEXT,
    comment TEXT,
    status ENUM('pending', 'reviewed', 'needs_discussion', 'dev_response') DEFAULT 'pending',
    kona_ids TEXT,
    cl_numbers TEXT,
    reviewed_by_username VARCHAR(50),
    created_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    last_modified DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (fms_key_id) REFERENCES `FMS_Keys`(fms_key_id) ON DELETE CASCADE,
    FOREIGN KEY (gbm_id) REFERENCES `Group_Branch_Model_Map`(gbm_id) ON DELETE CASCADE,
    FOREIGN KEY (reviewed_by_username) REFERENCES `Users`(username) ON DELETE SET NULL,
    UNIQUE KEY unique_key_gbm_review (fms_key_id, gbm_id),
    INDEX idx_fms_key (fms_key_id),
    INDEX idx_gbm (gbm_id),
    INDEX idx_status (status),
    INDEX idx_reviewer (reviewed_by_username)
);

-- Display success message
SELECT 'Samsung FMS Portal database schema created successfully!' as Status;
