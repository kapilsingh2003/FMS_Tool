import React from 'react';
import { Box, Typography, Container } from '@mui/material';

const Footer = () => {
    return (
        <Box
            component="footer"
            sx={{
                mt: 'auto',
                py: 2,
                px: 2,
                backgroundColor: '#f5f5f5',
                borderTop: '1px solid #e0e0e0',
                textAlign: 'center'
            }}
        >
            <Container maxWidth="lg">
                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 1 }}>
                    <Typography variant="body2" color="text.secondary">
                        FMS Review Manager v0.5
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                        Developed by Enterprise Product Team
                    </Typography>
                </Box>
            </Container>
        </Box>
    );
};

export default Footer;
