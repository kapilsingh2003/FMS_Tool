// KPI Routes - Samsung FMS Portal
const express = require('express');
const { executeQuery } = require('../config/database');
const router = express.Router();

// Middleware to check if user is system admin
const requireSystemAdmin = (req, res, next) => {
  if (req.user.username !== 'system') {
    return res.status(403).json({
      success: false,
      message: 'Access denied. Only system user can access KPI dashboard.'
    });
  }
  next();
};

// GET /api/kpi/stats - Get all KPI statistics
router.get('/stats', requireSystemAdmin, async (req, res) => {
  try {
    const stats = {};

    // 1. Active Users (last login < 1 week)
    const activeUsersQuery = `
      SELECT COUNT(*) as count 
      FROM Users 
      WHERE last_login >= DATE_SUB(NOW(), INTERVAL 7 DAY)
        AND username != 'system'
    `;
    const activeUsersResult = await executeQuery(activeUsersQuery);
    stats.activeUsers = activeUsersResult[0].count;

    // Total users (excluding system)
    const totalUsersQuery = `
      SELECT COUNT(*) as count 
      FROM Users 
      WHERE username != 'system'
    `;
    const totalUsersResult = await executeQuery(totalUsersQuery);
    stats.totalUsers = totalUsersResult[0].count;

    // 2. Projects created per month (last 12 months)
    const projectsPerMonthQuery = `
      SELECT 
        DATE_FORMAT(created_date, '%Y-%m') as month,
        DATE_FORMAT(created_date, '%b %Y') as month_label,
        COUNT(*) as count
      FROM Projects
      WHERE created_date >= DATE_SUB(NOW(), INTERVAL 12 MONTH)
      GROUP BY DATE_FORMAT(created_date, '%Y-%m'), DATE_FORMAT(created_date, '%b %Y')
      ORDER BY month ASC
    `;
    const projectsPerMonth = await executeQuery(projectsPerMonthQuery);
    stats.projectsPerMonth = projectsPerMonth;

    // Total projects
    const totalProjectsQuery = `SELECT COUNT(*) as count FROM Projects`;
    const totalProjectsResult = await executeQuery(totalProjectsQuery);
    stats.totalProjects = totalProjectsResult[0].count;

    // Active projects
    const activeProjectsQuery = `SELECT COUNT(*) as count FROM Projects WHERE status = 'active'`;
    const activeProjectsResult = await executeQuery(activeProjectsQuery);
    stats.activeProjects = activeProjectsResult[0].count;

    // 3. Key reviews modified by users (all time, excluding system changes)
    // Count key reviews with user-made changes (status, comment, kona, cl)
    const modifiedKeyReviewsQuery = `
      SELECT COUNT(DISTINCT kr.key_review_id) as count
      FROM Key_Reviews kr
      WHERE kr.reviewed_by_username IS NOT NULL 
        AND kr.reviewed_by_username != 'system'
    `;
    const modifiedKeyReviewsResult = await executeQuery(modifiedKeyReviewsQuery);
    stats.modifiedKeyReviews = modifiedKeyReviewsResult[0].count;

    // Key reviews modified this week
    const modifiedThisWeekQuery = `
      SELECT COUNT(DISTINCT kr.key_review_id) as count
      FROM Key_Reviews kr
      WHERE kr.reviewed_by_username IS NOT NULL 
        AND kr.reviewed_by_username != 'system'
        AND kr.reviewed_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
    `;
    const modifiedThisWeekResult = await executeQuery(modifiedThisWeekQuery);
    stats.modifiedKeyReviewsThisWeek = modifiedThisWeekResult[0].count;

    // Total key reviews
    const totalKeyReviewsQuery = `SELECT COUNT(*) as count FROM Key_Reviews`;
    const totalKeyReviewsResult = await executeQuery(totalKeyReviewsQuery);
    stats.totalKeyReviews = totalKeyReviewsResult[0].count;

    // 4. Comments by users (all time, excluding system)
    const userCommentsQuery = `
      SELECT COUNT(*) as count
      FROM Comments
      WHERE commented_by_username != 'system'
    `;
    const userCommentsResult = await executeQuery(userCommentsQuery);
    stats.userComments = userCommentsResult[0].count;

    // Comments added this week
    const commentsThisWeekQuery = `
      SELECT COUNT(*) as count
      FROM Comments
      WHERE commented_by_username != 'system'
        AND created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
    `;
    const commentsThisWeekResult = await executeQuery(commentsThisWeekQuery);
    stats.userCommentsThisWeek = commentsThisWeekResult[0].count;

    // Total comments
    const totalCommentsQuery = `SELECT COUNT(*) as count FROM Comments`;
    const totalCommentsResult = await executeQuery(totalCommentsQuery);
    stats.totalComments = totalCommentsResult[0].count;

    // 5. Key reviews by status distribution
    const statusDistributionQuery = `
      SELECT status, COUNT(*) as count
      FROM Key_Reviews
      GROUP BY status
      ORDER BY count DESC
    `;
    const statusDistribution = await executeQuery(statusDistributionQuery);
    stats.statusDistribution = statusDistribution;

    // 6. Projects by comparison type
    const comparisonTypeQuery = `
      SELECT g.comparison_type, COUNT(DISTINCT g.project_id) as count
      FROM grps g
      GROUP BY g.comparison_type
    `;
    const comparisonTypes = await executeQuery(comparisonTypeQuery);
    stats.comparisonTypes = comparisonTypes;

    // 7. Top active users (by key review modifications)
    const topUsersQuery = `
      SELECT 
        u.username,
        u.name,
        u.team,
        COUNT(DISTINCT kr.key_review_id) as reviews_modified,
        COUNT(DISTINCT c.comment_id) as comments_added
      FROM Users u
      LEFT JOIN Key_Reviews kr ON u.username = kr.reviewed_by_username AND kr.reviewed_by_username != 'system'
      LEFT JOIN Comments c ON u.username = c.commented_by_username AND c.commented_by_username != 'system'
      WHERE u.username != 'system'
      GROUP BY u.username, u.name, u.team
      HAVING reviews_modified > 0 OR comments_added > 0
      ORDER BY (reviews_modified + comments_added) DESC
      LIMIT 10
    `;
    const topUsers = await executeQuery(topUsersQuery);
    stats.topUsers = topUsers;

    // 8. Users by team distribution
    const teamDistributionQuery = `
      SELECT team, COUNT(*) as count
      FROM Users
      WHERE username != 'system'
      GROUP BY team
    `;
    const teamDistribution = await executeQuery(teamDistributionQuery);
    stats.teamDistribution = teamDistribution;

    // 9. Projects by admin (top creators)
    const projectsByAdminQuery = `
      SELECT 
        u.username,
        u.name,
        COUNT(p.project_id) as projects_created
      FROM Users u
      JOIN Projects p ON u.username = p.admin_username
      WHERE u.username != 'system'
      GROUP BY u.username, u.name
      ORDER BY projects_created DESC
      LIMIT 10
    `;
    const projectsByAdmin = await executeQuery(projectsByAdminQuery);
    stats.projectsByAdmin = projectsByAdmin;

    // 10. Key reviews modified per month (last 6 months)
    const reviewsPerMonthQuery = `
      SELECT 
        DATE_FORMAT(reviewed_at, '%Y-%m') as month,
        DATE_FORMAT(reviewed_at, '%b %Y') as month_label,
        COUNT(*) as count
      FROM Key_Reviews
      WHERE reviewed_at >= DATE_SUB(NOW(), INTERVAL 6 MONTH)
        AND reviewed_by_username IS NOT NULL
        AND reviewed_by_username != 'system'
      GROUP BY DATE_FORMAT(reviewed_at, '%Y-%m'), DATE_FORMAT(reviewed_at, '%b %Y')
      ORDER BY month ASC
    `;
    const reviewsPerMonth = await executeQuery(reviewsPerMonthQuery);
    stats.reviewsPerMonth = reviewsPerMonth;

    // 11. Average key reviews per project
    const avgReviewsQuery = `
      SELECT 
        ROUND(AVG(review_count), 1) as avg_reviews
      FROM (
        SELECT p.project_id, COUNT(kr.key_review_id) as review_count
        FROM Projects p
        LEFT JOIN grps g ON p.project_id = g.project_id
        LEFT JOIN Key_Reviews kr ON g.group_id = kr.group_id
        GROUP BY p.project_id
      ) as project_reviews
    `;
    const avgReviewsResult = await executeQuery(avgReviewsQuery);
    stats.avgReviewsPerProject = avgReviewsResult[0].avg_reviews || 0;

    // 12. Recent sync activity
    const recentSyncsQuery = `
      SELECT 
        p.project_id,
        p.title,
        p.status,
        p.last_refreshed_at,
        u.name as admin_name
      FROM Projects p
      JOIN Users u ON p.admin_username = u.username
      WHERE p.last_refreshed_at IS NOT NULL
      ORDER BY p.last_refreshed_at DESC
      LIMIT 10
    `;
    const recentSyncs = await executeQuery(recentSyncsQuery);
    stats.recentSyncs = recentSyncs;

    res.json({
      success: true,
      data: stats
    });
  } catch (error) {
    console.error('KPI stats error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch KPI statistics'
    });
  }
});

// GET /api/kpi/activity - Get recent user activity
router.get('/activity', requireSystemAdmin, async (req, res) => {
  try {
    // Parse and validate limit/offset as integers
    const limitNum = Math.min(Math.max(parseInt(req.query.limit) || 50, 1), 100);
    const offsetNum = Math.max(parseInt(req.query.offset) || 0, 0);

    // Get recent comments (user activity) - using LEFT JOINs for robustness
    // Note: LIMIT/OFFSET embedded directly to avoid prepared statement issues
    const recentCommentsQuery = `
      SELECT 
        c.comment_id,
        c.comment_text,
        c.commented_by_username as username,
        COALESCE(u.name, c.commented_by_username) as user_name,
        COALESCE(u.team, 'Unknown') as team,
        c.created_at,
        kr.key_review_id,
        COALESCE(fk.key_name, 'Unknown Key') as key_name,
        COALESCE(p.project_id, 0) as project_id,
        COALESCE(p.title, 'Unknown Project') as project_title,
        'comment_add' as action_type
      FROM Comments c
      LEFT JOIN Users u ON c.commented_by_username = u.username
      LEFT JOIN Key_Reviews kr ON c.key_review_id = kr.key_review_id
      LEFT JOIN FMS_Keys fk ON kr.fms_key_id = fk.fms_key_id
      LEFT JOIN grps g ON kr.group_id = g.group_id
      LEFT JOIN Projects p ON g.project_id = p.project_id
      WHERE c.commented_by_username != 'system'
      ORDER BY c.created_at DESC
      LIMIT ${limitNum} OFFSET ${offsetNum}
    `;
    const recentComments = await executeQuery(recentCommentsQuery);
    console.log(`[KPI Activity] Found ${recentComments.length} recent comments`);

    // Get recent key review updates - using LEFT JOINs for robustness
    const recentReviewsQuery = `
      SELECT 
        kr.key_review_id,
        kr.status,
        kr.kona_ids,
        kr.cl_numbers,
        kr.reviewed_by_username as username,
        COALESCE(u.name, kr.reviewed_by_username) as user_name,
        COALESCE(u.team, 'Unknown') as team,
        kr.reviewed_at,
        COALESCE(fk.key_name, 'Unknown Key') as key_name,
        COALESCE(p.project_id, 0) as project_id,
        COALESCE(p.title, 'Unknown Project') as project_title,
        'key_review_update' as action_type
      FROM Key_Reviews kr
      LEFT JOIN Users u ON kr.reviewed_by_username = u.username
      LEFT JOIN FMS_Keys fk ON kr.fms_key_id = fk.fms_key_id
      LEFT JOIN grps g ON kr.group_id = g.group_id
      LEFT JOIN Projects p ON g.project_id = p.project_id
      WHERE kr.reviewed_by_username IS NOT NULL 
        AND kr.reviewed_by_username != 'system'
        AND kr.reviewed_by_username != ''
      ORDER BY kr.reviewed_at DESC
      LIMIT ${limitNum} OFFSET ${offsetNum}
    `;
    const recentReviews = await executeQuery(recentReviewsQuery);
    console.log(`[KPI Activity] Found ${recentReviews.length} recent key review updates`);

    // Combine and sort by timestamp
    let allActivity = [];
    
    try {
      // Process comments
      for (const c of recentComments) {
        allActivity.push({
          ...c,
          timestamp: c.created_at,
          details: { comment: (c.comment_text || '').substring(0, 100) }
        });
      }
      
      // Process reviews
      for (const r of recentReviews) {
        allActivity.push({
          ...r,
          timestamp: r.reviewed_at,
          details: {
            status: r.status || '',
            kona: r.kona_ids || '',
            cl: r.cl_numbers || ''
          }
        });
      }
      
      // Sort by timestamp
      allActivity = allActivity
        .sort((a, b) => new Date(b.timestamp || 0) - new Date(a.timestamp || 0))
        .slice(0, limitNum);
    } catch (processError) {
      console.error('Error processing activity data:', processError);
      throw processError;
    }

    console.log(`[KPI Activity] Returning ${allActivity.length} total activity items`);

    res.json({
      success: true,
      data: {
        activity: allActivity,
        total: allActivity.length
      }
    });
  } catch (error) {
    console.error('========================================');
    console.error('KPI ACTIVITY ERROR');
    console.error('========================================');
    console.error('Error message:', error.message);
    console.error('Error stack:', error.stack);
    console.error('========================================');
    res.status(500).json({
      success: false,
      message: 'Failed to fetch activity data',
      error: error.message
    });
  }
});

// GET /api/kpi/users - Get detailed user statistics
router.get('/users', requireSystemAdmin, async (req, res) => {
  try {
    const usersQuery = `
      SELECT 
        u.username,
        u.name,
        u.email,
        u.team,
        u.user_type,
        u.created_date,
        u.last_login,
        u.is_verified,
        COUNT(DISTINCT p.project_id) as projects_owned,
        COUNT(DISTINCT pp.project_id) as projects_participating,
        COUNT(DISTINCT kr.key_review_id) as reviews_modified,
        COUNT(DISTINCT c.comment_id) as comments_added
      FROM Users u
      LEFT JOIN Projects p ON u.username = p.admin_username
      LEFT JOIN Project_Participants pp ON u.username = pp.user_username
      LEFT JOIN Key_Reviews kr ON u.username = kr.reviewed_by_username AND kr.reviewed_by_username != 'system'
      LEFT JOIN Comments c ON u.username = c.commented_by_username AND c.commented_by_username != 'system'
      WHERE u.username != 'system'
      GROUP BY u.username, u.name, u.email, u.team, u.user_type, u.created_date, u.last_login, u.is_verified
      ORDER BY u.last_login DESC
    `;
    const users = await executeQuery(usersQuery);

    // Calculate activity status
    const now = new Date();
    const oneWeekAgo = new Date(now - 7 * 24 * 60 * 60 * 1000);
    const oneMonthAgo = new Date(now - 30 * 24 * 60 * 60 * 1000);

    const usersWithStatus = users.map(user => {
      let activityStatus = 'inactive';
      if (user.last_login) {
        const lastLogin = new Date(user.last_login);
        if (lastLogin >= oneWeekAgo) {
          activityStatus = 'active';
        } else if (lastLogin >= oneMonthAgo) {
          activityStatus = 'moderate';
        }
      }
      return { ...user, activityStatus };
    });

    res.json({
      success: true,
      data: usersWithStatus
    });
  } catch (error) {
    console.error('KPI users error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch user statistics'
    });
  }
});

// GET /api/kpi/projects - Get detailed project statistics
router.get('/projects', requireSystemAdmin, async (req, res) => {
  try {
    const projectsQuery = `
      SELECT 
        p.project_id,
        p.title,
        p.description,
        p.status,
        p.created_date,
        p.last_refreshed_at,
        p.refresh_schedule,
        u.name as admin_name,
        u.username as admin_username,
        COUNT(DISTINCT g.group_id) as group_count,
        COUNT(DISTINCT kr.key_review_id) as total_keys,
        COUNT(DISTINCT CASE WHEN kr.status != 'unreviewed' THEN kr.key_review_id END) as reviewed_keys,
        COUNT(DISTINCT pp.user_username) as participant_count
      FROM Projects p
      JOIN Users u ON p.admin_username = u.username
      LEFT JOIN grps g ON p.project_id = g.project_id
      LEFT JOIN Key_Reviews kr ON g.group_id = kr.group_id
      LEFT JOIN Project_Participants pp ON p.project_id = pp.project_id
      GROUP BY p.project_id, p.title, p.description, p.status, p.created_date, 
               p.last_refreshed_at, p.refresh_schedule, u.name, u.username
      ORDER BY p.created_date DESC
    `;
    const projects = await executeQuery(projectsQuery);

    // Calculate review progress percentage
    const projectsWithProgress = projects.map(project => ({
      ...project,
      reviewProgress: project.total_keys > 0 
        ? Math.round((project.reviewed_keys / project.total_keys) * 100) 
        : 0
    }));

    res.json({
      success: true,
      data: projectsWithProgress
    });
  } catch (error) {
    console.error('KPI projects error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch project statistics'
    });
  }
});

module.exports = router;

