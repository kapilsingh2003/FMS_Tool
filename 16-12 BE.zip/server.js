const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const path = require('path');

// Import database connection
const { testConnection } = require('./config/database');

// Import scheduler service
const { startScheduler, stopScheduler } = require('./services/scheduler');

// Import routes
const { router: authRoutes, authenticateToken } = require('./routes/auth');
const usersRoutes = require('./routes/users');
const projectsRoutes = require('./routes/projects');
const referenceRoutes = require('./routes/reference');
const keyReviewRoutes = require('./routes/keyreviews');
const commentsRoutes = require('./routes/comments');
const kpiRoutes = require('./routes/kpi');

const app = express();
const PORT = 5000;

app.use(cors({
  origin: 'http://localhost:3000', // adjust if your React runs elsewhere
  credentials: true
}));

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Routes
app.use('/api/auth', authRoutes);
app.use('/api/users', usersRoutes);
app.use('/api/projects', projectsRoutes);
app.use('/api/reference', referenceRoutes);
app.use('/api/keyreviews', keyReviewRoutes);
app.use('/api/comments', commentsRoutes);
app.use('/api/kpi', authenticateToken, kpiRoutes);

// Serve static files from the React app
app.use(express.static(path.join(__dirname, '../build')));

// Catch all handler: send back React's index.html file
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '../build', 'index.html'));
});

// Initialize database connection and start server
const startServer = async () => {
  try {
    // Test database connection
    await testConnection();

    // Start scheduler service
    startScheduler();

    // Start server
    app.listen(PORT, () => {
      console.log(`🚀 Server running on http://localhost:${PORT}`);
      console.log(`📊 Connected to Samsung FMS Portal database`);
      console.log(`⏰ Automatic refresh scheduler started`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
};

// Graceful shutdown
process.on('SIGINT', () => {
  console.log('\n🛑 Shutting down server...');
  stopScheduler();
  process.exit(0);
});

process.on('SIGTERM', () => {
  console.log('\n🛑 Shutting down server...');
  stopScheduler();
  process.exit(0);
});

startServer();
