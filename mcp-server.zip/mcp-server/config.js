/**
 * Configuration for FMS Portal MCP Server
 * 
 * This file contains all configuration options for the MCP server.
 * You can override these values using environment variables.
 */

import dotenv from 'dotenv';

// Load environment variables from .env file if present
dotenv.config();

export const config = {
    // Database configuration (same as backend)
    db: {
        host: process.env.DB_HOST || 'localhost',
        port: parseInt(process.env.DB_PORT || '3306'),
        user: process.env.DB_USER || 'root',
        password: process.env.DB_PASSWORD || 'root',
        database: process.env.DB_NAME || 'samsung_fms_portal',
    },
    
    // Project configuration
    // This is the hardcoded project ID that the MCP server will query
    // Change this to the project you want to expose via MCP
    projectId: parseInt(process.env.MCP_PROJECT_ID || '1'),
    
    // Server configuration
    server: {
        name: 'fms-portal-mcp-server',
        version: '1.0.0',
    },
};
