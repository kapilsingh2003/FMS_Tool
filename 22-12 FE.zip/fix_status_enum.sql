-- Fix Key_Reviews status ENUM to only include the 5 required statuses

USE samsung_fms_portal;

-- Step 1: Check current status values
SELECT 'Current status values before update:' as Info;
SELECT status, COUNT(*) as count FROM `Key_Reviews` GROUP BY status;

-- Step 2: Update existing status values to new ones
UPDATE `Key_Reviews` SET status = 'changes_made' WHERE status = 'reviewed';
UPDATE `Key_Reviews` SET status = 'pending_response' WHERE status = 'pending';
UPDATE `Key_Reviews` SET status = 'pending_response' WHERE status = 'dev_response';
UPDATE `Key_Reviews` SET status = 'internal_discussion' WHERE status = 'needs_discussion';
UPDATE `Key_Reviews` SET status = 'no_change_req' WHERE status = 'no-change';
UPDATE `Key_Reviews` SET status = 'internal_discussion' WHERE status = 'discussion';

-- Step 3: Alter the table to use new ENUM values
ALTER TABLE `Key_Reviews` 
MODIFY COLUMN status ENUM('unreviewed', 'changes_made', 'pending_response', 'no_change_req', 'internal_discussion') DEFAULT 'unreviewed';

-- Step 4: Check final status values
SELECT 'Status values after update:' as Info;
SELECT status, COUNT(*) as count FROM `Key_Reviews` GROUP BY status;

SELECT '✅ Successfully updated Key_Reviews status ENUM!' as Status;
