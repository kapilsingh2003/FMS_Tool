import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { keyReviewAPI, commentAPI } from '../../services/api';
import { toast } from 'react-toastify';
import {
    Box,
    Typography,
    IconButton,
    Collapse,
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TableRow,
    Chip,
    Button,
    Dialog,
    DialogTitle,
    DialogContent,
    DialogActions,
    TextField,
    Card,
    CardContent,
    Divider,
    Tooltip,
    InputAdornment,
    CircularProgress,
    Paper,
    Pagination,
    FormControl,
    InputLabel,
    Select,
    MenuItem,
    Checkbox,
    FormControlLabel,
    Badge,
    ArrowUpward,
    ArrowDownward
} from '@mui/material';
import {
    ExpandMore,
    ExpandLess,
    Key,
    Search,
    Clear,
    ChatBubble,
    ChatBubbleOutline,
    FilterList,
    ArrowUpward as ArrowUp,
    ArrowDownward as ArrowDown
} from '@mui/icons-material';

// Status colors - matching KeyReview.js
const statusColors = {
    'unreviewed': { color: 'transparent', label: 'Unreviewed', textColor: '#000' },
    'changes_made': { color: '#4caf50', label: 'Changes Made', textColor: '#fff' },
    'pending_response': { color: '#ff9800', label: 'Pending Response', textColor: '#fff' },
    'no_change_req': { color: '#2196f3', label: 'No Change Required', textColor: '#fff' },
    'internal_discussion': { color: '#ffeb3b', label: 'Internal Discussion', textColor: '#000' },
    'changes_in_progress': { color: '#9e9e9e', label: 'Changes in Progress', textColor: '#fff' },
    'value_changed': { color: '#f44336', label: 'Value Changed', textColor: '#fff' }
};

const AllComments = () => {
    // Data states
    const [keys, setKeys] = useState([]);
    const [loading, setLoading] = useState(true);
    
    // UI states
    const [expandedKeys, setExpandedKeys] = useState({});
    const [expandedGroups, setExpandedGroups] = useState({});
    const [searchTerm, setSearchTerm] = useState('');
    const [sortBy, setSortBy] = useState('key_name');
    const [sortDirection, setSortDirection] = useState('asc');
    
    // Filter states
    const [filtersOpen, setFiltersOpen] = useState(false);
    const [filters, setFilters] = useState({
        status: [],
        project: [],
        group: [],
        owner: [],
        workAssignment: []
    });
    
    // Filter search states
    const [projectSearch, setProjectSearch] = useState('');
    const [groupSearch, setGroupSearch] = useState('');
    const [ownerSearch, setOwnerSearch] = useState('');
    const [waSearch, setWaSearch] = useState('');
    
    // Pagination
    const [currentPage, setCurrentPage] = useState(1);
    const [keysPerPage] = useState(20);
    
    // Comment dialog
    const [commentDialogOpen, setCommentDialogOpen] = useState(false);
    const [selectedKeyReview, setSelectedKeyReview] = useState(null);
    const [comments, setComments] = useState([]);
    const [loadingComments, setLoadingComments] = useState(false);

    // Load all comments data
    useEffect(() => {
        loadAllComments();
    }, []);

    const loadAllComments = async () => {
        setLoading(true);
        try {
            const result = await keyReviewAPI.getAllComments();
            if (result.success) {
                setKeys(result.data.keys || []);
            } else {
                toast.error('Failed to load comments: ' + result.error);
            }
        } catch (error) {
            console.error('Error loading all comments:', error);
            toast.error('Failed to load comments');
        } finally {
            setLoading(false);
        }
    };

    // Extract all unique values for filters
    const allStatuses = useMemo(() => Object.keys(statusColors), []);
    
    const allProjects = useMemo(() => {
        const projects = new Set();
        keys.forEach(key => {
            key.groups?.forEach(group => {
                if (group.project_title) projects.add(group.project_title);
            });
        });
        return Array.from(projects).sort();
    }, [keys]);

    const allGroups = useMemo(() => {
        const groups = new Set();
        keys.forEach(key => {
            key.groups?.forEach(group => {
                if (group.original_group_name) groups.add(group.original_group_name);
            });
        });
        return Array.from(groups).sort();
    }, [keys]);

    const allOwners = useMemo(() => {
        const owners = new Set();
        keys.forEach(key => {
            if (key.work_assignment_owner) owners.add(key.work_assignment_owner);
        });
        return Array.from(owners).sort();
    }, [keys]);

    const allWorkAssignments = useMemo(() => {
        const was = new Set();
        keys.forEach(key => {
            if (key.work_assignment) was.add(key.work_assignment);
        });
        return Array.from(was).sort();
    }, [keys]);

    // Filtered lists for search within filter dialog
    const filteredProjects = useMemo(() => {
        if (!projectSearch) return allProjects;
        return allProjects.filter(p => p.toLowerCase().includes(projectSearch.toLowerCase()));
    }, [allProjects, projectSearch]);

    const filteredGroups = useMemo(() => {
        if (!groupSearch) return allGroups;
        return allGroups.filter(g => g.toLowerCase().includes(groupSearch.toLowerCase()));
    }, [allGroups, groupSearch]);

    const filteredOwners = useMemo(() => {
        if (!ownerSearch) return allOwners;
        return allOwners.filter(o => o.toLowerCase().includes(ownerSearch.toLowerCase()));
    }, [allOwners, ownerSearch]);

    const filteredWorkAssignments = useMemo(() => {
        if (!waSearch) return allWorkAssignments;
        return allWorkAssignments.filter(wa => wa.toLowerCase().includes(waSearch.toLowerCase()));
    }, [allWorkAssignments, waSearch]);

    // Check if any filters are active
    const hasActiveFilters = useMemo(() => {
        return filters.status.length > 0 || 
               filters.project.length > 0 || 
               filters.group.length > 0 || 
               filters.owner.length > 0 || 
               filters.workAssignment.length > 0;
    }, [filters]);

    // Filter handler
    const handleFilterChange = useCallback((filterType, value) => {
        setFilters(prev => {
            const currentValues = prev[filterType];
            const newValues = currentValues.includes(value)
                ? currentValues.filter(v => v !== value)
                : [...currentValues, value];
            return { ...prev, [filterType]: newValues };
        });
    }, []);

    // Select all handler for filters
    const handleSelectAll = useCallback((filterType) => {
        setFilters(prev => {
            let allValues;
            switch (filterType) {
                case 'status':
                    allValues = allStatuses;
                    break;
                case 'project':
                    allValues = allProjects;
                    break;
                case 'group':
                    allValues = allGroups;
                    break;
                case 'owner':
                    allValues = allOwners;
                    break;
                case 'workAssignment':
                    allValues = allWorkAssignments;
                    break;
                default:
                    allValues = [];
            }
            const allSelected = allValues.every(v => prev[filterType].includes(v));
            return { ...prev, [filterType]: allSelected ? [] : [...allValues] };
        });
    }, [allStatuses, allProjects, allGroups, allOwners, allWorkAssignments]);

    // Clear all filters
    const clearFilters = useCallback(() => {
        setFilters({
            status: [],
            project: [],
            group: [],
            owner: [],
            workAssignment: []
        });
    }, []);

    // Filter and sort keys
    const filteredAndSortedKeys = useMemo(() => {
        let filtered = keys;
        
        // Apply search filter
        if (searchTerm) {
            const term = searchTerm.toLowerCase();
            filtered = keys.filter(key => 
                key.key_name.toLowerCase().includes(term) ||
                key.work_assignment?.toLowerCase().includes(term) ||
                key.work_assignment_owner?.toLowerCase().includes(term)
            );
        }
        
        // Apply owner filter
        if (filters.owner.length > 0) {
            filtered = filtered.filter(key => 
                key.work_assignment_owner && filters.owner.includes(key.work_assignment_owner)
            );
        }
        
        // Apply work assignment filter
        if (filters.workAssignment.length > 0) {
            filtered = filtered.filter(key => 
                key.work_assignment && filters.workAssignment.includes(key.work_assignment)
            );
        }
        
        // For status, project, and group filters, we need to filter at the group/model level
        // A key is shown if it has at least one group/model matching the filters
        if (filters.status.length > 0 || filters.project.length > 0 || filters.group.length > 0) {
            filtered = filtered.map(key => {
                const filteredGroups = key.groups.filter(group => {
                    // Project filter
                    if (filters.project.length > 0 && !filters.project.includes(group.project_title)) {
                        return false;
                    }
                    // Group name filter
                    if (filters.group.length > 0 && !filters.group.includes(group.original_group_name)) {
                        return false;
                    }
                    // Status filter - check if any model in group matches
                    if (filters.status.length > 0) {
                        const hasMatchingStatus = group.models.some(model => 
                            filters.status.includes(model.status || 'unreviewed')
                        );
                        if (!hasMatchingStatus) return false;
                    }
                    return true;
                }).map(group => {
                    // If status filter is active, also filter models within group
                    if (filters.status.length > 0) {
                        return {
                            ...group,
                            models: group.models.filter(model => 
                                filters.status.includes(model.status || 'unreviewed')
                            )
                        };
                    }
                    return group;
                }).filter(group => group.models.length > 0);

                return { ...key, groups: filteredGroups };
            }).filter(key => key.groups.length > 0);
        }
        
        // Apply sorting
        filtered = [...filtered].sort((a, b) => {
            let aVal = a[sortBy] || '';
            let bVal = b[sortBy] || '';
            
            if (typeof aVal === 'string') aVal = aVal.toLowerCase();
            if (typeof bVal === 'string') bVal = bVal.toLowerCase();
            
            if (sortDirection === 'asc') {
                return aVal < bVal ? -1 : aVal > bVal ? 1 : 0;
            } else {
                return aVal > bVal ? -1 : aVal < bVal ? 1 : 0;
            }
        });
        
        return filtered;
    }, [keys, searchTerm, sortBy, sortDirection, filters]);

    // Pagination
    const paginatedKeys = useMemo(() => {
        const startIndex = (currentPage - 1) * keysPerPage;
        return filteredAndSortedKeys.slice(startIndex, startIndex + keysPerPage);
    }, [filteredAndSortedKeys, currentPage, keysPerPage]);

    const totalPages = Math.ceil(filteredAndSortedKeys.length / keysPerPage);

    // Toggle handlers
    const toggleKeyExpansion = useCallback((keyId) => {
        setExpandedKeys(prev => ({
            ...prev,
            [keyId]: !prev[keyId]
        }));
    }, []);

    const toggleGroupExpansion = useCallback((keyId, groupKey) => {
        const fullGroupKey = `${keyId}_${groupKey}`;
        setExpandedGroups(prev => ({
            ...prev,
            [fullGroupKey]: !prev[fullGroupKey]
        }));
    }, []);

    // Expand all keys AND all groups within those keys
    const expandAllKeys = useCallback(() => {
        const newExpandedKeys = {};
        const newExpandedGroups = {};
        
        paginatedKeys.forEach(key => {
            newExpandedKeys[key.fms_key_id] = true;
            // Also expand all groups within each key
            key.groups?.forEach((group, idx) => {
                // Use the same key format as used in toggleGroupExpansion and rendering
                const groupKey = `${key.fms_key_id}_${group.project_title}_${group.original_group_name}`;
                newExpandedGroups[groupKey] = true;
            });
        });
        
        setExpandedKeys(newExpandedKeys);
        setExpandedGroups(newExpandedGroups);
    }, [paginatedKeys]);

    // Collapse all keys AND all groups
    const collapseAllKeys = useCallback(() => {
        setExpandedKeys({});
        setExpandedGroups({});
    }, []);

    // Comment dialog
    const handleOpenComments = async (keyReviewId) => {
        setSelectedKeyReview(keyReviewId);
        setCommentDialogOpen(true);
        setLoadingComments(true);
        
        try {
            const result = await commentAPI.getComments(keyReviewId);
            if (result.success) {
                setComments(result.data.comments || []);
            } else {
                toast.error('Failed to load comments');
                setComments([]);
            }
        } catch (error) {
            console.error('Error loading comments:', error);
            setComments([]);
        } finally {
            setLoadingComments(false);
        }
    };

    const handleCloseComments = () => {
        setCommentDialogOpen(false);
        setSelectedKeyReview(null);
        setComments([]);
    };

    // Get status info for styling
    const getStatusInfo = (status) => {
        return statusColors[status] || statusColors['unreviewed'];
    };

    // Handle dialog close with search reset
    const handleDialogClose = () => {
        setFiltersOpen(false);
        setProjectSearch('');
        setGroupSearch('');
        setOwnerSearch('');
        setWaSearch('');
    };

    if (loading) {
        return (
            <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: 300 }}>
                <CircularProgress />
                <Typography sx={{ ml: 2 }}>Loading all comments...</Typography>
            </Box>
        );
    }

    return (
        <Box>
            {/* Header Controls */}
            <Paper sx={{ p: 1.5, mb: 2 }}>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 1.5 }}>
                    <Typography variant="h6" sx={{ fontSize: '0.9rem', fontWeight: 600 }}>
                        All Comments
                    </Typography>
                    <Chip
                        label={`${filteredAndSortedKeys.length} of ${keys.length} keys`}
                        color={filteredAndSortedKeys.length === keys.length ? 'default' : 'primary'}
                        size="small"
                        sx={{ fontSize: '0.7rem', height: 24 }}
                    />
                    {hasActiveFilters && (
                        <Button
                            size="small"
                            startIcon={<Clear sx={{ fontSize: 14 }} />}
                            onClick={clearFilters}
                            sx={{ fontSize: '0.7rem', py: 0.25, px: 1 }}
                        >
                            Clear Filters
                        </Button>
                    )}
                </Box>

                <Box sx={{ display: 'flex', gap: 1.5, flexWrap: 'wrap', alignItems: 'center' }}>
                    {/* Search */}
                    <TextField
                        size="small"
                        placeholder="Search keys by name, work assignment, or owner..."
                        value={searchTerm}
                        onChange={(e) => {
                            setSearchTerm(e.target.value);
                            setCurrentPage(1);
                        }}
                        InputProps={{
                            startAdornment: (
                                <InputAdornment position="start">
                                    <Search sx={{ fontSize: 16 }} />
                                </InputAdornment>
                            ),
                            endAdornment: searchTerm && (
                                <InputAdornment position="end">
                                    <IconButton size="small" onClick={() => setSearchTerm('')}>
                                        <Clear sx={{ fontSize: 16 }} />
                                    </IconButton>
                                </InputAdornment>
                            ),
                            sx: { fontSize: '0.8rem', height: 32 }
                        }}
                        sx={{ minWidth: 250, '& .MuiInputBase-input': { fontSize: '0.8rem', py: 0.5 } }}
                    />

                    {/* Sort */}
                    <FormControl size="small" sx={{ minWidth: 120 }}>
                        <InputLabel sx={{ fontSize: '0.8rem' }}>Sort by</InputLabel>
                        <Select
                            value={sortBy}
                            label="Sort by"
                            onChange={(e) => setSortBy(e.target.value)}
                            sx={{ fontSize: '0.8rem', height: 32 }}
                        >
                            <MenuItem value="key_name" sx={{ fontSize: '0.8rem' }}>Key Name</MenuItem>
                            <MenuItem value="work_assignment" sx={{ fontSize: '0.8rem' }}>Work Assignment</MenuItem>
                            <MenuItem value="work_assignment_owner" sx={{ fontSize: '0.8rem' }}>Owner</MenuItem>
                        </Select>
                    </FormControl>

                    {/* Sort Direction */}
                    <IconButton
                        size="small"
                        onClick={() => setSortDirection(prev => prev === 'asc' ? 'desc' : 'asc')}
                        color="primary"
                        sx={{ p: 0.5 }}
                    >
                        {sortDirection === 'asc' ? <ArrowUp sx={{ fontSize: 18 }} /> : <ArrowDown sx={{ fontSize: 18 }} />}
                    </IconButton>

                    {/* Filters Button */}
                    <Button
                        size="small"
                        startIcon={<FilterList sx={{ fontSize: 14 }} />}
                        onClick={() => setFiltersOpen(true)}
                        variant={hasActiveFilters ? 'contained' : 'outlined'}
                        sx={{ fontSize: '0.7rem', py: 0.25, px: 1.5 }}
                    >
                        Filters
                        {hasActiveFilters && (
                            <Badge
                                color="secondary"
                                badgeContent={
                                    filters.status.length +
                                    filters.project.length +
                                    filters.group.length +
                                    filters.owner.length +
                                    filters.workAssignment.length
                                }
                                sx={{ ml: 0.5 }}
                            />
                        )}
                    </Button>
                </Box>

                {/* Active Filters Display */}
                {hasActiveFilters && (
                    <Box sx={{ mt: 1.5, display: 'flex', gap: 1, flexWrap: 'wrap' }}>
                        {filters.status.map(status => (
                            <Chip
                                key={status}
                                label={`Status: ${statusColors[status]?.label || status}`}
                                size="small"
                                onDelete={() => handleFilterChange('status', status)}
                                color="primary"
                                variant="outlined"
                                sx={{ fontSize: '0.7rem', height: 22 }}
                            />
                        ))}
                        {filters.project.map(project => (
                            <Chip
                                key={project}
                                label={`Project: ${project}`}
                                size="small"
                                onDelete={() => handleFilterChange('project', project)}
                                color="info"
                                variant="outlined"
                                sx={{ fontSize: '0.7rem', height: 22 }}
                            />
                        ))}
                        {filters.group.map(group => (
                            <Chip
                                key={group}
                                label={`Group: ${group}`}
                                size="small"
                                onDelete={() => handleFilterChange('group', group)}
                                color="secondary"
                                variant="outlined"
                                sx={{ fontSize: '0.7rem', height: 22 }}
                            />
                        ))}
                        {filters.owner.map(owner => (
                            <Chip
                                key={owner}
                                label={`Owner: ${owner}`}
                                size="small"
                                onDelete={() => handleFilterChange('owner', owner)}
                                color="warning"
                                variant="outlined"
                                sx={{ fontSize: '0.7rem', height: 22 }}
                            />
                        ))}
                        {filters.workAssignment.map(wa => (
                            <Chip
                                key={wa}
                                label={`WA: ${wa}`}
                                size="small"
                                onDelete={() => handleFilterChange('workAssignment', wa)}
                                color="success"
                                variant="outlined"
                                sx={{ fontSize: '0.7rem', height: 22 }}
                            />
                        ))}
                    </Box>
                )}

                {/* Additional Controls Row - Expand/Collapse */}
                <Box sx={{ display: 'flex', gap: 1.5, flexWrap: 'wrap', alignItems: 'center', mt: 1.5 }}>
                    {/* Expand All / Collapse All Buttons */}
                    <Button
                        size="small"
                        startIcon={<ExpandMore sx={{ fontSize: 14 }} />}
                        onClick={expandAllKeys}
                        variant="outlined"
                        sx={{ fontSize: '0.7rem', py: 0.25, px: 1.5 }}
                    >
                        Expand All
                    </Button>
                    <Button
                        size="small"
                        startIcon={<ExpandLess sx={{ fontSize: 14 }} />}
                        onClick={collapseAllKeys}
                        variant="outlined"
                        sx={{ fontSize: '0.7rem', py: 0.25, px: 1.5 }}
                    >
                        Collapse All
                    </Button>
                </Box>
            </Paper>

            {/* Keys List */}
            {paginatedKeys.length === 0 ? (
                <Paper sx={{ p: 4, textAlign: 'center' }}>
                    <ChatBubbleOutline sx={{ fontSize: 48, color: 'text.disabled', mb: 2 }} />
                    <Typography variant="h6" color="text.secondary">
                        No comments found
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                        {searchTerm || hasActiveFilters ? 'Try adjusting your search or filters' : 'No keys have comments yet'}
                    </Typography>
                </Paper>
            ) : (
                <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1 }}>
                    {paginatedKeys.map((key) => (
                        <Card key={key.fms_key_id} variant="outlined">
                            {/* Key Header */}
                            <Box
                                sx={{
                                    display: 'flex',
                                    alignItems: 'center',
                                    p: 1.5,
                                    cursor: 'pointer',
                                    '&:hover': { bgcolor: 'action.hover' }
                                }}
                                onClick={() => toggleKeyExpansion(key.fms_key_id)}
                            >
                                <IconButton size="small" sx={{ mr: 1 }}>
                                    {expandedKeys[key.fms_key_id] ? <ExpandLess /> : <ExpandMore />}
                                </IconButton>
                                <Key sx={{ fontSize: 18, mr: 1, color: 'primary.main' }} />
                                <Typography variant="subtitle2" sx={{ fontWeight: 600, flex: 1 }}>
                                    {key.key_name}
                                </Typography>
                                <Chip 
                                    size="small" 
                                    label={`${key.groups.length} project${key.groups.length > 1 ? 's' : ''}`}
                                    variant="outlined"
                                    sx={{ mr: 1 }}
                                />
                                {key.work_assignment_owner && (
                                    <Typography variant="caption" color="text.secondary">
                                        Owner: {key.work_assignment_owner}
                                    </Typography>
                                )}
                            </Box>
                            
                            {/* Key Content - Groups */}
                            <Collapse in={expandedKeys[key.fms_key_id]} timeout="auto" unmountOnExit>
                                <CardContent sx={{ pt: 0 }}>
                                    {key.groups.map((group, groupIndex) => {
                                        const groupKey = `${key.fms_key_id}_${group.project_title}_${group.original_group_name}`;
                                        const isGroupExpanded = expandedGroups[groupKey];
                                        
                                        return (
                                            <Box key={groupIndex} sx={{ mb: 1.5 }}>
                                                {/* Group Header */}
                                                <Box
                                                    sx={{
                                                        display: 'flex',
                                                        alignItems: 'center',
                                                        p: 1,
                                                        bgcolor: 'grey.50',
                                                        borderRadius: 1,
                                                        cursor: 'pointer',
                                                        '&:hover': { bgcolor: 'grey.100' }
                                                    }}
                                                    onClick={() => toggleGroupExpansion(key.fms_key_id, `${group.project_title}_${group.original_group_name}`)}
                                                >
                                                    <IconButton size="small" sx={{ mr: 1 }}>
                                                        {isGroupExpanded ? <ExpandLess /> : <ExpandMore />}
                                                    </IconButton>
                                                    <Typography variant="body2" sx={{ fontWeight: 500, color: 'primary.main' }}>
                                                        {group.group_name}
                                                    </Typography>
                                                    <Chip 
                                                        size="small" 
                                                        label={`${group.models.length} model${group.models.length > 1 ? 's' : ''}`}
                                                        sx={{ ml: 'auto', height: 20, fontSize: '0.7rem' }}
                                                    />
                                                </Box>
                                                
                                                {/* Models Table */}
                                                <Collapse in={isGroupExpanded} timeout="auto" unmountOnExit>
                                                    <TableContainer sx={{ mt: 1 }}>
                                                        <Table size="small">
                                                            <TableHead>
                                                                <TableRow sx={{ bgcolor: 'grey.100' }}>
                                                                    <TableCell sx={{ fontWeight: 600, fontSize: '0.75rem' }}>Target</TableCell>
                                                                    <TableCell sx={{ fontWeight: 600, fontSize: '0.75rem' }}>Ref 1</TableCell>
                                                                    {group.comparison_type !== '2-way' && (
                                                                        <TableCell sx={{ fontWeight: 600, fontSize: '0.75rem' }}>Ref 2</TableCell>
                                                                    )}
                                                                    {group.comparison_type === '4-way' && (
                                                                        <TableCell sx={{ fontWeight: 600, fontSize: '0.75rem' }}>Ref 3</TableCell>
                                                                    )}
                                                                    <TableCell sx={{ fontWeight: 600, fontSize: '0.75rem' }}>Status</TableCell>
                                                                    <TableCell sx={{ fontWeight: 600, fontSize: '0.75rem', minWidth: 200 }}>Comment</TableCell>
                                                                </TableRow>
                                                            </TableHead>
                                                            <TableBody>
                                                                {group.models.map((model, modelIndex) => (
                                                                    <TableRow key={modelIndex} hover>
                                                                        <TableCell sx={{ fontSize: '0.75rem' }}>
                                                                            <Tooltip 
                                                                                title={
                                                                                    <Box sx={{ p: 0.5 }}>
                                                                                        <Typography variant="caption" sx={{ fontWeight: 600 }}>Value:</Typography>
                                                                                        <Typography variant="body2" sx={{ whiteSpace: 'pre-wrap', mt: 0.5 }}>
                                                                                            {model.target || 'No value'}
                                                                                        </Typography>
                                                                                    </Box>
                                                                                }
                                                                                arrow
                                                                                placement="top"
                                                                            >
                                                                                <Box sx={{ cursor: 'help' }}>
                                                                                    <Typography variant="caption" sx={{ fontWeight: 500 }}>
                                                                                        {model.target_model_name}
                                                                                    </Typography>
                                                                                    <Typography variant="caption" display="block" color="text.secondary" sx={{ fontSize: '0.65rem' }}>
                                                                                        {model.target_branch_name}
                                                                                    </Typography>
                                                                                </Box>
                                                                            </Tooltip>
                                                                        </TableCell>
                                                                        <TableCell sx={{ fontSize: '0.75rem' }}>
                                                                            <Tooltip 
                                                                                title={
                                                                                    <Box sx={{ p: 0.5 }}>
                                                                                        <Typography variant="caption" sx={{ fontWeight: 600 }}>Value:</Typography>
                                                                                        <Typography variant="body2" sx={{ whiteSpace: 'pre-wrap', mt: 0.5 }}>
                                                                                            {model.ref1 || 'No value'}
                                                                                        </Typography>
                                                                                    </Box>
                                                                                }
                                                                                arrow
                                                                                placement="top"
                                                                            >
                                                                                <Box sx={{ cursor: 'help' }}>
                                                                                    <Typography variant="caption" sx={{ fontWeight: 500 }}>
                                                                                        {model.ref1_model_name}
                                                                                    </Typography>
                                                                                    <Typography variant="caption" display="block" color="text.secondary" sx={{ fontSize: '0.65rem' }}>
                                                                                        {model.ref1_branch_name}
                                                                                    </Typography>
                                                                                </Box>
                                                                            </Tooltip>
                                                                        </TableCell>
                                                                        {group.comparison_type !== '2-way' && (
                                                                            <TableCell sx={{ fontSize: '0.75rem' }}>
                                                                                <Tooltip 
                                                                                    title={
                                                                                        <Box sx={{ p: 0.5 }}>
                                                                                            <Typography variant="caption" sx={{ fontWeight: 600 }}>Value:</Typography>
                                                                                            <Typography variant="body2" sx={{ whiteSpace: 'pre-wrap', mt: 0.5 }}>
                                                                                                {model.ref2 || 'No value'}
                                                                                            </Typography>
                                                                                        </Box>
                                                                                    }
                                                                                    arrow
                                                                                    placement="top"
                                                                                >
                                                                                    <Box sx={{ cursor: 'help' }}>
                                                                                        <Typography variant="caption" sx={{ fontWeight: 500 }}>
                                                                                            {model.ref2_model_name || '-'}
                                                                                        </Typography>
                                                                                        <Typography variant="caption" display="block" color="text.secondary" sx={{ fontSize: '0.65rem' }}>
                                                                                            {model.ref2_branch_name}
                                                                                        </Typography>
                                                                                    </Box>
                                                                                </Tooltip>
                                                                            </TableCell>
                                                                        )}
                                                                        {group.comparison_type === '4-way' && (
                                                                            <TableCell sx={{ fontSize: '0.75rem' }}>
                                                                                <Tooltip 
                                                                                    title={
                                                                                        <Box sx={{ p: 0.5 }}>
                                                                                            <Typography variant="caption" sx={{ fontWeight: 600 }}>Value:</Typography>
                                                                                            <Typography variant="body2" sx={{ whiteSpace: 'pre-wrap', mt: 0.5 }}>
                                                                                                {model.ref3 || 'No value'}
                                                                                            </Typography>
                                                                                        </Box>
                                                                                    }
                                                                                    arrow
                                                                                    placement="top"
                                                                                >
                                                                                    <Box sx={{ cursor: 'help' }}>
                                                                                        <Typography variant="caption" sx={{ fontWeight: 500 }}>
                                                                                            {model.ref3_model_name || '-'}
                                                                                        </Typography>
                                                                                        <Typography variant="caption" display="block" color="text.secondary" sx={{ fontSize: '0.65rem' }}>
                                                                                            {model.ref3_branch_name}
                                                                                        </Typography>
                                                                                    </Box>
                                                                                </Tooltip>
                                                                            </TableCell>
                                                                        )}
                                                                        <TableCell>
                                                                            {(() => {
                                                                                const statusInfo = getStatusInfo(model.status);
                                                                                return (
                                                                                    <Chip
                                                                                        label={statusInfo.label}
                                                                                        size="small"
                                                                                        sx={{ 
                                                                                            fontSize: '0.65rem', 
                                                                                            height: 22,
                                                                                            backgroundColor: statusInfo.color === 'transparent' ? 'transparent' : statusInfo.color,
                                                                                            color: statusInfo.textColor,
                                                                                            border: statusInfo.color === 'transparent' ? '1px solid #ccc' : 'none'
                                                                                        }}
                                                                                    />
                                                                                );
                                                                            })()}
                                                                        </TableCell>
                                                                        <TableCell>
                                                                            <Box 
                                                                                sx={{ 
                                                                                    display: 'flex', 
                                                                                    alignItems: 'center', 
                                                                                    gap: 1,
                                                                                    cursor: 'pointer',
                                                                                    '&:hover': { color: 'primary.main' }
                                                                                }}
                                                                                onClick={() => handleOpenComments(model.key_review_id)}
                                                                            >
                                                                                <ChatBubble sx={{ fontSize: 16, color: 'primary.main' }} />
                                                                                <Typography 
                                                                                    variant="caption" 
                                                                                    sx={{ 
                                                                                        maxWidth: 200,
                                                                                        overflow: 'hidden',
                                                                                        textOverflow: 'ellipsis',
                                                                                        whiteSpace: 'nowrap'
                                                                                    }}
                                                                                >
                                                                                    {model.latest_comment || 'View comments'}
                                                                                </Typography>
                                                                                <Chip 
                                                                                    label={model.comment_count} 
                                                                                    size="small" 
                                                                                    sx={{ height: 18, fontSize: '0.65rem', ml: 'auto' }}
                                                                                />
                                                                            </Box>
                                                                        </TableCell>
                                                                    </TableRow>
                                                                ))}
                                                            </TableBody>
                                                        </Table>
                                                    </TableContainer>
                                                </Collapse>
                                            </Box>
                                        );
                                    })}
                                </CardContent>
                            </Collapse>
                        </Card>
                    ))}
                </Box>
            )}

            {/* Pagination */}
            {totalPages > 1 && (
                <Box sx={{ display: 'flex', justifyContent: 'center', mt: 3 }}>
                    <Pagination
                        count={totalPages}
                        page={currentPage}
                        onChange={(_, page) => setCurrentPage(page)}
                        color="primary"
                        showFirstButton
                        showLastButton
                    />
                </Box>
            )}

            {/* Filters Dialog */}
            <Dialog
                open={filtersOpen}
                onClose={handleDialogClose}
                maxWidth="md"
                fullWidth
            >
                <DialogTitle>Filter Keys</DialogTitle>
                <DialogContent>
                    <Box sx={{ mt: 1 }}>
                        {/* Status Filter */}
                        <Typography variant="subtitle2" gutterBottom>
                            Filter by Status:
                        </Typography>
                        <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                            <FormControlLabel
                                control={
                                    <Checkbox
                                        size="small"
                                        checked={allStatuses.length > 0 && allStatuses.every(status => filters.status.includes(status))}
                                        indeterminate={allStatuses.some(status => filters.status.includes(status)) && !allStatuses.every(status => filters.status.includes(status))}
                                        onChange={() => handleSelectAll('status')}
                                    />
                                }
                                label="Select All"
                            />
                            <Typography variant="caption" sx={{ ml: 1, color: 'text.secondary' }}>
                                ({filters.status.length} of {allStatuses.length} selected)
                            </Typography>
                        </Box>
                        <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap', mb: 3 }}>
                            {Object.entries(statusColors).map(([status, info]) => (
                                <FormControlLabel
                                    key={status}
                                    control={
                                        <Checkbox
                                            size="small"
                                            checked={filters.status.includes(status)}
                                            onChange={() => handleFilterChange('status', status)}
                                        />
                                    }
                                    label={
                                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                                            <Box
                                                sx={{
                                                    width: 12,
                                                    height: 12,
                                                    borderRadius: '50%',
                                                    backgroundColor: info.color === 'transparent' ? 'transparent' : info.color,
                                                    border: info.color === 'transparent' ? '1px solid #999' : 'none'
                                                }}
                                            />
                                            {info.label}
                                        </Box>
                                    }
                                />
                            ))}
                        </Box>

                        {/* Project Filter */}
                        <Typography variant="subtitle2" gutterBottom>
                            Filter by Project:
                        </Typography>
                        <Box sx={{ mb: 2 }}>
                            <TextField
                                size="small"
                                fullWidth
                                placeholder="Search projects..."
                                value={projectSearch}
                                onChange={(e) => setProjectSearch(e.target.value)}
                                InputProps={{
                                    startAdornment: (
                                        <InputAdornment position="start">
                                            <Search sx={{ fontSize: 16 }} />
                                        </InputAdornment>
                                    ),
                                }}
                                sx={{ mb: 1 }}
                            />
                            <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                                <FormControlLabel
                                    control={
                                        <Checkbox
                                            size="small"
                                            checked={allProjects.length > 0 && allProjects.every(p => filters.project.includes(p))}
                                            indeterminate={allProjects.some(p => filters.project.includes(p)) && !allProjects.every(p => filters.project.includes(p))}
                                            onChange={() => handleSelectAll('project')}
                                        />
                                    }
                                    label="Select All"
                                />
                                <Typography variant="caption" sx={{ ml: 1, color: 'text.secondary' }}>
                                    ({filters.project.length} of {allProjects.length} selected)
                                </Typography>
                            </Box>
                            <Box sx={{ maxHeight: 150, overflowY: 'auto', border: '1px solid #e0e0e0', borderRadius: 1, p: 1 }}>
                                {filteredProjects.map(project => (
                                    <FormControlLabel
                                        key={project}
                                        control={
                                            <Checkbox
                                                size="small"
                                                checked={filters.project.includes(project)}
                                                onChange={() => handleFilterChange('project', project)}
                                            />
                                        }
                                        label={project}
                                        sx={{ display: 'block', mb: 0.5 }}
                                    />
                                ))}
                                {filteredProjects.length === 0 && projectSearch && (
                                    <Typography variant="body2" sx={{ p: 1, textAlign: 'center', color: 'text.secondary' }}>
                                        No projects found matching "{projectSearch}"
                                    </Typography>
                                )}
                            </Box>
                        </Box>

                        {/* Group Filter */}
                        <Typography variant="subtitle2" gutterBottom>
                            Filter by Group:
                        </Typography>
                        <Box sx={{ mb: 2 }}>
                            <TextField
                                size="small"
                                fullWidth
                                placeholder="Search groups..."
                                value={groupSearch}
                                onChange={(e) => setGroupSearch(e.target.value)}
                                InputProps={{
                                    startAdornment: (
                                        <InputAdornment position="start">
                                            <Search sx={{ fontSize: 16 }} />
                                        </InputAdornment>
                                    ),
                                }}
                                sx={{ mb: 1 }}
                            />
                            <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                                <FormControlLabel
                                    control={
                                        <Checkbox
                                            size="small"
                                            checked={allGroups.length > 0 && allGroups.every(g => filters.group.includes(g))}
                                            indeterminate={allGroups.some(g => filters.group.includes(g)) && !allGroups.every(g => filters.group.includes(g))}
                                            onChange={() => handleSelectAll('group')}
                                        />
                                    }
                                    label="Select All"
                                />
                                <Typography variant="caption" sx={{ ml: 1, color: 'text.secondary' }}>
                                    ({filters.group.length} of {allGroups.length} selected)
                                </Typography>
                            </Box>
                            <Box sx={{ maxHeight: 150, overflowY: 'auto', border: '1px solid #e0e0e0', borderRadius: 1, p: 1 }}>
                                {filteredGroups.map(group => (
                                    <FormControlLabel
                                        key={group}
                                        control={
                                            <Checkbox
                                                size="small"
                                                checked={filters.group.includes(group)}
                                                onChange={() => handleFilterChange('group', group)}
                                            />
                                        }
                                        label={group}
                                        sx={{ display: 'block', mb: 0.5 }}
                                    />
                                ))}
                                {filteredGroups.length === 0 && groupSearch && (
                                    <Typography variant="body2" sx={{ p: 1, textAlign: 'center', color: 'text.secondary' }}>
                                        No groups found matching "{groupSearch}"
                                    </Typography>
                                )}
                            </Box>
                        </Box>

                        {/* Owner Filter */}
                        <Typography variant="subtitle2" gutterBottom>
                            Filter by Owner:
                        </Typography>
                        <Box sx={{ mb: 2 }}>
                            <TextField
                                size="small"
                                fullWidth
                                placeholder="Search owners..."
                                value={ownerSearch}
                                onChange={(e) => setOwnerSearch(e.target.value)}
                                InputProps={{
                                    startAdornment: (
                                        <InputAdornment position="start">
                                            <Search sx={{ fontSize: 16 }} />
                                        </InputAdornment>
                                    ),
                                }}
                                sx={{ mb: 1 }}
                            />
                            <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                                <FormControlLabel
                                    control={
                                        <Checkbox
                                            size="small"
                                            checked={allOwners.length > 0 && allOwners.every(o => filters.owner.includes(o))}
                                            indeterminate={allOwners.some(o => filters.owner.includes(o)) && !allOwners.every(o => filters.owner.includes(o))}
                                            onChange={() => handleSelectAll('owner')}
                                        />
                                    }
                                    label="Select All"
                                />
                                <Typography variant="caption" sx={{ ml: 1, color: 'text.secondary' }}>
                                    ({filters.owner.length} of {allOwners.length} selected)
                                </Typography>
                            </Box>
                            <Box sx={{ maxHeight: 150, overflowY: 'auto', border: '1px solid #e0e0e0', borderRadius: 1, p: 1 }}>
                                {filteredOwners.map(owner => (
                                    <FormControlLabel
                                        key={owner}
                                        control={
                                            <Checkbox
                                                size="small"
                                                checked={filters.owner.includes(owner)}
                                                onChange={() => handleFilterChange('owner', owner)}
                                            />
                                        }
                                        label={owner}
                                        sx={{ display: 'block', mb: 0.5 }}
                                    />
                                ))}
                                {filteredOwners.length === 0 && ownerSearch && (
                                    <Typography variant="body2" sx={{ p: 1, textAlign: 'center', color: 'text.secondary' }}>
                                        No owners found matching "{ownerSearch}"
                                    </Typography>
                                )}
                            </Box>
                        </Box>

                        {/* Work Assignment Filter */}
                        <Typography variant="subtitle2" gutterBottom>
                            Filter by Work Assignment:
                        </Typography>
                        <Box sx={{ mb: 2 }}>
                            <TextField
                                size="small"
                                fullWidth
                                placeholder="Search work assignments..."
                                value={waSearch}
                                onChange={(e) => setWaSearch(e.target.value)}
                                InputProps={{
                                    startAdornment: (
                                        <InputAdornment position="start">
                                            <Search sx={{ fontSize: 16 }} />
                                        </InputAdornment>
                                    ),
                                }}
                                sx={{ mb: 1 }}
                            />
                            <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                                <FormControlLabel
                                    control={
                                        <Checkbox
                                            size="small"
                                            checked={allWorkAssignments.length > 0 && allWorkAssignments.every(wa => filters.workAssignment.includes(wa))}
                                            indeterminate={allWorkAssignments.some(wa => filters.workAssignment.includes(wa)) && !allWorkAssignments.every(wa => filters.workAssignment.includes(wa))}
                                            onChange={() => handleSelectAll('workAssignment')}
                                        />
                                    }
                                    label="Select All"
                                />
                                <Typography variant="caption" sx={{ ml: 1, color: 'text.secondary' }}>
                                    ({filters.workAssignment.length} of {allWorkAssignments.length} selected)
                                </Typography>
                            </Box>
                            <Box sx={{ maxHeight: 150, overflowY: 'auto', border: '1px solid #e0e0e0', borderRadius: 1, p: 1 }}>
                                {filteredWorkAssignments.map(wa => (
                                    <FormControlLabel
                                        key={wa}
                                        control={
                                            <Checkbox
                                                size="small"
                                                checked={filters.workAssignment.includes(wa)}
                                                onChange={() => handleFilterChange('workAssignment', wa)}
                                            />
                                        }
                                        label={wa}
                                        sx={{ display: 'block', mb: 0.5 }}
                                    />
                                ))}
                                {filteredWorkAssignments.length === 0 && waSearch && (
                                    <Typography variant="body2" sx={{ p: 1, textAlign: 'center', color: 'text.secondary' }}>
                                        No work assignments found matching "{waSearch}"
                                    </Typography>
                                )}
                            </Box>
                        </Box>
                    </Box>
                </DialogContent>
                <DialogActions>
                    <Button onClick={clearFilters} color="secondary">
                        Clear All
                    </Button>
                    <Button onClick={handleDialogClose} variant="contained">
                        Apply
                    </Button>
                </DialogActions>
            </Dialog>

            {/* Comment Dialog (Read-Only) */}
            <Dialog 
                open={commentDialogOpen} 
                onClose={handleCloseComments}
                maxWidth="md"
                fullWidth
            >
                <DialogTitle sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                    <ChatBubble color="primary" />
                    Comments (Read Only)
                </DialogTitle>
                <DialogContent dividers>
                    {loadingComments ? (
                        <Box sx={{ display: 'flex', justifyContent: 'center', p: 3 }}>
                            <CircularProgress size={24} />
                        </Box>
                    ) : comments.length === 0 ? (
                        <Typography color="text.secondary" sx={{ textAlign: 'center', py: 3 }}>
                            No comments found
                        </Typography>
                    ) : (
                        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
                            {comments.map((comment, index) => (
                                <Paper 
                                    key={comment.comment_id || index} 
                                    variant="outlined" 
                                    sx={{ p: 2 }}
                                >
                                    <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
                                        <Typography variant="subtitle2" color="primary">
                                            {comment.commented_by_username || comment.username || 'Unknown User'}
                                        </Typography>
                                        <Typography variant="caption" color="text.secondary">
                                            {comment.created_at ? new Date(comment.created_at).toLocaleString() : ''}
                                        </Typography>
                                    </Box>
                                    <Typography variant="body2" sx={{ whiteSpace: 'pre-wrap' }}>
                                        {comment.comment_text}
                                    </Typography>
                                </Paper>
                            ))}
                        </Box>
                    )}
                </DialogContent>
                <DialogActions>
                    <Button onClick={handleCloseComments}>Close</Button>
                </DialogActions>
            </Dialog>
        </Box>
    );
};

export default AllComments;
