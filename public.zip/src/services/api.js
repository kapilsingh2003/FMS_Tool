import axios from 'axios';

// Create axios instance with base configuration
const api = axios.create({
    baseURL: 'http://localhost:5000',
    timeout: 10000,
    headers: {
        'Content-Type': 'application/json',
    },
});

// Request interceptor for adding auth headers
api.interceptors.request.use(
    (config) => {
        // Add auth token from localStorage if available
        const token = localStorage.getItem('token');
        if (token) {
            config.headers.Authorization = `Bearer ${token}`;
        }
        return config;
    },
    (error) => {
        return Promise.reject(error);
    }
);

// Response interceptor for error handling
api.interceptors.response.use(
    (response) => {
        return response;
    },
    (error) => {
        console.error('API Error:', error.response?.data || error.message);

        // Handle authentication errors
        if (error.response?.status === 401) {
            console.warn('Authentication failed on:', error.config?.url);

            // Clear stored token and user data
            localStorage.removeItem('token');
            // Clear cookies too  
            document.cookie = 'user=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;';

            // Only redirect if we're not already on auth pages
            if (window.location.pathname !== '/login' && window.location.pathname !== '/signup') {
                console.warn('Redirecting to login due to authentication failure');
                window.location.href = '/login';
            }
        }

        return Promise.reject(error);
    }
);

// Auth API
export const authAPI = {
    login: async (username, password) => {
        try {
            const response = await api.post('/api/auth/login', { username, password });
            return { success: true, data: response.data };
        } catch (error) {
            return {
                success: false,
                error: error.response?.data?.message || 'Login failed'
            };
        }
    },

    signup: async (userData) => {
        try {
            const response = await api.post('/api/auth/signup', userData);
            return { success: true, data: response.data };
        } catch (error) {
            return {
                success: false,
                error: error.response?.data?.message || 'Signup failed'
            };
        }
    },

    sendOtp: async (knoxId) => {
        try {
            const response = await api.post('/api/auth/send-otp', { knoxId });
            return { success: true, data: response.data };
        } catch (error) {
            return {
                success: false,
                error: error.response?.data?.message || 'Failed to send OTP'
            };
        }
    },

    verifyOtp: async (knoxId, otp) => {
        try {
            const response = await api.post('/api/auth/verify-otp', { knoxId, otp });
            return { success: true, data: response.data };
        } catch (error) {
            return {
                success: false,
                error: error.response?.data?.message || 'OTP verification failed'
            };
        }
    },

    getCurrentUser: async () => {
        try {
            const response = await api.get('/api/auth/me');
            return { success: true, data: response.data };
        } catch (error) {
            return {
                success: false,
                error: error.response?.data?.message || 'Failed to get user info'
            };
        }
    }
};

// Projects API
export const projectsAPI = {
    getAllProjects: async () => {
        try {
            const response = await api.get('/api/projects');
            return { success: true, data: response.data };
        } catch (error) {
            return { success: false, error: error.response?.data?.message || error.message };
        }
    },

    getProject: async (projectId) => {
        try {
            const response = await api.get(`/api/projects/${projectId}`);
            return { success: true, data: response.data };
        } catch (error) {
            return { success: false, error: error.response?.data?.message || error.message };
        }
    },

    createProject: async (projectData) => {
        try {
            const response = await api.post('/api/projects', projectData);
            return { success: true, data: response.data };
        } catch (error) {
            return { success: false, error: error.response?.data?.message || error.message };
        }
    },

    updateProject: async (projectId, projectData) => {
        try {
            const response = await api.put(`/api/projects/${projectId}`, projectData);
            return { success: true, data: response.data };
        } catch (error) {
            return { success: false, error: error.response?.data?.message || error.message };
        }
    },

    deleteProject: async (projectId) => {
        try {
            const response = await api.delete(`/api/projects/${projectId}`);
            return { success: true, data: response.data };
        } catch (error) {
            return { success: false, error: error.response?.data?.message || error.message };
        }
    },

    getProjectGroups: async (projectId) => {
        try {
            const response = await api.get(`/api/projects/${projectId}/groups`);
            return { success: true, data: response.data };
        } catch (error) {
            return { success: false, error: error.response?.data?.message || error.message };
        }
    },

    createGroup: async (projectId, groupData) => {
        try {
            const response = await api.post(`/api/projects/${projectId}/groups`, groupData);
            return { success: true, data: response.data };
        } catch (error) {
            return { success: false, error: error.response?.data?.message || error.message };
        }
    },

    getProjectReviews: async (projectId) => {
        try {
            const response = await api.get(`/api/projects/${projectId}/reviews`);
            return { success: true, data: response.data };
        } catch (error) {
            return { success: false, error: error.response?.data?.message || error.message };
        }
    },

    getProjectStats: async (projectId) => {
        try {
            const response = await api.get(`/api/projects/${projectId}/stats`);
            return { success: true, data: response.data };
        } catch (error) {
            return { success: false, error: error.response?.data?.message || error.message };
        }
    },

    addParticipant: async (projectId, username, role) => {
        try {
            const response = await api.post(`/api/projects/${projectId}/participants`, { username, role });
            return { success: true, data: response.data };
        } catch (error) {
            return { success: false, error: error.response?.data?.message || error.message };
        }
    },

    removeParticipant: async (projectId, username) => {
        try {
            const response = await api.delete(`/api/projects/${projectId}/participants/${username}`);
            return { success: true, data: response.data };
        } catch (error) {
            return { success: false, error: error.response?.data?.message || error.message };
        }
    }
};

// Reference API
export const referenceAPI = {
    getModels: async () => {
        try {
            const response = await api.get('/api/reference/models');
            return { success: true, data: response.data };
        } catch (error) {
            return {
                success: false,
                error: error.response?.data?.message || 'Failed to fetch models'
            };
        }
    },

    getBranches: async () => {
        try {
            const response = await api.get('/api/reference/branches');
            return { success: true, data: response.data };
        } catch (error) {
            return {
                success: false,
                error: error.response?.data?.message || 'Failed to fetch branches'
            };
        }
    },

    searchBranches: async (searchTerm) => {
        try {
            const response = await api.get(`/api/reference/branches/search?q=${encodeURIComponent(searchTerm)}`);
            return { success: true, data: response.data };
        } catch (error) {
            return {
                success: false,
                error: error.response?.data?.message || 'Failed to search branches'
            };
        }
    },

    searchModels: async (searchTerm) => {
        try {
            const response = await api.get(`/api/reference/models/search?q=${encodeURIComponent(searchTerm)}`);
            return { success: true, data: response.data };
        } catch (error) {
            return {
                success: false,
                error: error.response?.data?.message || 'Failed to search models'
            };
        }
    },

    getModelsInBranch: async (branchId) => {
        try {
            const response = await api.get(`/api/reference/models/branch/${branchId}`);
            return { success: true, data: response.data };
        } catch (error) {
            return {
                success: false,
                error: error.response?.data?.message || 'Failed to fetch models for branch'
            };
        }
    },

    validateBranchModel: async (branchId, modelId) => {
        try {
            const response = await api.post('/api/reference/validate-branch-model', { branchId, modelId });
            return { success: true, data: response.data };
        } catch (error) {
            return {
                success: false,
                error: error.response?.data?.message || 'Failed to validate branch-model compatibility'
            };
        }
    },

    getFMSKeys: async (withDifferences = false) => {
        try {
            const url = withDifferences ? '/api/reference/fms-keys?with_differences=true' : '/api/reference/fms-keys';
            const response = await api.get(url);
            return { success: true, data: response.data };
        } catch (error) {
            return {
                success: false,
                error: error.response?.data?.message || 'Failed to fetch FMS keys'
            };
        }
    },

    getWorkAssignments: async () => {
        try {
            const response = await api.get('/api/reference/work-assignments');
            return { success: true, data: response.data };
        } catch (error) {
            return {
                success: false,
                error: error.response?.data?.message || 'Failed to fetch work assignments'
            };
        }
    },

    getAvailableModelsForGroup: async (groupId) => {
        try {
            const response = await api.get(`/api/reference/group/${groupId}/available-models`);
            return { success: true, data: response.data };
        } catch (error) {
            return {
                success: false,
                error: error.response?.data?.message || 'Failed to fetch available models for group'
            };
        }
    }
};

// Users API (Admin only)
export const usersAPI = {
    getAllUsers: async () => {
        try {
            const response = await api.get('/api/users');
            return { success: true, data: response.data };
        } catch (error) {
            return { success: false, error: error.response?.data?.message || error.message };
        }
    },

    getUser: async (username) => {
        try {
            const response = await api.get(`/api/users/${username}`);
            return { success: true, data: response.data };
        } catch (error) {
            return { success: false, error: error.response?.data?.message || error.message };
        }
    },

    updateUser: async (username, userData) => {
        try {
            const response = await api.put(`/api/users/${username}`, userData);
            return { success: true, data: response.data };
        } catch (error) {
            return { success: false, error: error.response?.data?.message || error.message };
        }
    },

    deleteUser: async (username) => {
        try {
            const response = await api.delete(`/api/users/${username}`);
            return { success: true, data: response.data };
        } catch (error) {
            return { success: false, error: error.response?.data?.message || error.message };
        }
    },

    addUserToProject: async (username, projectId) => {
        try {
            const response = await api.post(`/api/users/${username}/projects/${projectId}`);
            return { success: true, data: response.data };
        } catch (error) {
            return { success: false, error: error.response?.data?.message || error.message };
        }
    },

    removeUserFromProject: async (username, projectId) => {
        try {
            const response = await api.delete(`/api/users/${username}/projects/${projectId}`);
            return { success: true, data: response.data };
        } catch (error) {
            return { success: false, error: error.response?.data?.message || error.message };
        }
    },

    getUserProjects: async (username) => {
        try {
            const response = await api.get(`/api/users/${username}/projects`);
            return { success: true, data: response.data };
        } catch (error) {
            return { success: false, error: error.response?.data?.message || error.message };
        }
    }
};

// Key Review API
export const keyReviewAPI = {
    getProjectReviews: async (projectId) => {
        try {
            const response = await api.get(`/api/keyreviews/project/${projectId}`);
            return { success: true, data: response.data };
        } catch (error) {
            return { success: false, error: error.response?.data?.message || error.message };
        }
    },

    getGroupReviews: async (groupId) => {
        try {
            const response = await api.get(`/api/keyreviews/group/${groupId}`);
            return { success: true, data: response.data };
        } catch (error) {
            return { success: false, error: error.response?.data?.message || error.message };
        }
    },

    createOrUpdateReview: async (reviewData) => {
        try {
            const response = await api.post('/api/keyreviews', reviewData);
            return { success: true, data: response.data };
        } catch (error) {
            return { success: false, error: error.response?.data?.message || error.message };
        }
    },

    updateReviewStatus: async (reviewId, status) => {
        try {
            const response = await api.put(`/api/keyreviews/${reviewId}/status`, { status });
            return { success: true, data: response.data };
        } catch (error) {
            return { success: false, error: error.response?.data?.message || error.message };
        }
    },

    updateReviewValues: async (reviewId, values) => {
        try {
            const response = await api.put(`/api/keyreviews/${reviewId}/values`, values);
            return { success: true, data: response.data };
        } catch (error) {
            return { success: false, error: error.response?.data?.message || error.message };
        }
    },

    updateReviewComment: async (reviewId, comment) => {
        try {
            const response = await api.put(`/api/keyreviews/${reviewId}/comment`, { comment });
            return { success: true, data: response.data };
        } catch (error) {
            return { success: false, error: error.response?.data?.message || error.message };
        }
    },

    updateKonaIds: async (reviewId, kona_ids) => {
        try {
            const response = await api.put(`/api/keyreviews/${reviewId}/kona`, { kona_ids });
            return { success: true, data: response.data };
        } catch (error) {
            return { success: false, error: error.response?.data?.message || error.message };
        }
    },

    updateClNumbers: async (reviewId, cl_numbers) => {
        try {
            const response = await api.put(`/api/keyreviews/${reviewId}/cl`, { cl_numbers });
            return { success: true, data: response.data };
        } catch (error) {
            return { success: false, error: error.response?.data?.message || error.message };
        }
    },

    getProjectStats: async (projectId) => {
        try {
            const response = await api.get(`/api/keyreviews/project/${projectId}/stats`);
            return { success: true, data: response.data };
        } catch (error) {
            return { success: false, error: error.response?.data?.message || error.message };
        }
    },

    getRecentActivity: async (projectId, limit = 10) => {
        try {
            const response = await api.get(`/api/keyreviews/project/${projectId}/activity?limit=${limit}`);
            return { success: true, data: response.data };
        } catch (error) {
            return { success: false, error: error.response?.data?.message || error.message };
        }
    },

    deleteReview: async (reviewId) => {
        try {
            const response = await api.delete(`/api/keyreviews/${reviewId}`);
            return { success: true, data: response.data };
        } catch (error) {
            return { success: false, error: error.response?.data?.message || error.message };
        }
    }
};

export default api; 