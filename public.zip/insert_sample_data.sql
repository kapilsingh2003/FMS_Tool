-- Samsung FMS Portal - Sample Data Insertion
-- Insert reference data and sample records for testing

USE samsung_fms_portal;

-- Insert sample users (Knox ID based)
INSERT INTO `Users` (username, name, password, role, email, team, is_verified) VALUES
('admin.john', 'John Kim', '$2b$10$GI0dXfMUox4yyBtmt2Qgm.RBQ1X6pyRp29SEYJNmfaa0oj/CxUHSG', 'admin', 'admin.john@samsung.com', 'ENT_SM', TRUE),
('reviewer.sarah', 'Sarah Lee', '$2b$10$GI0dXfMUox4yyBtmt2Qgm.RBQ1X6pyRp29SEYJNmfaa0oj/CxUHSG', 'reviewer', 'reviewer.sarah@samsung.com', 'CTV', TRUE),
('reviewer.mike', 'Mike Johnson', '$2b$10$GI0dXfMUox4yyBtmt2Qgm.RBQ1X6pyRp29SEYJNmfaa0oj/CxUHSG', 'reviewer', 'reviewer.mike@samsung.com', 'ENT_TV', TRUE),
('viewer.anna', 'Anna Park', '$2b$10$GI0dXfMUox4yyBtmt2Qgm.RBQ1X6pyRp29SEYJNmfaa0oj/CxUHSG', 'viewer', 'viewer.anna@samsung.com', 'ENT_SM', TRUE),
('admin.david', 'David Chen', '$2b$10$GI0dXfMUox4yyBtmt2Qgm.RBQ1X6pyRp29SEYJNmfaa0oj/CxUHSG', 'admin', 'admin.david@samsung.com', 'CTV', TRUE);

-- Insert sample projects
INSERT INTO `Projects` (title, description, admin_username, refresh_schedule, status) VALUES
('25to23.24 SM BizTV OSU', 'Comprehensive review of FMS keys for 25to24.23Y Smart Monitor and BizTV lineup', 'admin.john', 'Daily', 'active');

-- Insert project participants
INSERT INTO `Project_Participants` (project_id, user_username, added_by, participant_role) VALUES
(1, 'admin.john', 'admin.john', 'admin'),
(1, 'reviewer.sarah', 'admin.john', 'reviewer'),
(1, 'reviewer.mike', 'admin.john', 'reviewer'),
(1, 'viewer.anna', 'admin.john', 'viewer');


-- Insert sample groups
INSERT INTO `Grps` (project_id, name, comparison_type, target_branch_id, ref1_branch_id, ref2_branch_id, ref3_branch_id) VALUES
(1, '25to23Y SM OSU 2-Way', '2-way', 1, 26, NULL, NULL),
(1, '25to23Y SM OSU 3-Way', '3-way', 26, 20, 29, NULL),
(1, '25to23Y BizTV OSU 4-Way', '4-way', 26, 1, 21, 33);


-- Insert group-branch-model mappings (specific models used in each group)
INSERT INTO `Group_Model_Mapping` (group_id, target_model_id, ref1_model_id, ref2_model_id, ref3_model_id) VALUES
(1, 133, 133, NULL, NULL),
(1, 287, 287, NULL, NULL),
(1, 132, 132, NULL, NULL),
(2, 231, 231, 159, NULL),
(2, 218, 218, 159, NULL),
(2, 219, 219, 159, NULL),
(2, 140, 140, 159, NULL),
(3, 263, 263, 263, 9),
(3, 262, 262, 262, 9),
(3, 132, 132, 132, 9);

-- Insert sample key reviews with the new structure
INSERT INTO `Key_Reviews` (fms_key_id, gm_id, group_id, target_val, ref1_val, ref2_val, ref3_val, comment, status, kona_ids, cl_numbers, reviewed_by_username) VALUES

-- Group 1: 2-way comparison (M80D vs M80D, M70D vs M70D, G70D vs G70D)
(70, 1, 1, 'True', 'True', NULL, NULL, 'M80D vs M80D - both support white balance', 'no_change_req', 'RQ250701-0001', '1981001', 'reviewer.sarah'),
(70, 2, 1, 'True', 'True', NULL, NULL, 'M70D vs M70D - both support white balance', 'no_change_req', 'RQ250701-0002', '1981002', 'reviewer.mike'),
(70, 3, 1, 'False', 'False', NULL, NULL, 'G70D vs G70D - neither supports white balance', 'no_change_req', 'RQ250701-0003', '1981003', 'reviewer.sarah'),

(296, 1, 1, 'True', 'True', NULL, NULL, 'M80D vs M80D - both support 360 audio', 'no_change_req', 'RQ250701-0004', '1981004', 'reviewer.mike'),
(296, 2, 1, 'False', 'False', NULL, NULL, 'M70D vs M70D - neither supports 360 audio', 'no_change_req', 'RQ250701-0005', '1981005', 'reviewer.sarah'),
(296, 3, 1, 'True', 'True', NULL, NULL, 'G70D vs G70D - both support 360 audio', 'no_change_req', 'RQ250701-0006', '1981006', 'reviewer.mike'),

-- Group 2: 3-way comparison (G97NC vs G97NC vs M80F, S90PC vs S90PC vs M80F, G95SC vs G95SC vs M80F, M70C vs M70C vs M80F)
(103, 4, 2, 'True', 'True', 'False', NULL, 'G97NC vs G97NC vs M80F - target and ref1 support color mode', 'changes_made', 'RQ250701-0007', '1981007', 'reviewer.sarah'),
(103, 5, 2, 'False', 'False', 'True', NULL, 'S90PC vs S90PC vs M80F - only ref2 supports color mode', 'changes_made', 'RQ250701-0008', '1981008', 'reviewer.mike'),
(103, 6, 2, 'True', 'True', 'True', NULL, 'G95SC vs G95SC vs M80F - all support color mode', 'no_change_req', 'RQ250701-0009', '1981009', 'reviewer.sarah'),
(103, 7, 2, 'False', 'False', 'False', NULL, 'M70C vs M70C vs M80F - none support color mode', 'no_change_req', 'RQ250701-0010', '1981010', 'reviewer.mike'),

-- Group 3: 4-way comparison (BED_H vs BED_H vs BED_H vs BEFX_H2, BED_HA vs BED_HA vs BED_HA vs BEFX_H2, G70D vs G70D vs G70D vs BEFX_H2)
(510, 8, 3, 'True', 'True', 'True', 'False', 'BED_H vs BED_H vs BED_H vs BEFX_H2 - first three support PC mode', 'internal_discussion', 'RQ250701-0011', '1981011', 'reviewer.sarah'),
(510, 9, 3, 'False', 'False', 'False', 'True', 'BED_HA vs BED_HA vs BED_HA vs BEFX_H2 - only ref3 supports PC mode', 'changes_made', 'RQ250701-0012', '1981012', 'reviewer.mike'),
(510, 10, 3, 'True', 'True', 'True', 'True', 'G70D vs G70D vs G70D vs BEFX_H2 - all support PC mode', 'no_change_req', 'RQ250701-0013', '1981013', 'reviewer.sarah');

-- Display success message
SELECT 'Sample data inserted successfully!' as Status;
SELECT 'Database is ready for testing!' as Message;
SELECT COUNT(*) as 'Total Key Reviews' FROM Key_Reviews;
