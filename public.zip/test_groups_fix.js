// Test script to verify all groups -> grps fixes are working
const { executeQuery } = require('./backend/config/database');
const Group = require('./backend/models/Group');
const Project = require('./backend/models/Project');

async function testGroupsFix() {
    try {
        console.log('=== Testing Groups -> grps Fix ===');

        // Test 1: Direct table access
        console.log('1. Testing direct grps table access...');
        const groupsCount = await executeQuery('SELECT COUNT(*) as count FROM grps');
        console.log('✅ grps table accessible:', groupsCount[0].count, 'groups found');

        // Test 2: Group model methods
        console.log('\n2. Testing Group model methods...');

        // Test getByProject
        const projects = await executeQuery('SELECT project_id FROM Projects LIMIT 1');
        if (projects.length > 0) {
            const projectId = projects[0].project_id;
            const groups = await Group.getByProject(projectId);
            console.log('✅ Group.getByProject works:', groups.length, 'groups found for project', projectId);

            if (groups.length > 0) {
                const groupId = groups[0].group_id;

                // Test getBranches
                const branches = await Group.getBranches(groupId);
                console.log('✅ Group.getBranches works:', branches.length, 'branches found for group', groupId);

                // Test getModels
                const models = await Group.getModels(groupId);
                console.log('✅ Group.getModels works:', models.length, 'models found for group', groupId);
            }
        }

        // Test 3: Project model getGroups
        console.log('\n3. Testing Project.getGroups...');
        if (projects.length > 0) {
            const projectId = projects[0].project_id;
            const projectGroups = await Project.getGroups(projectId);
            console.log('✅ Project.getGroups works:', projectGroups.length, 'groups with branch config found');

            if (projectGroups.length > 0) {
                const firstGroup = projectGroups[0];
                console.log('✅ First group details:', {
                    name: firstGroup.name,
                    comparison_type: firstGroup.comparison_type,
                    has_branchConfig: !!firstGroup.branchConfig,
                    branchConfig: firstGroup.branchConfig
                });
            }
        }

        // Test 4: Check for any remaining groups table references
        console.log('\n4. Checking for remaining groups table references...');
        try {
            await executeQuery('SELECT COUNT(*) as count FROM groups');
            console.log('❌ groups table still exists - this might cause conflicts');
        } catch (error) {
            console.log('✅ groups table does not exist - good!');
        }

        console.log('\n✅ All groups -> grps fixes working correctly!');

    } catch (error) {
        console.error('❌ Groups fix test failed:', error.message);
        console.error('Error details:', error);
    }

    process.exit(0);
}

testGroupsFix();
