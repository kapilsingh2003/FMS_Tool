-- Add "unreviewed" status to existing Key_Reviews table

USE samsung_fms_portal;

-- Step 1: Add the new status option to the ENUM
ALTER TABLE `Key_Reviews` 
MODIFY COLUMN status ENUM('unreviewed', 'pending', 'reviewed', 'needs_discussion', 'dev_response') DEFAULT 'unreviewed';

-- Step 2: Update existing records that have NULL status to 'unreviewed'
UPDATE `Key_Reviews` SET status = 'unreviewed' WHERE status IS NULL;

-- Step 3: Display success message
SELECT '✅ Successfully added "unreviewed" status to Key_Reviews table!' as Status;
SELECT 'Current status distribution:' as Info;
SELECT status, COUNT(*) as count FROM `Key_Reviews` GROUP BY status;
